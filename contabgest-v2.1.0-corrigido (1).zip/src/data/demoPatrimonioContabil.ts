import {
  BemPatrimonial,
  CentroCusto,
  ContaContabil,
  ClassificacaoAtivo,
  BalancoPatrimonialData,
  DreData,
  DfcData,
  IndicadoresContabeis,
} from '../types';

// Tabela Oficial de Parâmetros de Depreciação (SRF / CPC 27)
export interface ParametroClassificacao {
  classificacao: ClassificacaoAtivo;
  nome: string;
  taxaAnual: number; // %
  vidaUtilAnos: number;
  contaAtivoCusto: string;
  contaDepreciacaoAcumulada: string;
  contaDespesaDepreciacao: string;
  sugestaoResidualPercentual: number;
}

export const TABELA_PARAMETROS_ATIVO: Record<ClassificacaoAtivo, ParametroClassificacao> = {
  computadores_ti: {
    classificacao: 'computadores_ti',
    nome: 'Computadores e Periféricos de TI',
    taxaAnual: 20.0,
    vidaUtilAnos: 5,
    contaAtivoCusto: '1.2.03.003 - Equipamentos de Processamento de Dados',
    contaDepreciacaoAcumulada: '1.2.03.093 - (-) Deprec. Acum. Equip. TI',
    contaDespesaDepreciacao: '5.1.03.015 - Despesas com Depreciação - TI',
    sugestaoResidualPercentual: 10,
  },
  veiculos: {
    classificacao: 'veiculos',
    nome: 'Veículos e Meios de Transporte',
    taxaAnual: 20.0,
    vidaUtilAnos: 5,
    contaAtivoCusto: '1.2.03.004 - Veículos Automotores',
    contaDepreciacaoAcumulada: '1.2.03.094 - (-) Deprec. Acum. Veículos',
    contaDespesaDepreciacao: '5.1.03.016 - Despesas com Depreciação - Veículos',
    sugestaoResidualPercentual: 20,
  },
  maquinas_equipamentos: {
    classificacao: 'maquinas_equipamentos',
    nome: 'Máquinas, Aparelhos e Equipamentos',
    taxaAnual: 10.0,
    vidaUtilAnos: 10,
    contaAtivoCusto: '1.2.03.001 - Máquinas e Equipamentos Industriais',
    contaDepreciacaoAcumulada: '1.2.03.091 - (-) Deprec. Acum. Máquinas',
    contaDespesaDepreciacao: '5.1.03.013 - Despesas com Depreciação - Máquinas',
    sugestaoResidualPercentual: 10,
  },
  moveis_utensilios: {
    classificacao: 'moveis_utensilios',
    nome: 'Móveis, Utensílios e Instalações Comerciais',
    taxaAnual: 10.0,
    vidaUtilAnos: 10,
    contaAtivoCusto: '1.2.03.002 - Móveis e Utensílios',
    contaDepreciacaoAcumulada: '1.2.03.092 - (-) Deprec. Acum. Móveis e Utens.',
    contaDespesaDepreciacao: '5.1.03.014 - Despesas com Depreciação - Móveis',
    sugestaoResidualPercentual: 10,
  },
  edificacoes: {
    classificacao: 'edificacoes',
    nome: 'Edificações e Construções Civis',
    taxaAnual: 4.0,
    vidaUtilAnos: 25,
    contaAtivoCusto: '1.2.03.005 - Edifícios e Prédios Comerciais',
    contaDepreciacaoAcumulada: '1.2.03.095 - (-) Deprec. Acum. Edificações',
    contaDespesaDepreciacao: '5.1.03.017 - Despesas com Depreciação - Edificações',
    sugestaoResidualPercentual: 20,
  },
  instalacoes: {
    classificacao: 'instalacoes',
    nome: 'Instalações Elétricas e Hidráulicas Industriais',
    taxaAnual: 10.0,
    vidaUtilAnos: 10,
    contaAtivoCusto: '1.2.03.006 - Instalações Gerais',
    contaDepreciacaoAcumulada: '1.2.03.096 - (-) Deprec. Acum. Instalações',
    contaDespesaDepreciacao: '5.1.03.018 - Despesas com Depreciação - Instalações',
    sugestaoResidualPercentual: 5,
  },
  benfeitorias: {
    classificacao: 'benfeitorias',
    nome: 'Benfeitorias em Imóveis de Terceiros',
    taxaAnual: 10.0,
    vidaUtilAnos: 10,
    contaAtivoCusto: '1.2.03.007 - Benfeitorias em Propriedades Arrendadas',
    contaDepreciacaoAcumulada: '1.2.03.097 - (-) Amortiz. Acum. Benfeitorias',
    contaDespesaDepreciacao: '5.1.03.019 - Despesas com Amortização - Benfeitorias',
    sugestaoResidualPercentual: 0,
  },
  ferramentas: {
    classificacao: 'ferramentas',
    nome: 'Ferramentas e Moldes de Precisão',
    taxaAnual: 20.0,
    vidaUtilAnos: 5,
    contaAtivoCusto: '1.2.03.008 - Ferramentas e Utensílios de Uso Contínuo',
    contaDepreciacaoAcumulada: '1.2.03.098 - (-) Deprec. Acum. Ferramentas',
    contaDespesaDepreciacao: '5.1.03.020 - Despesas com Depreciação - Ferramentas',
    sugestaoResidualPercentual: 5,
  },
  outros: {
    classificacao: 'outros',
    nome: 'Outros Ativos Imobilizados',
    taxaAnual: 10.0,
    vidaUtilAnos: 10,
    contaAtivoCusto: '1.2.03.099 - Outros Bens do Ativo Imobilizado',
    contaDepreciacaoAcumulada: '1.2.03.099 - (-) Outras Depreciações Acumuladas',
    contaDespesaDepreciacao: '5.1.03.021 - Outras Depreciações',
    sugestaoResidualPercentual: 10,
  },
};

// Centros de Custo Padrão
export const CENTROS_CUSTO_DEMO: CentroCusto[] = [
  {
    id: 'cc-01',
    empresaId: '1',
    codigo: '01.01',
    nome: 'Administrativo & Diretoria Executiva',
    responsavel: 'Carlos Alberto Mendes',
    orcamentoMensal: 45000,
    totalBensAlocados: 8,
    valorPatrimonioTotal: 125000,
  },
  {
    id: 'cc-02',
    empresaId: '1',
    codigo: '02.01',
    nome: 'Operações & Parque Fabril',
    responsavel: 'Marcos Vinicius Santos',
    orcamentoMensal: 120000,
    totalBensAlocados: 14,
    valorPatrimonioTotal: 480000,
  },
  {
    id: 'cc-03',
    empresaId: '1',
    codigo: '03.01',
    nome: 'Tecnologia da Informação & Servidores',
    responsavel: 'Lucas Gabriel Silveira',
    orcamentoMensal: 35000,
    totalBensAlocados: 12,
    valorPatrimonioTotal: 185000,
  },
  {
    id: 'cc-04',
    empresaId: '1',
    codigo: '04.01',
    nome: 'Comercial, Marketing & Vendas',
    responsavel: 'Juliana Paes Ferreira',
    orcamentoMensal: 28000,
    totalBensAlocados: 6,
    valorPatrimonioTotal: 92000,
  },
  {
    id: 'cc-05',
    empresaId: '1',
    codigo: '05.01',
    nome: 'Logística, Entrega & Frotas',
    responsavel: 'Roberto Dias Rocha',
    orcamentoMensal: 60000,
    totalBensAlocados: 5,
    valorPatrimonioTotal: 340000,
  },
];

// Cálculo automático de depreciação mensal e acumulada
export function calcularDepreciacaoBem(
  valorAquisicao: number,
  valorResidualPercentual: number,
  taxaAnual: number,
  dataAquisicao: string,
  dataReferencia: string = '2026-09-30',
  agio: number = 0,
  desagio: number = 0
): {
  valorResidual: number;
  valorDepreciavel: number;
  depreciacaoMensal: number;
  mesesDepreciados: number;
  depreciacaoAcumulada: number;
  valorContabilLiquido: number;
} {
  const valorResidual = Number(((valorAquisicao * valorResidualPercentual) / 100).toFixed(2));
  const valorDepreciavel = Math.max(0, valorAquisicao - valorResidual);
  const taxaMensal = taxaAnual / 12 / 100;
  const depreciacaoMensal = Number((valorDepreciavel * taxaMensal).toFixed(2));

  // Cálculo de meses decorridos
  const dtInicio = new Date(dataAquisicao);
  const dtFim = new Date(dataReferencia);
  const diffAnos = dtFim.getFullYear() - dtInicio.getFullYear();
  const diffMeses = dtFim.getMonth() - dtInicio.getMonth();
  let meses = Math.max(0, diffAnos * 12 + diffMeses);

  // Depreciação não pode ultrapassar o valor depreciável
  const depreciacaoAcumulada = Number(Math.min(valorDepreciavel, meses * depreciacaoMensal).toFixed(2));
  
  // Valor contábil líquido = Custo de Aquisição - Depreciação Acumulada + Ágio - Deságio
  const valorContabilLiquido = Number(
    Math.max(0, valorAquisicao - depreciacaoAcumulada + (agio || 0) - (desagio || 0)).toFixed(2)
  );

  return {
    valorResidual,
    valorDepreciavel,
    depreciacaoMensal,
    mesesDepreciados: meses,
    depreciacaoAcumulada,
    valorContabilLiquido,
  };
}

// Bens Patrimoniais de Demonstração
export const BENS_PATRIMONIAIS_DEMO: BemPatrimonial[] = [
  {
    id: 'bem-001',
    empresaId: '1',
    numeroPatrimonio: 'PAT-00101',
    placaIdentificacao: 'PLA-SP-2024-001',
    descricao: 'Servidor Rack Dell PowerEdge R750 32C/64GB',
    classificacao: 'computadores_ti',
    marca: 'Dell',
    modelo: 'PowerEdge R750',
    numeroSerie: 'BR-DELL-884920-X',
    localizacao: 'Sede - Sala Cofre / Data Center Andar 2',
    centroCustoId: 'cc-03',
    responsavel: 'Lucas Gabriel Silveira',
    status: 'ativo',
    dataAquisicao: '2024-03-15',
    numeroNotaFiscal: '000.412.890',
    serieNotaFiscal: '1',
    fornecedorNome: 'Dell Computadores do Brasil Ltda',
    fornecedorCnpj: '72.381.189/0001-10',
    chaveAcessoNfe: '35240372381189000110550010004128901004128905',
    valorAquisicao: 48500.0,
    contratoVinculado: 'CONT-TI-2024/02',
    agio: 0,
    desagio: 1200.0, // Desconto comercial negociado
    temSeguro: true,
    seguradora: 'Porto Seguro Cia de Seguros Gerais',
    numeroApolice: 'APOL-EQUIP-892401',
    seguroDataInicio: '2026-01-10',
    seguroDataFim: '2027-01-09',
    valorSegurado: 50000.0,
    seguroStatus: 'vigente',
    taxaDepreciacaoAnual: 20.0,
    vidaUtilAnos: 5,
    valorResidualPercentual: 10,
    valorResidual: 4850.0,
    valorDepreciavel: 43650.0,
    depreciacaoMensal: 727.5,
    mesesDepreciados: 30,
    depreciacaoAcumulada: 21825.0,
    valorContabilLiquido: 25475.0, // 48500 - 21825 - 1200 deságio = 25475
    observacoes: 'Garantia ProSupport Plus Dell vigente até 2027.',
    qrcodeSimulado: 'PAT-00101|PLA-SP-2024-001|DELL-R750|TI-DATACENTER',
    isDemo: true,
  },
  {
    id: 'bem-002',
    empresaId: '1',
    numeroPatrimonio: 'PAT-00102',
    placaIdentificacao: 'PLA-SP-2023-014',
    descricao: 'Caminhão Furgão Mercedes-Benz Sprinter 416 CDI 0km',
    classificacao: 'veiculos',
    marca: 'Mercedes-Benz',
    modelo: 'Sprinter 416 CDI Longo Teto Alto',
    numeroSerie: '9BM907633PB129480',
    localizacao: 'Galpão Logístico - Doca 3 (Frota Própria)',
    centroCustoId: 'cc-05',
    responsavel: 'Roberto Dias Rocha',
    status: 'ativo',
    dataAquisicao: '2023-08-20',
    numeroNotaFiscal: '000.198.540',
    serieNotaFiscal: '2',
    fornecedorNome: 'Comar Concessionária Mercedes-Benz SP',
    fornecedorCnpj: '60.840.231/0001-92',
    chaveAcessoNfe: '35230860840231000192550020001985401001985408',
    valorAquisicao: 245000.0,
    contratoVinculado: 'FINAME-BNDES-8910-A',
    agio: 5000.0, // Ágio de adaptação baú refrigerado
    desagio: 0,
    temSeguro: true,
    seguradora: 'Tokio Marine Seguradora S.A.',
    numeroApolice: 'AUTO-FROTA-77412-23',
    seguroDataInicio: '2025-10-01',
    seguroDataFim: '2026-10-01',
    valorSegurado: 250000.0,
    seguroStatus: 'vencendo', // Alerta de renovação em menos de 30 dias!
    taxaDepreciacaoAnual: 20.0,
    vidaUtilAnos: 5,
    valorResidualPercentual: 20,
    valorResidual: 49000.0,
    valorDepreciavel: 196000.0,
    depreciacaoMensal: 3266.67,
    mesesDepreciados: 37,
    depreciacaoAcumulada: 120866.79,
    valorContabilLiquido: 129133.21,
    observacoes: 'Rastreador Sascar telemetria instalado. Revisão de 60 mil km em dia.',
    qrcodeSimulado: 'PAT-00102|PLA-SP-2023-014|SPRINTER-416|LOGISTICA',
    isDemo: true,
  },
  {
    id: 'bem-003',
    empresaId: '1',
    numeroPatrimonio: 'PAT-00103',
    placaIdentificacao: 'PLA-SP-2022-008',
    descricao: 'Torno Mecânico CNC Universal Romi GL 240M',
    classificacao: 'maquinas_equipamentos',
    marca: 'Romi',
    modelo: 'GL 240M Bar Feed',
    numeroSerie: 'ROMI-CNC-004291-SP',
    localizacao: 'Unidade Industrial - Linha de Usinagem 1',
    centroCustoId: 'cc-02',
    responsavel: 'Marcos Vinicius Santos',
    status: 'ativo',
    dataAquisicao: '2022-05-10',
    numeroNotaFiscal: '000.089.123',
    serieNotaFiscal: '1',
    fornecedorNome: 'Indústrias Romi S.A.',
    fornecedorCnpj: '56.720.912/0001-44',
    chaveAcessoNfe: '35220556720912000144550010000891231000891234',
    valorAquisicao: 320000.0,
    contratoVinculado: 'LEASING-ITAU-2022-ROMI',
    agio: 0,
    desagio: 0,
    temSeguro: true,
    seguradora: 'Allianz Seguros S.A.',
    numeroApolice: 'IND-RISK-ALLZ-99124',
    seguroDataInicio: '2026-03-01',
    seguroDataFim: '2027-03-01',
    valorSegurado: 330000.0,
    seguroStatus: 'vigente',
    taxaDepreciacaoAnual: 10.0,
    vidaUtilAnos: 10,
    valorResidualPercentual: 10,
    valorResidual: 32000.0,
    valorDepreciavel: 288000.0,
    depreciacaoMensal: 2400.0,
    mesesDepreciados: 52,
    depreciacaoAcumulada: 124800.0,
    valorContabilLiquido: 195200.0,
    observacoes: 'Manutenção preventiva semestral cumprida em Julho/2026.',
    qrcodeSimulado: 'PAT-00103|PLA-SP-2022-008|ROMI-CNC-GL240|FABRICA-LINHA1',
    isDemo: true,
  },
  {
    id: 'bem-004',
    empresaId: '1',
    numeroPatrimonio: 'PAT-00104',
    placaIdentificacao: 'PLA-SP-2024-082',
    descricao: 'Conjunto Mobiliário Corporativo 12 Estações de Trabalho Herman Miller',
    classificacao: 'moveis_utensilios',
    marca: 'Herman Miller',
    modelo: 'Layout Ergonomico Pro',
    numeroSerie: 'HM-CORP-2024-BR',
    localizacao: 'Edifício Matriz - Escritório Open Space 4º Andar',
    centroCustoId: 'cc-01',
    responsavel: 'Carlos Alberto Mendes',
    status: 'ativo',
    dataAquisicao: '2024-02-18',
    numeroNotaFiscal: '000.045.678',
    serieNotaFiscal: '1',
    fornecedorNome: 'Atec Original Design Herman Miller Brasil',
    fornecedorCnpj: '48.912.441/0001-30',
    chaveAcessoNfe: '35240248912441000130550010000456781000456789',
    valorAquisicao: 78000.0,
    contratoVinculado: 'MOB-ATEC-2024-01',
    agio: 0,
    desagio: 0,
    temSeguro: false,
    seguroStatus: 'sem_seguro',
    taxaDepreciacaoAnual: 10.0,
    vidaUtilAnos: 10,
    valorResidualPercentual: 10,
    valorResidual: 7800.0,
    valorDepreciavel: 70200.0,
    depreciacaoMensal: 585.0,
    mesesDepreciados: 31,
    depreciacaoAcumulada: 18135.0,
    valorContabilLiquido: 59865.0,
    observacoes: 'Com certificação NR-17 de ergonomia do trabalho.',
    qrcodeSimulado: 'PAT-00104|PLA-SP-2024-082|HERMAN-MILLER-12EST|ADM-MATRIZ',
    isDemo: true,
  },
  {
    id: 'bem-005',
    empresaId: '1',
    numeroPatrimonio: 'PAT-00105',
    placaIdentificacao: 'PLA-SP-2025-019',
    descricao: 'Usina Solar Fotovoltaica 45kWp Bifacial WEG (Geração Própria)',
    classificacao: 'instalacoes',
    marca: 'WEG Solar',
    modelo: 'Inversor 50kW + 90 Módulos 500W',
    numeroSerie: 'WEG-SOL-INV-44129',
    localizacao: 'Cobertura do Galpão Matriz SP',
    centroCustoId: 'cc-02',
    responsavel: 'Marcos Vinicius Santos',
    status: 'ativo',
    dataAquisicao: '2025-01-12',
    numeroNotaFiscal: '000.312.450',
    serieNotaFiscal: '3',
    fornecedorNome: 'WEG Equipamentos Elétricos S.A.',
    fornecedorCnpj: '84.429.695/0001-11',
    chaveAcessoNfe: '35250184429695000111550030003124501003124502',
    valorAquisicao: 165000.0,
    contratoVinculado: 'SOLAR-WEG-SANTANDER-FGO',
    agio: 0,
    desagio: 3000.0,
    temSeguro: true,
    seguradora: 'Chubb Seguros Brasil S.A.',
    numeroApolice: 'CHUBB-SOLAR-09941',
    seguroDataInicio: '2026-01-20',
    seguroDataFim: '2027-01-20',
    valorSegurado: 170000.0,
    seguroStatus: 'vigente',
    taxaDepreciacaoAnual: 10.0,
    vidaUtilAnos: 10,
    valorResidualPercentual: 10,
    valorResidual: 16500.0,
    valorDepreciavel: 148500.0,
    depreciacaoMensal: 1237.5,
    mesesDepreciados: 20,
    depreciacaoAcumulada: 24750.0,
    valorContabilLiquido: 137250.0,
    observacoes: 'Redução média de R$ 7.200/mês na conta de energia da Enel SP.',
    qrcodeSimulado: 'PAT-00105|PLA-SP-2025-019|WEG-SOLAR-45KWP|GALPAO-COBERTURA',
    isDemo: true,
  },
  {
    id: 'bem-006',
    empresaId: '1',
    numeroPatrimonio: 'PAT-00088',
    placaIdentificacao: 'PLA-SP-2021-002',
    descricao: 'Veículo Utilitário Fiat Fiorino Endurance 1.4 Flex',
    classificacao: 'veiculos',
    marca: 'Fiat',
    modelo: 'Fiorino Endurance 1.4',
    numeroSerie: '9BD225124M8912401',
    localizacao: 'Pátio Operacional - Baixado por Venda',
    centroCustoId: 'cc-05',
    responsavel: 'Roberto Dias Rocha',
    status: 'baixado',
    dataAquisicao: '2021-04-10',
    numeroNotaFiscal: '000.034.120',
    serieNotaFiscal: '1',
    fornecedorNome: 'Sinal Fiat Veículos e Peças Ltda',
    fornecedorCnpj: '59.102.391/0001-55',
    chaveAcessoNfe: '35210459102391000155550010000341201000341207',
    valorAquisicao: 72000.0,
    contratoVinculado: 'FINANC-BV-2021-FIAT',
    agio: 0,
    desagio: 0,
    temSeguro: false,
    seguroStatus: 'sem_seguro',
    taxaDepreciacaoAnual: 20.0,
    vidaUtilAnos: 5,
    valorResidualPercentual: 20,
    valorResidual: 14400.0,
    valorDepreciavel: 57600.0,
    depreciacaoMensal: 960.0,
    mesesDepreciados: 50,
    depreciacaoAcumulada: 48000.0,
    valorContabilLiquido: 24000.0,
    dataBaixa: '2026-06-15',
    motivoBaixa: 'venda',
    valorVenda: 38000.0,
    ganhoPerdaCapital: 14000.0, // Ganho de capital contábil apurado (R$ 38.000 venda - R$ 24.000 valor contábil)
    notaFiscalBaixa: 'NF-e 000.009.841',
    observacoesBaixa: 'Alienado para renovação da frota com ganho de capital tributável de R$ 14.000,00.',
    observacoes: 'Veículo baixado e transferido ao adquirente.',
    qrcodeSimulado: 'PAT-00088|PLA-SP-2021-002|FIAT-FIORINO|BAIXADO-VENDA',
    isDemo: true,
  },
];

// Plano de Contas Contábil Padrão (CFC / ITG 1000 / ECD / ECF)
export const PLANO_CONTAS_DEMO: ContaContabil[] = [
  // 1. ATIVO
  { id: 'pc-1', codigo: '1', nome: 'ATIVO TOTAL', tipo: 'sintetica', natureza: 'devedora', grupo: 'ativo', grau: 1, saldoAtual: 2845000 },
  { id: 'pc-1.1', codigo: '1.1', nome: 'ATIVO CIRCULANTE', tipo: 'sintetica', natureza: 'devedora', grupo: 'ativo', grau: 2, saldoAtual: 1420000 },
  { id: 'pc-1.1.01', codigo: '1.1.01', nome: 'Caixa e Equivalentes de Caixa', tipo: 'sintetica', natureza: 'devedora', grupo: 'ativo', grau: 3, saldoAtual: 420000 },
  { id: 'pc-1.1.01.001', codigo: '1.1.01.001', nome: 'Caixa Geral da Empresa', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 4, saldoAtual: 15000 },
  { id: 'pc-1.1.01.002', codigo: '1.1.01.002', nome: 'Bancos Conta Movimento (Itaú / Bradesco / BB)', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 4, saldoAtual: 285000 },
  { id: 'pc-1.1.01.003', codigo: '1.1.01.003', nome: 'Aplicações Financeiras de Liquidez Imediata (CDB 100% CDI)', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 4, saldoAtual: 120000 },
  { id: 'pc-1.1.02', codigo: '1.1.02', nome: 'Contas a Receber / Clientes Nacionais', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 3, saldoAtual: 680000 },
  { id: 'pc-1.1.03', codigo: '1.1.03', nome: 'Estoques de Mercadorias e Insumos', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 3, saldoAtual: 260000 },
  { id: 'pc-1.1.04', codigo: '1.1.04', nome: 'Tributos a Recuperar (ICMS, IPI, PIS/COFINS a Compensar)', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 3, saldoAtual: 60000 },

  // 1.2 ATIVO NÃO CIRCULANTE
  { id: 'pc-1.2', codigo: '1.2', nome: 'ATIVO NÃO CIRCULANTE', tipo: 'sintetica', natureza: 'devedora', grupo: 'ativo', grau: 2, saldoAtual: 1425000 },
  { id: 'pc-1.2.01', codigo: '1.2.01', nome: 'Realizável a Longo Prazo', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 3, saldoAtual: 110000 },
  { id: 'pc-1.2.02', codigo: '1.2.02', nome: 'Investimentos em Coligadas e Controladas', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 3, saldoAtual: 90000 },
  { id: 'pc-1.2.03', codigo: '1.2.03', nome: 'IMOBILIZADO PATRIMONIAL (BENS EM OPERAÇÃO)', tipo: 'sintetica', natureza: 'devedora', grupo: 'ativo', grau: 3, saldoAtual: 1185000, vinculoPatrimonio: 'imobilizado_custo' },
  { id: 'pc-1.2.03.001', codigo: '1.2.03.001', nome: 'Máquinas e Equipamentos Industriais', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 4, saldoAtual: 320000, vinculoPatrimonio: 'imobilizado_custo' },
  { id: 'pc-1.2.03.002', codigo: '1.2.03.002', nome: 'Móveis, Utensílios e Instalações Escritório', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 4, saldoAtual: 78000, vinculoPatrimonio: 'imobilizado_custo' },
  { id: 'pc-1.2.03.003', codigo: '1.2.03.003', nome: 'Equipamentos de TI, Servidores e Notebooks', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 4, saldoAtual: 48500, vinculoPatrimonio: 'imobilizado_custo' },
  { id: 'pc-1.2.03.004', codigo: '1.2.03.004', nome: 'Veículos Automotores e Utilitários de Transporte', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 4, saldoAtual: 245000, vinculoPatrimonio: 'imobilizado_custo' },
  { id: 'pc-1.2.03.005', codigo: '1.2.03.005', nome: 'Instalações Elétricas e Usina Fotovoltaica', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 4, saldoAtual: 165000, vinculoPatrimonio: 'imobilizado_custo' },
  { id: 'pc-1.2.03.006', codigo: '1.2.03.006', nome: 'Edificações e Benfeitorias em Imóveis', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 4, saldoAtual: 520000, vinculoPatrimonio: 'imobilizado_custo' },
  { id: 'pc-1.2.03.090', codigo: '1.2.03.090', nome: '(-) DEPRECIAÇÃO ACUMULADA DO ATIVO IMOBILIZADO', tipo: 'analitica', natureza: 'credora', grupo: 'ativo', grau: 4, saldoAtual: -191500, vinculoPatrimonio: 'depreciacao_acumulada' },
  { id: 'pc-1.2.04', codigo: '1.2.04', nome: 'Intangível (Softwares, Licenças, Marcas & Patentes)', tipo: 'analitica', natureza: 'devedora', grupo: 'ativo', grau: 3, saldoAtual: 40000 },

  // 2. PASSIVO
  { id: 'pc-2', codigo: '2', nome: 'PASSIVO EXIGÍVEL', tipo: 'sintetica', natureza: 'credora', grupo: 'passivo', grau: 1, saldoAtual: 1120000 },
  { id: 'pc-2.1', codigo: '2.1', nome: 'PASSIVO CIRCULANTE', tipo: 'sintetica', natureza: 'credora', grupo: 'passivo', grau: 2, saldoAtual: 680000 },
  { id: 'pc-2.1.01', codigo: '2.1.01', nome: 'Fornecedores Nacionais e Estrangeiros', tipo: 'analitica', natureza: 'credora', grupo: 'passivo', grau: 3, saldoAtual: 280000 },
  { id: 'pc-2.1.02', codigo: '2.1.02', nome: 'Obrigações Trabalhistas e Previdenciárias (Salários / INSS / FGTS)', tipo: 'analitica', natureza: 'credora', grupo: 'passivo', grau: 3, saldoAtual: 175000 },
  { id: 'pc-2.1.03', codigo: '2.1.03', nome: 'Obrigações Tributárias (Simples Nacional, DAS, ISS, PIS/COFINS)', tipo: 'analitica', natureza: 'credora', grupo: 'passivo', grau: 3, saldoAtual: 95000 },
  { id: 'pc-2.1.04', codigo: '2.1.04', nome: 'Empréstimos e Financiamentos de Curto Prazo', tipo: 'analitica', natureza: 'credora', grupo: 'passivo', grau: 3, saldoAtual: 130000 },
  { id: 'pc-2.2', codigo: '2.2', nome: 'PASSIVO NÃO CIRCULANTE (LONGO PRAZO)', tipo: 'sintetica', natureza: 'credora', grupo: 'passivo', grau: 2, saldoAtual: 440000 },
  { id: 'pc-2.2.01', codigo: '2.2.01', nome: 'Financiamentos Bancários (BNDES / FINAME / Caixa)', tipo: 'analitica', natureza: 'credora', grupo: 'passivo', grau: 3, saldoAtual: 390000 },
  { id: 'pc-2.2.02', codigo: '2.2.02', nome: 'Provisões para Riscos Fiscais e Cíveis', tipo: 'analitica', natureza: 'credora', grupo: 'passivo', grau: 3, saldoAtual: 50000 },

  // 3. PATRIMÔNIO LÍQUIDO
  { id: 'pc-3', codigo: '3', nome: 'PATRIMÔNIO LÍQUIDO (PL)', tipo: 'sintetica', natureza: 'credora', grupo: 'patrimonio_liquido', grau: 1, saldoAtual: 1725000 },
  { id: 'pc-3.1', codigo: '3.1', nome: 'Capital Social Integralizado e Subscrito', tipo: 'analitica', natureza: 'credora', grupo: 'patrimonio_liquido', grau: 2, saldoAtual: 1000000 },
  { id: 'pc-3.2', codigo: '3.2', nome: 'Reservas de Capital e de Reavaliação', tipo: 'analitica', natureza: 'credora', grupo: 'patrimonio_liquido', grau: 2, saldoAtual: 120000 },
  { id: 'pc-3.3', codigo: '3.3', nome: 'Reservas de Lucros e Contingências', tipo: 'analitica', natureza: 'credora', grupo: 'patrimonio_liquido', grau: 2, saldoAtual: 285000 },
  { id: 'pc-3.4', codigo: '3.4', nome: 'Lucros ou Prejuízos Acumulados do Exercício', tipo: 'analitica', natureza: 'credora', grupo: 'patrimonio_liquido', grau: 2, saldoAtual: 320000 },

  // 4. RECEITAS
  { id: 'pc-4', codigo: '4', nome: 'RECEITAS OPERACIONAIS', tipo: 'sintetica', natureza: 'credora', grupo: 'receita', grau: 1, saldoAtual: 3450000 },
  { id: 'pc-4.1', codigo: '4.1', nome: 'Receita Bruta de Vendas de Mercadorias e Produtos', tipo: 'analitica', natureza: 'credora', grupo: 'receita', grau: 2, saldoAtual: 2150000 },
  { id: 'pc-4.2', codigo: '4.2', nome: 'Receita Bruta de Prestação de Serviços Técnicos', tipo: 'analitica', natureza: 'credora', grupo: 'receita', grau: 2, saldoAtual: 1300000 },
  { id: 'pc-4.3', codigo: '4.3', nome: 'Receitas Financeiras (Juros sobre Aplicações, Descontos Obtidos)', tipo: 'analitica', natureza: 'credora', grupo: 'receita', grau: 2, saldoAtual: 45000 },
  { id: 'pc-4.4', codigo: '4.4', nome: 'Outras Receitas Operacionais (Ganho de Capital em Alienação de Imobilizado)', tipo: 'analitica', natureza: 'credora', grupo: 'receita', grau: 2, saldoAtual: 14000 },

  // 5. CUSTOS E DESPESAS OPERACIONAIS
  { id: 'pc-5', codigo: '5', nome: 'CUSTOS E DESPESAS OPERACIONAIS', tipo: 'sintetica', natureza: 'devedora', grupo: 'despesa', grau: 1, saldoAtual: 3015000 },
  { id: 'pc-5.1', codigo: '5.1', nome: 'Custos dos Produtos e Serviços Vendidos (CPV / CSP)', tipo: 'analitica', natureza: 'devedora', grupo: 'custo', grau: 2, saldoAtual: 1720000 },
  { id: 'pc-5.2', codigo: '5.2', nome: 'Despesas com Pessoal, Salários e Pró-Labore', tipo: 'analitica', natureza: 'devedora', grupo: 'despesa', grau: 2, saldoAtual: 680000 },
  { id: 'pc-5.3', codigo: '5.3', nome: 'Despesas Administrativas, Aluguéis e Utilidades', tipo: 'analitica', natureza: 'devedora', grupo: 'despesa', grau: 2, saldoAtual: 310000 },
  { id: 'pc-5.4', codigo: '5.4', nome: 'DESPESAS COM DEPRECIAÇÃO E AMORTIZAÇÃO DO IMOBILIZADO', tipo: 'analitica', natureza: 'devedora', grupo: 'despesa', grau: 2, saldoAtual: 86450, vinculoPatrimonio: 'despesa_depreciacao' },
  { id: 'pc-5.5', codigo: '5.5', nome: 'Despesas Comerciais, Vendas e Marketing Digital', tipo: 'analitica', natureza: 'devedora', grupo: 'despesa', grau: 2, saldoAtual: 125000 },
  { id: 'pc-5.6', codigo: '5.6', nome: 'Despesas Financeiras (Juros Bancários, Tarifas e IOF)', tipo: 'analitica', natureza: 'devedora', grupo: 'despesa', grau: 2, saldoAtual: 93550 },
];

// Gerador de Dados de Balanço Patrimonial Integrado
export function gerarBalancoPatrimonial(bens: BemPatrimonial[], empresaId: string = '1'): BalancoPatrimonialData {
  // Totaliza os bens ativos da empresa
  const bensEmpresa = bens.filter((b) => b.empresaId === empresaId && b.status !== 'baixado');
  const imobilizadoBruto = bensEmpresa.reduce((acc, b) => acc + b.valorAquisicao, 520000); // 520k de prédios base
  const depreciacaoAcumulada = bensEmpresa.reduce((acc, b) => acc + b.depreciacaoAcumulada, 65000);
  const imobilizadoLiquido = imobilizadoBruto - depreciacaoAcumulada;

  const ativoCirculanteTotal = 1420000;
  const realizavelLongoPrazo = 110000;
  const investimentos = 90000;
  const intangivel = 40000;
  const ativoNaoCirculanteTotal = realizavelLongoPrazo + investimentos + intangivel + imobilizadoLiquido;
  const ativoTotal = ativoCirculanteTotal + ativoNaoCirculanteTotal;

  const passivoCirculanteTotal = 680000;
  const passivoNaoCirculanteTotal = 440000;
  const exigivelTotal = passivoCirculanteTotal + passivoNaoCirculanteTotal;
  const patrimonioLiquidoTotal = ativoTotal - exigivelTotal; // Equilíbrio contábil
  const passivoTotalComPl = exigivelTotal + patrimonioLiquidoTotal;

  const calcAV = (val: number) => Number(((val / ativoTotal) * 100).toFixed(2));
  const calcAH = (val26: number, val25: number) => Number((((val26 - val25) / val25) * 100).toFixed(2));

  const linhas = [
    // ATIVO CIRCULANTE
    { codigo: '1', descricao: '1. ATIVO TOTAL', saldo2025: 2590000, saldo2026: ativoTotal, analiseVertical2026: 100, analiseHorizontal: calcAH(ativoTotal, 2590000), nivel: 1, destaque: true, grupo: 'ativo' as const },
    { codigo: '1.1', descricao: '1.1 ATIVO CIRCULANTE', saldo2025: 1280000, saldo2026: ativoCirculanteTotal, analiseVertical2026: calcAV(ativoCirculanteTotal), analiseHorizontal: calcAH(ativoCirculanteTotal, 1280000), nivel: 2, destaque: true, grupo: 'ativo' as const },
    { codigo: '1.1.1', descricao: 'Disponibilidades (Caixa & Bancos)', saldo2025: 380000, saldo2026: 420000, analiseVertical2026: calcAV(420000), analiseHorizontal: calcAH(420000, 380000), nivel: 3, grupo: 'ativo' as const },
    { codigo: '1.1.2', descricao: 'Contas a Receber de Clientes', saldo2025: 620000, saldo2026: 680000, analiseVertical2026: calcAV(680000), analiseHorizontal: calcAH(680000, 620000), nivel: 3, grupo: 'ativo' as const },
    { codigo: '1.1.3', descricao: 'Estoques de Mercadorias e Produtos', saldo2025: 230000, saldo2026: 260000, analiseVertical2026: calcAV(260000), analiseHorizontal: calcAH(260000, 230000), nivel: 3, grupo: 'ativo' as const },
    { codigo: '1.1.4', descricao: 'Tributos e Adiantamentos a Recuperar', saldo2025: 50000, saldo2026: 60000, analiseVertical2026: calcAV(60000), analiseHorizontal: calcAH(60000, 50000), nivel: 3, grupo: 'ativo' as const },

    // ATIVO NÃO CIRCULANTE & IMOBILIZADO
    { codigo: '1.2', descricao: '1.2 ATIVO NÃO CIRCULANTE', saldo2025: 1310000, saldo2026: ativoNaoCirculanteTotal, analiseVertical2026: calcAV(ativoNaoCirculanteTotal), analiseHorizontal: calcAH(ativoNaoCirculanteTotal, 1310000), nivel: 2, destaque: true, grupo: 'ativo' as const },
    { codigo: '1.2.1', descricao: 'Realizável a Longo Prazo', saldo2025: 95000, saldo2026: realizavelLongoPrazo, analiseVertical2026: calcAV(realizavelLongoPrazo), analiseHorizontal: calcAH(realizavelLongoPrazo, 95000), nivel: 3, grupo: 'ativo' as const },
    { codigo: '1.2.2', descricao: 'Investimentos em Outras Sociedades', saldo2025: 85000, saldo2026: investimentos, analiseVertical2026: calcAV(investimentos), analiseHorizontal: calcAH(investimentos, 85000), nivel: 3, grupo: 'ativo' as const },
    { codigo: '1.2.3', descricao: 'IMOBILIZADO PATRIMONIAL LÍQUIDO', saldo2025: 1095000, saldo2026: imobilizadoLiquido, analiseVertical2026: calcAV(imobilizadoLiquido), analiseHorizontal: calcAH(imobilizadoLiquido, 1095000), nivel: 3, destaque: true, grupo: 'ativo' as const },
    { codigo: '1.2.3.1', descricao: '(+) Bens Imobilizados (Custo Histórico Aquisição)', saldo2025: 1250000, saldo2026: imobilizadoBruto, analiseVertical2026: calcAV(imobilizadoBruto), analiseHorizontal: calcAH(imobilizadoBruto, 1250000), nivel: 4, grupo: 'ativo' as const },
    { codigo: '1.2.3.2', descricao: '(-) Depreciação e Amortização Acumulada', saldo2025: -155000, saldo2026: -depreciacaoAcumulada, analiseVertical2026: calcAV(-depreciacaoAcumulada), analiseHorizontal: calcAH(depreciacaoAcumulada, 155000), nivel: 4, grupo: 'ativo' as const },
    { codigo: '1.2.4', descricao: 'Ativos Intangíveis (Softwares & Marcas)', saldo2025: 35000, saldo2026: intangivel, analiseVertical2026: calcAV(intangivel), analiseHorizontal: calcAH(intangivel, 35000), nivel: 3, grupo: 'ativo' as const },

    // PASSIVO CIRCULANTE
    { codigo: '2', descricao: '2. PASSIVO E PATRIMÔNIO LÍQUIDO', saldo2025: 2590000, saldo2026: passivoTotalComPl, analiseVertical2026: 100, analiseHorizontal: calcAH(passivoTotalComPl, 2590000), nivel: 1, destaque: true, grupo: 'passivo_pl' as const },
    { codigo: '2.1', descricao: '2.1 PASSIVO CIRCULANTE (CURTO PRAZO)', saldo2025: 610000, saldo2026: passivoCirculanteTotal, analiseVertical2026: calcAV(passivoCirculanteTotal), analiseHorizontal: calcAH(passivoCirculanteTotal, 610000), nivel: 2, destaque: true, grupo: 'passivo_pl' as const },
    { codigo: '2.1.1', descricao: 'Fornecedores a Pagar', saldo2025: 250000, saldo2026: 280000, analiseVertical2026: calcAV(280000), analiseHorizontal: calcAH(280000, 250000), nivel: 3, grupo: 'passivo_pl' as const },
    { codigo: '2.1.2', descricao: 'Obrigações Trabalhistas e Sociais (Folha/INSS/FGTS)', saldo2025: 160000, saldo2026: 175000, analiseVertical2026: calcAV(175000), analiseHorizontal: calcAH(175000, 160000), nivel: 3, grupo: 'passivo_pl' as const },
    { codigo: '2.1.3', descricao: 'Obrigações Fiscais e Tributárias (Simples/DAS/Tributos)', saldo2025: 85000, saldo2026: 95000, analiseVertical2026: calcAV(95000), analiseHorizontal: calcAH(95000, 85000), nivel: 3, grupo: 'passivo_pl' as const },
    { codigo: '2.1.4', descricao: 'Empréstimos Bancários a Curto Prazo', saldo2025: 115000, saldo2026: 130000, analiseVertical2026: calcAV(130000), analiseHorizontal: calcAH(130000, 115000), nivel: 3, grupo: 'passivo_pl' as const },

    // PASSIVO NÃO CIRCULANTE
    { codigo: '2.2', descricao: '2.2 PASSIVO NÃO CIRCULANTE (LONGO PRAZO)', saldo2025: 460000, saldo2026: passivoNaoCirculanteTotal, analiseVertical2026: calcAV(passivoNaoCirculanteTotal), analiseHorizontal: calcAH(passivoNaoCirculanteTotal, 460000), nivel: 2, destaque: true, grupo: 'passivo_pl' as const },
    { codigo: '2.2.1', descricao: 'Financiamentos de Longo Prazo (BNDES/FINAME)', saldo2025: 410000, saldo2026: 390000, analiseVertical2026: calcAV(390000), analiseHorizontal: calcAH(390000, 410000), nivel: 3, grupo: 'passivo_pl' as const },
    { codigo: '2.2.2', descricao: 'Provisões para Contingências', saldo2025: 50000, saldo2026: 50000, analiseVertical2026: calcAV(50000), analiseHorizontal: 0, nivel: 3, grupo: 'passivo_pl' as const },

    // PATRIMÔNIO LÍQUIDO
    { codigo: '2.3', descricao: '2.3 PATRIMÔNIO LÍQUIDO (PL)', saldo2025: 1520000, saldo2026: patrimonioLiquidoTotal, analiseVertical2026: calcAV(patrimonioLiquidoTotal), analiseHorizontal: calcAH(patrimonioLiquidoTotal, 1520000), nivel: 2, destaque: true, grupo: 'passivo_pl' as const },
    { codigo: '2.3.1', descricao: 'Capital Social Subscrito e Integralizado', saldo2025: 1000000, saldo2026: 1000000, analiseVertical2026: calcAV(1000000), analiseHorizontal: 0, nivel: 3, grupo: 'passivo_pl' as const },
    { codigo: '2.3.2', descricao: 'Reservas de Capital e Lucros Retidos', saldo2025: 340000, saldo2026: 405000, analiseVertical2026: calcAV(405000), analiseHorizontal: calcAH(405000, 340000), nivel: 3, grupo: 'passivo_pl' as const },
    { codigo: '2.3.3', descricao: 'Lucro Líquido Acumulado do Exercício Corrente', saldo2025: 180000, saldo2026: patrimonioLiquidoTotal - 1405000, analiseVertical2026: calcAV(patrimonioLiquidoTotal - 1405000), analiseHorizontal: calcAH(patrimonioLiquidoTotal - 1405000, 180000), nivel: 3, grupo: 'passivo_pl' as const },
  ];

  return {
    empresaId,
    competencia: '2026',
    ativoCirculanteTotal,
    ativoNaoCirculanteTotal,
    imobilizadoBruto,
    depreciacaoAcumulada,
    imobilizadoLiquido,
    ativoTotal,
    passivoCirculanteTotal,
    passivoNaoCirculanteTotal,
    patrimonioLiquidoTotal,
    passivoTotalComPl,
    linhas,
  };
}

// Gerador de DRE com Cálculo Direto de EBITDA e Depreciação Integrada
export function gerarDre(bens: BemPatrimonial[], empresaId: string = '1'): DreData {
  const bensEmpresa = bens.filter((b) => b.empresaId === empresaId && b.status !== 'baixado');
  // Depreciação anual total = soma das depreciações mensais * 12
  const somaDeprecMensal = bensEmpresa.reduce((acc, b) => acc + b.depreciacaoMensal, 2100);
  const despesaDepreciacao = Number((somaDeprecMensal * 12).toFixed(2)); // Cerca de R$ 86k a 110k

  const receitaBruta = 3450000.0;
  const deducoesImpostos = 380000.0; // PGDAS-D / ICMS / ISS
  const receitaLiquida = receitaBruta - deducoesImpostos; // 3.070.000,00
  const cpvCustoServicos = 1720000.0;
  const lucroBruto = receitaLiquida - cpvCustoServicos; // 1.350.000,00

  const despesasAdministrativas = 490000.0;
  const despesasComerciais = 185000.0;
  const despesasOperacionaisSemDeprec = despesasAdministrativas + despesasComerciais; // 675.000,00

  // EBITDA / LAIDA = Lucro Bruto - Despesas Operacionais em Dinheiro (Sem Depreciação)
  const ebitda = lucroBruto - despesasOperacionaisSemDeprec; // 675.000,00
  const margemEbitda = Number(((ebitda / receitaLiquida) * 100).toFixed(2));

  // EBIT = EBITDA - Depreciação
  const ebit = ebitda - despesaDepreciacao; // 675.000 - despesaDepreciacao
  const resultadoFinanceiro = -48550.0; // Despesas financeiras líquidas de juros
  const lair = ebit + resultadoFinanceiro;
  const provisaoTributos = Number((lair * 0.15).toFixed(2)); // Provisão IR/CSLL
  const lucroLiquido = lair - provisaoTributos;
  const margemLiquida = Number(((lucroLiquido / receitaLiquida) * 100).toFixed(2));

  const calcAV = (val: number) => Number(((val / receitaLiquida) * 100).toFixed(2));
  const calcAH = (v26: number, v25: number) => Number((((v26 - v25) / v25) * 100).toFixed(2));

  const linhas = [
    { codigo: '1', descricao: '1. RECEITA OPERACIONAL BRUTA', valor2025: 3120000, valor2026: receitaBruta, analiseVertical: calcAV(receitaBruta), analiseHorizontal: calcAH(receitaBruta, 3120000), destaque: true, tipo: 'receita' as const },
    { codigo: '1.1', descricao: '(-) Deduções da Receita Bruta e Tributos sobre Vendas', valor2025: -340000, valor2026: -deducoesImpostos, analiseVertical: calcAV(-deducoesImpostos), analiseHorizontal: calcAH(deducoesImpostos, 340000), tipo: 'deducao' as const },
    { codigo: '2', descricao: '2. RECEITA OPERACIONAL LÍQUIDA', valor2025: 2780000, valor2026: receitaLiquida, analiseVertical: 100, analiseHorizontal: calcAH(receitaLiquida, 2780000), destaque: true, tipo: 'receita' as const },
    { codigo: '3', descricao: '(-) Custos dos Produtos e Serviços Prestados (CPV/CSP)', valor2025: -1580000, valor2026: -cpvCustoServicos, analiseVertical: calcAV(-cpvCustoServicos), analiseHorizontal: calcAH(cpvCustoServicos, 1580000), tipo: 'custo' as const },
    { codigo: '4', descricao: '(=) LUCRO BRUTO OPERACIONAL', valor2025: 1200000, valor2026: lucroBruto, analiseVertical: calcAV(lucroBruto), analiseHorizontal: calcAH(lucroBruto, 1200000), destaque: true, tipo: 'resultado' as const },
    { codigo: '5', descricao: '(-) Despesas Gerais e Administrativas', valor2025: -450000, valor2026: -despesasAdministrativas, analiseVertical: calcAV(-despesasAdministrativas), analiseHorizontal: calcAH(despesasAdministrativas, 450000), tipo: 'despesa' as const },
    { codigo: '6', descricao: '(-) Despesas Comerciais e Marketing', valor2025: -170000, valor2026: -despesasComerciais, analiseVertical: calcAV(-despesasComerciais), analiseHorizontal: calcAH(despesasComerciais, 170000), tipo: 'despesa' as const },
    { codigo: '7', descricao: '(=) EBITDA / LAIDA (Lucro antes de Juros, Impostos, Depreciação e Amortização)', valor2025: 580000, valor2026: ebitda, analiseVertical: margemEbitda, analiseHorizontal: calcAH(ebitda, 580000), destaque: true, tipo: 'ebitda' as const },
    { codigo: '8', descricao: '(-) Despesa com Depreciação e Amortização do Patrimônio (Ativo Imobilizado)', valor2025: -78000, valor2026: -despesaDepreciacao, analiseVertical: calcAV(-despesaDepreciacao), analiseHorizontal: calcAH(despesaDepreciacao, 78000), tipo: 'despesa' as const },
    { codigo: '9', descricao: '(=) EBIT / LAIR (Resultado Operacional Antes do Resultado Financeiro)', valor2025: 502000, valor2026: ebit, analiseVertical: calcAV(ebit), analiseHorizontal: calcAH(ebit, 502000), destaque: true, tipo: 'resultado' as const },
    { codigo: '10', descricao: '(+/-) Resultado Financeiro Líquido (Receitas - Despesas de Juros)', valor2025: -42000, valor2026: resultadoFinanceiro, analiseVertical: calcAV(resultadoFinanceiro), analiseHorizontal: calcAH(Math.abs(resultadoFinanceiro), 42000), tipo: 'despesa' as const },
    { codigo: '11', descricao: '(=) LAIR (Lucro Antes do Imposto de Renda e Contribuição Social)', valor2025: 460000, valor2026: lair, analiseVertical: calcAV(lair), analiseHorizontal: calcAH(lair, 460000), destaque: true, tipo: 'resultado' as const },
    { codigo: '12', descricao: '(-) Provisão para Tributos sobre o Lucro (IRPJ / CSLL)', valor2025: -69000, valor2026: -provisaoTributos, analiseVertical: calcAV(-provisaoTributos), analiseHorizontal: calcAH(provisaoTributos, 69000), tipo: 'deducao' as const },
    { codigo: '13', descricao: '(=) LUCRO LÍQUIDO DO EXERCÍCIO (RESULTADO FINAL)', valor2025: 391000, valor2026: lucroLiquido, analiseVertical: margemLiquida, analiseHorizontal: calcAH(lucroLiquido, 391000), destaque: true, tipo: 'resultado' as const },
  ];

  return {
    empresaId,
    competencia: '2026',
    receitaBruta,
    deducoesImpostos,
    receitaLiquida,
    cpvCustoServicos,
    lucroBruto,
    despesasOperacionais: despesasOperacionaisSemDeprec + despesaDepreciacao,
    despesaDepreciacao,
    ebitda,
    margemEbitda,
    ebit,
    resultadoFinanceiro,
    lair,
    provisaoTributos,
    lucroLiquido,
    margemLiquida,
    linhas,
  };
}

// Gerador de Demonstração dos Fluxos de Caixa (DFC)
export function gerarDfc(dre: DreData, bens: BemPatrimonial[], empresaId: string = '1'): DfcData {
  // Lucro líquido conciliado com depreciação (Método Indireto)
  const fluxoOperacional = dre.lucroLiquido + dre.despesaDepreciacao - 42000; // variação do capital de giro (- R$ 42k)
  
  // Investimentos em Bens de Capital (CAPEX): aquisições menos alienações
  const fluxoInvestimento = -165000 + 38000; // -165k usina solar + 38k venda da fiorino = -127.000
  const fluxoFinanciamento = -50000 + 120000; // amortização de empréstimos + novos aportes = +70.000

  const variacaoLiquidaCaixa = fluxoOperacional + fluxoInvestimento + fluxoFinanciamento;
  const saldoInicialCaixa = 380000;
  const saldoFinalCaixa = saldoInicialCaixa + variacaoLiquidaCaixa;

  const linhas = [
    { categoria: 'operacional' as const, descricao: 'Lucro Líquido do Exercício', valor2025: 391000, valor2026: dre.lucroLiquido },
    { categoria: 'operacional' as const, descricao: '(+) Depreciação e Amortização Acumulada no Exercício (Sem Efeito Caixa)', valor2025: 78000, valor2026: dre.despesaDepreciacao },
    { categoria: 'operacional' as const, descricao: '(-) Aumento no Contas a Receber de Clientes', valor2025: -45000, valor2026: -60000 },
    { categoria: 'operacional' as const, descricao: '(-) Aumento nos Estoques Operacionais', valor2025: -25000, valor2026: -30000 },
    { categoria: 'operacional' as const, descricao: '(+) Aumento em Fornecedores e Contas a Pagar', valor2025: 35000, valor2026: 48000 },
    { categoria: 'operacional' as const, descricao: '(=) Fluxo Líquido de Caixa das Atividades Operacionais', valor2025: 434000, valor2026: fluxoOperacional },
    
    { categoria: 'investimento' as const, descricao: '(-) Aquisição de Bens do Ativo Imobilizado (CAPEX / Máquinas / TI)', valor2025: -180000, valor2026: -165000 },
    { categoria: 'investimento' as const, descricao: '(+) Recebimento por Alienação de Bens do Imobilizado', valor2025: 0, valor2026: 38000 },
    { categoria: 'investimento' as const, descricao: '(=) Fluxo Líquido de Caixa das Atividades de Investimento', valor2025: -180000, valor2026: fluxoInvestimento },

    { categoria: 'financiamento' as const, descricao: '(+) Captação de Novos Financiamentos Bancários', valor2025: 80000, valor2026: 120000 },
    { categoria: 'financiamento' as const, descricao: '(-) Amortização de Dívidas de Financiamentos e Leasing', valor2025: -45000, valor2026: -50000 },
    { categoria: 'financiamento' as const, descricao: '(=) Fluxo Líquido de Caixa das Atividades de Financiamento', valor2025: 35000, valor2026: fluxoFinanciamento },

    { categoria: 'saldo' as const, descricao: '(=) Variação Líquida de Caixa e Equivalentes no Período', valor2025: 289000, valor2026: variacaoLiquidaCaixa },
    { categoria: 'saldo' as const, descricao: 'Saldo Inicial de Disponibilidades', valor2025: 91000, valor2026: saldoInicialCaixa },
    { categoria: 'saldo' as const, descricao: 'Saldo Final de Disponibilidades', valor2025: 380000, valor2026: saldoFinalCaixa },
  ];

  return {
    empresaId,
    competencia: '2026',
    fluxoOperacional,
    fluxoInvestimento,
    fluxoFinanciamento,
    variacaoLiquidaCaixa,
    saldoInicialCaixa,
    saldoFinalCaixa,
    linhas,
  };
}

// Calculador de Indicadores Financeiros e Contábeis (Endividamento, Rentabilidade, Liquidez)
export function calcularIndicadoresContabeis(bp: BalancoPatrimonialData, dre: DreData): IndicadoresContabeis {
  const exigivelTotal = bp.passivoCirculanteTotal + bp.passivoNaoCirculanteTotal;
  const pl = bp.patrimonioLiquidoTotal;
  const ativo = bp.ativoTotal;
  const recLiq = dre.receitaLiquida;

  return {
    // Endividamento
    endividamentoGeral: Number(((exigivelTotal / ativo) * 100).toFixed(2)),
    composicaoEndividamento: Number(((bp.passivoCirculanteTotal / exigivelTotal) * 100).toFixed(2)),
    imobilizacaoPatrimonioLiquido: Number(((bp.imobilizadoLiquido / pl) * 100).toFixed(2)),

    // Rentabilidade
    margemBruta: Number(((dre.lucroBruto / recLiq) * 100).toFixed(2)),
    margemEbitda: dre.margemEbitda,
    margemLiquida: dre.margemLiquida,
    roe: Number(((dre.lucroLiquido / pl) * 100).toFixed(2)),
    roa: Number(((dre.lucroLiquido / ativo) * 100).toFixed(2)),

    // Liquidez
    liquidezCorrente: Number((bp.ativoCirculanteTotal / bp.passivoCirculanteTotal).toFixed(2)),
    liquidezSeca: Number(((bp.ativoCirculanteTotal - 260000) / bp.passivoCirculanteTotal).toFixed(2)),
    liquidezGeral: Number(((bp.ativoCirculanteTotal + 110000) / exigivelTotal).toFixed(2)),
  };
}
