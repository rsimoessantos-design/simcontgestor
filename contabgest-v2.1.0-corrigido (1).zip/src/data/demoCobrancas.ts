import {
  ServicoContabil,
  ContratoHonorario,
  MensalidadeHonorario,
  ReciboHonorario,
} from '../types';

export const SERVICOS_CONTABEIS_PADRAO: ServicoContabil[] = [
  {
    id: 'srv-1',
    codigo: 'CTB-01',
    nome: 'Escrituração Contábil e Balanço Anual',
    categoria: 'Contábil',
    descricao: 'Conciliação bancária, lançamentos contábeis, livros Diário e Razão, Balancetes mensais e elaboração do Balanço Patrimonial com DRE.',
    valorSugerido: 650.0,
    recorrente: true,
    ativo: true,
  },
  {
    id: 'srv-2',
    codigo: 'FSC-01',
    nome: 'Escrituração Fiscal e Apuração Simples Nacional (PGDAS-D)',
    categoria: 'Fiscal',
    descricao: 'Importação de NF-e/NFS-e, cálculo do DAS pelo PGDAS-D, segregação de receitas e transmissão das obrigações fiscais.',
    valorSugerido: 550.0,
    recorrente: true,
    ativo: true,
  },
  {
    id: 'srv-3',
    codigo: 'FSC-02',
    nome: 'Escrituração Fiscal Lucro Presumido / Real (SPED Fiscal & EFD)',
    categoria: 'Fiscal',
    descricao: 'Apuração de ICMS, IPI, PIS, COFINS, IRPJ, CSLL e transmissão do SPED Fiscal ICMS/IPI e EFD Contribuições.',
    valorSugerido: 950.0,
    recorrente: true,
    ativo: true,
  },
  {
    id: 'srv-4',
    codigo: 'FOL-01',
    nome: 'Folha de Pagamento & eSocial (DP)',
    categoria: 'Folha/DP',
    descricao: 'Processamento mensal da folha, holerites, transmissão de eventos ao eSocial (S-1200/S-1210), emissão de guias FGTS Digital e DCTFWeb.',
    valorSugerido: 500.0,
    recorrente: true,
    ativo: true,
  },
  {
    id: 'srv-5',
    codigo: 'MEI-01',
    nome: 'Gestão Completa e Fechamento MEI (PGMEI & DAS-MEI)',
    categoria: 'Fiscal',
    descricao: 'Acompanhamento do faturamento mensal, emissão de guias mensais DAS-MEI, relatório mensal de receitas e suporte para notas fiscais.',
    valorSugerido: 220.0,
    recorrente: true,
    ativo: true,
  },
  {
    id: 'srv-6',
    codigo: 'MEI-02',
    nome: 'Declaração Anual do MEI (DASN-SIMEI)',
    categoria: 'Fiscal',
    descricao: 'Conferência de faturamento bruto anual e transmissão oficial da DASN-SIMEI perante a Receita Federal do Brasil.',
    valorSugerido: 180.0,
    recorrente: false,
    ativo: true,
  },
  {
    id: 'srv-7',
    codigo: 'BPO-01',
    nome: 'BPO Financeiro (Gestão de Contas a Pagar e Receber)',
    categoria: 'BPO Financeiro',
    descricao: 'Operacionalização de pagamentos bancários, emissão e conciliação de boletos, fluxo de caixa diário e relatórios gerenciais.',
    valorSugerido: 1200.0,
    recorrente: true,
    ativo: true,
  },
  {
    id: 'srv-8',
    codigo: 'SOC-01',
    nome: 'Societário: Alteração Contratual / Consolidação',
    categoria: 'Societário',
    descricao: 'Redação de aditivo de contrato social, registro na Junta Comercial, atualização na Receita Federal e Prefeitura Municipal.',
    valorSugerido: 1100.0,
    recorrente: false,
    ativo: true,
  },
  {
    id: 'srv-9',
    codigo: 'SOC-02',
    nome: 'Abertura de Empresa e Obtenção de CNPJ / Alvarás',
    categoria: 'Societário',
    descricao: 'Viabilidade de endereço, elaboração de contrato social/ato constitutivo, registro na JUCESP, emissão de CNPJ, Inscrição Estadual e Alvarás.',
    valorSugerido: 1350.0,
    recorrente: false,
    ativo: true,
  },
  {
    id: 'srv-10',
    codigo: 'CRT-01',
    nome: 'Monitoramento Fiscal Contínuo e Emissão de CNDs',
    categoria: 'Certidões',
    descricao: 'Varredura semanal de pendências no e-CAC, emissão de certidões conjuntas federais (RFB/PGFN), FGTS, Trabalhista e Fazenda Estadual.',
    valorSugerido: 250.0,
    recorrente: true,
    ativo: true,
  },
  {
    id: 'srv-11',
    codigo: 'CNS-01',
    nome: 'Consultoria e Planejamento Tributário Estratégico',
    categoria: 'Consultoria',
    descricao: 'Estudo comparativo anual entre Simples Nacional, Lucro Presumido e Lucro Real visando redução legal da carga tributária.',
    valorSugerido: 1800.0,
    recorrente: false,
    ativo: true,
  },
];

export const CONTRATOS_HONORARIOS_PADRAO: ContratoHonorario[] = [
  {
    id: 'cont-1',
    empresaId: 'emp-1',
    numeroContrato: 'CONT-2024/001',
    dataAssinatura: '2024-01-15',
    dataInicioVigencia: '2024-01-15',
    diaVencimento: 10,
    valorMensalidade: 1850.0,
    status: 'ativo',
    reajusteAnualIndice: 'IPCA',
    servicosIds: ['srv-1', 'srv-2', 'srv-4', 'srv-10'],
    servicosContratadosNomes: [
      'Escrituração Contábil e Balanço Anual',
      'Escrituração Fiscal e Apuração Simples Nacional (PGDAS-D)',
      'Folha de Pagamento & eSocial (DP)',
      'Monitoramento Fiscal Contínuo e Emissão de CNDs',
    ],
    documentoContratoNome: 'Contrato_Prestacao_Servicos_AlphaTech_Assinado.pdf',
    documentoContratoUrl: '/documentos/contratos/CONT-2024-001_AlphaTech.pdf',
    observacoes: 'Contrato de prestação de serviços contábeis com cláusula de reajuste anual pelo IPCA. Vencimento todo dia 10.',
    isDemo: true,
  },
  {
    id: 'cont-2',
    empresaId: 'emp-2',
    numeroContrato: 'CONT-2023/042',
    dataAssinatura: '2023-05-10',
    dataInicioVigencia: '2023-05-10',
    diaVencimento: 15,
    valorMensalidade: 2400.0,
    status: 'ativo',
    reajusteAnualIndice: 'IGP-M',
    servicosIds: ['srv-1', 'srv-3', 'srv-4', 'srv-7'],
    servicosContratadosNomes: [
      'Escrituração Contábil e Balanço Anual',
      'Escrituração Fiscal Lucro Presumido / Real (SPED Fiscal & EFD)',
      'Folha de Pagamento & eSocial (DP)',
      'BPO Financeiro (Gestão de Contas a Pagar e Receber)',
    ],
    documentoContratoNome: 'Contrato_Comercio_Silva_Santos_Assinado.pdf',
    documentoContratoUrl: '/documentos/contratos/CONT-2023-042_SilvaSantos.pdf',
    observacoes: 'Inclui módulo de BPO Financeiro e conciliação bancária diária. Reajuste pelo IGP-M em maio.',
    isDemo: true,
  },
  {
    id: 'cont-3',
    empresaId: 'emp-3',
    numeroContrato: 'CONT-2024/089',
    dataAssinatura: '2024-03-20',
    dataInicioVigencia: '2024-04-01',
    diaVencimento: 20,
    valorMensalidade: 1450.0,
    status: 'ativo',
    reajusteAnualIndice: 'IPCA',
    servicosIds: ['srv-1', 'srv-2', 'srv-4'],
    servicosContratadosNomes: [
      'Escrituração Contábil e Balanço Anual',
      'Escrituração Fiscal e Apuração Simples Nacional (PGDAS-D)',
      'Folha de Pagamento & eSocial (DP)',
    ],
    documentoContratoNome: 'Contrato_Honorarios_Restaurante_SaborArte.pdf',
    documentoContratoUrl: '/documentos/contratos/CONT-2024-089_SaborArte.pdf',
    observacoes: 'Vencimento no dia 20 de cada mês (alinhado ao fechamento do Simples Nacional).',
    isDemo: true,
  },
  {
    id: 'cont-4',
    empresaId: 'emp-4',
    numeroContrato: 'CONT-2025/012',
    dataAssinatura: '2025-01-10',
    dataInicioVigencia: '2025-01-10',
    diaVencimento: 5,
    valorMensalidade: 250.0,
    status: 'ativo',
    reajusteAnualIndice: 'Fixo',
    servicosIds: ['srv-5', 'srv-6'],
    servicosContratadosNomes: [
      'Gestão Completa e Fechamento MEI (PGMEI & DAS-MEI)',
      'Declaração Anual do MEI (DASN-SIMEI)',
    ],
    documentoContratoNome: 'Termo_Adesao_MEI_LucasSilvaDev.pdf',
    documentoContratoUrl: '/documentos/contratos/CONT-2025-012_LucasDev.pdf',
    observacoes: 'Pacote MEI Profissional com emissão de até 15 NFS-e por mês e entrega da DASN inclusa.',
    isDemo: true,
  },
  {
    id: 'cont-5',
    empresaId: 'emp-5',
    numeroContrato: 'CONT-2025/031',
    dataAssinatura: '2025-02-18',
    dataInicioVigencia: '2025-02-18',
    diaVencimento: 10,
    valorMensalidade: 220.0,
    status: 'ativo',
    reajusteAnualIndice: 'Fixo',
    servicosIds: ['srv-5', 'srv-6', 'srv-10'],
    servicosContratadosNomes: [
      'Gestão Completa e Fechamento MEI (PGMEI & DAS-MEI)',
      'Declaração Anual do MEI (DASN-SIMEI)',
      'Monitoramento Fiscal Contínuo e Emissão de CNDs',
    ],
    documentoContratoNome: 'Contrato_MEI_BellaEstetica_Assinado.pdf',
    documentoContratoUrl: '/documentos/contratos/CONT-2025-031_BellaEstetica.pdf',
    observacoes: 'Assessoria MEI no ramo de estética e beleza. Monitoramento de CNDs municipais e estaduais.',
    isDemo: true,
  },
];

export const MENSALIDADES_HONORARIOS_PADRAO: MensalidadeHonorario[] = [
  // --- Competência 09/2026 (Atual) ---
  {
    id: 'mens-202609-1',
    contratoId: 'cont-1',
    empresaId: 'emp-1',
    competencia: '09/2026',
    dataVencimento: '2026-09-10',
    dataPagamento: '2026-09-09',
    valor: 1850.0,
    valorPago: 1850.0,
    status: 'pago',
    formaPagamento: 'pix',
    codigoBarras: '34191.79001 01043.510047 91020.150008 7 98350000185000',
    pixCopiaECola: '00020126580014br.gov.bcb.pix0136contabgest.financeiro@contabgest.com.br52040000530398654071850.005802BR5920CONTABGEST AUDITORIA6009SAO PAULO62070503***6304E8A2',
    reciboEmitido: true,
    reciboId: 'rec-202609-1',
    reciboNumero: 'REC-2026/091',
    historicoEnvios: [
      {
        id: 'env-1',
        canal: 'whatsapp',
        dataEnvio: '2026-09-02T14:30:00Z',
        destinatario: '(11) 98765-4321',
        status: 'lido',
      },
      {
        id: 'env-2',
        canal: 'email',
        dataEnvio: '2026-09-02T14:31:00Z',
        destinatario: 'financeiro@alphatech.com.br',
        status: 'entregue',
      },
    ],
    observacao: 'Pago pontualmente via PIX.',
    isDemo: true,
  },
  {
    id: 'mens-202609-2',
    contratoId: 'cont-2',
    empresaId: 'emp-2',
    competencia: '09/2026',
    dataVencimento: '2026-09-15',
    dataPagamento: '2026-09-15',
    valor: 2400.0,
    valorPago: 2400.0,
    status: 'pago',
    formaPagamento: 'boleto',
    codigoBarras: '23793.38128 60000.123456 01000.987654 3 98400000240000',
    pixCopiaECola: '00020126580014br.gov.bcb.pix0136contabgest.financeiro@contabgest.com.br52040000530398654072400.005802BR5920CONTABGEST AUDITORIA6009SAO PAULO62070503***6304C4F1',
    reciboEmitido: true,
    reciboId: 'rec-202609-2',
    reciboNumero: 'REC-2026/092',
    historicoEnvios: [
      {
        id: 'env-3',
        canal: 'email',
        dataEnvio: '2026-09-05T09:15:00Z',
        destinatario: 'contabilidade@silvasantos.com.br',
        status: 'lido',
      },
    ],
    observacao: 'Liquidação bancária confirmada.',
    isDemo: true,
  },
  {
    id: 'mens-202609-3',
    contratoId: 'cont-3',
    empresaId: 'emp-3',
    competencia: '09/2026',
    dataVencimento: '2026-09-20',
    valor: 1450.0,
    status: 'pendente',
    codigoBarras: '00190.00009 01234.567890 12345.678901 1 98450000145000',
    pixCopiaECola: '00020126580014br.gov.bcb.pix0136contabgest.financeiro@contabgest.com.br52040000530398654071450.005802BR5920CONTABGEST AUDITORIA6009SAO PAULO62070503***6304B729',
    reciboEmitido: false,
    historicoEnvios: [
      {
        id: 'env-4',
        canal: 'whatsapp',
        dataEnvio: '2026-09-10T11:00:00Z',
        destinatario: '(11) 97654-3210',
        status: 'entregue',
      },
      {
        id: 'env-5',
        canal: 'email',
        dataEnvio: '2026-09-10T11:02:00Z',
        destinatario: 'gestao@restaurantesaborarte.com.br',
        status: 'entregue',
      },
    ],
    observacao: 'Vencimento próximo em 20/09.',
    isDemo: true,
  },
  {
    id: 'mens-202609-4',
    contratoId: 'cont-4',
    empresaId: 'emp-4',
    competencia: '09/2026',
    dataVencimento: '2026-09-05',
    valor: 250.0,
    status: 'atrasado',
    codigoBarras: '34191.79001 01043.510047 91020.150008 7 98300000025000',
    pixCopiaECola: '00020126580014br.gov.bcb.pix0136contabgest.financeiro@contabgest.com.br52040000530398654070250.005802BR5920CONTABGEST AUDITORIA6009SAO PAULO62070503***6304F2D8',
    reciboEmitido: false,
    historicoEnvios: [
      {
        id: 'env-6',
        canal: 'whatsapp',
        dataEnvio: '2026-08-30T10:00:00Z',
        destinatario: '(11) 99888-7766',
        status: 'lido',
      },
      {
        id: 'env-7',
        canal: 'whatsapp',
        dataEnvio: '2026-09-08T15:00:00Z',
        destinatario: '(11) 99888-7766',
        status: 'entregue',
      },
    ],
    observacao: 'Lembrete de atraso enviado via WhatsApp.',
    isDemo: true,
  },
  {
    id: 'mens-202609-5',
    contratoId: 'cont-5',
    empresaId: 'emp-5',
    competencia: '09/2026',
    dataVencimento: '2026-09-10',
    dataPagamento: '2026-09-10',
    valor: 220.0,
    valorPago: 220.0,
    status: 'pago',
    formaPagamento: 'pix',
    codigoBarras: '23793.38128 60000.123456 01000.987654 3 98350000022000',
    pixCopiaECola: '00020126580014br.gov.bcb.pix0136contabgest.financeiro@contabgest.com.br52040000530398654070220.005802BR5920CONTABGEST AUDITORIA6009SAO PAULO62070503***6304A1B2',
    reciboEmitido: true,
    reciboId: 'rec-202609-5',
    reciboNumero: 'REC-2026/095',
    historicoEnvios: [
      {
        id: 'env-8',
        canal: 'whatsapp',
        dataEnvio: '2026-09-03T16:20:00Z',
        destinatario: '(11) 98111-2233',
        status: 'lido',
      },
    ],
    observacao: 'PIX compensado no mesmo dia.',
    isDemo: true,
  },

  // --- Competência 08/2026 (Mês Anterior - 100% Baixado) ---
  {
    id: 'mens-202608-1',
    contratoId: 'cont-1',
    empresaId: 'emp-1',
    competencia: '08/2026',
    dataVencimento: '2026-08-10',
    dataPagamento: '2026-08-10',
    valor: 1850.0,
    valorPago: 1850.0,
    status: 'pago',
    formaPagamento: 'pix',
    reciboEmitido: true,
    reciboId: 'rec-202608-1',
    reciboNumero: 'REC-2026/081',
    historicoEnvios: [],
    isDemo: true,
  },
  {
    id: 'mens-202608-2',
    contratoId: 'cont-2',
    empresaId: 'emp-2',
    competencia: '08/2026',
    dataVencimento: '2026-08-15',
    dataPagamento: '2026-08-14',
    valor: 2400.0,
    valorPago: 2400.0,
    status: 'pago',
    formaPagamento: 'boleto',
    reciboEmitido: true,
    reciboId: 'rec-202608-2',
    reciboNumero: 'REC-2026/082',
    historicoEnvios: [],
    isDemo: true,
  },
  {
    id: 'mens-202608-3',
    contratoId: 'cont-3',
    empresaId: 'emp-3',
    competencia: '08/2026',
    dataVencimento: '2026-08-20',
    dataPagamento: '2026-08-19',
    valor: 1450.0,
    valorPago: 1450.0,
    status: 'pago',
    formaPagamento: 'transferencia',
    reciboEmitido: true,
    reciboId: 'rec-202608-3',
    reciboNumero: 'REC-2026/083',
    historicoEnvios: [],
    isDemo: true,
  },
  {
    id: 'mens-202608-4',
    contratoId: 'cont-4',
    empresaId: 'emp-4',
    competencia: '08/2026',
    dataVencimento: '2026-08-05',
    dataPagamento: '2026-08-05',
    valor: 250.0,
    valorPago: 250.0,
    status: 'pago',
    formaPagamento: 'pix',
    reciboEmitido: true,
    reciboId: 'rec-202608-4',
    reciboNumero: 'REC-2026/084',
    historicoEnvios: [],
    isDemo: true,
  },
  {
    id: 'mens-202608-5',
    contratoId: 'cont-5',
    empresaId: 'emp-5',
    competencia: '08/2026',
    dataVencimento: '2026-08-10',
    dataPagamento: '2026-08-10',
    valor: 220.0,
    valorPago: 220.0,
    status: 'pago',
    formaPagamento: 'pix',
    reciboEmitido: true,
    reciboId: 'rec-202608-5',
    reciboNumero: 'REC-2026/085',
    historicoEnvios: [],
    isDemo: true,
  },
];

export const RECIBOS_HONORARIOS_PADRAO: ReciboHonorario[] = [
  {
    id: 'rec-202609-1',
    numero: 'REC-2026/091',
    mensalidadeId: 'mens-202609-1',
    contratoId: 'cont-1',
    empresaId: 'emp-1',
    razaoSocialCliente: 'Alpha Tech Sistemas e Consultoria Ltda',
    nomeFantasiaCliente: 'Alpha Tech',
    cnpjCpfCliente: '12.345.678/0001-90',
    enderecoCliente: 'Av. Paulista, 1000 - Bela Vista, São Paulo/SP - CEP: 01310-100',
    valor: 1850.0,
    valorPorExtenso: 'Um mil, oitocentos e cinquenta reais',
    competencia: '09/2026',
    dataEmissao: '2026-09-09',
    dataPagamento: '2026-09-09',
    formaPagamento: 'PIX (Chave CNPJ)',
    discriminacaoServicos: [
      'Escrituração Contábil e Balanço Anual',
      'Escrituração Fiscal e Apuração Simples Nacional (PGDAS-D)',
      'Folha de Pagamento & eSocial (DP)',
      'Monitoramento Fiscal Contínuo e Emissão de CNDs',
    ],
    nomeEscritorio: 'ContabGest Assessoria e Auditoria Contábil S/S',
    cnpjEscritorio: '45.879.123/0001-44',
    enderecoEscritorio: 'Rua Funchal, 418 - Vila Olímpia, São Paulo/SP - CEP: 04551-060',
    contadorResponsavel: 'Roberto Simões Santos',
    crcContador: 'CRC-SP 1SP234567/O-8',
  },
  {
    id: 'rec-202609-2',
    numero: 'REC-2026/092',
    mensalidadeId: 'mens-202609-2',
    contratoId: 'cont-2',
    empresaId: 'emp-2',
    razaoSocialCliente: 'Comércio de Materiais Silva & Santos Ltda',
    nomeFantasiaCliente: 'Silva & Santos Comércio',
    cnpjCpfCliente: '23.456.789/0001-01',
    enderecoCliente: 'Rua das Flores, 450 - Centro, Guarulhos/SP - CEP: 07010-010',
    valor: 2400.0,
    valorPorExtenso: 'Dois mil e quatrocentos reais',
    competencia: '09/2026',
    dataEmissao: '2026-09-15',
    dataPagamento: '2026-09-15',
    formaPagamento: 'Boleto Bancário Liquidado',
    discriminacaoServicos: [
      'Escrituração Contábil e Balanço Anual',
      'Escrituração Fiscal Lucro Presumido / Real (SPED Fiscal & EFD)',
      'Folha de Pagamento & eSocial (DP)',
      'BPO Financeiro (Gestão de Contas a Pagar e Receber)',
    ],
    nomeEscritorio: 'ContabGest Assessoria e Auditoria Contábil S/S',
    cnpjEscritorio: '45.879.123/0001-44',
    enderecoEscritorio: 'Rua Funchal, 418 - Vila Olímpia, São Paulo/SP - CEP: 04551-060',
    contadorResponsavel: 'Roberto Simões Santos',
    crcContador: 'CRC-SP 1SP234567/O-8',
  },
  {
    id: 'rec-202609-5',
    numero: 'REC-2026/095',
    mensalidadeId: 'mens-202609-5',
    contratoId: 'cont-5',
    empresaId: 'emp-5',
    razaoSocialCliente: 'Isabella Costa 98765432100',
    nomeFantasiaCliente: 'Bella Estética MEI',
    cnpjCpfCliente: '56.789.012/0001-34',
    enderecoCliente: 'Rua Augusta, 1200 - Consolação, São Paulo/SP - CEP: 01304-001',
    valor: 220.0,
    valorPorExtenso: 'Duzentos e vinte reais',
    competencia: '09/2026',
    dataEmissao: '2026-09-10',
    dataPagamento: '2026-09-10',
    formaPagamento: 'PIX Instantâneo',
    discriminacaoServicos: [
      'Gestão Completa e Fechamento MEI (PGMEI & DAS-MEI)',
      'Declaração Anual do MEI (DASN-SIMEI)',
      'Monitoramento Fiscal Contínuo e Emissão de CNDs',
    ],
    nomeEscritorio: 'ContabGest Assessoria e Auditoria Contábil S/S',
    cnpjEscritorio: '45.879.123/0001-44',
    enderecoEscritorio: 'Rua Funchal, 418 - Vila Olímpia, São Paulo/SP - CEP: 04551-060',
    contadorResponsavel: 'Roberto Simões Santos',
    crcContador: 'CRC-SP 1SP234567/O-8',
  },
];

/**
 * Utilitário para conversão de números monetários para texto por extenso em Português
 */
export function valorPorExtenso(valor: number): string {
  if (!valor || isNaN(valor)) return 'Zero reais';
  const inteiros = Math.floor(valor);
  const centavos = Math.round((valor - inteiros) * 100);

  const unidades = ['', 'um', 'dois', 'três', 'quatro', 'cinco', 'seis', 'sete', 'oito', 'nove'];
  const dezenasEspeciais = [
    'dez',
    'onze',
    'doze',
    'treze',
    'quatorze',
    'quinze',
    'dezesseis',
    'dezessete',
    'dezoito',
    'dezenove',
  ];
  const dezenas = [
    '',
    '',
    'vinte',
    'trinta',
    'quarenta',
    'cinquenta',
    'sessenta',
    'setenta',
    'oitenta',
    'noventa',
  ];
  const centenas = [
    '',
    'cento',
    'duzentos',
    'trezentos',
    'quatrocentos',
    'quinhentos',
    'seiscentos',
    'setecentos',
    'oitocentos',
    'novecentos',
  ];

  function converteCentena(n: number): string {
    if (n === 100) return 'cem';
    const c = Math.floor(n / 100);
    const d = Math.floor((n % 100) / 10);
    const u = n % 10;
    const partes: string[] = [];

    if (c > 0) partes.push(centenas[c]);
    if (d === 1) {
      partes.push(dezenasEspeciais[u]);
    } else {
      if (d > 1) partes.push(dezenas[d]);
      if (u > 0) partes.push(unidades[u]);
    }
    return partes.join(' e ');
  }

  let textoReais = '';
  if (inteiros === 0) {
    textoReais = '';
  } else if (inteiros < 1000) {
    textoReais = `${converteCentena(inteiros)} ${inteiros === 1 ? 'real' : 'reais'}`;
  } else {
    const milhares = Math.floor(inteiros / 1000);
    const resto = inteiros % 1000;
    const textoMilhares = milhares === 1 ? 'um mil' : `${converteCentena(milhares)} mil`;
    if (resto === 0) {
      textoReais = `${textoMilhares} reais`;
    } else {
      const conj = resto < 100 || resto % 100 === 0 ? ' e ' : ', ';
      textoReais = `${textoMilhares}${conj}${converteCentena(resto)} reais`;
    }
  }

  let textoCentavos = '';
  if (centavos > 0) {
    const palavraCentavos = centavos === 1 ? 'centavo' : 'centavos';
    textoCentavos = `${converteCentena(centavos)} ${palavraCentavos}`;
  }

  if (textoReais && textoCentavos) {
    return (textoReais.charAt(0).toUpperCase() + textoReais.slice(1) + ' e ' + textoCentavos);
  }
  if (textoReais) {
    return textoReais.charAt(0).toUpperCase() + textoReais.slice(1);
  }
  if (textoCentavos) {
    return textoCentavos.charAt(0).toUpperCase() + textoCentavos.slice(1);
  }
  return 'Zero reais';
}
