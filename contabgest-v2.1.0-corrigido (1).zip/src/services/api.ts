import {
  User,
  Empresa,
  Cliente,
  Socio,
  Obrigacao,
  Documento,
  Certidao,
  Tarefa,
  ContaPagar,
  ContaReceber,
  CategoriaFinanceira,
  NotaFiscal,
  NotaFiscalEntrada,
  TipoManifestacaoDestinatario,
  StatusEscrituracaoEntrada,
  SincronizacaoSefazLog,
  CertificadoDigital,
  PendenciaEcac,
  AlvaraLicenca,
  DashboardMetrics,
  DatabaseStats,
  DatabaseTableKey,
  FuncaoRH,
  Funcionario,
  HoleriteCalculado,
  RegistroPontoDia,
  MarcacaoPonto,
  EspelhoPontoMensal,
  TipoBatidaPonto,
  StatusAuditoriaPonto,
  ComprovantePontoEmitido,
  PeriodoGozoFerias,
  PeriodoAquisitivoHistorico,
  AlertaFeriasItem,
  PainelAvisosFeriasResponse,
  DocumentoAvisoReciboFerias,
  RescisaoContratualRegistro,
  CalculoRescisaoResultado,
  DocumentoTRCT,
  ESocialConfiguracao,
  EventoESocialRegistro,
  FechamentoFolhaESocialPainel,
  InconsistenciaValidacaoESocial,
  ApuracaoSimplesNacional,
  GuiaDasMei,
  DeclaracaoAnualMei,
  BackupSchedule,
  BackupHistoryItem,
  ServicoContabil,
  ContratoHonorario,
  MensalidadeHonorario,
  ReciboHonorario,
} from '../types';

// Configuração de URL base para suporte a provedores de hospedagem (Vercel, Netlify, Cloud Run)
const API_BASE_URL = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');

// Interceptador transparente de fetch para suportar backend externo ou relativo
const originalFetch = window.fetch.bind(window);
const fetch: typeof window.fetch = (input: RequestInfo | URL, init?: RequestInit) => {
  const url = typeof input === 'string' ? input : input.toString();
  const isApiRequest = url.startsWith('/api') || url.startsWith(API_BASE_URL + '/api');
  const headers = new Headers(init?.headers || {});
  const token = localStorage.getItem('contabgest_token') || sessionStorage.getItem('contabgest_token');
  if (isApiRequest && token && !headers.has('Authorization')) headers.set('Authorization', `Bearer ${token}`);
  const nextInit = { ...init, headers };
  const requestPromise = (typeof input === 'string' && input.startsWith('/api') && API_BASE_URL)
    ? originalFetch(`${API_BASE_URL}${input}`, nextInit)
    : originalFetch(input, nextInit);
  return requestPromise.then((response) => {
    if (response.status === 401 && !url.includes('/api/auth/login')) {
      localStorage.removeItem('contabgest_token');
      localStorage.removeItem('contabgest_user');
    }
    return response;
  });
};

export const api = {
  // Auth
  async login(email: string, password?: string): Promise<{ success: boolean; user: User; token: string }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Falha no login' }));
      throw new Error(err.error || 'Credenciais inválidas');
    }
    return res.json();
  },

  async logout(): Promise<void> {
    try { await fetch('/api/auth/logout', { method: 'POST' }); } finally { localStorage.removeItem('contabgest_token'); localStorage.removeItem('contabgest_user'); sessionStorage.removeItem('contabgest_token'); sessionStorage.removeItem('contabgest_user'); }
  },

  async getCurrentUser(): Promise<User> {
    const res = await fetch('/api/auth/me');
    if (!res.ok) throw new Error('Usuário não autenticado');
    const data = await res.json();
    return data.user;
  },

  // Dashboard
  async getDashboardMetrics(empresaId?: string): Promise<DashboardMetrics> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/dashboard?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/dashboard';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao obter métricas do dashboard');
    return res.json();
  },

  // Empresas
  async getEmpresas(): Promise<Empresa[]> {
    const res = await fetch('/api/empresas');
    if (!res.ok) throw new Error('Erro ao listar empresas');
    return res.json();
  },

  async createEmpresa(empresa: Omit<Empresa, 'id' | 'isDemo'>): Promise<Empresa> {
    const res = await fetch('/api/empresas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(empresa),
    });
    if (!res.ok) throw new Error('Erro ao cadastrar empresa');
    return res.json();
  },

  // Clientes
  async getClientes(empresaId?: string): Promise<Cliente[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/clientes?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/clientes';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao listar clientes');
    return res.json();
  },

  // Sócios
  async getSocios(empresaId?: string): Promise<Socio[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/socios?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/socios';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao listar sócios');
    return res.json();
  },

  // Obrigações
  async getObrigacoes(empresaId?: string): Promise<Obrigacao[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/obrigacoes?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/obrigacoes';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao listar obrigações');
    return res.json();
  },

  async updateObrigacaoStatus(id: string, status: Obrigacao['status']): Promise<Obrigacao> {
    const res = await fetch(`/api/obrigacoes/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (!res.ok) throw new Error('Erro ao atualizar status da obrigação');
    return res.json();
  },

  // Documentos
  async getDocumentos(empresaId?: string): Promise<Documento[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/documentos?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/documentos';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao listar documentos');
    return res.json();
  },

  async addDocumento(doc: Omit<Documento, 'id'>): Promise<Documento> {
    const res = await fetch('/api/documentos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(doc),
    });
    if (!res.ok) throw new Error('Erro ao registrar documento');
    return res.json();
  },

  // Certidões
  async getCertidoes(empresaId?: string): Promise<Certidao[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/certidoes?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/certidoes';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao listar certidões');
    return res.json();
  },

  // Tarefas
  async getTarefas(empresaId?: string): Promise<Tarefa[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/tarefas?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/tarefas';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao listar tarefas');
    return res.json();
  },

  async updateTarefaStatus(id: string, status: Tarefa['status']): Promise<Tarefa> {
    const res = await fetch(`/api/tarefas/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (!res.ok) throw new Error('Erro ao atualizar status da tarefa');
    return res.json();
  },

  // Financeiro
  async getContasPagar(empresaId?: string): Promise<ContaPagar[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/financeiro/contas-pagar?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/financeiro/contas-pagar';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao buscar contas a pagar');
    return res.json();
  },

  async getContasReceber(empresaId?: string): Promise<ContaReceber[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/financeiro/contas-receber?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/financeiro/contas-receber';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao buscar contas a receber');
    return res.json();
  },

  async getCategoriasFinanceiras(): Promise<CategoriaFinanceira[]> {
    const res = await fetch('/api/financeiro/categorias');
    if (!res.ok) throw new Error('Erro ao listar categorias financeiras');
    return res.json();
  },

  // Notas Fiscais Eletrônicas
  async getNotasFiscais(empresaId?: string): Promise<NotaFiscal[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/notas-fiscais?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/notas-fiscais';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao buscar notas fiscais');
    return res.json();
  },

  async createNotaFiscal(nota: Omit<NotaFiscal, 'id' | 'isDemo' | 'chaveAcesso'>): Promise<NotaFiscal> {
    const res = await fetch('/api/notas-fiscais', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(nota),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao emitir nota fiscal' }));
      throw new Error(err.error || 'Erro ao emitir nota fiscal');
    }
    return res.json();
  },

  async cancelarNotaFiscal(id: string, motivo: string): Promise<NotaFiscal> {
    const res = await fetch(`/api/notas-fiscais/${encodeURIComponent(id)}/cancelar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ motivo }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao cancelar nota fiscal' }));
      throw new Error(err.error || 'Erro ao cancelar nota fiscal');
    }
    return res.json();
  },

  async importarXmlSaida(empresaId: string, xmlContent: string): Promise<NotaFiscal> {
    const res = await fetch('/api/notas-fiscais/importar-xml-saida', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId, xmlContent }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao importar XML de saída modelo 55' }));
      throw new Error(err.error || 'Erro ao importar XML de saída modelo 55');
    }
    return res.json();
  },

  async importarLoteXmlSaida(
    empresaId: string,
    xmlContents: string[]
  ): Promise<{ importadas: NotaFiscal[]; totalImportadas: number; valorTotal: number }> {
    const res = await fetch('/api/notas-fiscais/importar-lote-xml-saida', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId, xmlContents }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao importar lote de XMLs de saída' }));
      throw new Error(err.error || 'Erro ao importar lote de XMLs de saída');
    }
    return res.json();
  },

  // --- SEFAZ DF-e: Captura & Gestão de Notas Emitidas Contra o CNPJ ---
  async getNotasFiscaisEntrada(empresaId?: string): Promise<NotaFiscalEntrada[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/notas-fiscais-entrada?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/notas-fiscais-entrada';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao buscar notas fiscais de entrada');
    return res.json();
  },

  async getNotaEntradaById(id: string): Promise<NotaFiscalEntrada> {
    const res = await fetch(`/api/notas-fiscais-entrada/${encodeURIComponent(id)}`);
    if (!res.ok) throw new Error('Erro ao carregar detalhes da nota fiscal de entrada');
    return res.json();
  },

  async capturarNotaPorChave(
    empresaId: string,
    chaveAcesso: string,
    efetuarCiencia = true
  ): Promise<NotaFiscalEntrada> {
    const res = await fetch('/api/notas-fiscais-entrada/capturar-chave', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId, chaveAcesso, efetuarCiencia }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao consultar chave na SEFAZ' }));
      throw new Error(err.error || 'Erro ao consultar chave na SEFAZ');
    }
    return res.json();
  },

  async sincronizarEntradasSefaz(empresaId: string): Promise<{
    novasNotas: NotaFiscalEntrada[];
    totalConsultadas: number;
    log: SincronizacaoSefazLog;
  }> {
    const res = await fetch('/api/notas-fiscais-entrada/sincronizar-sefaz', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao sincronizar com a SEFAZ' }));
      throw new Error(err.error || 'Erro ao sincronizar com a SEFAZ');
    }
    return res.json();
  },

  async importarXmlEntrada(empresaId: string, xmlContent: string): Promise<NotaFiscalEntrada> {
    const res = await fetch('/api/notas-fiscais-entrada/importar-xml', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId, xmlContent }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao importar arquivo XML' }));
      throw new Error(err.error || 'Erro ao importar arquivo XML');
    }
    return res.json();
  },

  async manifestarNotaEntrada(
    id: string,
    manifestacao: TipoManifestacaoDestinatario,
    justificativa?: string
  ): Promise<NotaFiscalEntrada> {
    const res = await fetch(`/api/notas-fiscais-entrada/${encodeURIComponent(id)}/manifestar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ manifestacao, justificativa }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao manifestar nota fiscal na SEFAZ' }));
      throw new Error(err.error || 'Erro ao manifestar nota fiscal na SEFAZ');
    }
    return res.json();
  },

  async updateStatusEscrituracaoEntrada(
    id: string,
    statusEscrituracao: StatusEscrituracaoEntrada
  ): Promise<NotaFiscalEntrada> {
    const res = await fetch(`/api/notas-fiscais-entrada/${encodeURIComponent(id)}/status-escrituracao`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ statusEscrituracao }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao atualizar escrituração contábil' }));
      throw new Error(err.error || 'Erro ao atualizar escrituração contábil');
    }
    return res.json();
  },

  async getSincronizacoesSefaz(empresaId?: string): Promise<SincronizacaoSefazLog[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/sefaz/sincronizacoes?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/sefaz/sincronizacoes';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao buscar logs de sincronização SEFAZ');
    return res.json();
  },

  // Certificados Digitais
  async getCertificados(empresaId?: string): Promise<CertificadoDigital[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/certificados?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/certificados';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao buscar certificados digitais');
    return res.json();
  },

  async createCertificado(cert: Omit<CertificadoDigital, 'id' | 'isDemo'>): Promise<CertificadoDigital> {
    const res = await fetch('/api/certificados', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cert),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao cadastrar certificado' }));
      throw new Error(err.error || 'Erro ao cadastrar certificado');
    }
    return res.json();
  },

  async instalarCertificado(id: string, senhaSalva: boolean = true): Promise<CertificadoDigital> {
    const res = await fetch(`/api/certificados/${encodeURIComponent(id)}/instalar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ senhaSalva }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao instalar certificado digital' }));
      throw new Error(err.error || 'Erro ao instalar certificado digital');
    }
    return res.json();
  },

  // e-CAC & Receita Federal
  async getPendenciasEcac(empresaId?: string): Promise<PendenciaEcac[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/ecac/pendencias?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/ecac/pendencias';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao buscar pendências do e-CAC');
    return res.json();
  },

  async resolverPendenciaEcac(id: string, protocolo?: string): Promise<PendenciaEcac> {
    const res = await fetch(`/api/ecac/pendencias/${encodeURIComponent(id)}/resolver`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ protocolo }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao resolver pendência' }));
      throw new Error(err.error || 'Erro ao resolver pendência');
    }
    return res.json();
  },

  async sincronizarReceitaFederal(empresaId?: string): Promise<{ sincronizadoEm: string; totalConsultadas: number; novasPendencias: number }> {
    const res = await fetch('/api/ecac/sincronizar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId }),
    });
    if (!res.ok) throw new Error('Erro ao sincronizar com e-CAC / Receita Federal');
    return res.json();
  },

  // =========================================================================
  // --- ALVARÁS E LICENÇAS ---
  // =========================================================================

  async getAlvaras(empresaId?: string): Promise<AlvaraLicenca[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/alvaras?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/alvaras';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao buscar alvarás e licenças');
    return res.json();
  },

  async createAlvara(alvara: Omit<AlvaraLicenca, 'id' | 'isDemo'>): Promise<AlvaraLicenca> {
    const res = await fetch('/api/alvaras', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(alvara),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao cadastrar alvará/licença' }));
      throw new Error(err.error || 'Erro ao cadastrar alvará/licença');
    }
    return res.json();
  },

  async updateAlvara(id: string, updates: Partial<AlvaraLicenca>): Promise<AlvaraLicenca> {
    const res = await fetch(`/api/alvaras/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao atualizar alvará/licença' }));
      throw new Error(err.error || 'Erro ao atualizar alvará/licença');
    }
    return res.json();
  },

  async deleteAlvara(id: string): Promise<boolean> {
    const res = await fetch(`/api/alvaras/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao excluir alvará/licença' }));
      throw new Error(err.error || 'Erro ao excluir alvará/licença');
    }
    return true;
  },

  async renovarAlvara(id: string, protocolo: string, dataSolicitacao?: string): Promise<AlvaraLicenca> {
    const res = await fetch(`/api/alvaras/${encodeURIComponent(id)}/renovar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ protocolo, dataSolicitacao }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao registrar renovação de alvará' }));
      throw new Error(err.error || 'Erro ao registrar renovação de alvará');
    }
    return res.json();
  },

  // =========================================================================
  // --- RECURSOS HUMANOS E DEPARTAMENTO PESSOAL (RH & DP) ---
  // =========================================================================

  async getFuncoes(empresaId?: string): Promise<FuncaoRH[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/funcoes?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/funcoes';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao listar funções de RH');
    return res.json();
  },

  async createFuncao(funcao: Omit<FuncaoRH, 'id' | 'isDemo'>): Promise<FuncaoRH> {
    const res = await fetch('/api/funcoes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(funcao),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao cadastrar função' }));
      throw new Error(err.error || 'Erro ao cadastrar função');
    }
    return res.json();
  },

  async updateFuncao(id: string, updates: Partial<FuncaoRH>): Promise<FuncaoRH> {
    const res = await fetch(`/api/funcoes/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao atualizar função' }));
      throw new Error(err.error || 'Erro ao atualizar função');
    }
    return res.json();
  },

  async deleteFuncao(id: string): Promise<boolean> {
    const res = await fetch(`/api/funcoes/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao excluir função' }));
      throw new Error(err.error || 'Erro ao excluir função');
    }
    return true;
  },

  async getFuncionarios(empresaId?: string): Promise<Funcionario[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/funcionarios?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/funcionarios';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao listar funcionários');
    return res.json();
  },

  async getFuncionarioById(id: string): Promise<Funcionario> {
    const res = await fetch(`/api/funcionarios/${encodeURIComponent(id)}`);
    if (!res.ok) throw new Error('Funcionário não encontrado');
    return res.json();
  },

  async createFuncionario(func: Omit<Funcionario, 'id' | 'isDemo'>): Promise<Funcionario> {
    const res = await fetch('/api/funcionarios', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(func),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao cadastrar funcionário' }));
      throw new Error(err.error || 'Erro ao cadastrar funcionário');
    }
    return res.json();
  },

  async updateFuncionario(id: string, updates: Partial<Funcionario>): Promise<Funcionario> {
    const res = await fetch(`/api/funcionarios/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao atualizar funcionário' }));
      throw new Error(err.error || 'Erro ao atualizar funcionário');
    }
    return res.json();
  },

  async deleteFuncionario(id: string): Promise<boolean> {
    const res = await fetch(`/api/funcionarios/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao excluir funcionário' }));
      throw new Error(err.error || 'Erro ao excluir funcionário');
    }
    return true;
  },

  async registrarFeriasFuncionario(
    id: string,
    dias: number,
    dataInicio: string,
    dataFim: string
  ): Promise<Funcionario> {
    const res = await fetch(`/api/funcionarios/${encodeURIComponent(id)}/ferias`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dias, dataInicio, dataFim }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao registrar férias' }));
      throw new Error(err.error || 'Erro ao registrar férias');
    }
    return res.json();
  },

  async registrarAfastamentoFuncionario(id: string, motivo: string): Promise<Funcionario> {
    const res = await fetch(`/api/funcionarios/${encodeURIComponent(id)}/afastamento`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ motivo }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao registrar afastamento' }));
      throw new Error(err.error || 'Erro ao registrar afastamento');
    }
    return res.json();
  },

  async getHoleriteFuncionario(id: string, competencia?: string): Promise<{ funcionario: Funcionario; holerite: HoleriteCalculado }> {
    const url = competencia
      ? `/api/funcionarios/${encodeURIComponent(id)}/holerite?competencia=${encodeURIComponent(competencia)}`
      : `/api/funcionarios/${encodeURIComponent(id)}/holerite`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao calcular holerite do funcionário');
    return res.json();
  },

  async getFolhaPagamentoSimulada(empresaId?: string, competencia?: string): Promise<{
    competencia: string;
    totalFuncionarios: number;
    totalSalarioBase: number;
    totalBruto: number;
    totalDescontos: number;
    totalLiquido: number;
    totalInssEmpregados: number;
    totalIrrf: number;
    totalFgts: number;
    inssPatronalEstimado: number;
    holerites: Array<{ funcionario: Funcionario; holerite: HoleriteCalculado }>;
  }> {
    const params = new URLSearchParams();
    if (empresaId && empresaId !== 'todas') params.append('empresaId', empresaId);
    if (competencia) params.append('competencia', competencia);
    const url = `/api/folha-pagamento/simulacao${params.toString() ? `?${params.toString()}` : ''}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao simular folha de pagamento');
    return res.json();
  },

  async fecharFolhaPagamento(payload: {
    empresaId?: string;
    competencia: string;
    totalLiquido: number;
    totalInss: number;
    totalFgts: number;
  }): Promise<{ success: boolean; message: string; contasCriadas: any[] }> {
    const res = await fetch('/api/folha-pagamento/fechar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao fechar folha de pagamento' }));
      throw new Error(err.error || 'Erro ao fechar folha de pagamento');
    }
    return res.json();
  },

  // =========================================================================
  // --- PONTO ELETRÔNICO & AUDITORIA DE JORNADA (REP-P / PORTARIA 671 MTE) ---
  // =========================================================================

  async getPontos(filtros: {
    empresaId?: string;
    funcionarioId?: string;
    dataInicio?: string;
    dataFim?: string;
    competencia?: string;
    status?: string;
    inconsistenciasApenas?: boolean;
  } = {}): Promise<RegistroPontoDia[]> {
    const params = new URLSearchParams();
    if (filtros.empresaId && filtros.empresaId !== 'todas') params.append('empresaId', filtros.empresaId);
    if (filtros.funcionarioId && filtros.funcionarioId !== 'todos') params.append('funcionarioId', filtros.funcionarioId);
    if (filtros.competencia) params.append('competencia', filtros.competencia);
    if (filtros.dataInicio) params.append('dataInicio', filtros.dataInicio);
    if (filtros.dataFim) params.append('dataFim', filtros.dataFim);
    if (filtros.status && filtros.status !== 'todos') params.append('status', filtros.status);
    if (filtros.inconsistenciasApenas) params.append('inconsistenciasApenas', 'true');

    const url = `/api/pontos${params.toString() ? `?${params.toString()}` : ''}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao listar registros de ponto');
    return res.json();
  },

  async getPontosHoje(empresaId?: string): Promise<{
    dataHoje: string;
    totalFuncionarios: number;
    trabalhandoAgora: number;
    emIntervalo: number;
    expedienteConcluido: number;
    semRegistro: number;
    comInconsistencia: number;
    registros: RegistroPontoDia[];
    colaboradoresSemRegistro: Funcionario[];
  }> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/pontos/hoje?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/pontos/hoje';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao carregar monitor de jornada');
    return res.json();
  },

  async baterPonto(dados: {
    funcionarioId: string;
    tipo: TipoBatidaPonto;
    dataHora?: string;
    geolocalizacao?: {
      latitude: number;
      longitude: number;
      precisao?: number;
      endereco?: string;
    };
    fotoComprovante?: string;
    observacao?: string;
    origem?: string;
  }): Promise<{
    success: boolean;
    message: string;
    marcacao: MarcacaoPonto;
    pontoDia: RegistroPontoDia;
    comprovante: ComprovantePontoEmitido;
  }> {
    const res = await fetch('/api/pontos/bater', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao registrar ponto' }));
      throw new Error(err.error || 'Erro ao registrar ponto');
    }
    return res.json();
  },

  async ajustarPontoDia(
    id: string,
    ajustes: {
      entrada1?: string;
      saidaIntervalo?: string;
      retornoIntervalo?: string;
      saida2?: string;
      motivoAjuste: string;
      observacaoRH?: string;
      auditadoPor: string;
      statusAuditoria?: StatusAuditoriaPonto;
    }
  ): Promise<{ success: boolean; message: string; ponto: RegistroPontoDia }> {
    const res = await fetch(`/api/pontos/${encodeURIComponent(id)}/ajuste`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(ajustes),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao ajustar ponto' }));
      throw new Error(err.error || 'Erro ao ajustar ponto');
    }
    return res.json();
  },

  async auditarPontoDia(
    id: string,
    dados: {
      status: StatusAuditoriaPonto;
      observacaoRH?: string;
      auditadoPor: string;
    }
  ): Promise<{ success: boolean; message: string; ponto: RegistroPontoDia }> {
    const res = await fetch(`/api/pontos/${encodeURIComponent(id)}/auditar`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao auditar ponto' }));
      throw new Error(err.error || 'Erro ao auditar ponto');
    }
    return res.json();
  },

  async homologarPontosLote(dados: {
    empresaId?: string;
    competencia?: string;
    apenasSemInconsistencia?: boolean;
    auditadoPor?: string;
  }): Promise<{ success: boolean; message: string; totalHomologados: number }> {
    const res = await fetch('/api/pontos/homologar-lote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao homologar pontos em lote' }));
      throw new Error(err.error || 'Erro ao homologar pontos em lote');
    }
    return res.json();
  },

  async getEspelhoPonto(funcionarioId: string, competencia?: string): Promise<EspelhoPontoMensal> {
    const params = new URLSearchParams({ funcionarioId });
    if (competencia) params.append('competencia', competencia);
    const res = await fetch(`/api/pontos/espelho?${params.toString()}`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao gerar espelho de ponto' }));
      throw new Error(err.error || 'Erro ao gerar espelho de ponto');
    }
    return res.json();
  },

  // =========================================================================
  // --- ADMINISTRAÇÃO DO BANCO DE DADOS ---
  // =========================================================================

  async getDatabaseStats(): Promise<DatabaseStats> {
    const res = await fetch('/api/database/stats');
    if (!res.ok) throw new Error('Erro ao obter estatísticas do banco de dados');
    return res.json();
  },

  async getDatabaseDump(): Promise<any> {
    const res = await fetch('/api/database/dump');
    if (!res.ok) throw new Error('Erro ao baixar dump do banco de dados');
    return res.json();
  },

  async getBackupSchedules(): Promise<BackupSchedule[]> {
    const res = await fetch('/api/database/backup/schedules');
    if (!res.ok) throw new Error('Erro ao buscar agendamentos de backup');
    return res.json();
  },

  async saveBackupSchedule(schedule: Partial<BackupSchedule>): Promise<BackupSchedule> {
    const res = await fetch('/api/database/backup/schedules', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(schedule),
    });
    if (!res.ok) throw new Error('Erro ao salvar agendamento de backup');
    return res.json();
  },

  async deleteBackupSchedule(id: string): Promise<boolean> {
    const res = await fetch(`/api/database/backup/schedules/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
    if (!res.ok) throw new Error('Erro ao remover agendamento de backup');
    return res.json();
  },

  async getBackupHistory(): Promise<BackupHistoryItem[]> {
    const res = await fetch('/api/database/backup/history');
    if (!res.ok) throw new Error('Erro ao buscar histórico de backups');
    return res.json();
  },

  async executarBackup(params: {
    formato: 'json' | 'csv';
    destino?: string;
    scheduleId?: string;
    titulo?: string;
  }): Promise<{ item: BackupHistoryItem; dumpContent: string }> {
    const res = await fetch('/api/database/backup/executar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    if (!res.ok) throw new Error('Erro ao executar backup');
    return res.json();
  },

  async exportarDadosCsv(tabela?: string): Promise<{ nomeArquivo: string; conteudoCsv: string }[]> {
    const url = tabela
      ? `/api/database/backup/exportar-csv?tabela=${encodeURIComponent(tabela)}`
      : '/api/database/backup/exportar-csv';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao exportar dados em CSV');
    return res.json();
  },

  async getDatabaseTable(table: DatabaseTableKey): Promise<any[]> {
    const res = await fetch(`/api/database/tables/${table}`);
    if (!res.ok) throw new Error(`Erro ao obter registros da tabela ${table}`);
    return res.json();
  },

  async createDatabaseRecord(table: DatabaseTableKey, record: any): Promise<any> {
    const res = await fetch(`/api/database/tables/${table}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(record),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao criar registro' }));
      throw new Error(err.error || 'Erro ao criar registro');
    }
    return res.json();
  },

  async updateDatabaseRecord(table: DatabaseTableKey, id: string, updates: any): Promise<any> {
    const res = await fetch(`/api/database/tables/${table}/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao atualizar registro' }));
      throw new Error(err.error || 'Erro ao atualizar registro');
    }
    return res.json();
  },

  async deleteDatabaseRecord(table: DatabaseTableKey, id: string): Promise<boolean> {
    const res = await fetch(`/api/database/tables/${table}/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao excluir registro' }));
      throw new Error(err.error || 'Erro ao excluir registro');
    }
    return true;
  },

  async restoreDatabase(backupData: any): Promise<any> {
    const res = await fetch('/api/database/restore', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(backupData),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Falha ao restaurar banco de dados' }));
      throw new Error(err.error || 'Falha ao restaurar banco de dados');
    }
    return res.json();
  },

  async resetDatabase(): Promise<any> {
    const res = await fetch('/api/database/reset', {
      method: 'POST',
    });
    if (!res.ok) throw new Error('Erro ao resetar banco de dados');
    return res.json();
  },

  async setProductionMode(enabled: boolean = true, cleanLabels: boolean = true): Promise<{
    success: boolean;
    message: string;
    version: string;
    isDemoDatabase: boolean;
    cleanedCount: number;
  }> {
    const res = await fetch('/api/database/production-mode', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ enabled, cleanLabels }),
    });
    if (!res.ok) throw new Error('Erro ao atualizar modo de produção');
    return res.json();
  },

  async getSystemStatus(): Promise<{
    environment: string;
    version: string;
    readyForDeploy: boolean;
    timestamp: string;
    modules: Record<string, string>;
  }> {
    const res = await fetch('/api/system/status');
    if (!res.ok) throw new Error('Erro ao verificar status do sistema');
    return res.json();
  },

  // =========================================================================
  // --- GESTÃO DE FÉRIAS, AVISOS CLT & PERÍODOS AQUISITIVOS ---
  // =========================================================================

  async getPeriodosFerias(filtros: {
    empresaId?: string;
    funcionarioId?: string;
    status?: string;
    ano?: number;
  } = {}): Promise<PeriodoGozoFerias[]> {
    const params = new URLSearchParams();
    if (filtros.empresaId && filtros.empresaId !== 'todas') params.append('empresaId', filtros.empresaId);
    if (filtros.funcionarioId && filtros.funcionarioId !== 'todos') params.append('funcionarioId', filtros.funcionarioId);
    if (filtros.status && filtros.status !== 'todos') params.append('status', filtros.status);
    if (filtros.ano) params.append('ano', String(filtros.ano));

    const qs = params.toString();
    const res = await fetch(`/api/ferias${qs ? `?${qs}` : ''}`);
    if (!res.ok) throw new Error('Erro ao listar períodos de férias');
    return res.json();
  },

  async getPainelAvisosFerias(empresaId?: string): Promise<PainelAvisosFeriasResponse> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/ferias/painel-avisos?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/ferias/painel-avisos';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao obter painel de avisos de férias');
    return res.json();
  },

  async getCalculoSaldosPeriodosFuncionario(funcionarioId: string): Promise<{
    funcionario: Funcionario;
    periodos: PeriodoAquisitivoHistorico[];
    saldoTotalDisponivel: number;
    avisos: AlertaFeriasItem[];
  }> {
    const res = await fetch(`/api/ferias/funcionario/${encodeURIComponent(funcionarioId)}`);
    if (!res.ok) throw new Error('Erro ao obter dados de férias do funcionário');
    return res.json();
  },

  async simularCalculoFerias(params: {
    salarioBase: number;
    diasGozo: number;
    abonoPecuniario: boolean;
    diasAbono: number;
    adiantamentoDecimoTerceiro: boolean;
    dependentesIrrf?: number;
  }): Promise<{
    salarioBase: number;
    valorFeriasBruto: number;
    tercoConstitucional: number;
    valorAbono: number;
    tercoAbono: number;
    adiantamento13: number;
    inssFerias: number;
    irrfFerias: number;
    totalLiquido: number;
  }> {
    const res = await fetch('/api/ferias/calcular-simulacao', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao calcular simulação de férias' }));
      throw new Error(err.error || 'Erro ao calcular simulação de férias');
    }
    return res.json();
  },

  async registrarPeriodoGozo(dados: {
    funcionarioId: string;
    periodoAquisitivoInicio: string;
    periodoAquisitivoFim: string;
    limiteConcessivo: string;
    fracionamentoNumero: 1 | 2 | 3;
    dataInicio: string;
    dataFim: string;
    diasGozo: number;
    abonoPecuniario: boolean;
    diasAbono: number;
    adiantamentoDecimoTerceiro: boolean;
    dataAvisoFerias?: string;
    dataLimitePagamento?: string;
    observacoes?: string;
  }): Promise<{ success: boolean; message: string; periodo: PeriodoGozoFerias; funcionario: Funcionario }> {
    const res = await fetch('/api/ferias/registrar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao registrar férias' }));
      throw new Error(err.error || 'Erro ao registrar férias');
    }
    return res.json();
  },

  async cancelarPeriodoGozo(id: string): Promise<{ success: boolean; message: string; periodo: PeriodoGozoFerias }> {
    const res = await fetch(`/api/ferias/${encodeURIComponent(id)}/cancelar`, {
      method: 'POST',
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao cancelar férias' }));
      throw new Error(err.error || 'Erro ao cancelar férias');
    }
    return res.json();
  },

  async getDocumentoAvisoRecibo(periodoId: string): Promise<DocumentoAvisoReciboFerias> {
    const res = await fetch(`/api/ferias/${encodeURIComponent(periodoId)}/documento`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao emitir aviso/recibo de férias' }));
      throw new Error(err.error || 'Erro ao emitir aviso/recibo de férias');
    }
    return res.json();
  },

  // =========================================================================
  // --- RESCISÃO CONTRATUAL, CÁLCULO DE VERBAS & TRCT (CLT) ---
  // =========================================================================

  async getRescisoes(empresaId?: string, funcionarioId?: string): Promise<RescisaoContratualRegistro[]> {
    const params = new URLSearchParams();
    if (empresaId && empresaId !== 'todas') params.append('empresaId', empresaId);
    if (funcionarioId && funcionarioId !== 'todos') params.append('funcionarioId', funcionarioId);
    const queryString = params.toString() ? `?${params.toString()}` : '';
    const res = await fetch(`/api/rh/rescisoes${queryString}`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao buscar rescisões' }));
      throw new Error(err.error || 'Erro ao buscar rescisões');
    }
    return res.json();
  },

  async getRescisaoById(id: string): Promise<RescisaoContratualRegistro> {
    const res = await fetch(`/api/rh/rescisoes/${encodeURIComponent(id)}`);
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Rescisão não encontrada' }));
      throw new Error(err.error || 'Rescisão não encontrada');
    }
    return res.json();
  },

  async simularCalculoRescisao(dados: {
    funcionarioId: string;
    motivoRescisao: string;
    tipoAvisoPrevio: string;
    dataDesligamento: string;
    dataAvisoPrevio?: string;
    saldoFgtsInformado?: number;
    diasSaldoSalarioManual?: number;
    horasExtrasValor?: number;
    outrosAdicionaisValor?: number;
    faltasDsrValor?: number;
    outrosDescontosValor?: number;
    diasFeriasVencidasManual?: number;
  }): Promise<{ calculo: CalculoRescisaoResultado; trct: DocumentoTRCT; funcionario: Funcionario; empresa: Empresa }> {
    const res = await fetch('/api/rh/rescisoes/calcular', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao simular rescisão contratual' }));
      throw new Error(err.error || 'Erro ao simular rescisão contratual');
    }
    return res.json();
  },

  async salvarRescisao(dados: Partial<RescisaoContratualRegistro> & { atualizarStatusFuncionario?: boolean }): Promise<{
    success: boolean;
    message: string;
    rescisao: RescisaoContratualRegistro;
  }> {
    const res = await fetch('/api/rh/rescisoes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao salvar rescisão' }));
      throw new Error(err.error || 'Erro ao salvar rescisão');
    }
    return res.json();
  },

  async homologarRescisao(id: string): Promise<{ success: boolean; message: string; rescisao: RescisaoContratualRegistro }> {
    const res = await fetch(`/api/rh/rescisoes/${encodeURIComponent(id)}/homologar`, {
      method: 'POST',
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao homologar rescisão' }));
      throw new Error(err.error || 'Erro ao homologar rescisão');
    }
    return res.json();
  },

  async deleteRescisao(id: string): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`/api/rh/rescisoes/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao excluir rescisão' }));
      throw new Error(err.error || 'Erro ao excluir rescisão');
    }
    return res.json();
  },

  // --- MÓDULO ESOCIAL & FECHAMENTO DE FOLHA ---
  async getESocialConfiguracao(empresaId: string): Promise<ESocialConfiguracao> {
    const res = await fetch(`/api/esocial/configuracao/${encodeURIComponent(empresaId)}`);
    if (!res.ok) throw new Error('Erro ao carregar parâmetros do eSocial');
    return res.json();
  },

  async salvarESocialConfiguracao(
    empresaId: string,
    dados: Partial<ESocialConfiguracao>
  ): Promise<{ success: boolean; message: string; config: ESocialConfiguracao }> {
    const res = await fetch(`/api/esocial/configuracao/${encodeURIComponent(empresaId)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao salvar configurações do eSocial' }));
      throw new Error(err.error || 'Erro ao salvar configurações do eSocial');
    }
    return res.json();
  },

  async getESocialEventos(filtros?: {
    empresaId?: string;
    competencia?: string;
  }): Promise<EventoESocialRegistro[]> {
    const params = new URLSearchParams();
    if (filtros?.empresaId && filtros.empresaId !== 'todas') params.append('empresaId', filtros.empresaId);
    if (filtros?.competencia) params.append('competencia', filtros.competencia);

    const url = `/api/esocial/eventos${params.toString() ? `?${params.toString()}` : ''}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao carregar eventos do eSocial');
    return res.json();
  },

  async validarEventosPeriodicos(empresaId: string, competencia: string): Promise<{
    competencia: string;
    totalColaboradoresApurados: number;
    totalEventosPeriodicos: number;
    totalEventosValidados: number;
    totalEventosComErro: number;
    totalErros: number;
    totalAvisos: number;
    relatorioInconsistencias: Array<{
      colaborador: string;
      cpf: string;
      inconsistencias: InconsistenciaValidacaoESocial[];
    }>;
    eventos: EventoESocialRegistro[];
  }> {
    const res = await fetch('/api/esocial/validar-periodicos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId, competencia }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao validar eventos periódicos' }));
      throw new Error(err.error || 'Erro ao validar eventos periódicos');
    }
    return res.json();
  },

  async getPainelFechamentoESocial(empresaId: string, competencia: string): Promise<FechamentoFolhaESocialPainel> {
    const res = await fetch(
      `/api/esocial/fechamento-painel/${encodeURIComponent(empresaId)}?competencia=${encodeURIComponent(competencia)}`
    );
    if (!res.ok) throw new Error('Erro ao carregar painel de fechamento do eSocial');
    return res.json();
  },

  async fecharFolhaESocialS1299(empresaId: string, competencia: string): Promise<{
    sucesso: boolean;
    mensagem: string;
    reciboS1299: string;
    protocoloEnvio: string;
    totalizadorDctfWeb: {
      valorTotalDarf: number;
      guiaNumero: string;
      dataVencimento: string;
    };
    evento: EventoESocialRegistro;
  }> {
    const res = await fetch('/api/esocial/fechar-folha-s1299', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId, competencia }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao transmitir fechamento S-1299' }));
      throw new Error(err.error || 'Erro ao transmitir fechamento S-1299');
    }
    return res.json();
  },

  async reabrirFolhaESocialS1298(empresaId: string, competencia: string): Promise<{
    sucesso: boolean;
    mensagem: string;
    evento: EventoESocialRegistro;
  }> {
    const res = await fetch('/api/esocial/reabrir-folha-s1298', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ empresaId, competencia }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao reabrir folha S-1298' }));
      throw new Error(err.error || 'Erro ao reabrir folha S-1298');
    }
    return res.json();
  },

  async downloadXmlEventoESocial(eventoId: string): Promise<{ blob: Blob; filename: string }> {
    const res = await fetch(`/api/esocial/eventos/${encodeURIComponent(eventoId)}/xml`);
    if (!res.ok) throw new Error('Erro ao baixar XML do eSocial');
    const blob = await res.blob();
    const disposition = res.headers.get('content-disposition');
    let filename = `evento_esocial_${eventoId}.xml`;
    if (disposition && disposition.includes('filename=')) {
      const match = disposition.match(/filename="?([^"]+)"?/);
      if (match && match[1]) filename = match[1];
    }
    return { blob, filename };
  },

  // --- Conformidade Fiscal Consolidada ---
  async getConformidadeFiscalConsolidado(ano?: number): Promise<{
    ano: number;
    empresas: Empresa[];
    apuracoes: ApuracaoSimplesNacional[];
    guiasMei: GuiaDasMei[];
    declaracoesMei: DeclaracaoAnualMei[];
    pendenciasEcac: PendenciaEcac[];
    obrigacoes: Obrigacao[];
  }> {
    const url = ano ? `/api/conformidade-fiscal/consolidado?ano=${ano}` : '/api/conformidade-fiscal/consolidado';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao carregar dados consolidados de conformidade');
    return res.json();
  },

  async getGuiasMeiTodas(ano?: number): Promise<GuiaDasMei[]> {
    const url = ano ? `/api/mei/guias?ano=${ano}` : '/api/mei/guias';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao buscar guias do MEI');
    return res.json();
  },

  async getApuracoesSimplesTodas(): Promise<ApuracaoSimplesNacional[]> {
    const res = await fetch('/api/simples-nacional/apuracoes');
    if (!res.ok) throw new Error('Erro ao buscar apurações do Simples Nacional');
    return res.json();
  },

  // --- Cobranças, Contratos, Mensalidades e Recibos ---
  async getServicosContabeis(): Promise<ServicoContabil[]> {
    const res = await fetch('/api/cobrancas/servicos');
    if (!res.ok) throw new Error('Erro ao carregar tabela de serviços contábeis');
    return res.json();
  },

  async createServicoContabil(data: Partial<ServicoContabil>): Promise<ServicoContabil> {
    const res = await fetch('/api/cobrancas/servicos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao cadastrar serviço' }));
      throw new Error(err.error || 'Erro ao cadastrar serviço');
    }
    return res.json();
  },

  async updateServicoContabil(id: string, data: Partial<ServicoContabil>): Promise<ServicoContabil> {
    const res = await fetch(`/api/cobrancas/servicos/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Erro ao atualizar serviço contábil');
    return res.json();
  },

  async getContratosHonorarios(empresaId?: string): Promise<ContratoHonorario[]> {
    const url = empresaId && empresaId !== 'todas'
      ? `/api/cobrancas/contratos?empresaId=${encodeURIComponent(empresaId)}`
      : '/api/cobrancas/contratos';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao carregar contratos de honorários');
    return res.json();
  },

  async createContratoHonorario(data: Partial<ContratoHonorario>): Promise<{ contrato: ContratoHonorario; mensalidade: MensalidadeHonorario }> {
    const res = await fetch('/api/cobrancas/contratos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao cadastrar contrato de honorários' }));
      throw new Error(err.error || 'Erro ao cadastrar contrato');
    }
    return res.json();
  },

  async updateContratoHonorario(id: string, data: Partial<ContratoHonorario>): Promise<ContratoHonorario> {
    const res = await fetch(`/api/cobrancas/contratos/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Erro ao atualizar contrato');
    return res.json();
  },

  async getMensalidadesHonorarios(params?: {
    empresaId?: string;
    competencia?: string;
    status?: string;
  }): Promise<MensalidadeHonorario[]> {
    const query = new URLSearchParams();
    if (params?.empresaId && params.empresaId !== 'todas') query.append('empresaId', params.empresaId);
    if (params?.competencia && params.competencia !== 'todas') query.append('competencia', params.competencia);
    if (params?.status && params.status !== 'todos') query.append('status', params.status);

    const url = query.toString() ? `/api/cobrancas/mensalidades?${query.toString()}` : '/api/cobrancas/mensalidades';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao carregar mensalidades de honorários');
    return res.json();
  },

  async baixarMensalidade(
    id: string,
    data: { dataPagamento?: string; formaPagamento?: string; valorPago?: number; observacao?: string }
  ): Promise<MensalidadeHonorario> {
    const res = await fetch(`/api/cobrancas/mensalidades/${encodeURIComponent(id)}/baixa`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Erro ao registrar baixa de pagamento');
    return res.json();
  },

  async enviarCobranca(
    id: string,
    canal: 'email' | 'whatsapp',
    destinatario: string
  ): Promise<{ success: boolean; mensalidade: MensalidadeHonorario; envio: any }> {
    const res = await fetch(`/api/cobrancas/mensalidades/${encodeURIComponent(id)}/enviar`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ canal, destinatario }),
    });
    if (!res.ok) throw new Error('Erro ao registrar envio de cobrança');
    return res.json();
  },

  async getRecibosHonorarios(params?: {
    empresaId?: string;
    mensalidadeId?: string;
  }): Promise<ReciboHonorario[]> {
    const query = new URLSearchParams();
    if (params?.empresaId && params.empresaId !== 'todas') query.append('empresaId', params.empresaId);
    if (params?.mensalidadeId) query.append('mensalidadeId', params.mensalidadeId);

    const url = query.toString() ? `/api/cobrancas/recibos?${query.toString()}` : '/api/cobrancas/recibos';
    const res = await fetch(url);
    if (!res.ok) throw new Error('Erro ao buscar recibos de honorários');
    return res.json();
  },

  async emitirReciboHonorario(mensalidadeId: string): Promise<ReciboHonorario> {
    const res = await fetch('/api/cobrancas/recibos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mensalidadeId }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Erro ao emitir recibo' }));
      throw new Error(err.error || 'Erro ao emitir recibo');
    }
    return res.json();
  },

  async gerarMensalidadesEmLote(competencia: string): Promise<{ success: boolean; totalGeradas: number; mensalidades: MensalidadeHonorario[] }> {
    const res = await fetch('/api/cobrancas/mensalidades/gerar-lote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ competencia }),
    });
    if (!res.ok) throw new Error('Erro ao processar lote de mensalidades');
    return res.json();
  },
};
