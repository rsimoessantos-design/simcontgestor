export type Role = 'contador_admin' | 'analista_fiscal' | 'cliente_gestor';

export interface User {
  id: string;
  nome: string;
  email: string;
  cargo: string;
  role: Role;
  avatarUrl?: string;
  escritorioNome: string;
}

export type RegimeTributario = 'Simples Nacional' | 'Lucro Presumido' | 'Lucro Real' | 'MEI';
export type EmpresaStatus = 'ativa' | 'inativa' | 'em_abertura';

export interface Empresa {
  id: string;
  cnpj: string;
  razaoSocial: string;
  nomeFantasia: string;
  regimeTributario: RegimeTributario;
  status: EmpresaStatus;
  telefone: string;
  email: string;
  cidade: string;
  uf: string;
  faturamentoMensal: number;
  qtdeFuncionarios: number;
  responsavelContabil: string;
  rbt12?: number;
  folhaPagamento12Meses?: number;
  anexoPrincipalSimples?: 'Anexo I' | 'Anexo II' | 'Anexo III' | 'Anexo IV' | 'Anexo V';
  tipoAtividadeMei?: TipoAtividadeMei;
  categoriaMei?: string;
  dataAberturaMei?: string;
  limiteAnualCustomizado?: number;
  isDemo: boolean;
}

export interface Cliente {
  id: string;
  empresaId: string;
  nome: string;
  cpfCnpj: string;
  tipo: 'PF' | 'PJ';
  email: string;
  telefone: string;
  status: 'ativo' | 'inativo';
  cidade: string;
  uf: string;
  isDemo: boolean;
}

export interface Socio {
  id: string;
  empresaId: string;
  nome: string;
  cpf: string;
  participacaoPercentual: number;
  cargo: 'Sócio Administrador' | 'Sócio Cotista' | 'Diretor';
  email: string;
  telefone: string;
  proLabore: number;
  isDemo: boolean;
}

export type TipoObrigacao = 'Federal' | 'Estadual' | 'Municipal' | 'Trabalhista';
export type StatusObrigacao = 'pendente' | 'vencendo' | 'concluida' | 'atrasada';

export interface Obrigacao {
  id: string;
  empresaId: string;
  titulo: string;
  tipo: TipoObrigacao;
  competencia: string;
  dataVencimento: string; // YYYY-MM-DD
  status: StatusObrigacao;
  valorTributo?: number;
  responsavel: string;
  guiaEmitida: boolean;
  dataEntrega?: string;
  reciboEntrega?: string;
  isDemo: boolean;
}

export type CategoriaDocumento = 'Fiscal' | 'Contábil' | 'DP/RH' | 'Legal' | 'Certidão';
export type StatusDocumento = 'pendente' | 'aprovado' | 'arquivado';

export interface Documento {
  id: string;
  empresaId: string;
  nome: string;
  categoria: CategoriaDocumento;
  tamanho: string;
  dataEnvio: string;
  status: StatusDocumento;
  enviadoPor: string;
  extensao: string;
  isDemo: boolean;
}

export type StatusCertidao = 'valida' | 'vencida' | 'alerta';

export interface Certidao {
  id: string;
  empresaId: string;
  orgao: 'Receita Federal e PGFN' | 'FGTS (CRF)' | 'Trabalhista (CNDT)' | 'Estadual (ICMS)' | 'Municipal (ISS)';
  codigo: string;
  dataEmissao: string;
  dataValidade: string;
  status: StatusCertidao;
  isDemo: boolean;
}

export type PrioridadeTarefa = 'baixa' | 'media' | 'alta' | 'urgente';
export type StatusTarefa = 'a_fazer' | 'em_andamento' | 'concluida';

export interface Tarefa {
  id: string;
  empresaId: string;
  titulo: string;
  descricao: string;
  prioridade: PrioridadeTarefa;
  status: StatusTarefa;
  dataVencimento: string;
  responsavel: string;
  isDemo: boolean;
}

export type StatusFinanceiro = 'pendente' | 'pago' | 'recebido' | 'vencido';

export interface CategoriaFinanceira {
  id: string;
  empresaId?: string; // null = global do escritório
  nome: string;
  tipo: 'despesa' | 'receita';
  cor: string;
  isDemo: boolean;
}

export interface ContaPagar {
  id: string;
  empresaId: string;
  descricao: string;
  categoriaId: string;
  beneficiario: string;
  valor: number;
  dataVencimento: string;
  dataPagamento?: string;
  status: 'pendente' | 'pago' | 'vencido';
  isDemo: boolean;
}

export interface ContaReceber {
  id: string;
  empresaId: string;
  descricao: string;
  categoriaId: string;
  clienteId?: string;
  pagador: string;
  valor: number;
  dataVencimento: string;
  dataRecebimento?: string;
  status: 'pendente' | 'recebido' | 'vencido';
  isDemo: boolean;
}

export type SegregacaoSimplesNacional =
  | 'tributacao_integral'
  | 'substituicao_tributaria_icms'
  | 'pis_cofins_monofasico'
  | 'icms_st_e_monofasico'
  | 'exportacao'
  | 'isento_imune';

export interface NotaFiscal {
  id: string;
  empresaId: string;
  numero: number;
  serie: string;
  tipo: 'NFe' | 'NFSe' | 'NFCe';
  modeloDoc?: '55' | '65' | 'NFSe' | 'CFe'; // 55 = NF-e mercadoria, 65 = NFC-e cupom eletrônico consumidor
  cfopPrincipal?: string; // Ex: '5.102', '5.405'
  anexoSimples?: 'Anexo I' | 'Anexo II' | 'Anexo III' | 'Anexo IV' | 'Anexo V';
  segregacaoTributaria?: SegregacaoSimplesNacional;
  naturezaOperacao: string;
  destinatarioNome: string;
  destinatarioCpfCnpj: string;
  destinatarioEmail?: string;
  valorTotal: number;
  valorServicosOuProdutos?: number;
  impostos?: {
    icms?: number;
    iss?: number;
    pis?: number;
    cofins?: number;
    irpj?: number;
    csll?: number;
    icmsSt?: number;
  };
  itens: Array<{
    numeroItem?: number;
    descricao: string;
    quantidade: number;
    valorUnitario: number;
    valorTotal: number;
    cfop?: string;
    ncm?: string;
    csosn?: string;
  }>;
  dataEmissao: string;
  status: 'autorizada' | 'cancelada' | 'rejeitada' | 'processando';
  chaveAcesso: string;
  protocoloAutorizacao?: string;
  motivoCancelamento?: string;
  origem?: 'emitida_sistema' | 'importado_erp';
  isDemo: boolean;
}

export type TipoManifestacaoDestinatario =
  | 'sem_manifestacao'
  | 'ciencia'
  | 'confirmada'
  | 'desconhecida'
  | 'nao_realizada';

export type StatusEscrituracaoEntrada =
  | 'pendente'
  | 'escriturada'
  | 'estoque_atualizado'
  | 'divergencia';

export interface NotaFiscalEntrada {
  id: string;
  empresaId: string; // Empresa compradora (destinatária)
  numero: number;
  serie: string;
  modelo: '55' | '65' | '57'; // 55 = NF-e, 65 = NFC-e, 57 = CT-e
  chaveAcesso: string;
  dataEmissao: string;
  dataCapturaSefaz: string;
  nsuSefaz?: string; // Número Sequencial Único da SEFAZ

  // Fornecedor (Emitente da nota emitida contra o CNPJ da nossa empresa)
  fornecedorNome: string;
  fornecedorCnpj: string;
  fornecedorIe?: string;
  fornecedorUf: string;
  fornecedorMunicipio: string;

  // Destinatário (Nossa Empresa)
  destinatarioNome: string;
  destinatarioCnpj: string;

  naturezaOperacao: string;
  cfopPrincipal: string; // Ex: '5.102' / '1.102'
  valorProdutos: number;
  valorFrete?: number;
  valorDesconto?: number;
  valorTotal: number;

  impostos: {
    icms?: number;
    baseCalculoIcms?: number;
    icmsSt?: number;
    ipi?: number;
    pis?: number;
    cofins?: number;
  };

  itens: Array<{
    codigo?: string;
    descricao: string;
    ncm?: string;
    cst?: string;
    cfop?: string;
    unidade?: string;
    quantidade: number;
    valorUnitario: number;
    valorTotal: number;
  }>;

  statusSefaz: 'autorizada' | 'cancelada' | 'denegada';
  manifestacao: TipoManifestacaoDestinatario;
  dataManifestacao?: string;
  protocoloManifestacao?: string;
  statusEscrituracao: StatusEscrituracaoEntrada;
  observacoes?: string;
  xmlCompletoDisponivel: boolean;
  xmlContent?: string;
  isDemo: boolean;
}

export interface SincronizacaoSefazLog {
  id: string;
  empresaId: string;
  dataHora: string;
  tipo: 'automatica' | 'manual_chave' | 'sincronizacao_dfe';
  nsuConsultado?: string;
  notasEncontradas: number;
  status: 'sucesso' | 'aviso' | 'erro';
  mensagem: string;
  tempoMs: number;
}

export interface CertificadoDigital {
  id: string;
  empresaId: string;
  titular: string;
  tipo: 'A1' | 'A3';
  categoria: 'e-CNPJ' | 'e-CPF' | 'NF-e';
  emissor: string;
  cnpjCpf: string;
  dataEmissao: string;
  dataValidade: string;
  diasParaVencer: number;
  status: 'valido' | 'alerta' | 'expirando' | 'expirado';
  instaladoNoServidor: boolean;
  senhaSalva: boolean;
  arquivoNome?: string;
  serialNumber?: string;
  isDemo: boolean;
}

export interface PendenciaEcac {
  id: string;
  empresaId: string;
  codigo: string;
  titulo: string;
  descricao: string;
  orgao: 'Receita Federal' | 'PGFN' | 'Previdenciário (INSS)' | 'DTE' | 'Simples Nacional';
  gravidade: 'critica' | 'alta' | 'media' | 'baixa';
  valorEnvolvido?: number;
  dataDeteccao: string;
  status: 'pendente' | 'em_regularizacao' | 'resolvida';
  acaoRecomendada: string;
  protocoloRegularizacao?: string;
  resolvidoEm?: string;
  isDemo: boolean;
}

export type TipoAlvaraLicenca =
  | 'Alvará de Funcionamento'
  | 'Alvará Sanitário'
  | 'Alvará do Corpo de Bombeiros (AVCB/CLCB)'
  | 'Licença Ambiental (LP/LI/LO)'
  | 'Licença da Polícia Civil'
  | 'Licença da Polícia Federal'
  | 'Certificado de Registro Exército'
  | 'Outras Licenças';

export type StatusAlvaraLicenca =
  | 'vigente'
  | 'vencendo'
  | 'vencido'
  | 'em_renovacao'
  | 'dispensado';

export interface AlvaraLicenca {
  id: string;
  empresaId: string;
  tipo: TipoAlvaraLicenca;
  orgaoEmissor: string;
  numeroAlvara: string;
  numeroClcbAvcb?: string;
  numeroIptuPredio: string;
  areaImovel: number;
  areaConstruida: number;
  areaUtilizada: number;
  numeroCadastroImobiliario: string;
  numeroInscricaoMunicipal: string;
  dataEmissao: string;
  dataValidade: string;
  diasParaVencer: number;
  status: StatusAlvaraLicenca;
  protocoloRenovacao?: string;
  dataSolicitacaoRenovacao?: string;
  responsavelTecnico?: string;
  artRrtNumero?: string;
  observacoes?: string;
  documentoAnexo?: string;
  isDemo: boolean;
}

// --- RH & DEPARTAMENTO PESSOAL ---

export type NivelCargo =
  | 'Estagiário'
  | 'Júnior'
  | 'Pleno'
  | 'Sênior'
  | 'Especialista'
  | 'Coordenação'
  | 'Gerência'
  | 'Diretoria';

export type GrauInsalubridade = 'nenhum' | 'grau_minimo' | 'grau_medio' | 'grau_maximo';

export interface FuncaoRH {
  id: string;
  empresaId: string; // pode ser 'todas' para padrão do escritório ou empresaId
  titulo: string;
  cbo: string; // Classificação Brasileira de Ocupações (ex: 2124-05)
  departamento: string;
  salarioBase: number;
  cargaHorariaSemanal: number; // ex: 44, 40, 30, 20
  nivel: NivelCargo;
  descricao?: string;
  requisitos?: string;
  adicionalPericulosidade?: boolean; // 30%
  adicionalInsalubridade?: GrauInsalubridade; // 10%, 20%, 40%
  isDemo: boolean;
}

export type TipoContrato =
  | 'CLT Indeterminado'
  | 'CLT Prazo Determinado'
  | 'Estágio'
  | 'Jovem Aprendiz'
  | 'PJ / Terceirizado'
  | 'Temporário';

export type StatusFuncionario =
  | 'ativo'
  | 'ferias'
  | 'afastado'
  | 'aviso_previo'
  | 'desligado';

export type RegimeTrabalho = 'presencial' | 'hibrido' | 'remoto';

export interface Dependente {
  id: string;
  nome: string;
  parentesco: 'Filho(a)' | 'Cônjuge' | 'Pais' | 'Outro';
  cpf: string;
  dataNascimento: string;
  deducaoIrrf: boolean;
  salarioFamilia: boolean;
}

export interface Funcionario {
  id: string;
  empresaId: string;
  matricula: string; // eSocial
  nomeCompleto: string;
  cpf: string;
  rg: string;
  rgOrgaoEmissor: string;
  dataNascimento: string;
  sexo: 'M' | 'F' | 'Outro';
  estadoCivil: 'Solteiro(a)' | 'Casado(a)' | 'Divorciado(a)' | 'Viúvo(a)' | 'União Estável';
  nomeMae: string;
  nomePai?: string;
  pisPasep: string;
  ctpsNumero: string;
  ctpsSerie: string;
  ctpsUf: string;
  email: string;
  telefone: string;
  whatsapp?: string;
  // Endereço
  cep: string;
  logradouro: string;
  numero: string;
  complemento?: string;
  bairro: string;
  cidade: string;
  uf: string;
  // Cargo e Contrato
  funcaoId: string;
  cargoNome: string;
  cbo: string;
  departamento: string;
  tipoContrato: TipoContrato;
  regimeTrabalho: RegimeTrabalho;
  dataAdmissao: string;
  terminoExperiencia?: string;
  terminoContrato?: string;
  salarioBase: number;
  adicionaisTotal?: number;
  status: StatusFuncionario;
  // Dados Bancários
  bancoNome?: string;
  bancoAgencia?: string;
  bancoConta?: string;
  chavePix?: string;
  // Benefícios
  valeTransporte: boolean;
  valorVrVaMensal?: number;
  planoSaude: boolean;
  dependentes: Dependente[];
  // Férias
  periodoAquisitivoInicio?: string;
  periodoAquisitivoFim?: string;
  limiteConcessivoFerias?: string;
  diasFeriasSaldo: number;
  // Saúde Ocupacional (ASO)
  dataUltimoAso?: string;
  dataValidadeAso?: string;
  observacoes?: string;
  avatarUrl?: string;
  isDemo: boolean;
}

export interface ItemHolerite {
  codigo: string;
  descricao: string;
  referencia: string;
  tipo: 'provento' | 'desconto';
  valor: number;
}

// =========================================================================
// --- PONTO ELETRÔNICO & AUDITORIA DE JORNADA (PORTARIA 671 MTE / REP-P) ---
// =========================================================================

export type TipoBatidaPonto =
  | 'entrada_1'
  | 'saida_intervalo'
  | 'retorno_intervalo'
  | 'saida_2'
  | 'extra_inicio'
  | 'extra_fim';

export type OrigemBatida = 'rep_p' | 'web' | 'mobile' | 'ajuste_rh';

export type StatusAuditoriaPonto =
  | 'pendente'
  | 'aprovado'
  | 'ajustado'
  | 'com_inconsistencia'
  | 'abonado';

export interface MarcacaoPonto {
  id: string;
  funcionarioId: string;
  empresaId: string;
  dataHora: string; // ISO string
  tipo: TipoBatidaPonto;
  nsr: number; // Número Sequencial de Registro
  hashRegistro: string; // Hash SHA-256 da marcação
  origem: OrigemBatida;
  geolocalizacao?: {
    latitude: number;
    longitude: number;
    precisao?: number;
    endereco?: string;
  };
  ip?: string;
  fotoComprovante?: string;
  observacao?: string;
  editadoManualmente?: boolean;
  motivoAjuste?: string;
  ajustadoPor?: string;
  dataHoraAjuste?: string;
  isDemo?: boolean;
}

export interface RegistroPontoDia {
  id: string;
  funcionarioId: string;
  funcionarioNome: string;
  funcionarioMatricula: string;
  funcionarioCargo: string;
  departamento: string;
  empresaId: string;
  empresaNome?: string;
  data: string; // YYYY-MM-DD
  diaSemana: string;
  entrada1?: string; // HH:mm
  saidaIntervalo?: string; // HH:mm
  retornoIntervalo?: string; // HH:mm
  saida2?: string; // HH:mm
  horasPrevistasMinutos: number; // Ex: 480 (8h)
  horasTrabalhadasMinutos: number;
  horasIntervaloMinutos: number;
  horasExtrasMinutos: number;
  horasExtras50Minutos?: number;
  horasExtras100Minutos?: number;
  horasNegativasMinutos: number;
  tipoDia?: 'util' | 'dsr' | 'sabado_compensado' | 'feriado' | 'ferias' | 'afastamento' | 'futuro';
  isFaltaIntegral?: boolean;
  ocorrenciaDescricao?: string;
  statusAuditoria: StatusAuditoriaPonto;
  inconsistencias: string[];
  batidas: MarcacaoPonto[];
  observacaoRH?: string;
  auditadoPor?: string;
  dataAuditado?: string;
  isDemo?: boolean;
}

export interface EspelhoPontoMensal {
  funcionarioId: string;
  competencia: string; // MM/YYYY
  empresaId: string;
  empresa?: {
    razaoSocial: string;
    cnpj: string;
    endereco?: string;
    cidadeUf?: string;
  };
  funcionario?: {
    nome: string;
    cpf: string;
    pisPasep?: string;
    matricula: string;
    cargo: string;
    departamento: string;
    salarioBase: number;
    dataAdmissao: string;
    jornadaDescricao?: string;
  };
  periodoDescricao?: string;
  totalDiasMes?: number;
  totalDiasTrabalhados: number;
  totalDiasUteis?: number;
  totalDiasDsr?: number;
  totalFaltasDias?: number;
  totalFaltasMinutos?: number;
  totalHorasTrabalhadasMinutos: number;
  totalHorasPrevistasMinutos: number;
  saldoHorasMinutos: number;
  totalHorasExtrasMinutos: number;
  totalHorasExtras50Minutos?: number;
  totalHorasExtras100Minutos?: number;
  totalDsrSobreHorasExtrasMinutos?: number;
  totalAtrasosMinutos: number;
  totalInconsistencias: number;
  valorHoraNormal?: number;
  valorHorasExtras50?: number;
  valorHorasExtras100?: number;
  valorDsrHorasExtras?: number;
  valorDescontoFaltas?: number;
  valorDescontoAtrasos?: number;
  valorTotalProventosExtras?: number;
  valorTotalDescontosPonto?: number;
  saldoFinanceiroLiquido?: number;
  hashAutenticidade?: string;
  dataEmissao?: string;
  dias: RegistroPontoDia[];
}

export interface ComprovantePontoEmitido {
  nsr: number;
  dataHora: string;
  tipo: TipoBatidaPonto;
  tipoDescricao: string;
  hashRegistro: string;
  empresa: {
    razaoSocial: string;
    cnpj: string;
    endereco?: string;
  };
  funcionario: {
    nome: string;
    cpf: string;
    pisPasep?: string;
    matricula: string;
    cargo: string;
  };
  dispositivo: string;
  geolocalizacao?: string;
}

// =========================================================================
// --- CONTROLE DE FÉRIAS, PERÍODOS AQUISITIVOS & CONCESSIVOS (CLT) ---
// =========================================================================

export type StatusFeriasPeriodo = 'planejado' | 'aprovado' | 'em_gozo' | 'concluido' | 'cancelado';
export type StatusPeriodoFerias = StatusFeriasPeriodo;

export interface PeriodoGozoFerias {
  id: string;
  funcionarioId: string;
  funcionarioNome: string;
  funcionarioMatricula?: string;
  funcionarioCargo?: string;
  empresaId: string;
  empresaNome?: string;
  periodoAquisitivoInicio: string; // YYYY-MM-DD
  periodoAquisitivoFim: string; // YYYY-MM-DD
  limiteConcessivo: string; // YYYY-MM-DD
  fracionamentoNumero: 1 | 2 | 3;
  dataInicio: string; // YYYY-MM-DD
  dataFim: string; // YYYY-MM-DD
  diasGozo: number;
  abonoPecuniario: boolean;
  diasAbono: number; // 0 a 10 dias (Art. 143 CLT)
  adiantamentoDecimoTerceiro: boolean;
  dataAvisoFerias: string; // Mínimo 30 dias de antecedência (Art. 135 CLT)
  dataLimitePagamento: string; // Até 2 dias antes do início (Art. 145 CLT)
  status: StatusFeriasPeriodo;
  valoresFinanceiros?: {
    salarioBase: number;
    valorFeriasBruto: number;
    tercoConstitucional: number;
    valorAbono: number;
    tercoAbono: number;
    adiantamento13: number;
    inssFerias: number;
    irrfFerias: number;
    totalLiquido: number;
  };
  observacoes?: string;
  criadoEm: string;
  isDemo?: boolean;
}

export type SeveridadeAlertaFerias =
  | 'vencido_dobro'
  | 'urgente_30'
  | 'atencao_60'
  | 'em_gozo'
  | 'regular';

export interface AlertaFeriasItem {
  id: string;
  funcionarioId: string;
  funcionarioNome: string;
  funcionarioCargo: string;
  departamento: string;
  empresaId: string;
  empresaNome?: string;
  periodoAquisitivoInicio: string;
  periodoAquisitivoFim: string;
  limiteConcessivo: string;
  diasParaVencer: number; // Negativo se já venceu o período concessivo
  saldoDiasRestantes: number;
  severidade: SeveridadeAlertaFerias;
  mensagem: string;
  riscoMultaDobro: boolean;
  estimativaCustoDobro: number;
  dataSugeridaInicio?: string;
}

export interface PeriodoAquisitivoHistorico {
  id: string;
  funcionarioId: string;
  numeroPeriodo: number;
  dataInicio: string;
  dataFim: string;
  limiteConcessivo: string;
  diasDireito: number; // Conforme faltas injustificadas (Art. 130 CLT)
  faltasInjustificadas: number;
  diasGozados: number;
  diasAbonados: number;
  saldoDias: number;
  diasProporcionais?: number;
  situacao:
    | 'em_aquisicao'
    | 'adquirido_regular'
    | 'alerta_vencendo'
    | 'urgente_30_dias'
    | 'vencido_dobro'
    | 'quitado';
  diasParaVencer: number;
  periodosGozo: PeriodoGozoFerias[];
}

export interface PainelAvisosFeriasResponse {
  totalFuncionarios: number;
  emGozo: number;
  alerta60Dias: number;
  urgente30Dias: number;
  vencidasDobro: number;
  saldoTotalDiasEmpresa: number;
  alertas: AlertaFeriasItem[];
}

export interface DocumentoAvisoReciboFerias {
  id: string;
  periodoGozoId: string;
  empresa: {
    razaoSocial: string;
    cnpj: string;
    endereco: string;
    cidadeUf: string;
  };
  funcionario: {
    nome: string;
    cargo: string;
    matricula: string;
    cpf: string;
    ctps: string;
    pis: string;
    departamento: string;
    dataAdmissao: string;
  };
  periodoAquisitivo: {
    inicio: string;
    fim: string;
  };
  periodoGozo: {
    inicio: string;
    fim: string;
    dias: number;
    dataRetorno: string;
    fracionamentoNumero: number;
  };
  abono: {
    solicitado: boolean;
    dias: number;
  };
  adiantamento13: {
    solicitado: boolean;
    valor: number;
  };
  datasLegais: {
    dataComunicacaoAviso: string;
    dataLimitePagamento: string;
    dataEmissaoDocumento: string;
  };
  demonstrativo: {
    salarioBase: number;
    valorFeriasGozadas: number;
    tercoConstitucional: number;
    valorAbonoPecuniario: number;
    tercoConstitucionalAbono: number;
    adiantamentoDecimoTerceiro: number;
    totalBruto: number;
    descontoInss: number;
    descontoIrrf: number;
    outrosDescontos: number;
    totalDescontos: number;
    totalLiquidoReceber: number;
  };
}

export interface HoleriteCalculado {
  funcionarioId: string;
  competencia: string;
  salarioBase: number;
  totalProventos: number;
  totalDescontos: number;
  salarioLiquido: number;
  valorLiquido?: number;
  baseInss: number;
  valorInss: number;
  baseIrrf: number;
  valorIrrf: number;
  baseFgts: number;
  valorFgts: number;
  faixaInssAliquotaEfetiva: string;
  faixaIrrfAliquota: string;
  itens: ItemHolerite[];
  bases?: {
    salarioBase: number;
    baseInss: number;
    baseIrrf: number;
    fgtsMes: number;
  };
  memoriaCalculo?: {
    inssFaixas?: Array<{
      faixa: string;
      baseCalculada: number;
      aliquota: number;
      valor: number;
    }>;
    irrfDeducaoTipo?: 'legal' | 'simplificada';
    irrfDeducaoValor?: number;
    dependentesQtd?: number;
    encargosPatronais?: {
      inssPatronal: number;
      ratFap: number;
      terceiros: number;
      totalEncargos: number;
    };
  };
}

export interface DashboardMetrics {
  totalEmpresas: number;
  empresasAtivas: number;
  obrigacoesPendentes: number;
  obrigacoesVencendo: number;
  documentosPendentes: number;
  totalContasPagar: number;
  valorContasPagar: number;
  totalContasReceber: number;
  valorContasReceber: number;
  taxaConformidade: number; // %
  monthlyFlow: Array<{
    mes: string;
    receber: number;
    pagar: number;
    saldo: number;
  }>;
  statusObrigacoes: {
    concluidas: number;
    pendentes: number;
    vencendo: number;
    atrasadas: number;
  };
  regimesDistribuicao: Array<{
    regime: string;
    quantidade: number;
  }>;
  totalNotasEmitidas?: number;
  certificadosAlerta?: number;
  pendenciasEcacResolvidasPercentual?: number;
  pendenciasEcacTotal?: number;
  pendenciasEcacPendentes?: number;
}

export type NavSection =
  | 'dashboard'
  | 'conformidade_fiscal'
  | 'cobrancas'
  | 'patrimonio'
  | 'contabilidade'
  | 'empresas'
  | 'clientes'
  | 'simples_nacional'
  | 'mei'
  | 'simulador_tributario'
  | 'rh'
  | 'alvaras_licencas'
  | 'notas_fiscais'
  | 'captura_sefaz'
  | 'certificados_digitais'
  | 'ecac_pendencias'
  | 'controle_entregas'
  | 'obrigacoes'
  | 'documentos'
  | 'certidoes'
  | 'tarefas'
  | 'agenda'
  | 'financeiro'
  | 'relatorios'
  | 'configuracoes'
  | 'banco_dados';

// =========================================================================
// --- CÁLCULO DE RESCISÃO CONTRATUAL, VERBAS RESCISÓRIAS & TRCT (CLT) ---
// =========================================================================

export type TipoMotivoRescisao =
  | 'sem_justa_causa'
  | 'pedido_demissao'
  | 'justa_causa'
  | 'acordo_mutuo'
  | 'termino_experiencia'
  | 'rescisao_antecipada_empregador'
  | 'rescisao_indireta';

export type TipoAvisoPrevioRescisao =
  | 'indenizado'
  | 'trabalhado'
  | 'descontado'
  | 'dispensado'
  | 'nao_aplicavel';

export interface RubricaRescisao {
  codigo: string;
  descricao: string;
  referencia: string;
  tipo: 'provento' | 'desconto';
  valor: number;
  incideInss?: boolean;
  incideIrrf?: boolean;
  incideFgts?: boolean;
}

export interface CalculoRescisaoResultado {
  funcionarioId: string;
  empresaId: string;
  motivoRescisao: TipoMotivoRescisao;
  tipoAvisoPrevio: TipoAvisoPrevioRescisao;
  dataAdmissao: string;
  dataAvisoPrevio: string;
  dataDesligamento: string;
  dataProjecaoAviso: string;
  dataLimitePagamento: string; // Art. 477 § 6º CLT (10 dias)
  anosCompletosTrabalho: number;
  mesesTrabalhadosTotal: number;
  diasAvisoLei12506: number; // 30 + 3 por ano completo (máx 90)
  diasSaldoSalario: number;
  avos13Salario: number;
  avos13Indenizado: number;
  avosFeriasProporcionais: number;
  avosFeriasIndenizadas: number;
  diasFeriasVencidas: number;
  salarioBase: number;
  remuneracaoBaseCalculo: number;
  proventos: {
    saldoSalario: number;
    avisoPrevioIndenizado: number;
    decimoTerceiroProporcional: number;
    decimoTerceiroAvisoIndenizado: number;
    feriasVencidas: number;
    tercoFeriasVencidas: number;
    feriasProporcionais: number;
    tercoFeriasProporcionais: number;
    feriasAvisoIndenizado: number;
    tercoFeriasAvisoIndenizado: number;
    adicionalPericulosidadeInsalubridade: number;
    horasExtrasRescisorias: number;
    indenizacaoArt479?: number;
    totalBruto: number;
  };
  descontos: {
    inssSaldoSalario: number;
    inssDecimoTerceiro: number;
    irrfSaldoSalario: number;
    irrfDecimoTerceiro: number;
    avisoPrevioDescontado: number;
    faltasDsr: number;
    adiantamentosOutros: number;
    totalDescontos: number;
  };
  totalLiquidoRescisao: number;
  fgts: {
    saldoParaFinsRescisorios: number;
    depositoMesRescisao: number;
    deposito13Rescisorio: number;
    depositoAvisoIndenizado: number;
    baseCalculoMultaFgts: number;
    aliquotaMultaFgts: number; // 40, 20 ou 0
    valorMultaRescisoriaFgts: number;
    totalRecolhimentoFgtsDigital: number;
    codigoSaqueFgts: string;
    direitoSeguroDesemprego: boolean;
    chaveConectividadeSocial?: string;
  };
  rubricas: RubricaRescisao[];
  memoriaCalculo: {
    inssFaixasSaldo?: Array<{ faixa: string; base: number; aliquota: number; valor: number }>;
    inssFaixas13?: Array<{ faixa: string; base: number; aliquota: number; valor: number }>;
    deducaoDependentesIrrf: number;
    dependentesQtd: number;
    diasProjetadosAviso: number;
    avisoExplicacao: string;
  };
}

export interface DocumentoTRCT {
  numeroTermo: string;
  empresa: {
    razaoSocial: string;
    cnpj: string;
    endereco: string;
    cidadeUf: string;
    cnae?: string;
  };
  funcionario: {
    nome: string;
    cpf: string;
    pisPasep: string;
    ctps: string;
    cargo: string;
    cbo: string;
    dataAdmissao: string;
    dataAviso: string;
    dataAfastamento: string;
    dataNascimento?: string;
    nomeMae?: string;
    endereco?: string;
    remuneracaoMesAnterior: number;
  };
  dadosRescisao: {
    tipoContrato: string;
    motivoDescricao: string;
    codigoAfastamento: string;
    tipoAvisoDescricao: string;
    dataLimitePagamento: string;
    pensaoAlimenticia?: string;
    sindicatoNome?: string;
    codigoSindical?: string;
  };
  rubricas: RubricaRescisao[];
  totais: {
    totalBruto: number;
    totalDescontos: number;
    totalLiquido: number;
  };
  dadosFgts: {
    saldoBaseFgts: number;
    multaRescisoria: number;
    aliquotaMulta: number;
    codigoSaque: string;
    direitoSeguroDesemprego: boolean;
    chaveConectividade?: string;
  };
  declaracaoQuitacao: string;
  dataEmissao: string;
}

export interface RescisaoContratualRegistro {
  id: string;
  empresaId: string;
  empresaNome?: string;
  funcionarioId: string;
  funcionarioNome: string;
  funcionarioCargo: string;
  funcionarioCpf: string;
  motivoRescisao: TipoMotivoRescisao;
  tipoAvisoPrevio: TipoAvisoPrevioRescisao;
  dataAdmissao?: string;
  dataAfastamento: string;
  dataAvisoPrevio?: string;
  dataLimitePagamento?: string;
  totalBruto: number;
  totalDescontos: number;
  totalLiquido: number;
  saldoFgts?: number;
  multaFgts: number;
  multaFgtsValor?: number;
  status: 'calculada' | 'homologada' | 'paga' | 'transmitida_esocial';
  calculo: CalculoRescisaoResultado;
  trct: DocumentoTRCT;
  criadoEm: string;
  homologadoEm?: string;
  isDemo?: boolean;
}

export interface ESocialConfiguracao {
  id: string;
  empresaId: string;
  ambiente: 'producao' | 'producao_restrita'; // 1 = Produção, 2 = Produção Restrita (Testes)
  versaoManual: string; // ex: S-1.2, S-1.3
  classificacaoTributaria: string; // 01, 02, 03 (Simples), 99 etc.
  tipoInscricao: 'CNPJ' | 'CPF';
  numeroInscricao: string;
  razaoSocial: string;
  indicativoCooperativa: '0' | '1' | '2' | '3';
  indicativoConstrutora: '0' | '1';
  indicativoDesoneracaoFolha: '0' | '1';
  naturezaJuridica: string;
  cnaePrincipal: string;
  aliquotaRat: number; // 1, 2 ou 3%
  fap: number; // Fator Acidentário de Prevenção (0.5000 a 2.0000)
  aliquotaRatAjustada: number;
  codigoTerceirosOutrasEntidades: string; // ex: 0079, 0000
  aliquotaTerceiros: number; // % Outras entidades (Salário Educação, INCRA, SENAI, etc.)
  certificadoDigitalId?: string;
  certificadoValidade?: string;
  certificadoNome?: string;
  transmissaoAutomatica: boolean;
  procuracaoEletronicaAtiva: boolean;
  contatoResponsavelNome: string;
  contatoResponsavelCpf: string;
  contatoResponsavelEmail: string;
  contatoResponsavelTelefone: string;
  atualizadoEm: string;
}

export type TipoEventoESocial =
  | 'S-1000' // Informações do Empregador
  | 'S-1005' // Tabela de Estabelecimentos
  | 'S-1010' // Tabela de Rubricas
  | 'S-1020' // Tabela de Lotações Tributárias
  | 'S-1200' // Remuneração do Trabalhador
  | 'S-1210' // Pagamentos de Rendimentos
  | 'S-1260' // Comercialização Prod. Rural
  | 'S-1280' // Informações Complementares aos Eventos Periódicos
  | 'S-1298' // Reabertura dos Eventos Periódicos
  | 'S-1299' // Fechamento dos Eventos Periódicos
  | 'S-2200' // Cadastramento Inicial / Admissão
  | 'S-2205' // Alteração Cadastral
  | 'S-2206' // Alteração Contratual
  | 'S-2220' // Monitoramento da Saúde do Trabalhador (ASO)
  | 'S-2230' // Afastamento Temporário
  | 'S-2240' // Condições Ambientais do Trabalho (SST)
  | 'S-2299' // Desligamento (Rescisão)
  | 'S-5001' // Informações das Contribuições Sociais por Trabalhador (Retorno)
  | 'S-5011'; // Informações das Contribuições Sociais Consolidadas (DCTFWeb)

export type StatusEventoESocial =
  | 'pendente'
  | 'validado'
  | 'em_processamento'
  | 'transmitido_sucesso'
  | 'rejeitado_erro'
  | 'advertencia';

export interface InconsistenciaValidacaoESocial {
  codigoRegra: string;
  campo: string;
  descricao: string;
  tipo: 'erro' | 'aviso';
  sugestaoCorrecao: string;
}

export interface EventoESocialRegistro {
  id: string;
  empresaId: string;
  empresaNome: string;
  tipoEvento: TipoEventoESocial;
  descricaoEvento: string;
  competencia?: string; // MM/AAAA
  trabalhadorId?: string;
  trabalhadorNome?: string;
  trabalhadorCpf?: string;
  trabalhadorMatricula?: string;
  status: StatusEventoESocial;
  numeroReciboEnvio?: string;
  protocoloEnvio?: string;
  xmlGerado?: string;
  inconsistencias?: InconsistenciaValidacaoESocial[];
  dataGeracao: string;
  dataTransmissao?: string;
  usuarioResponsavel: string;
}

export interface FechamentoFolhaESocialPainel {
  empresaId: string;
  empresaNome: string;
  cnpj: string;
  competencia: string;
  statusFechamento: 'aberto' | 'validando' | 'pronto_envio' | 'fechado_transmitido' | 'reaberto';
  versaoManual: string;
  ambiente: 'producao' | 'producao_restrita';
  totais: {
    totalColaboradores: number;
    remuneracaoBrutaTotal: number;
    totalBaseInss: number;
    totalInssSegurados: number;
    totalInssPatronal: number;
    totalRatAjustado: number;
    totalTerceirosOutrasEntidades: number;
    totalInssDctfWeb: number;
    totalBaseFgts: number;
    totalFgtsDigital: number;
    totalIrrfRetido: number;
  };
  eventosPeriodicos: {
    totalEsperados: number;
    validadosComSucesso: number;
    comErrosPendentes: number;
    transmitidos: number;
    itens: EventoESocialRegistro[];
  };
  reciboFechamento?: {
    numeroReciboS1299: string;
    protocoloRecepcao: string;
    hashXmlAssinado: string;
    dataHoraEnvio: string;
    retornoS5011DctfWeb?: {
      numeroControleDctfWeb: string;
      valorTotalGuiaDarfer: number;
      codigoReceitaPrincipal: string;
      vencimentoDarfer: string;
    };
  };
  inconsistenciasGerais: InconsistenciaValidacaoESocial[];
}

export type DatabaseTableKey =
  | 'empresas'
  | 'clientes'
  | 'socios'
  | 'obrigacoes'
  | 'documentos'
  | 'certidoes'
  | 'tarefas'
  | 'contasPagar'
  | 'contasReceber'
  | 'categoriasFinanceiras'
  | 'users'
  | 'notasFiscais'
  | 'certificados'
  | 'pendenciasEcac'
  | 'alvaras'
  | 'funcionarios'
  | 'funcoes'
  | 'pontos'
  | 'ferias'
  | 'rescisoes'
  | 'esocialConfiguracoes'
  | 'esocialEventos';

export interface DatabaseStats {
  storageType: string;
  filePath: string;
  version: string;
  isDemoDatabase?: boolean;
  totalRecords: number;
  lastSaved: string;
  tableCounts: Record<DatabaseTableKey, number>;
}

// =========================================================================
// --- SIMULADOR DE REGIME TRIBUTÁRIO & REFORMA TRIBUTÁRIA (FISCAL CODE) ---
// =========================================================================

export type TipoAtividadeSimulador =
  | 'comercio'             // Anexo I (Revenda de Mercadorias)
  | 'industria'            // Anexo II (Fabricação e Transformação)
  | 'servicos_anexo3'      // Anexo III (Serviços em Geral, Manutenção, TI regular)
  | 'servicos_anexo4'      // Anexo IV (Limpeza, Vigilância, Obras/Construção, Advocacia)
  | 'servicos_anexo5';     // Anexo V (Atividades Intelectuais com Fator R: TI, Engenharia, Medicina, Consultoria)

export type AnoSimulacaoReforma = 2026 | 2027 | 2028 | 2029 | 2030 | 2031 | 2032 | 2033;

export interface ParametrosSimulacaoTributaria {
  id: string;
  empresaId?: string; // id de uma empresa do sistema ou 'avulsa'
  nomeEmpresa: string;
  cnpj?: string;
  atividade: TipoAtividadeSimulador;
  descricaoAtividade?: string;
  anoAnalise: AnoSimulacaoReforma;
  faturamentoAnual: number;
  folhaAnual: number;           // salários brutos anuais
  proLaboreAnual: number;       // pró-labore anual dos sócios
  percentualVendasB2B: number;  // 0 a 100 (% de clientes PJ que aproveitam créditos)
  comprasInsumosAnual: number;  // Compras de mercadorias para revenda ou insumos produtivos
  despesasOperacionaisAnual: number; // Aluguel, energia, serviços tomados com crédito
  margemLucroEstimada: number;  // 0 a 100 (% margem líquida presumida/real)
  aliquotaIssMunicipal: number; // 2 a 5% (default 3% ou 5%)
  aliquotaIcmsInterno: number;  // default 18% (17% a 22%)
  aliquotaRatFap: number;       // default 2%
  aliquotaTerceiros: number;    // default 5.8%
}

export interface DetalhamentoTributosRegime {
  irpj: number;
  csll: number;
  pisCofinsOuCbs: number;
  icmsIssOuIbs: number;
  inssPatronalFolha: number;
  inssProLabore: number;
  outrosTributos?: number;
  totalTributosAnual: number;
  totalTributosMensal: number;
  aliquotaEfetivaTotal: number; // % sobre o faturamento
  creditoGeradoClientesB2B: number; // Crédito transferível aos compradores PJ
  creditoAproveitadoCompras: number; // Crédito que a própria empresa abate de compras
  custoLiquidoTributario: number;   // Total tributos menos créditos aproveitados
}

export interface ResultadoCenarioSimulacao {
  id: 'simples_tradicional' | 'simples_hibrido' | 'lucro_presumido' | 'lucro_real';
  titulo: string;
  subtitulo: string;
  descricao: string;
  elegivel: boolean;
  motivoInelegibilidade?: string;
  anexoSimples?: string;
  fatorRCalculado?: number; // Folha total / Faturamento
  fatorREnquadrado?: boolean; // Se >= 0.28
  tributos: DetalhamentoTributosRegime;
  diferencaAnualMelhorOpcao: number;
  percentualEconomia: number;
  isMelhorOpcao: boolean;
  pontosFortes: string[];
  pontosAtencao: string[];
}

export interface RelatorioParecerTributario {
  dataGeracao: string;
  contadorResponsavel: string;
  crcContador: string;
  escritorioNome: string;
  empresaNome: string;
  cnpj: string;
  faturamentoAnual: number;
  regimeRecomendado: string;
  economiaAnualProjetada: number;
  economiaMensalMedia: number;
  resumoParecer: string;
  cenarios: ResultadoCenarioSimulacao[];
}

export interface SimulacaoSalva {
  id: string;
  titulo: string;
  dataCriacao: string;
  parametros: ParametrosSimulacaoTributaria;
  regimeRecomendado: string;
  economiaAnual: number;
}

// =========================================================================
// --- MÓDULO DE FECHAMENTO DO SIMPLES NACIONAL & APURAÇÃO PGDAS-D ---
// =========================================================================

export type TipoAnexoSimples = 'Anexo I' | 'Anexo II' | 'Anexo III' | 'Anexo IV' | 'Anexo V';

export interface ReparticaoTributariaSimples {
  irpj: number;
  csll: number;
  cofins: number;
  pis: number;
  cpp: number;
  icms: number;
  ipi: number;
  iss: number;
}

export interface ItemApuracaoAnexo {
  anexo: TipoAnexoSimples;
  descricao: string;
  faixaIndex: number;
  faixaDescricao: string;
  rbt12: number;
  aliquotaNominal: number;
  parcelaDeduzir: number;
  aliquotaEfetivaBase: number;
  
  // Receitas segregadas
  receitaBrutaPeriodo: number;
  receitaTributacaoIntegral: number;
  receitaSubstituicaoTributariaIcms: number;
  receitaPisCofinsMonofasico: number;
  receitaExportacao: number;
  receitaIsentaImune: number;

  // Alíquotas segregadas aplicadas
  aliquotaEfetivaIntegral: number;
  aliquotaEfetivaSemIcms: number;
  aliquotaEfetivaSemPisCofins: number;
  aliquotaEfetivaSemIcmsPisCofins: number;

  // Valores calculados
  valorTributacaoIntegral: number;
  valorSubstituicaoTributariaIcms: number;
  valorPisCofinsMonofasico: number;
  valorDevidoTotal: number;

  reparticaoTributos: ReparticaoTributariaSimples;
}

export interface ResumoDocumentosPeriodo {
  totalDocumentos: number;
  totalNfe: {
    quantidade: number;
    valor: number;
  };
  totalNfce: {
    quantidade: number;
    valor: number;
  };
  totalNfse: {
    quantidade: number;
    valor: number;
  };
  totalCanceladas: {
    quantidade: number;
    valor: number;
  };
}

export interface ApuracaoSimplesNacional {
  id: string;
  empresaId: string;
  competencia: string; // Ex: '09/2026'
  dataApuracao: string;
  dataVencimentoDas: string;
  status: 'rascunho' | 'apurado' | 'transmitido_pgdas' | 'pago';
  
  // Receitas acumuladas e no período
  rbt12: number; // Receita Bruta acumulada 12 meses anteriores
  rpa: number; // Receita do Período de Apuração (Mês)
  rpaExportacao?: number;
  
  // Fator r (se aplicável para empresas com folha de pagamento)
  folha12Meses: number; // Folha de pagamentos + encargos dos últimos 12 meses
  fatorRCalculado: number; // Folha12 / RBT12
  fatorREnquadramento: 'Anexo III' | 'Anexo V' | 'Nao se aplica';
  
  // Segregação e Apuração por Anexos
  anexos: ItemApuracaoAnexo[];
  documentosResumo: ResumoDocumentosPeriodo;
  notasFiscaisIds: string[];

  // Totalizadores de tributos
  valorTotalDas: number;
  totalIrpj: number;
  totalCsll: number;
  totalCofins: number;
  totalPis: number;
  totalCpp: number;
  totalIcms: number;
  totalIpi: number;
  totalIss: number;

  // Guia DAS e Declaração PGDAS-D
  numeroGuiaDas: string;
  codigoBarras: string;
  linhaDigitavel: string;
  pixQrCodePayload: string;
  protocoloTransmissao?: string;
  reciboDeclaracao?: string;
  transmitidoEm?: string;
  usuarioTransmissao?: string;
  observacoes?: string;
  isDemo?: boolean;
}

export type TipoAtividadeMei =
  | 'comercio'
  | 'servicos'
  | 'comercio_e_servicos'
  | 'transporte_caminhoneiro';

export interface GuiaDasMei {
  id: string;
  empresaId: string;
  ano: number;
  mes: number; // 1 a 12
  competencia: string; // Ex: '01/2026'
  dataVencimento: string; // YYYY-MM-DD
  valorInss: number;
  valorIcms: number;
  valorIss: number;
  valorTotal: number;
  status: 'pendente' | 'pago' | 'vencido';
  dataPagamento?: string;
  codigoBarras: string;
  linhaDigitavel: string;
  pixQrCodePayload: string;
  numeroDocumento: string;
  observacoes?: string;
  isDemo?: boolean;
}

export type SituacaoLimiteMei = 'normal' | 'excesso_ate_20' | 'excesso_acima_20';

export interface DeclaracaoAnualMei {
  id: string;
  empresaId: string;
  anoCalendario: number;
  tipoDeclaracao: 'original' | 'retificadora' | 'extincao';
  status: 'rascunho' | 'transmitida';
  dataTransmissao?: string;
  receitaBrutaComercio: number;
  receitaBrutaServicos: number;
  receitaBrutaTotal: number;
  possuiuEmpregado: boolean;
  limiteAnual: number;
  excedeuLimite: boolean;
  valorExcedente: number;
  percentualExcesso: number;
  situacaoLimite: SituacaoLimiteMei;
  dasComplementarEstimado?: number;
  protocoloTransmissao?: string;
  reciboEntrega?: string;
  hashAutenticidade?: string;
  usuarioTransmissao?: string;
  observacoes?: string;
  isDemo?: boolean;
}

export interface ResumoFaturamentoMei {
  empresaId: string;
  ano: number;
  limiteAnual: number;
  limiteMensalMedio: number;
  faturamentoAcumuladoAno: number;
  percentualUtilizado: number;
  saldoRestante: number;
  faturamentoMedioMensal: number;
  projecaoAnual: number;
  statusLimite: 'seguro' | 'atencao' | 'alerta_20' | 'estourado';
  totalNotasFiscaisEmitidas: number;
  faturamentoComercio: number;
  faturamentoServicos: number;
  mesesFaturamento: {
    mes: number;
    mesNome: string;
    valorComercio: number;
    valorServicos: number;
    valorTotal: number;
    emitidasNfeQtd: number;
  }[];
  qtdeFuncionarios: number;
  funcionarioConforme: boolean;
  alertaCompras?: {
    totalCompras: number;
    percentualSobreFaturamento: number;
    excedeuLimiteCompras: boolean; // máx 80% do faturamento
  };
}

// =========================================================================
// --- DASHBOARD DE CONFORMIDADE FISCAL CONSOLIDADA (ESCRITÓRIO) ---
// =========================================================================

export interface FunilEtapaConformidade {
  id: string;
  etapa: string;
  contagem: number;
  totalBase: number;
  percentual: number; // 0-100
  valorFinanceiro?: number;
  detalhe: string;
  cor: string;
  gargalo?: boolean;
}

export interface MetricItemConformidade {
  titulo: string;
  valor: string | number;
  subtexto: string;
  status: 'normal' | 'alerta' | 'critico' | 'sucesso';
  variacao?: string;
}

export interface ResumoConformidadeEmpresa {
  empresaId: string;
  razaoSocial: string;
  nomeFantasia: string;
  cnpj: string;
  regimeTributario: RegimeTributario;
  scoreConformidade: number; // 0 a 100
  grauRisco: 'baixo' | 'medio' | 'alto' | 'critico';
  
  // Simples Nacional
  simplesStatus?: 'concluido' | 'pendente' | 'atrasado' | 'nao_se_aplica';
  simplesCompetencia?: string;
  simplesValorDas?: number;
  simplesVencimento?: string;

  // MEI
  meiStatus?: 'em_dia' | 'pendente' | 'atrasado' | 'nao_se_aplica';
  meiGuiaAtualPaga?: boolean;
  meiDasnStatus?: 'transmitida' | 'pendente' | 'nao_se_aplica';
  meiPercentualLimite?: number;

  // e-CAC / RFB
  pendenciasEcacTotal: number;
  pendenciasEcacCriticas: number;
  pendenciasEcacAltas: number;
  valorEcacEnvolvido: number;

  // Próximo marco e ação
  proximoPrazo?: string;
  proximaAcao: string;
  linkAcao: 'simples_nacional' | 'mei' | 'ecac_pendencias' | 'obrigacoes';
}

export interface EvolucaoMensalConformidade {
  mes: string;
  competencia: string;
  simplesTransmitidos: number;
  simplesPendentes: number;
  meiGuiasPagas: number;
  meiGuiasPendentes: number;
  ecacDetectadas: number;
  ecacResolvidas: number;
  taxaConformidadeGeral: number; // %
}

export interface DistribuicaoOrgaoEcac {
  orgao: string;
  quantidade: number;
  valorTotal: number;
  criticas: number;
}

// =========================================================================
// --- COBRANÇAS DE HONORÁRIOS, CONTRATOS, MENSALIDADES E RECIBOS ---
// =========================================================================

export type CategoriaServicoContabil =
  | 'Fiscal'
  | 'Contábil'
  | 'Folha/DP'
  | 'Societário'
  | 'BPO Financeiro'
  | 'Consultoria'
  | 'Certidões';

export interface ServicoContabil {
  id: string;
  codigo: string;
  nome: string;
  categoria: CategoriaServicoContabil;
  descricao: string;
  valorSugerido: number;
  recorrente: boolean;
  ativo: boolean;
}

export type StatusContratoHonorario = 'ativo' | 'suspenso' | 'cancelado' | 'renovado';

export interface ContratoHonorario {
  id: string;
  empresaId: string;
  clienteId?: string;
  numeroContrato: string;
  dataAssinatura: string; // YYYY-MM-DD
  dataInicioVigencia: string; // YYYY-MM-DD
  dataTerminoVigencia?: string; // YYYY-MM-DD ou indeterminado
  diaVencimento: number; // 5, 10, 15, 20, 25, etc.
  valorMensalidade: number;
  status: StatusContratoHonorario;
  reajusteAnualIndice: 'IPCA' | 'IGP-M' | 'INPC' | 'Fixo';
  servicosIds: string[];
  servicosContratadosNomes?: string[];
  documentoContratoUrl?: string;
  documentoContratoNome?: string;
  observacoes?: string;
  isDemo?: boolean;
}

export type StatusMensalidade = 'pendente' | 'pago' | 'atrasado' | 'cancelado';

export interface HistoricoEnvioCobranca {
  id: string;
  canal: 'email' | 'whatsapp';
  dataEnvio: string; // ISO string
  destinatario: string; // email ou telefone
  status: 'enviado' | 'entregue' | 'lido';
}

export interface MensalidadeHonorario {
  id: string;
  contratoId: string;
  empresaId: string;
  competencia: string; // Ex: '09/2026'
  dataVencimento: string; // YYYY-MM-DD
  dataPagamento?: string; // YYYY-MM-DD
  valor: number;
  valorPago?: number;
  status: StatusMensalidade;
  formaPagamento?: 'pix' | 'boleto' | 'transferencia' | 'dinheiro' | 'cartao';
  codigoBarras?: string;
  pixCopiaECola?: string;
  qrCodePixUrl?: string;
  reciboEmitido?: boolean;
  reciboId?: string;
  reciboNumero?: string;
  historicoEnvios: HistoricoEnvioCobranca[];
  observacao?: string;
  isDemo?: boolean;
}

export interface ReciboHonorario {
  id: string;
  numero: string; // Ex: 'REC-2026/094'
  mensalidadeId: string;
  contratoId: string;
  empresaId: string;
  razaoSocialCliente: string;
  nomeFantasiaCliente?: string;
  cnpjCpfCliente: string;
  enderecoCliente?: string;
  valor: number;
  valorPorExtenso: string;
  competencia: string; // '09/2026'
  dataEmissao: string; // YYYY-MM-DD
  dataPagamento: string; // YYYY-MM-DD
  formaPagamento: string;
  discriminacaoServicos: string[];
  nomeEscritorio: string;
  cnpjEscritorio: string;
  enderecoEscritorio: string;
  contadorResponsavel: string;
  crcContador: string;
}

export type TipoLembreteCobranca = 'preventivo' | 'vencimento' | 'atraso';

export interface RegraLembreteCobranca {
  id: string;
  nome: string;
  tipo: TipoLembreteCobranca;
  diasGatilho: number; // Ex: -5, -3, -1 (antes), 0 (no dia), 1, 3, 7, 15 (depois)
  canalPadrao: 'whatsapp' | 'email' | 'ambos';
  ativo: boolean;
  horarioDisparo: string; // Ex: '09:00'
  templateAssunto: string;
  templateMensagem: string;
}

export interface LogEnvioLembrete {
  id: string;
  mensalidadeId: string;
  empresaId: string;
  clienteNome: string;
  valor: number;
  competencia: string;
  dataVencimento: string;
  tipoLembrete: TipoLembreteCobranca;
  diasReferencia: number;
  canal: 'whatsapp' | 'email';
  destinatario: string;
  dataHoraEnvio: string; // ISO string
  status: 'entregue' | 'aberto' | 'falha';
  origem: 'robo_automatico' | 'disparo_manual';
  mensagemEnviada?: string;
}

export interface LembreteFilaItem {
  mensalidade: MensalidadeHonorario;
  empresa: Empresa;
  contrato?: ContratoHonorario;
  tipo: TipoLembreteCobranca;
  diasDiferenca: number; // negativo se vencendo no futuro, 0 hoje, positivo se atrasado
  regraAplicada: RegraLembreteCobranca;
  canalSugerido: 'whatsapp' | 'email' | 'ambos';
  destinatarioWhatsApp: string;
  destinatarioEmail: string;
  mensagemFormatada: string;
  assuntoFormatado: string;
  jaEnviadoHoje: boolean;
  ultimoEnvio?: HistoricoEnvioCobranca;
}

// =========================================================================
// --- CONTROLE PATRIMONIAL, ATIVO IMOBILIZADO & DEPRECIAÇÃO (CPC 27) ---
// =========================================================================

export type ClassificacaoAtivo =
  | 'maquinas_equipamentos'
  | 'moveis_utensilios'
  | 'veiculos'
  | 'computadores_ti'
  | 'edificacoes'
  | 'instalacoes'
  | 'benfeitorias'
  | 'ferramentas'
  | 'outros';

export type StatusBemPatrimonial =
  | 'ativo'
  | 'manutencao'
  | 'depreciado'
  | 'baixado'
  | 'doado';

export type StatusSeguro = 'vigente' | 'vencendo' | 'expirado' | 'sem_seguro';

export interface BemPatrimonial {
  id: string;
  empresaId: string;
  numeroPatrimonio: string; // Tombamento, ex: PAT-00104
  placaIdentificacao: string; // Ex: PLA-SP-2024-001
  descricao: string;
  classificacao: ClassificacaoAtivo;
  marca?: string;
  modelo?: string;
  numeroSerie?: string;
  localizacao: string; // Ex: "Sede - Sala TI", "Galpão Operacional"
  centroCustoId: string;
  responsavel?: string;
  status: StatusBemPatrimonial;

  // Dados de Aquisição / Nota Fiscal
  dataAquisicao: string; // YYYY-MM-DD
  numeroNotaFiscal: string;
  serieNotaFiscal?: string;
  fornecedorNome: string;
  fornecedorCnpj?: string;
  chaveAcessoNfe?: string;
  valorAquisicao: number;
  contratoVinculado?: string; // Número de contrato ou aditivo
  agio: number; // Ágio na aquisição / reavaliação
  desagio: number; // Deságio na aquisição

  // Dados do Seguro
  temSeguro: boolean;
  seguradora?: string;
  numeroApolice?: string;
  seguroDataInicio?: string;
  seguroDataFim?: string;
  valorSegurado?: number;
  seguroStatus?: StatusSeguro;

  // Parâmetros de Depreciação (CPC 27 / Tabela SRF)
  taxaDepreciacaoAnual: number; // % ao ano (ex: 20 para 20% a.a.)
  vidaUtilAnos: number; // Anos (ex: 5)
  valorResidualPercentual: number; // % do valor que não se deprecia
  valorResidual: number; // R$
  valorDepreciavel: number; // Valor Aquisição - Valor Residual
  depreciacaoMensal: number; // Quota mensal de depreciação
  mesesDepreciados: number; // Quantidade de meses decorridos desde a compra
  depreciacaoAcumulada: number; // Quota mensal * meses (limitado ao valor depreciável)
  valorContabilLiquido: number; // Valor Aquisição - Depreciação Acumulada + Ágio - Deságio

  // Baixa / Alienação
  dataBaixa?: string;
  motivoBaixa?: 'venda' | 'sucateamento' | 'sinistro' | 'doacao' | 'perda';
  valorVenda?: number;
  ganhoPerdaCapital?: number; // Valor Venda - Valor Contábil Líquido
  notaFiscalBaixa?: string;
  observacoesBaixa?: string;

  observacoes?: string;
  qrcodeSimulado?: string;
  isDemo?: boolean;
}

// =========================================================================
// --- CONTABILIDADE, PLANO DE CONTAS, CENTROS DE CUSTO & DEMONSTRAÇÕES ---
// =========================================================================

export interface CentroCusto {
  id: string;
  empresaId: string;
  codigo: string; // Ex: "01.01"
  nome: string;
  responsavel?: string;
  orcamentoMensal: number;
  totalBensAlocados?: number;
  valorPatrimonioTotal?: number;
}

export type NaturezaConta = 'devedora' | 'credora';
export type GrupoConta =
  | 'ativo'
  | 'passivo'
  | 'patrimonio_liquido'
  | 'receita'
  | 'custo'
  | 'despesa';

export interface ContaContabil {
  id: string;
  empresaId?: string; // Se 'padrao', compartilhada
  codigo: string; // Ex: "1.1.01.001", "1.2.03.001"
  nome: string;
  tipo: 'sintetica' | 'analitica';
  natureza: NaturezaConta;
  grupo: GrupoConta;
  grau: number; // 1 a 5
  saldoAtual: number;
  vinculoPatrimonio?: 'imobilizado_custo' | 'depreciacao_acumulada' | 'despesa_depreciacao' | 'nenhum';
}

export interface LinhaBalanco {
  codigo: string;
  descricao: string;
  saldo2025: number;
  saldo2026: number;
  analiseVertical2026: number; // % sobre Ativo Total
  analiseHorizontal: number; // % variação (2026 vs 2025)
  nivel: number;
  destaque?: boolean;
  grupo: 'ativo' | 'passivo_pl';
}

export interface BalancoPatrimonialData {
  empresaId: string;
  competencia: string; // '2026'
  ativoCirculanteTotal: number;
  ativoNaoCirculanteTotal: number;
  imobilizadoBruto: number;
  depreciacaoAcumulada: number;
  imobilizadoLiquido: number;
  ativoTotal: number;

  passivoCirculanteTotal: number;
  passivoNaoCirculanteTotal: number;
  patrimonioLiquidoTotal: number;
  passivoTotalComPl: number;

  linhas: LinhaBalanco[];
}

export interface LinhaDre {
  codigo: string;
  descricao: string;
  valor2025: number;
  valor2026: number;
  analiseVertical: number; // % sobre Receita Líquida
  analiseHorizontal: number; // % variação
  destaque?: boolean;
  tipo: 'receita' | 'deducao' | 'custo' | 'despesa' | 'ebitda' | 'resultado';
}

export interface DreData {
  empresaId: string;
  competencia: string; // '2026'
  receitaBruta: number;
  deducoesImpostos: number;
  receitaLiquida: number;
  cpvCustoServicos: number;
  lucroBruto: number;
  despesasOperacionais: number;
  despesaDepreciacao: number;
  ebitda: number; // LAIDA
  margemEbitda: number; // %
  ebit: number; // LAIR operacional
  resultadoFinanceiro: number;
  lair: number;
  provisaoTributos: number;
  lucroLiquido: number;
  margemLiquida: number; // %
  linhas: LinhaDre[];
}

export interface DfcLinha {
  categoria: 'operacional' | 'investimento' | 'financiamento' | 'saldo';
  descricao: string;
  valor2025: number;
  valor2026: number;
}

export interface DfcData {
  empresaId: string;
  competencia: string;
  fluxoOperacional: number;
  fluxoInvestimento: number; // Aquisições e alienações de imobilizado
  fluxoFinanciamento: number;
  variacaoLiquidaCaixa: number;
  saldoInicialCaixa: number;
  saldoFinalCaixa: number;
  linhas: DfcLinha[];
}

export interface IndicadoresContabeis {
  // Endividamento
  endividamentoGeral: number; // (Exigível Total / Ativo Total) * 100
  composicaoEndividamento: number; // (Passivo Circulante / Exigível Total) * 100
  imobilizacaoPatrimonioLiquido: number; // (Imobilizado Líquido / PL) * 100

  // Rentabilidade & Margens
  margemBruta: number; // (Lucro Bruto / Receita Líquida) * 100
  margemEbitda: number; // (EBITDA / Receita Líquida) * 100
  margemLiquida: number; // (Lucro Líquido / Receita Líquida) * 100
  roe: number; // (Lucro Líquido / PL) * 100
  roa: number; // (Lucro Líquido / Ativo Total) * 100

  // Liquidez
  liquidezCorrente: number; // Ativo Circulante / Passivo Circulante
  liquidezSeca: number; // (Ativo Circulante - Estoques) / Passivo Circulante
  liquidezGeral: number; // (Ativo Circulante + RLP) / (Passivo Circulante + PNC)
}

export interface LinhaBalancete {
  id: string;
  codigo: string;
  nome: string;
  tipo: 'sintetica' | 'analitica';
  natureza: NaturezaConta;
  grau: number;
  grupo: GrupoConta;
  saldoAnterior: number;
  saldoAnteriorNatureza: 'D' | 'C';
  movimentoDebito: number;
  movimentoCredito: number;
  saldoAtual: number;
  saldoAtualNatureza: 'D' | 'C';
  temMovimentacao: boolean;
}

export interface BalanceteData {
  empresaId: string;
  mes: number; // 1 a 12
  ano: number; // 2026
  competenciaTexto: string; // Ex: "Setembro de 2026"
  periodoInicio: string; // "01/09/2026"
  periodoFim: string; // "30/09/2026"
  linhas: LinhaBalancete[];
  totalSaldoAnteriorDevedor: number;
  totalSaldoAnteriorCredor: number;
  totalMovimentoDebito: number;
  totalMovimentoCredito: number;
  totalSaldoAtualDevedor: number;
  totalSaldoAtualCredor: number;
  diferencaMovimento: number;
  diferencaSaldoAtual: number;
  statusAuditoria: 'balanceado' | 'divergente';
  hashAuditoria: string;
  dataGeracao: string;
  contadorResponsavel: string;
  crcContador: string;
  auditorResponsavel?: string;
  auditorCrc?: string;
}

export type FrequenciaBackup = 'diario' | 'semanal' | 'quinzenal' | 'mensal';
export type FormatoBackup = 'json' | 'csv';
export type DestinoBackup = 'local_criptografado' | 'cloud_storage_seguro' | 'sftp_externo';

export interface BackupSchedule {
  id: string;
  titulo: string;
  frequencia: FrequenciaBackup;
  horarioExecucao: string; // Ex: "02:00"
  diasSemana?: number[]; // 0 = Domingo, 1 = Segunda, etc.
  diaDoMes?: number; // 1 a 31
  formato: FormatoBackup;
  destinoArmazenamento: DestinoBackup;
  incluirAnexos: boolean;
  criptografiaAtiva: boolean;
  retencaoDias: number; // Ex: 90 dias
  ativo: boolean;
  ultimoBackupEm?: string;
  proximaExecucaoEm?: string;
  criadoEm: string;
}

export interface BackupHistoryItem {
  id: string;
  scheduleId?: string;
  titulo: string;
  tipoTrigger: 'automatico' | 'manual';
  formato: FormatoBackup;
  destinoArmazenamento: DestinoBackup;
  status: 'sucesso' | 'em_andamento' | 'falha';
  tamanhoFormatado: string;
  tamanhoBytes: number;
  quantidadeRegistros: number;
  hashSha256: string;
  dataInicio: string;
  dataConclusao?: string;
  mensagemLog: string;
}




