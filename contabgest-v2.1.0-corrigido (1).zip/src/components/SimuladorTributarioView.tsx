import React, { useState, useEffect, useMemo } from 'react';
import {
  Calculator,
  Building2,
  TrendingDown,
  Percent,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Save,
  RotateCcw,
  Sparkles,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  ArrowRight,
  ShieldCheck,
  Award,
  Layers,
  Info,
  Calendar,
  DollarSign,
  Briefcase,
  Users,
  Trash2,
} from 'lucide-react';
import {
  Empresa,
  User,
  ParametrosSimulacaoTributaria,
  AnoSimulacaoReforma,
  TipoAtividadeSimulador,
  SimulacaoSalva,
} from '../types';
import {
  calcularComparativoTributario,
  obterParametrosReformaPorAno,
} from '../utils/tributarioCalculator';
import { GraficoComparativoTributario } from './simulador/GraficoComparativoTributario';
import { RelatorioParecerModal } from './simulador/RelatorioParecerModal';

interface SimuladorTributarioViewProps {
  empresas: Empresa[];
  selectedEmpresa?: Empresa | null;
  currentUser: User;
}

const CENARIOS_PREDEFINIDOS: Array<{
  nome: string;
  descricao: string;
  valores: Partial<ParametrosSimulacaoTributaria>;
}> = [
  {
    nome: 'Empresa de TI & Software (B2B)',
    descricao: 'Desenvolvimento e licenciamento com clientes corporativos e folha técnica',
    valores: {
      nomeEmpresa: 'Nexus Softwares S/A',
      atividade: 'servicos_anexo5',
      faturamentoAnual: 1800000,
      folhaAnual: 520000,
      proLaboreAnual: 140000,
      percentualVendasB2B: 95,
      comprasInsumosAnual: 120000,
      despesasOperacionaisAnual: 180000,
      margemLucroEstimada: 25,
      aliquotaIssMunicipal: 3.0,
    },
  },
  {
    nome: 'Comércio Atacadista / Distribuidora',
    descricao: 'Revenda de mercadorias em grande volume com compras tributadas de ICMS',
    valores: {
      nomeEmpresa: 'Distribuidora Aliança Ltda',
      atividade: 'comercio',
      faturamentoAnual: 3600000,
      folhaAnual: 240000,
      proLaboreAnual: 60000,
      percentualVendasB2B: 80,
      comprasInsumosAnual: 2200000,
      despesasOperacionaisAnual: 350000,
      margemLucroEstimada: 12,
      aliquotaIcmsInterno: 18.0,
    },
  },
  {
    nome: 'Clínica Médica & Saúde (Fator R)',
    descricao: 'Consultório especializado com sócios médicos e pró-labore representativo',
    valores: {
      nomeEmpresa: 'Clínica Vida Integrada',
      atividade: 'servicos_anexo5',
      faturamentoAnual: 960000,
      folhaAnual: 120000,
      proLaboreAnual: 190000,
      percentualVendasB2B: 10,
      comprasInsumosAnual: 80000,
      despesasOperacionaisAnual: 140000,
      margemLucroEstimada: 35,
      aliquotaIssMunicipal: 4.0,
    },
  },
  {
    nome: 'Indústria Metalúrgica & Manufatura',
    descricao: 'Fabricação e transformação de produtos com créditos expressivos de insumos',
    valores: {
      nomeEmpresa: 'Metalúrgica Precisão Ind.',
      atividade: 'industria',
      faturamentoAnual: 4200000,
      folhaAnual: 850000,
      proLaboreAnual: 120000,
      percentualVendasB2B: 90,
      comprasInsumosAnual: 2100000,
      despesasOperacionaisAnual: 400000,
      margemLucroEstimada: 15,
      aliquotaIcmsInterno: 18.0,
    },
  },
];

const ANOS_REFORMA: Array<{
  ano: AnoSimulacaoReforma;
  rotulo: string;
  destaque: string;
  descricao: string;
}> = [
  {
    ano: 2026,
    rotulo: '2026 (Ano Teste)',
    destaque: 'CBS 0,9% + IBS 0,1%',
    descricao: 'Fase de testes operacionais. Alíquotas simbólicas compensáveis com tributos federais.',
  },
  {
    ano: 2027,
    rotulo: '2027 (CBS Plena)',
    destaque: 'Fim do PIS/COFINS',
    descricao: 'PIS e COFINS são extintos. Entra a CBS com alíquota plena (~8,8%).',
  },
  {
    ano: 2028,
    rotulo: '2028 (Ajustes)',
    destaque: 'CBS Plena + IBS',
    descricao: 'Consolidação da CBS federal e alinhamento dos sistemas estaduais e municipais.',
  },
  {
    ano: 2029,
    rotulo: '2029 (Início IBS)',
    destaque: '10% IBS / 90% ICMS-ISS',
    descricao: 'Início da transição gradual de ICMS e ISS para o IBS estadual/municipal.',
  },
  {
    ano: 2030,
    rotulo: '2030 (Transição)',
    destaque: '20% IBS / 80% ICMS-ISS',
    descricao: 'Segunda etapa da transição federativa dos impostos sobre consumo.',
  },
  {
    ano: 2031,
    rotulo: '2031 (Transição)',
    destaque: '30% IBS / 70% ICMS-ISS',
    descricao: 'Aprofundamento da migração com transferência progressiva de créditos aos adquirentes.',
  },
  {
    ano: 2032,
    rotulo: '2032 (Último Ano)',
    destaque: '40% IBS / 60% ICMS-ISS',
    descricao: 'Último ano antes da extinção definitiva do ICMS estadual e ISS municipal.',
  },
  {
    ano: 2033,
    rotulo: '2033 (Vigência Plena)',
    destaque: 'IVA Dual Completo',
    descricao: 'Conclusão total da Reforma. Fim do ICMS/ISS. Vigência plena de IBS (~17,7%) + CBS (~8,8%).',
  },
];

export const SimuladorTributarioView: React.FC<SimuladorTributarioViewProps> = ({
  empresas,
  selectedEmpresa,
  currentUser,
}) => {
  // Estado das Premissas
  const [parametros, setParametros] = useState<ParametrosSimulacaoTributaria>({
    id: 'sim_1',
    nomeEmpresa: selectedEmpresa?.nomeFantasia || 'Nova Simulação Tributária',
    cnpj: selectedEmpresa?.cnpj || '',
    atividade: 'servicos_anexo3',
    descricaoAtividade: 'Prestação de Serviços em Geral e Tecnologia',
    anoAnalise: 2027,
    faturamentoAnual: selectedEmpresa ? selectedEmpresa.faturamentoMensal * 12 : 1200000,
    folhaAnual: selectedEmpresa ? (selectedEmpresa.qtdeFuncionarios || 4) * 4500 * 13.33 : 320000,
    proLaboreAnual: 120000,
    percentualVendasB2B: 70,
    comprasInsumosAnual: 250000,
    despesasOperacionaisAnual: 140000,
    margemLucroEstimada: 20,
    aliquotaIssMunicipal: 3.5,
    aliquotaIcmsInterno: 18.0,
    aliquotaRatFap: 2.0,
    aliquotaTerceiros: 5.8,
  });

  const [activeTab, setActiveTab] = useState<'simulador' | 'cenarios_salvos' | 'guia_reforma'>('simulador');
  const [modalRelatorioOpen, setModalRelatorioOpen] = useState(false);
  const [detalhesAbertos, setDetalhesAbertos] = useState<Record<string, boolean>>({
    simples_tradicional: false,
    simples_hibrido: false,
    lucro_presumido: false,
    lucro_real: false,
  });
  const [salvandoSucesso, setSalvandoSucesso] = useState(false);
  const [simulacoesSalvas, setSimulacoesSalvas] = useState<SimulacaoSalva[]>([]);

  // Carregar simulações salvas no localStorage
  useEffect(() => {
    const salvas = localStorage.getItem('contabgest_simulacoes_tributarias');
    if (salvas) {
      try {
        setSimulacoesSalvas(JSON.parse(salvas));
      } catch (e) {
        console.error('Erro ao ler simulações salvas:', e);
      }
    }
  }, []);

  // Quando o usuário seleciona uma empresa no menu superior ou dropdown
  const handleSelecionarEmpresa = (empresaId: string) => {
    if (empresaId === 'avulsa') {
      setParametros((prev) => ({
        ...prev,
        empresaId: undefined,
        nomeEmpresa: 'Cliente Prospect / Novo Negócio',
        cnpj: '',
        faturamentoAnual: 1200000,
      }));
      return;
    }

    const emp = empresas.find((e) => e.id === empresaId);
    if (!emp) return;

    setParametros((prev) => ({
      ...prev,
      empresaId: emp.id,
      nomeEmpresa: emp.nomeFantasia || emp.razaoSocial,
      cnpj: emp.cnpj,
      faturamentoAnual: emp.faturamentoMensal * 12,
      folhaAnual: Math.max(80000, (emp.qtdeFuncionarios || 3) * 4200 * 13.33),
      proLaboreAnual: 120000,
      atividade:
        emp.regimeTributario === 'Simples Nacional'
          ? 'servicos_anexo3'
          : emp.regimeTributario === 'Lucro Real'
          ? 'industria'
          : 'comercio',
    }));
  };

  // Carregar um cenário pré-definido
  const handleCarregarCenario = (cenario: typeof CENARIOS_PREDEFINIDOS[0]) => {
    setParametros((prev) => ({
      ...prev,
      ...cenario.valores,
    }));
  };

  // Executar Cálculo em Tempo Real
  const resultadoCalculo = useMemo(() => {
    return calcularComparativoTributario(parametros);
  }, [parametros]);

  const { cenarios, melhorOpcao, fatorRCalculado, fatorREnquadrado, resumoParecer } =
    resultadoCalculo;

  const reformaAtual = obterParametrosReformaPorAno(parametros.anoAnalise);

  const formatarMoeda = (val: number) =>
    val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  const toggleDetalhes = (id: string) => {
    setDetalhesAbertos((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Salvar Simulação no Histórico
  const handleSalvarSimulacao = () => {
    const novaSimulacao: SimulacaoSalva = {
      id: `sim_${Date.now()}`,
      titulo: `${parametros.nomeEmpresa} (${parametros.anoAnalise})`,
      dataCriacao: new Date().toISOString(),
      parametros: { ...parametros },
      regimeRecomendado: melhorOpcao.titulo,
      economiaAnual: Math.max(...cenarios.map((c) => c.diferencaAnualMelhorOpcao)),
    };

    const listaAtualizada = [novaSimulacao, ...simulacoesSalvas];
    setSimulacoesSalvas(listaAtualizada);
    localStorage.setItem('contabgest_simulacoes_tributarias', JSON.stringify(listaAtualizada));
    setSalvandoSucesso(true);
    setTimeout(() => setSalvandoSucesso(false), 2500);
  };

  const handleExcluirSimulacaoSalva = (id: string) => {
    const listaAtualizada = simulacoesSalvas.filter((s) => s.id !== id);
    setSimulacoesSalvas(listaAtualizada);
    localStorage.setItem('contabgest_simulacoes_tributarias', JSON.stringify(listaAtualizada));
  };

  const handleCarregarSimulacaoSalva = (sim: SimulacaoSalva) => {
    setParametros(sim.parametros);
    setActiveTab('simulador');
  };

  return (
    <div id="simulador-tributario-root" className="space-y-6 pb-12">
      {/* Header Principal com Breadcrumbs e Ações */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-900/20">
            <Calculator className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">
                Simulador de Regime Tributário & Reforma Tributária
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                Modelo Fiscal Code
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Compare Simples Tradicional, Simples Híbrido, Lucro Presumido e Lucro Real de 2026 a 2033 com diagnóstico e parecer executivo.
            </p>
          </div>
        </div>

        {/* Botões de Ação do Topo */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Seletor de Empresa */}
          <div className="relative">
            <select
              value={parametros.empresaId || 'avulsa'}
              onChange={(e) => handleSelecionarEmpresa(e.target.value)}
              className="appearance-none bg-slate-50 hover:bg-slate-100 border border-slate-300 text-slate-800 text-xs font-semibold rounded-lg pl-3 pr-8 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
            >
              <option value="avulsa">👤 Simulação Avulsa / Prospect</option>
              {empresas.map((emp) => (
                <option key={emp.id} value={emp.id}>
                  🏢 {emp.nomeFantasia} ({emp.regimeTributario})
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-3 pointer-events-none" />
          </div>

          <button
            onClick={handleSalvarSimulacao}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-300 transition-colors"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{salvandoSucesso ? 'Salvo no Histórico!' : 'Salvar Cenário'}</span>
          </button>

          <button
            onClick={() => setModalRelatorioOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition-colors shadow-sm shadow-emerald-700/20"
          >
            <FileText className="w-4 h-4" />
            <span>Gerar Parecer / PDF</span>
          </button>
        </div>
      </div>

      {/* Tabs de Navegação Interna */}
      <div className="flex border-b border-slate-200 bg-white px-4 rounded-xl">
        <button
          onClick={() => setActiveTab('simulador')}
          className={`py-3 px-4 font-semibold text-xs border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'simulador'
              ? 'border-emerald-600 text-emerald-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Calculator className="w-4 h-4" />
          <span>Calculadora & Comparativo</span>
        </button>

        <button
          onClick={() => setActiveTab('cenarios_salvos')}
          className={`py-3 px-4 font-semibold text-xs border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'cenarios_salvos'
              ? 'border-emerald-600 text-emerald-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Save className="w-4 h-4" />
          <span>Cenários Salvos ({simulacoesSalvas.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('guia_reforma')}
          className={`py-3 px-4 font-semibold text-xs border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'guia_reforma'
              ? 'border-emerald-600 text-emerald-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Info className="w-4 h-4" />
          <span>Cronograma da Reforma (2026 - 2033)</span>
        </button>
      </div>

      {activeTab === 'simulador' && (
        <>
          {/* Seletor de Ano da Reforma Tributária (Linha do Tempo 2026 - 2033) */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-600" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Ano de Análise da Transição da Reforma Tributária:
                </h3>
              </div>
              <span className="text-[11px] font-medium text-slate-500">
                Selecione o ano base para calcular o impacto do IVA Dual (IBS + CBS)
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
              {ANOS_REFORMA.map((item) => {
                const isSelected = parametros.anoAnalise === item.ano;
                return (
                  <button
                    key={item.ano}
                    onClick={() => setParametros((prev) => ({ ...prev, anoAnalise: item.ano }))}
                    className={`p-2 rounded-lg border text-left transition-all ${
                      isSelected
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <div className="font-bold text-xs">{item.ano}</div>
                    <div className={`text-[10px] truncate ${isSelected ? 'text-emerald-100' : 'text-slate-500'}`}>
                      {item.destaque}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Banner de Contexto do Ano Selecionado */}
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 flex items-center justify-between text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  <strong>Exercício {parametros.anoAnalise}:</strong>{' '}
                  {ANOS_REFORMA.find((a) => a.ano === parametros.anoAnalise)?.descricao}
                </span>
              </div>
              <span className="font-mono text-[11px] text-slate-500 hidden md:inline">
                CBS Efetiva: {(reformaAtual.aliquotaCbsEfetiva * 100).toFixed(1)}% | IBS Efetivo:{' '}
                {(reformaAtual.aliquotaIbsEfetiva * 100).toFixed(1)}%
              </span>
            </div>
          </div>

          {/* Cards de Cenários Rápidos / Exemplos Prontos */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                Exemplos de Negócios / Cenários Prontos:
              </span>
              <span className="text-[11px] text-slate-400">
                Clique para carregar premissas típicas de mercado
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {CENARIOS_PREDEFINIDOS.map((cenario, idx) => (
                <button
                  key={idx}
                  onClick={() => handleCarregarCenario(cenario)}
                  className="p-3 bg-white hover:bg-emerald-50/40 rounded-xl border border-slate-200 hover:border-emerald-300 text-left transition-all group"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-slate-800 group-hover:text-emerald-700">
                      {cenario.nome}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-emerald-600 transition-transform group-hover:translate-x-0.5" />
                  </div>
                  <p className="text-[11px] text-slate-500 line-clamp-2">
                    {cenario.descricao}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Painel Principal de Premissas e Inputs */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-emerald-600" />
                <h3 className="text-sm font-bold text-slate-800">
                  Premissas Financeiras & Operacionais da Empresa
                </h3>
              </div>
              <span className="text-xs text-slate-400">
                Ajuste os valores para recalcular automaticamente os 4 regimes
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {/* Coluna 1: Identificação e Atividade */}
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nome da Empresa / Cliente:
                  </label>
                  <input
                    type="text"
                    value={parametros.nomeEmpresa}
                    onChange={(e) => setParametros({ ...parametros, nomeEmpresa: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 bg-slate-50 focus:bg-white"
                    placeholder="Ex: Minha Empresa Ltda"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Segmento / Atividade Econômica:
                  </label>
                  <select
                    value={parametros.atividade}
                    onChange={(e) =>
                      setParametros({
                        ...parametros,
                        atividade: e.target.value as TipoAtividadeSimulador,
                      })
                    }
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 bg-slate-50 focus:bg-white font-medium"
                  >
                    <option value="comercio">🛒 Comércio (Revenda de Mercadorias - Anexo I)</option>
                    <option value="industria">🏭 Indústria (Transformação & Fabricação - Anexo II)</option>
                    <option value="servicos_anexo3">💼 Serviços em Geral / Manutenção (Anexo III)</option>
                    <option value="servicos_anexo4">🛡️ Limpeza, Vigilância, Obras, Advocacia (Anexo IV)</option>
                    <option value="servicos_anexo5">🔬 Serviços Intelectuais / TI / Medicina (Anexo V - Fator R)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    CNPJ (Opcional):
                  </label>
                  <input
                    type="text"
                    value={parametros.cnpj || ''}
                    onChange={(e) => setParametros({ ...parametros, cnpj: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 bg-slate-50 focus:bg-white font-mono"
                    placeholder="00.000.000/0001-00"
                  />
                </div>
              </div>

              {/* Coluna 2: Faturamento e Vendas B2B */}
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700">
                      Faturamento Bruto Anual:
                    </label>
                    <span className="text-[11px] text-emerald-700 font-semibold">
                      ~{formatarMoeda(parametros.faturamentoAnual / 12)} / mês
                    </span>
                  </div>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 text-xs font-bold">
                      R$
                    </span>
                    <input
                      type="number"
                      step="10000"
                      value={parametros.faturamentoAnual}
                      onChange={(e) =>
                        setParametros({
                          ...parametros,
                          faturamentoAnual: Math.max(0, Number(e.target.value)),
                        })
                      }
                      className="w-full pl-9 pr-3 py-2 text-xs font-semibold border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 bg-slate-50 focus:bg-white"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700">
                      Perfil de Clientes: Vendas B2B (% para Empresas PJ):
                    </label>
                    <span className="text-xs font-bold text-emerald-700">
                      {parametros.percentualVendasB2B}% B2B
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="5"
                    value={parametros.percentualVendasB2B}
                    onChange={(e) =>
                      setParametros({
                        ...parametros,
                        percentualVendasB2B: Number(e.target.value),
                      })
                    }
                    className="w-full accent-emerald-600 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                    <span>0% (100% Consumidor Final B2C)</span>
                    <span>100% (Grandes Empresas PJ B2B)</span>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700">
                      Margem Líquida Real Estimada (%):
                    </label>
                    <span className="text-xs font-bold text-slate-800">
                      {parametros.margemLucroEstimada}%
                    </span>
                  </div>
                  <input
                    type="number"
                    min="1"
                    max="90"
                    value={parametros.margemLucroEstimada}
                    onChange={(e) =>
                      setParametros({
                        ...parametros,
                        margemLucroEstimada: Math.max(1, Math.min(90, Number(e.target.value))),
                      })
                    }
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 bg-slate-50 focus:bg-white"
                  />
                </div>
              </div>

              {/* Coluna 3: Folha, Pró-Labore e Fator R */}
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Folha de Salários Bruta Anual (CLT):
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 text-xs font-bold">
                      R$
                    </span>
                    <input
                      type="number"
                      step="5000"
                      value={parametros.folhaAnual}
                      onChange={(e) =>
                        setParametros({
                          ...parametros,
                          folhaAnual: Math.max(0, Number(e.target.value)),
                        })
                      }
                      className="w-full pl-9 pr-3 py-2 text-xs font-semibold border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 bg-slate-50 focus:bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Pró-Labore Anual dos Sócios:
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 text-xs font-bold">
                      R$
                    </span>
                    <input
                      type="number"
                      step="5000"
                      value={parametros.proLaboreAnual}
                      onChange={(e) =>
                        setParametros({
                          ...parametros,
                          proLaboreAnual: Math.max(0, Number(e.target.value)),
                        })
                      }
                      className="w-full pl-9 pr-3 py-2 text-xs font-semibold border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 bg-slate-50 focus:bg-white"
                    />
                  </div>
                </div>

                {/* Card de Fator R em Tempo Real */}
                <div
                  className={`p-3 rounded-xl border text-xs ${
                    fatorREnquadrado
                      ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900'
                      : 'bg-amber-50/70 border-amber-300 text-amber-900'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold flex items-center gap-1.5">
                      <Percent className="w-3.5 h-3.5" />
                      Fator R Calculado:
                    </span>
                    <span className="font-black text-sm">
                      {(fatorRCalculado * 100).toFixed(1)}%
                    </span>
                  </div>
                  <p className="text-[11px] leading-tight">
                    {fatorREnquadrado
                      ? '🎉 Fator R ≥ 28%! Atividades do Anexo V migram para o Anexo III (alíquotas a partir de 6%).'
                      : '⚠️ Fator R < 28%. Se optar pelo Simples no Anexo V, pagará alíquota majorada (inicia em 15,5%).'}
                  </p>
                </div>
              </div>
            </div>

            {/* Accordion / Seção Expansível de Custos e Alíquotas Detalhadas */}
            <div className="pt-3 border-t border-slate-100">
              <details className="group">
                <summary className="text-xs font-bold text-slate-600 hover:text-slate-900 cursor-pointer flex items-center gap-1.5 select-none">
                  <ChevronDown className="w-4 h-4 transition-transform group-open:rotate-180 text-slate-400" />
                  <span>Configurações Avançadas de Custos & Alíquotas Locais (ICMS, ISS, Insumos)</span>
                </summary>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mt-3 pt-3 border-t border-slate-100 text-xs">
                  <div>
                    <label className="block text-slate-600 mb-1">
                      Compras Insumos / Mercadorias (Anual):
                    </label>
                    <input
                      type="number"
                      value={parametros.comprasInsumosAnual}
                      onChange={(e) =>
                        setParametros({
                          ...parametros,
                          comprasInsumosAnual: Math.max(0, Number(e.target.value)),
                        })
                      }
                      className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 mb-1">
                      Despesas Operacionais com Crédito (Anual):
                    </label>
                    <input
                      type="number"
                      value={parametros.despesasOperacionaisAnual}
                      onChange={(e) =>
                        setParametros({
                          ...parametros,
                          despesasOperacionaisAnual: Math.max(0, Number(e.target.value)),
                        })
                      }
                      className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 mb-1">
                      Alíquota ISS Municipal (%):
                    </label>
                    <input
                      type="number"
                      step="0.5"
                      min="2"
                      max="5"
                      value={parametros.aliquotaIssMunicipal}
                      onChange={(e) =>
                        setParametros({
                          ...parametros,
                          aliquotaIssMunicipal: Number(e.target.value),
                        })
                      }
                      className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 mb-1">
                      Alíquota ICMS Interno (%):
                    </label>
                    <input
                      type="number"
                      step="0.5"
                      value={parametros.aliquotaIcmsInterno}
                      onChange={(e) =>
                        setParametros({
                          ...parametros,
                          aliquotaIcmsInterno: Number(e.target.value),
                        })
                      }
                      className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs"
                    />
                  </div>
                </div>
              </details>
            </div>
          </div>

          {/* Banner de Destaque da Melhor Opção Encontrada */}
          <div className="bg-gradient-to-r from-emerald-700 via-emerald-600 to-teal-700 rounded-2xl p-6 text-white shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-white/20 text-white backdrop-blur-xs">
                <Award className="w-4 h-4" />
                <span>Regime Mais Vantajoso Identificado</span>
              </div>
              <h2 className="text-2xl font-black tracking-tight">
                {melhorOpcao.titulo}
              </h2>
              <p className="text-xs text-emerald-100 max-w-2xl leading-relaxed">
                {melhorOpcao.subtitulo} • Proporciona a menor carga líquida tributária anual de{' '}
                <strong>{formatarMoeda(melhorOpcao.tributos.totalTributosAnual)}</strong> com alíquota
                efetiva de <strong>{melhorOpcao.tributos.aliquotaEfetivaTotal.toFixed(2)}%</strong>.
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/20 min-w-[220px] text-right">
              <span className="text-xs text-emerald-100 block font-medium">
                Economia Máxima Anual Projetada:
              </span>
              <span className="text-2xl font-black text-white block">
                {formatarMoeda(Math.max(...cenarios.map((c) => c.diferencaAnualMelhorOpcao)))}
              </span>
              <span className="text-[11px] text-emerald-200 block">
                frente ao regime menos vantajoso
              </span>
            </div>
          </div>

          {/* Comparativo Lado a Lado: 4 Cenários (Cards) */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            {cenarios.map((cenario) => {
              const isWinner = cenario.isMelhorOpcao;
              const isOpen = detalhesAbertos[cenario.id];

              return (
                <div
                  key={cenario.id}
                  className={`rounded-2xl border transition-all flex flex-col justify-between ${
                    isWinner
                      ? 'bg-white border-2 border-emerald-500 shadow-md shadow-emerald-500/10 ring-4 ring-emerald-500/10'
                      : 'bg-white border-slate-200 shadow-xs hover:border-slate-300'
                  }`}
                >
                  {/* Topo do Card */}
                  <div className="p-5 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span
                          className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                            isWinner
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {isWinner ? '🏆 Recomendado' : 'Alternativa'}
                        </span>
                        <h3 className="text-base font-bold text-slate-900 mt-1">
                          {cenario.titulo}
                        </h3>
                        <p className="text-[11px] text-slate-500 line-clamp-1">
                          {cenario.subtitulo}
                        </p>
                      </div>
                    </div>

                    {/* Preço / Carga Total */}
                    <div className="py-2 border-y border-slate-100">
                      <span className="text-[11px] text-slate-400 block font-medium">
                        Carga Tributária Anual Total:
                      </span>
                      <div className="flex items-baseline gap-2">
                        <span className="text-2xl font-black text-slate-900">
                          {formatarMoeda(cenario.tributos.totalTributosAnual)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs mt-1">
                        <span className="text-slate-500">
                          ~{formatarMoeda(cenario.tributos.totalTributosMensal)} / mês
                        </span>
                        <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          {cenario.tributos.aliquotaEfetivaTotal.toFixed(2)}% efetivo
                        </span>
                      </div>
                    </div>

                    {/* Crédito B2B Gerado aos Clientes */}
                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 space-y-1 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500 font-medium">Crédito B2B p/ Clientes:</span>
                        <strong className="text-emerald-700 font-mono">
                          {formatarMoeda(cenario.tributos.creditoGeradoClientesB2B)}
                        </strong>
                      </div>
                      <p className="text-[10px] text-slate-400 leading-tight">
                        {cenario.id === 'simples_tradicional'
                          ? 'Transfere pouco ou nenhum crédito de PIS/COFINS/CBS aos clientes.'
                          : 'Gera crédito pleno, atraindo grandes compradores corporativos.'}
                      </p>
                    </div>

                    {/* Comparativo vs Melhor Opção */}
                    {!isWinner && (
                      <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-900 text-xs">
                        <div className="flex items-center justify-between font-bold">
                          <span>Custo Adicional:</span>
                          <span>+{formatarMoeda(cenario.diferencaAnualMelhorOpcao)}</span>
                        </div>
                        <span className="text-[10px] text-rose-700">
                          {cenario.percentualEconomia.toFixed(1)}% mais oneroso que o regime recomendado.
                        </span>
                      </div>
                    )}

                    {/* Toggle de Detalhamento de Tributos */}
                    <div>
                      <button
                        onClick={() => toggleDetalhes(cenario.id)}
                        className="w-full py-1.5 px-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-between transition-colors"
                      >
                        <span>{isOpen ? 'Ocultar Detalhes' : 'Ver Composição Tributária'}</span>
                        {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                      </button>

                      {isOpen && (
                        <div className="mt-2 p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1.5 font-mono">
                          <div className="flex justify-between">
                            <span className="text-slate-500">IRPJ:</span>
                            <span>{formatarMoeda(cenario.tributos.irpj)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">CSLL:</span>
                            <span>{formatarMoeda(cenario.tributos.csll)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">PIS/COFINS (ou CBS):</span>
                            <span>{formatarMoeda(cenario.tributos.pisCofinsOuCbs)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">ICMS / ISS (ou IBS):</span>
                            <span>{formatarMoeda(cenario.tributos.icmsIssOuIbs)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">INSS Patronal Folha:</span>
                            <span>{formatarMoeda(cenario.tributos.inssPatronalFolha)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">INSS Pró-Labore:</span>
                            <span>{formatarMoeda(cenario.tributos.inssProLabore)}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Rodapé do Card com Prós e Contras */}
                  <div className="p-4 bg-slate-50/60 border-t border-slate-100 rounded-b-2xl space-y-2 text-xs">
                    <div>
                      <span className="text-[10px] font-bold uppercase text-emerald-800 tracking-wider block mb-1">
                        Vantagens:
                      </span>
                      <ul className="space-y-1 text-[11px] text-slate-600">
                        {cenario.pontosFortes.slice(0, 2).map((p, i) => (
                          <li key={i} className="flex items-start gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0 mt-0.5" />
                            <span>{p}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <span className="text-[10px] font-bold uppercase text-amber-800 tracking-wider block mb-1">
                        Atenção:
                      </span>
                      <p className="text-[11px] text-slate-500">
                        {cenario.pontosAtencao[0]}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Gráfico Comparativo Recharts */}
          <GraficoComparativoTributario cenarios={cenarios} />

          {/* Tabela Analítica Comparativa Linha por Linha */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">
                Detalhamento Analítico Comparativo de Tributos
              </h3>
              <p className="text-xs text-slate-500">
                Visualização minuciosa de cada rubrica fiscal em base anual
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <th className="py-3 px-4">Tributo / Encargo</th>
                    <th className="py-3 px-4 text-right">Simples Tradicional</th>
                    <th className="py-3 px-4 text-right">Simples Híbrido</th>
                    <th className="py-3 px-4 text-right">Lucro Presumido</th>
                    <th className="py-3 px-4 text-right">Lucro Real</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  <tr className="hover:bg-slate-50">
                    <td className="py-2.5 px-4 font-sans font-medium text-slate-700">
                      IRPJ (Imposto de Renda PJ)
                    </td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[0].tributos.irpj)}</td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[1].tributos.irpj)}</td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[2].tributos.irpj)}</td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[3].tributos.irpj)}</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-2.5 px-4 font-sans font-medium text-slate-700">
                      CSLL (Contribuição Social s/ Lucro)
                    </td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[0].tributos.csll)}</td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[1].tributos.csll)}</td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[2].tributos.csll)}</td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[3].tributos.csll)}</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-2.5 px-4 font-sans font-medium text-slate-700">
                      PIS & COFINS / CBS Federal
                    </td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[0].tributos.pisCofinsOuCbs)}</td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[1].tributos.pisCofinsOuCbs)}</td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[2].tributos.pisCofinsOuCbs)}</td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[3].tributos.pisCofinsOuCbs)}</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-2.5 px-4 font-sans font-medium text-slate-700">
                      ICMS / ISS / IBS Subnacional
                    </td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[0].tributos.icmsIssOuIbs)}</td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[1].tributos.icmsIssOuIbs)}</td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[2].tributos.icmsIssOuIbs)}</td>
                    <td className="py-2.5 px-4 text-right">{formatarMoeda(cenarios[3].tributos.icmsIssOuIbs)}</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="py-2.5 px-4 font-sans font-medium text-slate-700">
                      INSS Patronal (Folha & Pró-Labore)
                    </td>
                    <td className="py-2.5 px-4 text-right">
                      {formatarMoeda(cenarios[0].tributos.inssPatronalFolha + cenarios[0].tributos.inssProLabore)}
                    </td>
                    <td className="py-2.5 px-4 text-right">
                      {formatarMoeda(cenarios[1].tributos.inssPatronalFolha + cenarios[1].tributos.inssProLabore)}
                    </td>
                    <td className="py-2.5 px-4 text-right">
                      {formatarMoeda(cenarios[2].tributos.inssPatronalFolha + cenarios[2].tributos.inssProLabore)}
                    </td>
                    <td className="py-2.5 px-4 text-right">
                      {formatarMoeda(cenarios[3].tributos.inssPatronalFolha + cenarios[3].tributos.inssProLabore)}
                    </td>
                  </tr>
                  <tr className="bg-slate-50 font-bold text-slate-900 border-t-2 border-slate-300">
                    <td className="py-3 px-4 font-sans">CARGA TRIBUTÁRIA ANUAL</td>
                    <td className="py-3 px-4 text-right text-emerald-800 font-extrabold">
                      {formatarMoeda(cenarios[0].tributos.totalTributosAnual)}
                    </td>
                    <td className="py-3 px-4 text-right text-emerald-800 font-extrabold">
                      {formatarMoeda(cenarios[1].tributos.totalTributosAnual)}
                    </td>
                    <td className="py-3 px-4 text-right text-emerald-800 font-extrabold">
                      {formatarMoeda(cenarios[2].tributos.totalTributosAnual)}
                    </td>
                    <td className="py-3 px-4 text-right text-emerald-800 font-extrabold">
                      {formatarMoeda(cenarios[3].tributos.totalTributosAnual)}
                    </td>
                  </tr>
                  <tr className="bg-emerald-50/60 font-sans font-bold text-emerald-950">
                    <td className="py-2.5 px-4">Alíquota Efetiva Real (% s/ Faturamento)</td>
                    <td className="py-2.5 px-4 text-right">{cenarios[0].tributos.aliquotaEfetivaTotal.toFixed(2)}%</td>
                    <td className="py-2.5 px-4 text-right">{cenarios[1].tributos.aliquotaEfetivaTotal.toFixed(2)}%</td>
                    <td className="py-2.5 px-4 text-right">{cenarios[2].tributos.aliquotaEfetivaTotal.toFixed(2)}%</td>
                    <td className="py-2.5 px-4 text-right">{cenarios[3].tributos.aliquotaEfetivaTotal.toFixed(2)}%</td>
                  </tr>
                  <tr className="hover:bg-slate-50 font-sans text-slate-600">
                    <td className="py-2.5 px-4">Crédito Tributário B2B Transferido</td>
                    <td className="py-2.5 px-4 text-right font-mono font-medium text-emerald-700">
                      {formatarMoeda(cenarios[0].tributos.creditoGeradoClientesB2B)}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono font-medium text-emerald-700">
                      {formatarMoeda(cenarios[1].tributos.creditoGeradoClientesB2B)}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono font-medium text-emerald-700">
                      {formatarMoeda(cenarios[2].tributos.creditoGeradoClientesB2B)}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono font-medium text-emerald-700">
                      {formatarMoeda(cenarios[3].tributos.creditoGeradoClientesB2B)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {/* Aba de Cenários Salvos */}
      {activeTab === 'cenarios_salvos' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Histórico de Cenários & Simulações Salvas
              </h3>
              <p className="text-xs text-slate-500">
                Recupere simulações anteriores para renegociações ou reuniões com clientes
              </p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 bg-slate-100 rounded-lg text-slate-700">
              {simulacoesSalvas.length} {simulacoesSalvas.length === 1 ? 'registro' : 'registros'}
            </span>
          </div>

          {simulacoesSalvas.length === 0 ? (
            <div className="text-center py-12 border-2 border-dashed border-slate-200 rounded-xl space-y-2">
              <Calculator className="w-8 h-8 text-slate-400 mx-auto" />
              <p className="text-sm font-semibold text-slate-700">Nenhum cenário salvo ainda</p>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Na aba da calculadora, clique em &ldquo;Salvar Cenário&rdquo; para armazenar simulações de clientes e prospects.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
              {simulacoesSalvas.map((sim) => (
                <div
                  key={sim.id}
                  className="p-4 hover:bg-slate-50 flex items-center justify-between gap-4 transition-colors"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-800">{sim.titulo}</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                        {sim.regimeRecomendado}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 flex items-center gap-3">
                      <span>Faturamento: {formatarMoeda(sim.parametros.faturamentoAnual)}</span>
                      <span>•</span>
                      <span>Ano: {sim.parametros.anoAnalise}</span>
                      <span>•</span>
                      <span>Data: {new Date(sim.dataCriacao).toLocaleDateString('pt-BR')}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleCarregarSimulacaoSalva(sim)}
                      className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition-colors"
                    >
                      Carregar
                    </button>
                    <button
                      onClick={() => handleExcluirSimulacaoSalva(sim.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      title="Excluir simulação salva"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Aba do Guia da Reforma Tributária */}
      {activeTab === 'guia_reforma' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-6">
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-slate-900">
              Guia Prático da Reforma Tributária (EC 132/2023 & LC 224/2025)
            </h3>
            <p className="text-xs text-slate-500">
              Entenda a transição do sistema tributário tradicional para o IVA Dual (CBS + IBS) e o impacto no Simples Nacional
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200">
                <h4 className="font-bold text-emerald-950 text-sm mb-1">
                  O que é o Modelo Híbrido do Simples Nacional?
                </h4>
                <p className="text-xs text-emerald-900 leading-relaxed">
                  A Emenda Constitucional 132/2023 permite que micro e pequenas empresas optantes pelo Simples Nacional escolham recolher o <strong>IBS (estadual/municipal)</strong> e a <strong>CBS (federal)</strong> pelo regime regular não-cumulativo, mantendo o IRPJ, CSLL e CPP dentro do Simples. Isso permite <strong>transferir 100% de crédito tributário</strong> aos clientes B2B, evitando perda de contratos com grandes empresas.
                </p>
              </div>

              <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
                <h4 className="font-bold text-blue-950 text-sm mb-1">
                  Por que o B2B muda tudo na Reforma?
                </h4>
                <p className="text-xs text-blue-900 leading-relaxed">
                  Hoje, clientes do Simples Tradicional aproveitam apenas uma fração de crédito de ICMS/ISS e zero de PIS/COFINS. Com o IVA Dual, compradores do regime geral exigirão crédito amplo de 26,5% a 28%. Empresas que vendem exclusivamente para outras empresas (B2B) precisarão avaliar a migração para o Simples Híbrido ou Lucro Presumido/Real.
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
                Linha do Tempo da Transição (Ano a Ano):
              </h4>
              <div className="space-y-2 text-xs">
                {ANOS_REFORMA.map((ano) => (
                  <div key={ano.ano} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-start gap-3">
                    <span className="font-bold text-emerald-700 font-mono text-sm shrink-0">
                      {ano.ano}
                    </span>
                    <div>
                      <strong className="text-slate-800 block text-xs">{ano.rotulo}</strong>
                      <span className="text-[11px] text-slate-600 leading-tight block">
                        {ano.descricao}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Parecer e Impressão de Relatório */}
      <RelatorioParecerModal
        isOpen={modalRelatorioOpen}
        onClose={() => setModalRelatorioOpen(false)}
        parametros={parametros}
        cenarios={cenarios}
        melhorOpcao={melhorOpcao}
        fatorRCalculado={fatorRCalculado}
        fatorREnquadrado={fatorREnquadrado}
        resumoParecer={resumoParecer}
        currentUser={currentUser}
      />
    </div>
  );
};
