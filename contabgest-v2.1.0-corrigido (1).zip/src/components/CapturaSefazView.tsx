import React, { useState, useEffect, useMemo, useRef } from 'react';
import JSZip from 'jszip';
import {
  Download,
  Printer,
  Search,
  Filter,
  RefreshCw,
  FileText,
  FileCode,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Ban,
  Building2,
  DollarSign,
  Calendar,
  X,
  Eye,
  SlidersHorizontal,
  RotateCcw,
  CheckSquare,
  Square,
  Archive,
  UploadCloud,
  KeyRound,
  FileCheck2,
  HelpCircle,
  Copy,
  ExternalLink,
  ChevronDown,
  Layers,
  ArrowDownToLine,
  Truck,
  PackageCheck,
  Send,
  Loader2,
  Check,
} from 'lucide-react';
import {
  Empresa,
  NotaFiscalEntrada,
  TipoManifestacaoDestinatario,
  StatusEscrituracaoEntrada,
  SincronizacaoSefazLog,
} from '../types';
import { api } from '../services/api';
import {
  gerarDanfeEntradaPdf,
  getDanfeEntradaPdfBlob,
  gerarLoteDanfeEntradasPdf,
  gerarXmlDanfeEntrada,
  formatChaveAcesso,
  formatMoedaDanfe,
  formatCpfCnpjDanfe,
  formatDataDanfe,
} from '../utils/danfePdfGenerator';

interface CapturaSefazViewProps {
  selectedEmpresa?: Empresa;
  empresas: Empresa[];
  onRefreshParent?: () => void;
}

export const CapturaSefazView: React.FC<CapturaSefazViewProps> = ({
  selectedEmpresa,
  empresas,
  onRefreshParent,
}) => {
  const [notas, setNotas] = useState<NotaFiscalEntrada[]>([]);
  const [logsSefaz, setLogsSefaz] = useState<SincronizacaoSefazLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isCapturingKey, setIsCapturingKey] = useState(false);
  const [isExportingZip, setIsExportingZip] = useState(false);
  const [statusFeedback, setStatusFeedback] = useState<{ tipo: 'sucesso' | 'erro' | 'aviso'; mensagem: string } | null>(null);

  // Consulta por Chave
  const [chaveInput, setChaveInput] = useState('');
  const [efetuarCienciaAuto, setEfetuarCienciaAuto] = useState(true);

  // Filtros
  const [searchTerm, setSearchTerm] = useState('');
  const [filtroManifestacao, setFiltroManifestacao] = useState<string>('todas');
  const [filtroEscrituracao, setFiltroEscrituracao] = useState<string>('todas');
  const [filtroDataInicio, setFiltroDataInicio] = useState('');
  const [filtroDataFim, setFiltroDataFim] = useState('');
  const [filtroFornecedorUf, setFiltroFornecedorUf] = useState('todas');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  // Seleção em lote
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Modais
  const [selectedNotaDetalhes, setSelectedNotaDetalhes] = useState<NotaFiscalEntrada | null>(null);
  const [selectedNotaManifestar, setSelectedNotaManifestar] = useState<{
    nota: NotaFiscalEntrada;
    tipo: TipoManifestacaoDestinatario;
  } | null>(null);
  const [justificativaManifestacao, setJustificativaManifestacao] = useState('');
  const [showLogsModal, setShowLogsModal] = useState(false);
  const [copiadoId, setCopiadoId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Carrega notas fiscais de entrada emitidas contra a empresa ativa
  const carregarNotas = async () => {
    setLoading(true);
    try {
      const [notasData, logsData] = await Promise.all([
        api.getNotasFiscaisEntrada(selectedEmpresa?.id),
        api.getSincronizacoesSefaz(selectedEmpresa?.id),
      ]);
      setNotas(notasData);
      setLogsSefaz(logsData);
    } catch (err: any) {
      console.error('Erro ao carregar dados DF-e:', err);
      setStatusFeedback({
        tipo: 'erro',
        mensagem: 'Não foi possível carregar as notas fiscais de entrada do servidor.',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregarNotas();
  }, [selectedEmpresa?.id]);

  // Sincronização do Robô DF-e da SEFAZ
  const handleSincronizarSefaz = async () => {
    const empresaAlvo = selectedEmpresa || empresas[0];
    if (!empresaAlvo) {
      alert('Selecione uma empresa para consultar os documentos fiscais na SEFAZ.');
      return;
    }

    setIsSyncing(true);
    setStatusFeedback(null);
    try {
      const resultado = await api.sincronizarEntradasSefaz(empresaAlvo.id);
      await carregarNotas();
      if (onRefreshParent) onRefreshParent();
      setStatusFeedback({
        tipo: 'sucesso',
        mensagem: `${resultado.log.mensagem} (${resultado.log.tempoMs}ms)`,
      });
      setTimeout(() => setStatusFeedback(null), 7000);
    } catch (err: any) {
      console.error('Erro na sincronização SEFAZ:', err);
      setStatusFeedback({
        tipo: 'erro',
        mensagem: err.message || 'Falha ao conectar ao Web Service Distribuição DF-e da Receita Federal.',
      });
    } finally {
      setIsSyncing(false);
    }
  };

  // Captura direta via Chave de 44 Dígitos
  const handleCapturarPorChave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const chaveLimpa = chaveInput.replace(/\D/g, '');

    if (chaveLimpa.length !== 44) {
      setStatusFeedback({
        tipo: 'aviso',
        mensagem: 'A chave de acesso da NF-e deve conter exatamente 44 dígitos numéricos.',
      });
      return;
    }

    const empresaAlvo = selectedEmpresa || empresas[0];
    if (!empresaAlvo) {
      alert('Selecione uma empresa destinatária.');
      return;
    }

    setIsCapturingKey(true);
    setStatusFeedback(null);
    try {
      const notaCapturada = await api.capturarNotaPorChave(
        empresaAlvo.id,
        chaveLimpa,
        efetuarCienciaAuto
      );
      setChaveInput('');
      await carregarNotas();
      if (onRefreshParent) onRefreshParent();
      setStatusFeedback({
        tipo: 'sucesso',
        mensagem: `NF-e Nº ${notaCapturada.numero} capturada com sucesso da SEFAZ! XML e DANFE prontos para download.`,
      });
      setTimeout(() => setStatusFeedback(null), 6000);
    } catch (err: any) {
      console.error('Erro ao capturar chave:', err);
      setStatusFeedback({
        tipo: 'erro',
        mensagem: err.message || 'Erro ao consultar documento fiscal por chave na SEFAZ.',
      });
    } finally {
      setIsCapturingKey(false);
    }
  };

  // Importar XML via arquivo local
  const handleImportarArquivoXml = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.xml')) {
      alert('Selecione um arquivo de extensão .XML válido.');
      return;
    }

    const empresaAlvo = selectedEmpresa || empresas[0];
    if (!empresaAlvo) {
      alert('Selecione uma empresa antes de importar o XML.');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (event) => {
      const xmlString = event.target?.result as string;
      if (!xmlString) return;

      try {
        const nova = await api.importarXmlEntrada(empresaAlvo.id, xmlString);
        await carregarNotas();
        if (onRefreshParent) onRefreshParent();
        setStatusFeedback({
          tipo: 'sucesso',
          mensagem: `Arquivo XML da NF-e Nº ${nova.numero} (${nova.fornecedorNome}) importado e integrado com sucesso!`,
        });
        setTimeout(() => setStatusFeedback(null), 6000);
      } catch (err: any) {
        console.error('Erro ao importar XML:', err);
        setStatusFeedback({
          tipo: 'erro',
          mensagem: err.message || 'Falha ao processar a estrutura do arquivo XML.',
        });
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Manifestar Destinatário
  const handleExecutarManifestacao = async () => {
    if (!selectedNotaManifestar) return;
    const { nota, tipo } = selectedNotaManifestar;

    if (tipo === 'nao_realizada' && justificativaManifestacao.trim().length < 15) {
      alert('A justificativa de operação não realizada deve ter no mínimo 15 caracteres (Exigência SEFAZ).');
      return;
    }

    try {
      await api.manifestarNotaEntrada(nota.id, tipo, justificativaManifestacao);
      setSelectedNotaManifestar(null);
      setJustificativaManifestacao('');
      await carregarNotas();
      setStatusFeedback({
        tipo: 'sucesso',
        mensagem: `Evento de Manifestação (${tipo.toUpperCase()}) registrado na SEFAZ para a NF-e Nº ${nota.numero}!`,
      });
      setTimeout(() => setStatusFeedback(null), 5000);
    } catch (err: any) {
      alert(err.message || 'Erro ao registrar manifestação do destinatário na SEFAZ.');
    }
  };

  // Alterar Status de Escrituração
  const handleAlterarEscrituracao = async (id: string, novoStatus: StatusEscrituracaoEntrada) => {
    try {
      await api.updateStatusEscrituracaoEntrada(id, novoStatus);
      setNotas((prev) =>
        prev.map((n) => (n.id === id ? { ...n, statusEscrituracao: novoStatus } : n))
      );
    } catch (err: any) {
      alert(err.message || 'Erro ao atualizar escrituração.');
    }
  };

  // Baixar XML individual
  const handleBaixarXmlIndividual = (nota: NotaFiscalEntrada) => {
    const xmlContent = gerarXmlDanfeEntrada(nota);
    const blob = new Blob([xmlContent], { type: 'application/xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `NFe_${nota.chaveAcesso}.xml`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setStatusFeedback({
      tipo: 'sucesso',
      mensagem: `Arquivo XML da NF-e Nº ${nota.numero} baixado com sucesso!`,
    });
    setTimeout(() => setStatusFeedback(null), 4000);
  };

  // Baixar / Imprimir DANFE em PDF individual
  const handleBaixarDanfePdfIndividual = (nota: NotaFiscalEntrada, printDirectly = false) => {
    try {
      gerarDanfeEntradaPdf(nota, {
        autoDownload: !printDirectly,
        printDirectly,
      });
      setStatusFeedback({
        tipo: 'sucesso',
        mensagem: printDirectly
          ? `Disparando impressão do DANFE de entrada da NF-e Nº ${nota.numero}...`
          : `DANFE em PDF da NF-e Nº ${nota.numero} baixado com sucesso!`,
      });
      setTimeout(() => setStatusFeedback(null), 4000);
    } catch (err: any) {
      console.error('Erro ao gerar DANFE PDF:', err);
      alert('Erro ao gerar o arquivo PDF do DANFE.');
    }
  };

  // Baixar Lote em arquivo .ZIP (XMLs e PDFs selecionados)
  const handleBaixarLoteZip = async (modo: 'ambos' | 'xmls_apenas' | 'pdfs_apenas' = 'ambos') => {
    const lista = selectedIds.length > 0 ? notas.filter((n) => selectedIds.includes(n.id)) : filteredNotas;

    if (lista.length === 0) {
      alert('Nenhuma nota fiscal encontrada para exportação.');
      return;
    }

    setIsExportingZip(true);
    setStatusFeedback(null);
    try {
      const zip = new JSZip();
      const pastaXmls = zip.folder('XMLs_NFe_Entrada');
      const pastaPdfs = zip.folder('DANFEs_PDF_Entrada');

      for (let i = 0; i < lista.length; i++) {
        const n = lista[i];
        const chave = (n.chaveAcesso || '').replace(/\D/g, '');
        const nomeBase = `NFe_${String(n.numero).padStart(9, '0')}_${chave.slice(0, 14)}`;

        // Adiciona XML
        if (modo === 'ambos' || modo === 'xmls_apenas') {
          const xml = gerarXmlDanfeEntrada(n);
          pastaXmls?.file(`${nomeBase}.xml`, xml);
        }

        // Adiciona PDF
        if (modo === 'ambos' || modo === 'pdfs_apenas') {
          const pdfBlob = getDanfeEntradaPdfBlob(n);
          pastaPdfs?.file(`${nomeBase}.pdf`, pdfBlob);
        }
      }

      // Manifesto contábil em JSON
      const manifesto = {
        titulo: 'Arquivo em Lote de Documentos Fiscais Eletrônicos de Entrada (SEFAZ DF-e)',
        empresaDestinataria: selectedEmpresa?.razaoSocial || 'Empresa Selecionada',
        cnpjDestinatario: selectedEmpresa?.cnpj || 'N/A',
        dataExportacao: new Date().toISOString(),
        sistema: 'ContabGest ERP - Captura e Controle DF-e (fsist/Quive)',
        totalNotas: lista.length,
        valorTotalEntradas: lista.reduce((acc, curr) => acc + curr.valorTotal, 0),
        creditosTributariosRecuperaveis: {
          icms: lista.reduce((acc, curr) => acc + (curr.impostos.icms || 0), 0),
          pis: lista.reduce((acc, curr) => acc + (curr.impostos.pis || 0), 0),
          cofins: lista.reduce((acc, curr) => acc + (curr.impostos.cofins || 0), 0),
          ipi: lista.reduce((acc, curr) => acc + (curr.impostos.ipi || 0), 0),
        },
        documentos: lista.map((n) => ({
          numero: n.numero,
          serie: n.serie,
          chaveAcesso: n.chaveAcesso,
          dataEmissao: n.dataEmissao,
          dataCapturaSefaz: n.dataCapturaSefaz,
          nsuSefaz: n.nsuSefaz,
          fornecedorNome: n.fornecedorNome,
          fornecedorCnpj: n.fornecedorCnpj,
          fornecedorUf: n.fornecedorUf,
          valorTotal: n.valorTotal,
          manifestacao: n.manifestacao,
          statusEscrituracao: n.statusEscrituracao,
        })),
      };

      zip.file('manifesto_remessa_fiscal_dfe.json', JSON.stringify(manifesto, null, 2));

      const blob = await zip.generateAsync({ type: 'blob' });
      const dataStr = new Date().toISOString().split('T')[0];
      const nomeZip = `DF-e_SEFAZ_Entradas_${dataStr}_(${lista.length}_notas).zip`;

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = nomeZip;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setStatusFeedback({
        tipo: 'sucesso',
        mensagem: `Pacote ZIP com ${lista.length} nota(s) fiscais baixado com sucesso!`,
      });
      setTimeout(() => setStatusFeedback(null), 6000);
    } catch (err: any) {
      console.error('Erro ao gerar ZIP de lote:', err);
      alert('Erro ao compactar o lote de arquivos.');
    } finally {
      setIsExportingZip(false);
    }
  };

  // Imprimir Lote de DANFEs em PDF consolidado
  const handleImprimirLotePdf = (printDirectly = false) => {
    const lista = selectedIds.length > 0 ? notas.filter((n) => selectedIds.includes(n.id)) : filteredNotas;
    if (lista.length === 0) {
      alert('Nenhuma nota fiscal para gerar o lote de impressão.');
      return;
    }
    gerarLoteDanfeEntradasPdf(lista, {
      autoDownload: !printDirectly,
      printDirectly,
    });
  };

  // Filtragem das Notas de Entrada
  const filteredNotas = useMemo(() => {
    return notas.filter((nota) => {
      const term = searchTerm.trim().toLowerCase();
      const matchesSearch =
        !term ||
        nota.fornecedorNome.toLowerCase().includes(term) ||
        nota.fornecedorCnpj.replace(/\D/g, '').includes(term.replace(/\D/g, '')) ||
        String(nota.numero).includes(term) ||
        nota.chaveAcesso.includes(term.replace(/\D/g, '')) ||
        nota.naturezaOperacao.toLowerCase().includes(term);

      const matchesManifestacao =
        filtroManifestacao === 'todas' || nota.manifestacao === filtroManifestacao;

      const matchesEscrituracao =
        filtroEscrituracao === 'todas' || nota.statusEscrituracao === filtroEscrituracao;

      const matchesUf =
        filtroFornecedorUf === 'todas' || nota.fornecedorUf === filtroFornecedorUf;

      let matchesPeriodo = true;
      if (filtroDataInicio) {
        matchesPeriodo = matchesPeriodo && nota.dataEmissao.split('T')[0] >= filtroDataInicio;
      }
      if (filtroDataFim) {
        matchesPeriodo = matchesPeriodo && nota.dataEmissao.split('T')[0] <= filtroDataFim;
      }

      return matchesSearch && matchesManifestacao && matchesEscrituracao && matchesUf && matchesPeriodo;
    });
  }, [
    notas,
    searchTerm,
    filtroManifestacao,
    filtroEscrituracao,
    filtroFornecedorUf,
    filtroDataInicio,
    filtroDataFim,
  ]);

  // Métricas agregadas
  const metricas = useMemo(() => {
    const totalNotas = filteredNotas.length;
    const valorTotal = filteredNotas.reduce((acc, curr) => acc + curr.valorTotal, 0);
    const icmsRecuperavel = filteredNotas.reduce((acc, curr) => acc + (curr.impostos.icms || 0), 0);
    const semManifestacao = filteredNotas.filter((n) => n.manifestacao === 'sem_manifestacao').length;
    const pendentesEscrituracao = filteredNotas.filter((n) => n.statusEscrituracao === 'pendente').length;
    return {
      totalNotas,
      valorTotal,
      icmsRecuperavel,
      semManifestacao,
      pendentesEscrituracao,
    };
  }, [filteredNotas]);

  // Gestão de Seleção
  const visibleIds = filteredNotas.map((n) => n.id);
  const isAllSelected = visibleIds.length > 0 && visibleIds.every((id) => selectedIds.includes(id));
  const isSomeSelected = visibleIds.some((id) => selectedIds.includes(id)) && !isAllSelected;

  const toggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedIds((prev) => prev.filter((id) => !visibleIds.includes(id)));
    } else {
      setSelectedIds((prev) => Array.from(new Set([...prev, ...visibleIds])));
    }
  };

  const toggleSelectOne = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const copiarChave = (chave: string) => {
    navigator.clipboard.writeText(chave);
    setCopiadoId(chave);
    setTimeout(() => setCopiadoId(null), 2500);
  };

  const badgeManifestacao = (manifestacao: TipoManifestacaoDestinatario) => {
    switch (manifestacao) {
      case 'confirmada':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Operação Confirmada
          </span>
        );
      case 'ciencia':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-200">
            <Eye className="w-3.5 h-3.5 text-blue-600" />
            Ciência da Emissão
          </span>
        );
      case 'desconhecida':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            Desconhecida
          </span>
        );
      case 'nao_realizada':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-100 text-rose-800 border border-rose-200">
            <Ban className="w-3.5 h-3.5 text-rose-600" />
            Não Realizada
          </span>
        );
      case 'sem_manifestacao':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300">
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            Sem Manifestação
          </span>
        );
    }
  };

  const badgeEscrituracao = (status: StatusEscrituracaoEntrada) => {
    switch (status) {
      case 'escriturada':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
            <FileCheck2 className="w-3 h-3 text-emerald-600" />
            Escriturada
          </span>
        );
      case 'estoque_atualizado':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-indigo-50 text-indigo-700 border border-indigo-200">
            <PackageCheck className="w-3 h-3 text-indigo-600" />
            Estoque Entrado
          </span>
        );
      case 'divergencia':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-rose-50 text-rose-700 border border-rose-200">
            <AlertTriangle className="w-3 h-3 text-rose-600" />
            Divergência
          </span>
        );
      case 'pendente':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-amber-50 text-amber-700 border border-amber-200">
            <Clock className="w-3 h-3 text-amber-600" />
            Pendente
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Feedback */}
      {statusFeedback && (
        <div
          className={`px-4 py-3 rounded-xl text-xs flex items-center justify-between shadow-sm animate-in fade-in ${
            statusFeedback.tipo === 'sucesso'
              ? 'bg-emerald-50 border border-emerald-300 text-emerald-800'
              : statusFeedback.tipo === 'aviso'
              ? 'bg-amber-50 border border-amber-300 text-amber-800'
              : 'bg-rose-50 border border-rose-300 text-rose-800'
          }`}
        >
          <div className="flex items-center gap-2">
            {statusFeedback.tipo === 'sucesso' && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />}
            {statusFeedback.tipo === 'aviso' && <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />}
            {statusFeedback.tipo === 'erro' && <Ban className="w-4 h-4 text-rose-600 shrink-0" />}
            <span className="font-semibold">{statusFeedback.mensagem}</span>
          </div>
          <button
            type="button"
            onClick={() => setStatusFeedback(null)}
            className="text-slate-500 hover:text-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Banner de Integração SEFAZ estilo fsist / Quive */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-6 shadow-md border border-slate-800 relative overflow-hidden">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-1.5 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold tracking-wide uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Robô de Distribuição DF-e Ativo
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-white/10 text-slate-300">
                Ambiente Nacional SEFAZ
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
              Captura Automática de NF-e Emitidas contra o CNPJ
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Consulta contínua de notas eletrônicas de fornecedores no Web Service da Receita Federal,
              com registro de Manifestação do Destinatário (MDe) e download em lote de arquivos XMLs e DANFEs em PDF.
            </p>

            {selectedEmpresa && (
              <div className="pt-1 flex flex-wrap items-center gap-3 text-xs text-slate-300">
                <span className="flex items-center gap-1.5 font-medium text-white">
                  <Building2 className="w-3.5 h-3.5 text-emerald-400" />
                  {selectedEmpresa.razaoSocial}
                </span>
                <span className="text-slate-400 font-mono">CNPJ: {selectedEmpresa.cnpj}</span>
                <span className="text-slate-400">UF: {selectedEmpresa.uf}</span>
              </div>
            )}
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
            <button
              id="btn-sincronizar-sefaz-top"
              type="button"
              disabled={isSyncing}
              onClick={handleSincronizarSefaz}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white text-sm font-semibold rounded-xl shadow-sm transition-colors disabled:opacity-60"
            >
              <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
              {isSyncing ? 'Varrendo SEFAZ...' : 'Sincronizar SEFAZ Agora'}
            </button>

            <button
              id="btn-ver-logs-sefaz"
              type="button"
              onClick={() => setShowLogsModal(true)}
              className="inline-flex items-center justify-center gap-2 px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-white text-sm font-medium rounded-xl border border-white/15 transition-colors"
            >
              <Layers className="w-4 h-4 text-slate-300" />
              Histórico DF-e
            </button>
          </div>
        </div>
      </div>

      {/* Caixa de Captura Rápida por Chave de Acesso (Estilo fsist.com) */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900">
              Captura Expressa por Chave de Acesso (44 Dígitos)
            </h3>
          </div>
          <span className="text-xs text-slate-500">
            Consulta individual direta no portal da SEFAZ com desbloqueio do XML completo
          </span>
        </div>

        <form onSubmit={handleCapturarPorChave} className="space-y-3">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <input
                id="input-chave-acesso-sefaz"
                type="text"
                maxLength={54}
                value={chaveInput}
                onChange={(e) => setChaveInput(e.target.value)}
                placeholder="Ex: 3526 0919 8224 5000 0178 5500 2000 0123 9010 0918 2736"
                className="w-full px-4 py-2.5 text-sm font-mono tracking-wider border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 placeholder:text-slate-400"
              />
              {chaveInput && (
                <button
                  type="button"
                  onClick={() => setChaveInput('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                id="btn-capturar-chave-submit"
                type="submit"
                disabled={isCapturingKey || !chaveInput.trim()}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-sm font-semibold rounded-xl shadow-sm transition-colors disabled:opacity-50"
              >
                {isCapturingKey ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Consultando SEFAZ...
                  </>
                ) : (
                  <>
                    <ArrowDownToLine className="w-4 h-4" />
                    Capturar Nota
                  </>
                )}
              </button>

              <label
                htmlFor="input-upload-xml-file"
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 text-sm font-medium rounded-xl border border-slate-300 shadow-sm transition-colors cursor-pointer"
                title="Importar arquivo XML da máquina"
              >
                <UploadCloud className="w-4 h-4 text-slate-600" />
                Importar XML
              </label>
              <input
                id="input-upload-xml-file"
                ref={fileInputRef}
                type="file"
                accept=".xml"
                onChange={handleImportarArquivoXml}
                className="hidden"
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-600 pt-1">
            <label className="inline-flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={efetuarCienciaAuto}
                onChange={(e) => setEfetuarCienciaAuto(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
              />
              <span className="font-medium">
                Efetuar <strong>Ciência da Emissão</strong> automaticamente para obter o XML completo na SEFAZ
              </span>
            </label>

            <span className="text-slate-400 hidden sm:inline">
              {chaveInput.replace(/\D/g, '').length}/44 dígitos
            </span>
          </div>
        </form>
      </div>

      {/* Cards de Métricas */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-slate-200/80 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Notas de Entrada</span>
            <span className="p-2 bg-blue-50 text-blue-600 rounded-lg">
              <FileText className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-xl font-bold text-slate-900">
            {metricas.totalNotas}
          </div>
          <div className="text-xs text-slate-500 mt-1 font-mono">
            R$ {formatMoedaDanfe(metricas.valorTotal)}
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200/80 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Créditos ICMS</span>
            <span className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
              <DollarSign className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-xl font-bold text-emerald-600 font-mono">
            R$ {formatMoedaDanfe(metricas.icmsRecuperavel)}
          </div>
          <div className="text-xs text-slate-500 mt-1">Crédito fiscal a compensar</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200/80 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Pendente de Ciência</span>
            <span className="p-2 bg-amber-50 text-amber-600 rounded-lg">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-xl font-bold text-amber-600">
            {metricas.semManifestacao}
          </div>
          <div className="text-xs text-slate-500 mt-1">Aguardando manifestação MDe</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200/80 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Pendente Escrituração</span>
            <span className="p-2 bg-purple-50 text-purple-600 rounded-lg">
              <FileCheck2 className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 text-xl font-bold text-purple-600">
            {metricas.pendentesEscrituracao}
          </div>
          <div className="text-xs text-slate-500 mt-1">Aguardando lançamento fiscal</div>
        </div>
      </div>

      {/* Barra de Filtros e Busca */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="input-busca-notas-entrada"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por Fornecedor, CNPJ, Nº da Nota, Chave de Acesso ou CFOP..."
              className="w-full pl-9 pr-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              id="select-filtro-manifestacao"
              value={filtroManifestacao}
              onChange={(e) => setFiltroManifestacao(e.target.value)}
              className="px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg text-slate-700 focus:ring-2 focus:ring-emerald-500"
            >
              <option value="todas">Manifestação: Todas</option>
              <option value="confirmada">Operação Confirmada</option>
              <option value="ciencia">Ciência da Emissão</option>
              <option value="sem_manifestacao">Sem Manifestação</option>
              <option value="desconhecida">Desconhecida</option>
              <option value="nao_realizada">Não Realizada</option>
            </select>

            <select
              id="select-filtro-escrituracao"
              value={filtroEscrituracao}
              onChange={(e) => setFiltroEscrituracao(e.target.value)}
              className="px-3 py-2 text-xs font-medium bg-white border border-slate-300 rounded-lg text-slate-700 focus:ring-2 focus:ring-emerald-500"
            >
              <option value="todas">Escrituração: Todas</option>
              <option value="pendente">Pendente</option>
              <option value="escriturada">Escriturada</option>
              <option value="estoque_atualizado">Estoque Atualizado</option>
              <option value="divergencia">Com Divergência</option>
            </select>

            <button
              id="btn-toggle-filtros-avancados-entrada"
              type="button"
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border transition-colors ${
                showAdvancedFilters || filtroDataInicio || filtroDataFim || filtroFornecedorUf !== 'todas'
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-700 font-semibold'
                  : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              Filtro por Período / UF
            </button>
          </div>
        </div>

        {/* Linha de Filtros Avançados */}
        {showAdvancedFilters && (
          <div className="pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-3 animate-in fade-in">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">
                Data Emissão Inicial
              </label>
              <input
                type="date"
                value={filtroDataInicio}
                onChange={(e) => setFiltroDataInicio(e.target.value)}
                className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">
                Data Emissão Final
              </label>
              <input
                type="date"
                value={filtroDataFim}
                onChange={(e) => setFiltroDataFim(e.target.value)}
                className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
              />
            </div>
            <div className="flex items-end gap-2">
              <div className="flex-1">
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  UF do Fornecedor
                </label>
                <select
                  value={filtroFornecedorUf}
                  onChange={(e) => setFiltroFornecedorUf(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                >
                  <option value="todas">Todas as UFs</option>
                  <option value="SP">SP - São Paulo</option>
                  <option value="RJ">RJ - Rio de Janeiro</option>
                  <option value="MG">MG - Minas Gerais</option>
                  <option value="RS">RS - Rio Grande do Sul</option>
                  <option value="PR">PR - Paraná</option>
                  <option value="GO">GO - Goiás</option>
                </select>
              </div>

              {(filtroDataInicio || filtroDataFim || filtroFornecedorUf !== 'todas') && (
                <button
                  type="button"
                  onClick={() => {
                    setFiltroDataInicio('');
                    setFiltroDataFim('');
                    setFiltroFornecedorUf('todas');
                  }}
                  className="px-3 py-1.5 text-xs text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-lg"
                >
                  Limpar
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Barra de Ações em Lote */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={toggleSelectAll}
            className="flex items-center gap-2 text-xs font-medium text-slate-700 hover:text-slate-900"
          >
            {isAllSelected ? (
              <CheckSquare className="w-4 h-4 text-emerald-600" />
            ) : isSomeSelected ? (
              <div className="w-4 h-4 bg-emerald-600 rounded flex items-center justify-center text-white text-[10px] font-bold">
                -
              </div>
            ) : (
              <Square className="w-4 h-4 text-slate-400" />
            )}
            <span>
              {selectedIds.length > 0
                ? `${selectedIds.length} selecionada(s)`
                : `Selecionar todas (${filteredNotas.length})`}
            </span>
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Botão Baixar XMLs em ZIP */}
          <button
            id="btn-baixar-lote-xml-zip-entrada"
            type="button"
            disabled={isExportingZip || filteredNotas.length === 0}
            onClick={() => handleBaixarLoteZip('xmls_apenas')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-white hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-300 shadow-sm transition-colors disabled:opacity-50"
            title="Baixar pacote .ZIP contendo os arquivos XML das notas selecionadas"
          >
            <FileCode className="w-3.5 h-3.5 text-blue-600" />
            Baixar XMLs (.ZIP)
          </button>

          {/* Botão Baixar DANFEs PDF em ZIP */}
          <button
            id="btn-baixar-lote-danfe-zip-entrada"
            type="button"
            disabled={isExportingZip || filteredNotas.length === 0}
            onClick={() => handleBaixarLoteZip('pdfs_apenas')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-white hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-300 shadow-sm transition-colors disabled:opacity-50"
            title="Baixar pacote .ZIP contendo os DANFEs em PDF das notas selecionadas"
          >
            <FileText className="w-3.5 h-3.5 text-rose-600" />
            Baixar PDFs (.ZIP)
          </button>

          {/* Pacote Completo Contábil */}
          <button
            id="btn-baixar-pacote-completo-entrada"
            type="button"
            disabled={isExportingZip || filteredNotas.length === 0}
            onClick={() => handleBaixarLoteZip('ambos')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-sm transition-colors disabled:opacity-50"
            title="Baixar pacote completo com XMLs + PDFs + Manifesto JSON"
          >
            <Archive className="w-3.5 h-3.5" />
            Pacote Completo Contábil (.ZIP)
          </button>

          {/* Imprimir Lote de PDFs */}
          <button
            id="btn-imprimir-lote-pdf-entrada"
            type="button"
            onClick={() => handleImprimirLotePdf(false)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-white hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-300 shadow-sm transition-colors"
            title="Gerar um único PDF com todos os DANFEs consolidados para impressão em massa"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
            Imprimir Lote DANFE
          </button>
        </div>
      </div>

      {/* Tabela de Notas Fiscais de Entrada */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        {loading ? (
          <div className="h-64 flex items-center justify-center">
            <div className="flex flex-col items-center gap-2">
              <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
              <span className="text-xs text-slate-500 font-medium">
                Carregando documentos fiscais de entrada...
              </span>
            </div>
          </div>
        ) : filteredNotas.length === 0 ? (
          <div className="text-center py-16 px-4">
            <div className="w-14 h-14 bg-slate-100 text-slate-400 rounded-2xl flex items-center justify-center mx-auto mb-3">
              <FileText className="w-7 h-7" />
            </div>
            <h4 className="text-base font-semibold text-slate-800">
              Nenhuma nota fiscal de entrada encontrada
            </h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
              Não foram encontradas notas fiscais emitidas contra o CNPJ com os filtros atuais.
              Clique em "Sincronizar SEFAZ Agora" para efetuar uma varredura DF-e ou consulte por Chave de Acesso.
            </p>
            <div className="mt-4 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={handleSincronizarSefaz}
                className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-sm"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Varredura SEFAZ
              </button>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-4 w-10 text-center">
                    <input
                      type="checkbox"
                      checked={isAllSelected}
                      onChange={toggleSelectAll}
                      className="w-3.5 h-3.5 text-emerald-600 rounded border-slate-300"
                    />
                  </th>
                  <th className="py-3 px-4">Documento / Emissão</th>
                  <th className="py-3 px-4">Fornecedor (Emitente)</th>
                  <th className="py-3 px-4">Natureza / CFOP</th>
                  <th className="py-3 px-4 text-right">Valor Total / Impostos</th>
                  <th className="py-3 px-4 text-center">Manifestação MDe</th>
                  <th className="py-3 px-4 text-center">Escrituração</th>
                  <th className="py-3 px-4 text-center">Downloads & Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredNotas.map((nota) => {
                  const isSelected = selectedIds.includes(nota.id);
                  return (
                    <tr
                      key={nota.id}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        isSelected ? 'bg-emerald-50/40' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="py-3.5 px-4 text-center">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelectOne(nota.id)}
                          className="w-3.5 h-3.5 text-emerald-600 rounded border-slate-300"
                        />
                      </td>

                      {/* Documento / Emissão */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 text-sm">
                            NF-e {nota.numero}
                          </span>
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-600">
                            Série {nota.serie}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1.5">
                          <Calendar className="w-3 h-3 text-slate-400" />
                          <span>Emissão: {formatDataDanfe(nota.dataEmissao)}</span>
                        </div>
                        <div className="mt-1 flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => copiarChave(nota.chaveAcesso)}
                            className="font-mono text-[10px] text-slate-500 hover:text-slate-900 flex items-center gap-1 group"
                            title="Clique para copiar os 44 dígitos da chave"
                          >
                            <span>{nota.chaveAcesso.slice(0, 4)}...{nota.chaveAcesso.slice(-4)}</span>
                            {copiadoId === nota.chaveAcesso ? (
                              <Check className="w-3 h-3 text-emerald-600" />
                            ) : (
                              <Copy className="w-3 h-3 text-slate-400 group-hover:text-slate-600" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Fornecedor */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900 max-w-[240px] truncate" title={nota.fornecedorNome}>
                          {nota.fornecedorNome}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                          CNPJ: {formatCpfCnpjDanfe(nota.fornecedorCnpj)}
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          {nota.fornecedorMunicipio} - {nota.fornecedorUf}
                        </div>
                      </td>

                      {/* Natureza / CFOP */}
                      <td className="py-3.5 px-4">
                        <div className="max-w-[200px] truncate font-medium text-slate-800" title={nota.naturezaOperacao}>
                          {nota.naturezaOperacao}
                        </div>
                        <div className="text-[10px] text-slate-500 mt-0.5 font-mono">
                          CFOP: {nota.cfopPrincipal}
                        </div>
                      </td>

                      {/* Valor Total & Impostos */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="font-bold text-slate-900 font-mono text-sm">
                          R$ {formatMoedaDanfe(nota.valorTotal)}
                        </div>
                        {nota.impostos?.icms ? (
                          <div className="text-[10px] text-emerald-600 font-mono mt-0.5 font-medium">
                            ICMS: R$ {formatMoedaDanfe(nota.impostos.icms)}
                          </div>
                        ) : null}
                        <div className="text-[10px] text-slate-400">
                          {nota.itens?.length || 1} item(ns)
                        </div>
                      </td>

                      {/* Manifestação do Destinatário */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex flex-col items-center gap-1.5">
                          {badgeManifestacao(nota.manifestacao)}

                          {/* Ações de Manifestação rápida */}
                          <div className="flex items-center gap-1">
                            {nota.manifestacao === 'sem_manifestacao' && (
                              <>
                                <button
                                  type="button"
                                  onClick={() =>
                                    setSelectedNotaManifestar({ nota, tipo: 'ciencia' })
                                  }
                                  className="px-2 py-0.5 text-[10px] font-semibold bg-blue-50 text-blue-700 hover:bg-blue-100 rounded border border-blue-200 transition-colors"
                                  title="Dar Ciência da Emissão para liberar download do XML completo"
                                >
                                  Dar Ciência
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    setSelectedNotaManifestar({ nota, tipo: 'confirmada' })
                                  }
                                  className="px-2 py-0.5 text-[10px] font-semibold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded border border-emerald-200 transition-colors"
                                  title="Confirmar Operação (Mercadoria recebida)"
                                >
                                  Confirmar
                                </button>
                              </>
                            )}

                            {nota.manifestacao !== 'desconhecida' && nota.manifestacao !== 'nao_realizada' && (
                              <button
                                type="button"
                                onClick={() =>
                                  setSelectedNotaManifestar({ nota, tipo: 'desconhecida' })
                                }
                                className="px-1.5 py-0.5 text-[10px] text-slate-500 hover:text-amber-700 hover:bg-amber-50 rounded transition-colors"
                                title="Desconhecer Operação (Proteção contra nota fria)"
                              >
                                Desconhecer
                              </button>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Status de Escrituração */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex flex-col items-center gap-1">
                          {badgeEscrituracao(nota.statusEscrituracao)}
                          <select
                            value={nota.statusEscrituracao}
                            onChange={(e) =>
                              handleAlterarEscrituracao(
                                nota.id,
                                e.target.value as StatusEscrituracaoEntrada
                              )
                            }
                            className="text-[10px] text-slate-600 bg-transparent border-0 hover:bg-slate-100 rounded px-1 py-0.5 cursor-pointer focus:ring-1 focus:ring-emerald-500"
                          >
                            <option value="pendente">Mudar: Pendente</option>
                            <option value="escriturada">Mudar: Escriturada</option>
                            <option value="estoque_atualizado">Mudar: Estoque Atualizado</option>
                            <option value="divergencia">Mudar: Divergência</option>
                          </select>
                        </div>
                      </td>

                      {/* Downloads e Ações */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {/* Baixar XML */}
                          <button
                            id={`btn-download-xml-${nota.id}`}
                            type="button"
                            onClick={() => handleBaixarXmlIndividual(nota)}
                            className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors"
                            title="Baixar arquivo XML da NF-e"
                          >
                            <FileCode className="w-4 h-4" />
                          </button>

                          {/* Baixar DANFE PDF */}
                          <button
                            id={`btn-download-danfe-pdf-${nota.id}`}
                            type="button"
                            onClick={() => handleBaixarDanfePdfIndividual(nota, false)}
                            className="p-1.5 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded-lg transition-colors"
                            title="Baixar DANFE em PDF oficial"
                          >
                            <FileText className="w-4 h-4" />
                          </button>

                          {/* Imprimir DANFE */}
                          <button
                            id={`btn-imprimir-danfe-${nota.id}`}
                            type="button"
                            onClick={() => handleBaixarDanfePdfIndividual(nota, true)}
                            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                            title="Imprimir DANFE diretamente"
                          >
                            <Printer className="w-4 h-4" />
                          </button>

                          {/* Detalhes da Nota */}
                          <button
                            id={`btn-ver-detalhes-${nota.id}`}
                            type="button"
                            onClick={() => setSelectedNotaDetalhes(nota)}
                            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                            title="Ver itens e detalhes completos da NF-e"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal de Detalhes da Nota Fiscal de Entrada */}
      {selectedNotaDetalhes && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-xl max-w-3xl w-full border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95">
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <FileText className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="text-base font-bold">
                    NF-e Nº {selectedNotaDetalhes.numero} - Série {selectedNotaDetalhes.serie}
                  </h3>
                  <span className="text-xs text-slate-300">
                    Capturada da SEFAZ em {formatDataDanfe(selectedNotaDetalhes.dataCapturaSefaz)}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedNotaDetalhes(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto text-xs">
              {/* Chave de Acesso */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-1">
                <span className="text-[11px] font-semibold text-slate-500 uppercase">
                  Chave de Acesso Oficial (44 Dígitos)
                </span>
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-xs font-bold text-slate-800 break-all">
                    {formatChaveAcesso(selectedNotaDetalhes.chaveAcesso)}
                  </span>
                  <button
                    type="button"
                    onClick={() => copiarChave(selectedNotaDetalhes.chaveAcesso)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs bg-white border border-slate-300 hover:bg-slate-100 rounded text-slate-700 shrink-0 font-medium"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    Copiar
                  </button>
                </div>
              </div>

              {/* Informações do Emitente e Destinatário */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
                  <span className="text-[11px] font-bold text-slate-600 uppercase flex items-center gap-1.5">
                    <Truck className="w-3.5 h-3.5 text-indigo-600" />
                    Fornecedor (Emitente)
                  </span>
                  <div className="font-bold text-slate-900 text-sm">
                    {selectedNotaDetalhes.fornecedorNome}
                  </div>
                  <div className="text-slate-600">
                    CNPJ: <span className="font-mono">{formatCpfCnpjDanfe(selectedNotaDetalhes.fornecedorCnpj)}</span>
                  </div>
                  <div className="text-slate-600">
                    IE: {selectedNotaDetalhes.fornecedorIe || 'Isento / Não informado'}
                  </div>
                  <div className="text-slate-600">
                    Município: {selectedNotaDetalhes.fornecedorMunicipio} - {selectedNotaDetalhes.fornecedorUf}
                  </div>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
                  <span className="text-[11px] font-bold text-slate-600 uppercase flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-emerald-600" />
                    Destinatário (Nossa Empresa)
                  </span>
                  <div className="font-bold text-slate-900 text-sm">
                    {selectedNotaDetalhes.destinatarioNome}
                  </div>
                  <div className="text-slate-600">
                    CNPJ: <span className="font-mono">{formatCpfCnpjDanfe(selectedNotaDetalhes.destinatarioCnpj)}</span>
                  </div>
                  <div className="text-slate-600">
                    Natureza da Operação: {selectedNotaDetalhes.naturezaOperacao}
                  </div>
                  <div className="text-slate-600">
                    NSU SEFAZ: <span className="font-mono">{selectedNotaDetalhes.nsuSefaz || '-'}</span>
                  </div>
                </div>
              </div>

              {/* Itens e Mercadorias da NF-e */}
              <div>
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide mb-2">
                  Itens e Produtos da Nota Fiscal
                </h4>
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-100 text-slate-600 font-semibold border-b border-slate-200">
                        <th className="py-2 px-3">Código</th>
                        <th className="py-2 px-3">Descrição do Produto / Mercadoria</th>
                        <th className="py-2 px-2 text-center">NCM</th>
                        <th className="py-2 px-2 text-center">CFOP</th>
                        <th className="py-2 px-2 text-center">UN</th>
                        <th className="py-2 px-2 text-right">Qtd</th>
                        <th className="py-2 px-3 text-right">Valor Unit.</th>
                        <th className="py-2 px-3 text-right">Valor Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {selectedNotaDetalhes.itens.map((item, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-mono text-slate-500">{item.codigo || '-'}</td>
                          <td className="py-2 px-3 font-medium text-slate-800">{item.descricao}</td>
                          <td className="py-2 px-2 text-center font-mono text-slate-500">{item.ncm || '-'}</td>
                          <td className="py-2 px-2 text-center font-mono text-slate-500">{item.cfop || selectedNotaDetalhes.cfopPrincipal}</td>
                          <td className="py-2 px-2 text-center">{item.unidade || 'UN'}</td>
                          <td className="py-2 px-2 text-right font-mono">{item.quantidade}</td>
                          <td className="py-2 px-3 text-right font-mono">R$ {formatMoedaDanfe(item.valorUnitario)}</td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">
                            R$ {formatMoedaDanfe(item.valorTotal)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Quadro de Totais e Impostos Destacados */}
              <div className="bg-emerald-50/50 border border-emerald-200 rounded-xl p-4">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                  <div>
                    <span className="text-[11px] text-slate-500 block">Total dos Produtos</span>
                    <span className="text-sm font-bold text-slate-900 font-mono">
                      R$ {formatMoedaDanfe(selectedNotaDetalhes.valorProdutos || selectedNotaDetalhes.valorTotal)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 block">Base Cálculo ICMS</span>
                    <span className="text-sm font-bold text-slate-900 font-mono">
                      R$ {formatMoedaDanfe(selectedNotaDetalhes.impostos.baseCalculoIcms || selectedNotaDetalhes.valorTotal)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 block">ICMS Destacado</span>
                    <span className="text-sm font-bold text-emerald-700 font-mono">
                      R$ {formatMoedaDanfe(selectedNotaDetalhes.impostos.icms || 0)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 block">Valor Total da NF-e</span>
                    <span className="text-base font-extrabold text-emerald-800 font-mono">
                      R$ {formatMoedaDanfe(selectedNotaDetalhes.valorTotal)}
                    </span>
                  </div>
                </div>
              </div>

              {selectedNotaDetalhes.observacoes && (
                <div className="text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="font-semibold block text-[11px] text-slate-500 uppercase">
                    Informações Complementares / Observações
                  </span>
                  <p className="mt-0.5">{selectedNotaDetalhes.observacoes}</p>
                </div>
              )}
            </div>

            <div className="bg-slate-50 border-t border-slate-200 px-6 py-3.5 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleBaixarXmlIndividual(selectedNotaDetalhes)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold text-xs transition-colors"
                >
                  <FileCode className="w-4 h-4" />
                  Baixar XML da Nota
                </button>

                <button
                  type="button"
                  onClick={() => handleBaixarDanfePdfIndividual(selectedNotaDetalhes, false)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-semibold text-xs transition-colors"
                >
                  <FileText className="w-4 h-4" />
                  Baixar DANFE (PDF)
                </button>

                <button
                  type="button"
                  onClick={() => handleBaixarDanfePdfIndividual(selectedNotaDetalhes, true)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-300 font-semibold text-xs transition-colors"
                >
                  <Printer className="w-4 h-4" />
                  Imprimir
                </button>
              </div>

              <button
                type="button"
                onClick={() => setSelectedNotaDetalhes(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Registro de Manifestação do Destinatário */}
      {selectedNotaManifestar && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <FileCheck2 className="w-4 h-4 text-emerald-600" />
                Registrar Evento de Manifestação na SEFAZ
              </h3>
              <button
                type="button"
                onClick={() => {
                  setSelectedNotaManifestar(null);
                  setJustificativaManifestacao('');
                }}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-1">
                <div className="font-bold text-slate-800 text-sm">
                  NF-e Nº {selectedNotaManifestar.nota.numero} (Série {selectedNotaManifestar.nota.serie})
                </div>
                <div className="text-slate-600">
                  Fornecedor: {selectedNotaManifestar.nota.fornecedorNome}
                </div>
                <div className="text-slate-600 font-mono">
                  Valor: R$ {formatMoedaDanfe(selectedNotaManifestar.nota.valorTotal)}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Tipo de Manifestação a Enviar:
                </label>
                <select
                  value={selectedNotaManifestar.tipo}
                  onChange={(e) =>
                    setSelectedNotaManifestar({
                      ...selectedNotaManifestar,
                      tipo: e.target.value as TipoManifestacaoDestinatario,
                    })
                  }
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white font-medium"
                >
                  <option value="ciencia">Ciência da Emissão (Desbloqueia XML completo)</option>
                  <option value="confirmada">Confirmação da Operação (Mercadoria recebida)</option>
                  <option value="desconhecida">Desconhecimento da Operação (Proteção fiscal)</option>
                  <option value="nao_realizada">Operação não Realizada (Devolução / Carga avariada)</option>
                </select>
              </div>

              {selectedNotaManifestar.tipo === 'nao_realizada' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Justificativa Obrigatória (mínimo 15 caracteres):
                  </label>
                  <textarea
                    rows={3}
                    value={justificativaManifestacao}
                    onChange={(e) => setJustificativaManifestacao(e.target.value)}
                    placeholder="Ex: Mercadoria devolvida à transportadora devido a avarias graves de transporte..."
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                  <span className="text-[10px] text-slate-500">
                    {justificativaManifestacao.length}/15 caracteres mínimos exigidos pela SEFAZ
                  </span>
                </div>
              )}

              <p className="text-[11px] text-slate-500 leading-relaxed">
                Este evento será assinado digitalmente com o Certificado Digital da empresa e transmitido
                ao Ambiente Nacional da SEFAZ para registro oficial no banco de dados fiscal.
              </p>
            </div>

            <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  setSelectedNotaManifestar(null);
                  setJustificativaManifestacao('');
                }}
                className="px-3.5 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-lg"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleExecutarManifestacao}
                className="px-4 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-sm"
              >
                Transmitir Evento à SEFAZ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Histórico de Logs SEFAZ */}
      {showLogsModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Layers className="w-4 h-4 text-indigo-600" />
                Histórico de Consultas Web Service DF-e (SEFAZ)
              </h3>
              <button
                type="button"
                onClick={() => setShowLogsModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 max-h-[60vh] overflow-y-auto space-y-3 text-xs">
              {logsSefaz.length === 0 ? (
                <div className="text-center py-8 text-slate-400">
                  Nenhum log de consulta registrado ainda.
                </div>
              ) : (
                logsSefaz.map((log) => (
                  <div
                    key={log.id}
                    className="p-3 rounded-xl border border-slate-200 bg-slate-50 space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-900">
                        {log.tipo === 'sincronizacao_dfe'
                          ? 'Varredura Lote DF-e Distribuição'
                          : log.tipo === 'manual_chave'
                          ? 'Consulta Individual por Chave'
                          : 'Sincronização Automática'}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {formatDataDanfe(log.dataHora)} {log.dataHora.split('T')[1]?.slice(0, 8)}
                      </span>
                    </div>
                    <p className="text-slate-600 text-[11px]">{log.mensagem}</p>
                    <div className="flex items-center gap-4 text-[10px] text-slate-500 pt-1 font-mono">
                      <span>NSU: {log.nsuConsultado || '-'}</span>
                      <span>Documentos: {log.notasEncontradas}</span>
                      <span>Tempo: {log.tempoMs}ms</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setShowLogsModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200 rounded-lg"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
