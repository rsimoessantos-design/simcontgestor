import React, { useState, useRef } from 'react';
import {
  Building2,
  Plus,
  Search,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Users,
  Briefcase,
  Mail,
  Phone,
  MapPin,
  FileSpreadsheet,
  ShieldCheck,
  Upload,
  Key,
  Lock,
  Eye,
  EyeOff,
  Sparkles,
  X,
  FileKey,
  FileText,
  Calendar,
  AlertTriangle,
} from 'lucide-react';
import { Empresa, Socio, CertificadoDigital, RegimeTributario, EmpresaStatus } from '../types';
import { api } from '../services/api';

interface EmpresasViewProps {
  empresas: Empresa[];
  socios: Socio[];
  certificados?: CertificadoDigital[];
  onSelectEmpresa: (id: string) => void;
  selectedEmpresaId: string;
  onRefresh?: () => void;
}

export const EmpresasView: React.FC<EmpresasViewProps> = ({
  empresas,
  socios,
  certificados = [],
  onSelectEmpresa,
  selectedEmpresaId,
  onRefresh,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRegime, setFilterRegime] = useState('todos');
  const [activeModalEmpresa, setActiveModalEmpresa] = useState<Empresa | null>(null);

  // Modal Cadastrar Empresa
  const [isModalCadastroOpen, setIsModalCadastroOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'dados' | 'certificado'>('dados');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedbackSuccess, setFeedbackSuccess] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form State - Empresa
  const [empresaForm, setEmpresaForm] = useState({
    cnpj: '',
    razaoSocial: '',
    nomeFantasia: '',
    regimeTributario: 'Simples Nacional' as RegimeTributario,
    status: 'ativa' as EmpresaStatus,
    telefone: '(11) 3200-1000',
    email: '',
    cidade: 'São Paulo',
    uf: 'SP',
    faturamentoMensal: 65000,
    qtdeFuncionarios: 6,
    responsavelContabil: 'Mariana Duarte',
  });

  // Form State - Certificado Digital
  const [hasCertificado, setHasCertificado] = useState(false);
  const [certFileName, setCertFileName] = useState('');
  const [certPassword, setCertPassword] = useState('');
  const [certEmissor, setCertEmissor] = useState('Certisign Autoridade Certificadora ICP-Brasil');
  const [certValidadeFim, setCertValidadeFim] = useState(
    new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [certTitular, setCertTitular] = useState('');
  const [salvarNoServidor, setSalvarNoServidor] = useState(true);

  const filteredEmpresas = empresas.filter((emp) => {
    const matchesSearch =
      emp.razaoSocial.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.nomeFantasia.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.cnpj.includes(searchTerm);
    const matchesRegime = filterRegime === 'todos' || emp.regimeTributario === filterRegime;
    return matchesSearch && matchesRegime;
  });

  const formatCurrency = (val: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  // Formatar CNPJ automaticamente
  const handleCnpjChange = (value: string) => {
    const cleaned = value.replace(/\D/g, '').substring(0, 14);
    let formatted = cleaned;
    if (cleaned.length > 12) {
      formatted = cleaned.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{1,2})$/, '$1.$2.$3/$4-$5');
    } else if (cleaned.length > 8) {
      formatted = cleaned.replace(/^(\d{2})(\d{3})(\d{3})(\d{0,4})$/, '$1.$2.$3/$4');
    } else if (cleaned.length > 5) {
      formatted = cleaned.replace(/^(\d{2})(\d{3})(\d{0,3})$/, '$1.$2.$3');
    } else if (cleaned.length > 2) {
      formatted = cleaned.replace(/^(\d{2})(\d{0,3})$/, '$1.$2');
    }
    setEmpresaForm((prev) => ({ ...prev, cnpj: formatted }));
  };

  // Importação de arquivo de certificado A1 (.pfx / .p12)
  const handleCertFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setCertFileName(file.name);
      setHasCertificado(true);

      // Se ainda não preencheu a razão social ou nome fantasia, deduzir do arquivo
      const baseName = file.name
        .replace(/\.[^/.]+$/, '')
        .replace(/_/g, ' ')
        .replace(/cert|ecnpj|a1/gi, '')
        .trim();

      const suggestedName = baseName.length > 3 ? baseName.toUpperCase() : 'NOVA EMPRESA BRASIL';

      setEmpresaForm((prev) => ({
        ...prev,
        razaoSocial: prev.razaoSocial || `${suggestedName} LTDA`,
        nomeFantasia: prev.nomeFantasia || suggestedName,
      }));

      setCertTitular(
        `${empresaForm.razaoSocial || suggestedName} : ${empresaForm.cnpj.replace(/\D/g, '') || '00000000000100'}`
      );
    }
  };

  // Carregar dados e certificado de demonstração
  const handleLoadDemoCert = () => {
    const demoCnpj = '48.912.304/0001-85';
    const demoRazao = 'SIGMA INOVACOES DIGITAIS & TECNOLOGIA LTDA';
    const demoFantasia = 'Sigma Tech Inovações';

    setEmpresaForm((prev) => ({
      ...prev,
      cnpj: demoCnpj,
      razaoSocial: demoRazao,
      nomeFantasia: demoFantasia,
      email: 'contato@sigmatech.demo',
      telefone: '(11) 3345-9870',
      cidade: 'São Paulo',
      uf: 'SP',
      regimeTributario: 'Simples Nacional',
      faturamentoMensal: 85000,
    }));

    setCertFileName('sigmatech_ecnpj_a1_2026.pfx');
    setHasCertificado(true);
    setCertPassword('Sigma@A1#2026');
    setCertTitular(`${demoRazao} : 48912304000185`);
    setCertEmissor('Certisign Autoridade Certificadora ICP-Brasil');
  };

  // Submeter cadastro da empresa + certificado
  const handleSalvarEmpresa = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!empresaForm.cnpj || !empresaForm.razaoSocial) {
      alert('Por favor, preencha o CNPJ e a Razão Social da empresa.');
      setActiveTab('dados');
      return;
    }

    if (hasCertificado && !certPassword) {
      alert('Por favor, informe a senha do arquivo de certificado digital A1.');
      setActiveTab('certificado');
      return;
    }

    setIsSubmitting(true);
    try {
      // 1. Cria a nova empresa
      const novaEmpresa = await api.createEmpresa({
        ...empresaForm,
        faturamentoMensal: Number(empresaForm.faturamentoMensal) || 0,
        qtdeFuncionarios: Number(empresaForm.qtdeFuncionarios) || 1,
      });

      // 2. Se o usuário importou o certificado digital, vincula e instala imediatamente
      if (hasCertificado) {
        const diasRestantes = Math.ceil(
          (new Date(certValidadeFim).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
        );
        let status: 'valido' | 'alerta' | 'expirando' | 'expirado' = 'valido';
        if (diasRestantes <= 0) status = 'expirado';
        else if (diasRestantes <= 15) status = 'expirando';
        else if (diasRestantes <= 30) status = 'alerta';

        await api.createCertificado({
          empresaId: novaEmpresa.id,
          titular:
            certTitular ||
            `${novaEmpresa.razaoSocial} : ${novaEmpresa.cnpj.replace(/\D/g, '')}`,
          tipo: 'A1',
          categoria: novaEmpresa.cnpj.replace(/\D/g, '').length > 11 ? 'e-CNPJ' : 'e-CPF',
          emissor: certEmissor,
          cnpjCpf: novaEmpresa.cnpj,
          dataEmissao: new Date().toISOString().split('T')[0],
          dataValidade: certValidadeFim,
          diasParaVencer: diasRestantes,
          status,
          instaladoNoServidor: salvarNoServidor,
          senhaSalva: true,
          arquivoNome: certFileName || 'certificado_a1.pfx',
          serialNumber: `A1:${Math.floor(10000000 + Math.random() * 90000000)}:2026`,
        });
      }

      setFeedbackSuccess(
        hasCertificado
          ? `Empresa "${novaEmpresa.nomeFantasia}" cadastrada e Certificado Digital A1 instalado com sucesso!`
          : `Empresa "${novaEmpresa.nomeFantasia}" cadastrada com sucesso!`
      );

      onRefresh?.();
      onSelectEmpresa(novaEmpresa.id);

      setTimeout(() => {
        setIsModalCadastroOpen(false);
        setFeedbackSuccess('');
        // Limpar form
        setEmpresaForm({
          cnpj: '',
          razaoSocial: '',
          nomeFantasia: '',
          regimeTributario: 'Simples Nacional',
          status: 'ativa',
          telefone: '(11) 3200-1000',
          email: '',
          cidade: 'São Paulo',
          uf: 'SP',
          faturamentoMensal: 65000,
          qtdeFuncionarios: 6,
          responsavelContabil: 'Mariana Duarte',
        });
        setHasCertificado(false);
        setCertFileName('');
        setCertPassword('');
      }, 1400);
    } catch (err: any) {
      alert('Erro ao cadastrar empresa: ' + (err.message || 'Falha na requisição'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900">Gestão de Empresas Clientes</h1>
            <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
              DEMO
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Isolamento de dados por empresa, instalação de certificados A1 e gestão societária/tributária
          </p>
        </div>

        <button
          id="btn-cadastrar-nova-empresa"
          onClick={() => {
            setIsModalCadastroOpen(true);
            setActiveTab('dados');
          }}
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Cadastrar Empresa</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Pesquisar por Razão Social, Nome Fantasia ou CNPJ..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-slate-500">Regime:</span>
          <select
            value={filterRegime}
            onChange={(e) => setFilterRegime(e.target.value)}
            className="text-xs border border-slate-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-700 bg-slate-50"
          >
            <option value="todos">Todos os regimes</option>
            <option value="Simples Nacional">Simples Nacional</option>
            <option value="Lucro Presumido">Lucro Presumido</option>
            <option value="Lucro Real">Lucro Real</option>
            <option value="MEI">MEI</option>
          </select>
        </div>
      </div>

      {/* Companies List Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredEmpresas.map((emp) => {
          const isSelected = selectedEmpresaId === emp.id;
          const empCert = certificados.find((c) => c.empresaId === emp.id);

          return (
            <div
              key={emp.id}
              className={`bg-white rounded-xl border transition-all p-5 shadow-xs flex flex-col justify-between ${
                isSelected
                  ? 'border-emerald-500 ring-2 ring-emerald-500/20'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center font-bold text-sm">
                    {emp.nomeFantasia.substring(0, 2).toUpperCase()}
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap justify-end">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        emp.status === 'ativa'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {emp.status.toUpperCase()}
                    </span>
                    <span className="text-[10px] bg-slate-100 text-slate-700 font-semibold px-2 py-0.5 rounded-full">
                      {emp.regimeTributario}
                    </span>
                  </div>
                </div>

                <h3 className="font-bold text-slate-900 text-sm leading-snug">
                  {emp.nomeFantasia}
                </h3>
                <p className="text-xs text-slate-500 truncate mt-0.5">{emp.razaoSocial}</p>

                {/* Status do Certificado Digital A1 */}
                <div className="mt-2.5">
                  {empCert ? (
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-800 text-[11px] font-medium">
                      <ShieldCheck className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                      <span className="truncate">
                        Certificado A1 {empCert.status === 'valido' ? 'Ativo' : empCert.status} (
                        {empCert.diasParaVencer}d)
                      </span>
                    </div>
                  ) : (
                    <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-lg bg-slate-100 text-slate-600 text-[11px]">
                      <FileKey className="w-3 h-3 text-slate-400" />
                      <span>Sem Certificado A1 vinculado</span>
                    </div>
                  )}
                </div>

                <div className="mt-3 pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400 font-mono text-[11px]">CNPJ:</span>
                    <span className="font-mono text-slate-800 font-semibold">{emp.cnpj}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Localização:</span>
                    <span className="text-slate-700 font-medium">
                      {emp.cidade} / {emp.uf}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Faturamento Médio:</span>
                    <span className="font-semibold text-emerald-700">
                      {formatCurrency(emp.faturamentoMensal)}/mês
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Contador Responsável:</span>
                    <span className="text-slate-700">{emp.responsavelContabil}</span>
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center gap-2">
                <button
                  onClick={() => onSelectEmpresa(emp.id)}
                  className={`flex-1 py-1.5 px-3 text-xs font-semibold rounded-lg transition-colors text-center ${
                    isSelected
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {isSelected ? '✓ Empresa Ativa no Topo' : 'Filtrar Sistema'}
                </button>

                <button
                  onClick={() => setActiveModalEmpresa(emp)}
                  className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors"
                  title="Ver Quadro Societário e Detalhes"
                >
                  <Users className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* MODAL CADASTRAR NOVA EMPRESA (COM CAMPO & BOTÃO PARA IMPORTAR CERTIFICADO DIGITAL) */}
      {isModalCadastroOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-5 sm:p-6 shadow-2xl border border-slate-200 my-8">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">Cadastrar Nova Empresa</h3>
                  <p className="text-xs text-slate-500">
                    Dados cadastrais e instalação facilitada de Certificado Digital A1
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsModalCadastroOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Feedback Success */}
            {feedbackSuccess && (
              <div className="mt-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{feedbackSuccess}</span>
              </div>
            )}

            {/* Tab Navigation */}
            <div className="flex items-center border-b border-slate-200 mt-4">
              <button
                type="button"
                onClick={() => setActiveTab('dados')}
                className={`pb-2.5 px-4 text-xs font-bold transition-all relative ${
                  activeTab === 'dados'
                    ? 'text-emerald-700 border-b-2 border-emerald-600'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                1. Dados Cadastrais & Fiscais
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('certificado')}
                className={`pb-2.5 px-4 text-xs font-bold transition-all relative flex items-center gap-1.5 ${
                  activeTab === 'certificado'
                    ? 'text-indigo-700 border-b-2 border-indigo-600'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                <span>2. Certificado Digital A1</span>
                {hasCertificado && (
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                )}
              </button>
            </div>

            <form onSubmit={handleSalvarEmpresa} className="mt-4 space-y-4 text-xs">
              {/* ABA 1: DADOS CADASTRAIS & FISCAIS */}
              {activeTab === 'dados' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">
                        CNPJ da Empresa <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="00.000.000/0000-00"
                        value={empresaForm.cnpj}
                        onChange={(e) => handleCnpjChange(e.target.value)}
                        required
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">
                        Regime Tributário
                      </label>
                      <select
                        value={empresaForm.regimeTributario}
                        onChange={(e) =>
                          setEmpresaForm((prev) => ({
                            ...prev,
                            regimeTributario: e.target.value as RegimeTributario,
                          }))
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800 bg-white"
                      >
                        <option value="Simples Nacional">Simples Nacional</option>
                        <option value="Lucro Presumido">Lucro Presumido</option>
                        <option value="Lucro Real">Lucro Real</option>
                        <option value="MEI">MEI</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">
                        Razão Social <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: Comercial Brasileira de Alimentos Ltda"
                        value={empresaForm.razaoSocial}
                        onChange={(e) =>
                          setEmpresaForm((prev) => ({ ...prev, razaoSocial: e.target.value }))
                        }
                        required
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">
                        Nome Fantasia
                      </label>
                      <input
                        type="text"
                        placeholder="Ex: Comercial Alimentos"
                        value={empresaForm.nomeFantasia}
                        onChange={(e) =>
                          setEmpresaForm((prev) => ({ ...prev, nomeFantasia: e.target.value }))
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">E-mail</label>
                      <input
                        type="email"
                        placeholder="financeiro@empresa.com.br"
                        value={empresaForm.email}
                        onChange={(e) =>
                          setEmpresaForm((prev) => ({ ...prev, email: e.target.value }))
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">Telefone</label>
                      <input
                        type="text"
                        placeholder="(11) 3200-0000"
                        value={empresaForm.telefone}
                        onChange={(e) =>
                          setEmpresaForm((prev) => ({ ...prev, telefone: e.target.value }))
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="col-span-1 sm:col-span-2">
                      <label className="block text-slate-700 font-semibold mb-1">Cidade</label>
                      <input
                        type="text"
                        value={empresaForm.cidade}
                        onChange={(e) =>
                          setEmpresaForm((prev) => ({ ...prev, cidade: e.target.value }))
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">UF</label>
                      <input
                        type="text"
                        maxLength={2}
                        value={empresaForm.uf}
                        onChange={(e) =>
                          setEmpresaForm((prev) => ({
                            ...prev,
                            uf: e.target.value.toUpperCase(),
                          }))
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-center uppercase focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">
                        Funcionários
                      </label>
                      <input
                        type="number"
                        min={1}
                        value={empresaForm.qtdeFuncionarios}
                        onChange={(e) =>
                          setEmpresaForm((prev) => ({
                            ...prev,
                            qtdeFuncionarios: parseInt(e.target.value) || 1,
                          }))
                        }
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
                      />
                    </div>
                  </div>

                  {/* Banner de convite para instalar o Certificado */}
                  <div className="p-3.5 bg-indigo-50/70 border border-indigo-200 rounded-xl flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      <ShieldCheck className="w-5 h-5 text-indigo-600 shrink-0" />
                      <div>
                        <p className="font-bold text-indigo-950">
                          {hasCertificado
                            ? `Certificado "${certFileName}" pronto para instalação!`
                            : 'Deseja já instalar o Certificado Digital A1?'}
                        </p>
                        <p className="text-[11px] text-indigo-700">
                          Habilita emissão de NF-e, consulta à Receita Federal e e-CAC imediatamente.
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveTab('certificado')}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold text-xs transition-colors shrink-0 shadow-xs"
                    >
                      {hasCertificado ? 'Editar Certificado' : 'Instalar Certificado A1'}
                    </button>
                  </div>
                </div>
              )}

              {/* ABA 2: CERTIFICADO DIGITAL (A1 / ICP-BRASIL) - O DESTAQUE PRINCIPAL SOLICITADO */}
              {activeTab === 'certificado' && (
                <div className="space-y-4">
                  {/* Explicação & Status */}
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2.5">
                        <div className="p-1.5 bg-indigo-100 text-indigo-700 rounded-lg shrink-0 mt-0.5">
                          <Lock className="w-4 h-4" />
                        </div>
                        <div>
                          <h4 className="font-bold text-slate-900 text-xs">
                            Cofre Seguro de Certificados Digitais A1 (ICP-Brasil)
                          </h4>
                          <p className="text-[11px] text-slate-600 mt-0.5">
                            O arquivo criptografado (.pfx / .p12) é armazenado com chave de segurança AES-256 no servidor para assinatura automática de NF-e e transmissão e-CAC.
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={handleLoadDemoCert}
                        className="px-2.5 py-1 text-[11px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 rounded-lg transition-colors flex items-center gap-1 shrink-0"
                        title="Preencher com arquivo e dados de certificado A1 para teste"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Usar Certificado Demo</span>
                      </button>
                    </div>
                  </div>

                  {/* Input de Arquivo Oculto */}
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept=".pfx,.p12"
                    onChange={handleCertFileChange}
                    className="hidden"
                  />

                  {/* Área de Importação / Botão */}
                  {!hasCertificado ? (
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-indigo-300 hover:border-indigo-500 bg-indigo-50/40 hover:bg-indigo-50/70 p-6 rounded-2xl text-center cursor-pointer transition-all space-y-2.5"
                    >
                      <div className="w-12 h-12 bg-white rounded-full shadow-sm text-indigo-600 flex items-center justify-center mx-auto">
                        <Upload className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="font-bold text-slate-900 text-sm">
                          Clique para Importar o Certificado Digital A1
                        </p>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Suporta arquivos de certificado padrão <strong>.pfx</strong> ou <strong>.p12</strong> (ICP-Brasil)
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          fileInputRef.current?.click();
                        }}
                        className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Selecionar Arquivo .pfx / .p12</span>
                      </button>
                    </div>
                  ) : (
                    /* Card de Certificado Importado */
                    <div className="p-4 bg-emerald-50/50 border border-emerald-200 rounded-xl space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                            <CheckCircle2 className="w-5 h-5" />
                          </div>
                          <div>
                            <p className="font-bold text-slate-900 text-xs">{certFileName}</p>
                            <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-100 px-1.5 py-0.5 rounded">
                              Certificado A1 Carregado
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold underline"
                          >
                            Trocar Arquivo
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setHasCertificado(false);
                              setCertFileName('');
                              setCertPassword('');
                            }}
                            className="text-xs text-rose-500 hover:text-rose-700 font-semibold"
                          >
                            Remover
                          </button>
                        </div>
                      </div>

                      {/* Senha do Certificado */}
                      <div>
                        <label className="block text-slate-700 font-semibold mb-1">
                          Senha do Certificado Digital A1 <span className="text-rose-500">*</span>
                        </label>
                        <div className="relative">
                          <Key className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type={showPassword ? 'text' : 'password'}
                            value={certPassword}
                            onChange={(e) => setCertPassword(e.target.value)}
                            placeholder="Informe a senha de exportação do .pfx"
                            required={hasCertificado}
                            className="w-full pl-9 pr-10 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 font-mono"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                          >
                            {showPassword ? (
                              <EyeOff className="w-4 h-4" />
                            ) : (
                              <Eye className="w-4 h-4" />
                            )}
                          </button>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-1">
                          A senha é criptografada e usada apenas para assinar documentos fiscais e e-CAC.
                        </p>
                      </div>

                      {/* Autoridade Certificadora & Validade */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                        <div>
                          <label className="block text-slate-700 font-semibold mb-1">
                            Autoridade Certificadora (Emissor)
                          </label>
                          <select
                            value={certEmissor}
                            onChange={(e) => setCertEmissor(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 bg-white"
                          >
                            <option value="Certisign Autoridade Certificadora ICP-Brasil">
                              Certisign AC
                            </option>
                            <option value="Serasa Experian AC ICP-Brasil">Serasa Experian</option>
                            <option value="Soluti Autoridade Certificadora">Soluti AC</option>
                            <option value="Valid Certificadora Digital">Valid Certificadora</option>
                            <option value="Safeweb Autoridade Certificadora">Safeweb</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-slate-700 font-semibold mb-1">
                            Data de Vencimento
                          </label>
                          <input
                            type="date"
                            value={certValidadeFim}
                            onChange={(e) => setCertValidadeFim(e.target.value)}
                            className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800"
                          />
                        </div>
                      </div>

                      {/* Checkbox salvar no servidor */}
                      <div className="pt-2">
                        <label className="flex items-center gap-2 cursor-pointer text-slate-700">
                          <input
                            type="checkbox"
                            checked={salvarNoServidor}
                            onChange={(e) => setSalvarNoServidor(e.target.checked)}
                            className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                          />
                          <span className="font-semibold text-xs">
                            Ativar certificado no servidor para emissão automática de NF-e e e-CAC
                          </span>
                        </label>
                      </div>
                    </div>
                  )}

                  {/* Informação caso não tenha certificado agora */}
                  {!hasCertificado && (
                    <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl text-amber-800 text-[11px] flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                      <span>
                        A instalação do certificado digital é opcional no momento do cadastro. Você pode cadastrar a empresa agora e instalar o certificado A1 posteriormente na tela de Certificados Digitais.
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Modal Footer / Ações */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-100">
                <div className="text-xs text-slate-500">
                  {hasCertificado ? (
                    <span className="text-emerald-700 font-semibold flex items-center gap-1">
                      <ShieldCheck className="w-4 h-4" /> Certificado A1 anexado
                    </span>
                  ) : (
                    <span>Nenhum certificado anexado (opcional)</span>
                  )}
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => setIsModalCadastroOpen(false)}
                    className="flex-1 sm:flex-none px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                  >
                    Cancelar
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-colors disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {isSubmitting
                        ? 'Salvando...'
                        : hasCertificado
                        ? 'Cadastrar Empresa & Instalar Certificado'
                        : 'Cadastrar Empresa'}
                    </span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Partners / Details Modal */}
      {activeModalEmpresa && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-bold text-slate-900 text-base">
                  {activeModalEmpresa.nomeFantasia}
                </h3>
                <p className="text-xs text-slate-500 font-mono">
                  CNPJ: {activeModalEmpresa.cnpj}
                </p>
              </div>
              <button
                onClick={() => setActiveModalEmpresa(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs">
              <div>
                <h4 className="font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-emerald-600" />
                  <span>Quadro de Sócios e Administradores (QSA) [DEMO]</span>
                </h4>
                <div className="space-y-2">
                  {socios
                    .filter((s) => s.empresaId === activeModalEmpresa.id)
                    .map((socio) => (
                      <div
                        key={socio.id}
                        className="p-3 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between"
                      >
                        <div>
                          <p className="font-semibold text-slate-800">{socio.nome}</p>
                          <p className="text-slate-500 text-[11px]">
                            {socio.cargo} • CPF: {socio.cpf}
                          </p>
                        </div>
                        <div className="text-right">
                          <span className="font-bold text-emerald-700 text-sm">
                            {socio.participacaoPercentual}%
                          </span>
                          <span className="block text-[10px] text-slate-400">
                            Pró-labore: {formatCurrency(socio.proLabore)}
                          </span>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 space-y-1 text-slate-600">
                <p>
                  <strong>Regime Tributário:</strong> {activeModalEmpresa.regimeTributario}
                </p>
                <p>
                  <strong>Contato:</strong> {activeModalEmpresa.email} •{' '}
                  {activeModalEmpresa.telefone}
                </p>
                <p>
                  <strong>Funcionários Ativos:</strong>{' '}
                  {activeModalEmpresa.qtdeFuncionarios} colaboradores
                </p>
              </div>
            </div>

            <div className="mt-6 pt-3 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setActiveModalEmpresa(null)}
                className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
