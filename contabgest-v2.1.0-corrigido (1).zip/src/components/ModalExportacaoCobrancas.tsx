import React, { useState, useMemo } from 'react';
import {
  X,
  Download,
  FileSpreadsheet,
  FileCode,
  CheckCircle2,
  Filter,
  DollarSign,
  AlertCircle,
  Building2,
  Calendar,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { MensalidadeHonorario, ContratoHonorario, Empresa } from '../types';
import {
  gerarOfxCobrancas,
  gerarCsvCobrancas,
  baixarArquivo,
} from '../utils/exportContabilUtils';

interface ModalExportacaoCobrancasProps {
  isOpen: boolean;
  onClose: () => void;
  mensalidadesTotais: MensalidadeHonorario[];
  mensalidadesFiltradas: MensalidadeHonorario[];
  mensalidadesSelecionadasIds: string[];
  contratos: ContratoHonorario[];
  empresas: Empresa[];
  onFeedback: (msg: string) => void;
}

export const ModalExportacaoCobrancas: React.FC<ModalExportacaoCobrancasProps> = ({
  isOpen,
  onClose,
  mensalidadesTotais,
  mensalidadesFiltradas,
  mensalidadesSelecionadasIds,
  contratos,
  empresas,
  onFeedback,
}) => {
  const [formato, setFormato] = useState<'ofx' | 'csv'>('csv');
  const [delimitadorCsv, setDelimitadorCsv] = useState<';' | ','>(';');
  const [escopo, setEscopo] = useState<'selecionados' | 'filtrados' | 'todos'>(
    mensalidadesSelecionadasIds.length > 0 ? 'selecionados' : 'filtrados'
  );
  const [filtroStatusModal, setFiltroStatusModal] = useState<'todos' | 'pago' | 'pendente' | 'atrasado'>('todos');

  // Determina os itens base conforme escopo
  const itensBase = useMemo(() => {
    if (escopo === 'selecionados') {
      const setIds = new Set(mensalidadesSelecionadasIds);
      return mensalidadesTotais.filter((m) => setIds.has(m.id));
    }
    if (escopo === 'filtrados') {
      return mensalidadesFiltradas;
    }
    return mensalidadesTotais;
  }, [escopo, mensalidadesSelecionadasIds, mensalidadesFiltradas, mensalidadesTotais]);

  // Aplica filtro de status adicional do modal
  const itensFinais = useMemo(() => {
    if (filtroStatusModal === 'todos') return itensBase;
    return itensBase.filter((m) => m.status === filtroStatusModal);
  }, [itensBase, filtroStatusModal]);

  // Estatísticas do lote
  const estatisticas = useMemo(() => {
    const totalQtd = itensFinais.length;
    const valorTotal = itensFinais.reduce((acc, curr) => acc + curr.valor, 0);
    const pagosQtd = itensFinais.filter((m) => m.status === 'pago').length;
    const valorPago = itensFinais
      .filter((m) => m.status === 'pago')
      .reduce((acc, curr) => acc + (curr.valorPago || curr.valor), 0);
    const pendentesQtd = itensFinais.filter((m) => m.status === 'pendente').length;
    const atrasadosQtd = itensFinais.filter((m) => m.status === 'atrasado').length;

    return {
      totalQtd,
      valorTotal,
      pagosQtd,
      valorPago,
      pendentesQtd,
      atrasadosQtd,
    };
  }, [itensFinais]);

  if (!isOpen) return null;

  const handleExportar = () => {
    if (itensFinais.length === 0) {
      onFeedback('Nenhum registro selecionado para exportação.');
      return;
    }

    const dataHoje = new Date().toISOString().slice(0, 10);

    if (formato === 'ofx') {
      const conteudo = gerarOfxCobrancas(itensFinais, contratos, empresas, {
        nomeOrganizacao: 'ContabGest Assessoria Contabil',
        identificadorConta: 'HONORARIOS-MENSALIDADES',
      });
      const nomeArquivo = `Honorarios_Cobrancas_${dataHoje}_${itensFinais.length}itens.ofx`;
      baixarArquivo(conteudo, nomeArquivo, 'application/x-ofx');
      onFeedback(`Arquivo OFX gerado com sucesso (${itensFinais.length} transações financeiras)!`);
    } else {
      const conteudo = gerarCsvCobrancas(itensFinais, contratos, empresas, {
        delimitador: delimitadorCsv,
      });
      const nomeArquivo = `Honorarios_Cobrancas_${dataHoje}_${itensFinais.length}itens.csv`;
      baixarArquivo(conteudo, nomeArquivo, 'text/csv');
      onFeedback(`Arquivo CSV gerado com sucesso (${itensFinais.length} cobranças exportadas)!`);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        id="modal-exportacao-cobrancas"
        className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Cabeçalho */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                Exportação em Lote de Cobranças & Honorários
              </h2>
              <p className="text-xs text-slate-500">
                Gere arquivos padronizados OFX ou CSV para importação direta no seu software contábil ou ERP
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-6">
          {/* 1. Escolha do Formato */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5">
              1. Selecione o Formato de Exportação
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setFormato('csv')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer relative ${
                  formato === 'csv'
                    ? 'border-emerald-600 bg-emerald-50/50 ring-2 ring-emerald-500/20 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className={`p-2 rounded-lg ${formato === 'csv' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                      <FileSpreadsheet className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-sm font-bold text-slate-900 block">Arquivo CSV (Planilha)</span>
                      <span className="text-[11px] text-slate-500">Excel, ERPs Contábeis, BI</span>
                    </div>
                  </div>
                  {formato === 'csv' && <CheckCircle2 className="w-5 h-5 text-emerald-600" />}
                </div>
                <p className="text-xs text-slate-600 mt-2.5">
                  Exporta todas as colunas detalhadas (valores, clientes, CNPJs, contratos, recibos e datas) com UTF-8 BOM.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setFormato('ofx')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer relative ${
                  formato === 'ofx'
                    ? 'border-emerald-600 bg-emerald-50/50 ring-2 ring-emerald-500/20 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className={`p-2 rounded-lg ${formato === 'ofx' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                      <FileCode className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-sm font-bold text-slate-900 block">Arquivo OFX (Bancário)</span>
                      <span className="text-[11px] text-slate-500">Extrato & Conciliação ERP</span>
                    </div>
                  </div>
                  {formato === 'ofx' && <CheckCircle2 className="w-5 h-5 text-emerald-600" />}
                </div>
                <p className="text-xs text-slate-600 mt-2.5">
                  Padrão Open Financial Exchange. Perfeito para conciliação em ContaAzul, Domínio, Omie, Bling e Fortes.
                </p>
              </button>
            </div>

            {/* Opção de Delimitador para CSV */}
            {formato === 'csv' && (
              <div className="mt-3.5 bg-slate-50 p-3 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                <span className="font-semibold text-slate-700">Delimitador de Colunas:</span>
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-1.5 cursor-pointer text-slate-700">
                    <input
                      type="radio"
                      name="delim"
                      checked={delimitadorCsv === ';'}
                      onChange={() => setDelimitadorCsv(';')}
                      className="text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Ponto e vírgula ( ; ) <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-100 px-1 rounded">Padrão Brasil / Excel</span></span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer text-slate-700">
                    <input
                      type="radio"
                      name="delim"
                      checked={delimitadorCsv === ','}
                      onChange={() => setDelimitadorCsv(',')}
                      className="text-emerald-600 focus:ring-emerald-500"
                    />
                    <span>Vírgula ( , )</span>
                  </label>
                </div>
              </div>
            )}
          </div>

          {/* 2. Escopo dos Dados */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5">
              2. Defina o Escopo do Lote
            </label>
            <div className="space-y-2">
              <label
                className={`flex items-start gap-3 p-3 rounded-xl border transition-all cursor-pointer ${
                  escopo === 'selecionados'
                    ? 'border-emerald-500 bg-emerald-50/40 text-slate-900'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700'
                } ${mensalidadesSelecionadasIds.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <input
                  type="radio"
                  name="escopo"
                  value="selecionados"
                  disabled={mensalidadesSelecionadasIds.length === 0}
                  checked={escopo === 'selecionados'}
                  onChange={() => setEscopo('selecionados')}
                  className="mt-1 text-emerald-600 focus:ring-emerald-500"
                />
                <div>
                  <span className="text-sm font-semibold block">
                    Apenas itens selecionados com caixa de seleção ({mensalidadesSelecionadasIds.length} selecionados)
                  </span>
                  <span className="text-xs text-slate-500">
                    Exporta exclusivamente as mensalidades marcadas manualmente na tabela.
                  </span>
                </div>
              </label>

              <label
                className={`flex items-start gap-3 p-3 rounded-xl border transition-all cursor-pointer ${
                  escopo === 'filtrados'
                    ? 'border-emerald-500 bg-emerald-50/40 text-slate-900'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="escopo"
                  value="filtrados"
                  checked={escopo === 'filtrados'}
                  onChange={() => setEscopo('filtrados')}
                  className="mt-1 text-emerald-600 focus:ring-emerald-500"
                />
                <div>
                  <span className="text-sm font-semibold block">
                    Registros que atendem aos filtros atuais da tela ({mensalidadesFiltradas.length} cobranças)
                  </span>
                  <span className="text-xs text-slate-500">
                    Respeita os filtros ativos na barra de pesquisa (empresa, competência, status e busca textual).
                  </span>
                </div>
              </label>

              <label
                className={`flex items-start gap-3 p-3 rounded-xl border transition-all cursor-pointer ${
                  escopo === 'todos'
                    ? 'border-emerald-500 bg-emerald-50/40 text-slate-900'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="escopo"
                  value="todos"
                  checked={escopo === 'todos'}
                  onChange={() => setEscopo('todos')}
                  className="mt-1 text-emerald-600 focus:ring-emerald-500"
                />
                <div>
                  <span className="text-sm font-semibold block">
                    Base completa de mensalidades ({mensalidadesTotais.length} cobranças)
                  </span>
                  <span className="text-xs text-slate-500">
                    Exporta todo o histórico de cobranças sem nenhum filtro aplicado.
                  </span>
                </div>
              </label>
            </div>
          </div>

          {/* 3. Filtro Opcional de Status */}
          <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200">
            <span className="text-xs font-semibold text-slate-700">Filtrar por Status no Lote:</span>
            <select
              value={filtroStatusModal}
              onChange={(e) => setFiltroStatusModal(e.target.value as any)}
              className="text-xs border border-slate-300 rounded-lg px-2.5 py-1.5 bg-white text-slate-800 font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              <option value="todos">Todos os Status</option>
              <option value="pago">Apenas Pagos / Liquidados</option>
              <option value="pendente">Apenas Pendentes (A Vencer)</option>
              <option value="atrasado">Apenas Inadimplentes (Atrasados)</option>
            </select>
          </div>

          {/* Resumo do Arquivo a ser Gerado */}
          <div className="bg-slate-900 text-white rounded-xl p-4">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2.5">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Resumo do Lote de Exportação
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full font-mono uppercase bg-emerald-500/20 text-emerald-400 font-semibold">
                Formato .{formato.toUpperCase()}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="bg-slate-800/60 p-2.5 rounded-lg">
                <span className="text-[11px] text-slate-400 block">Total de Registros</span>
                <span className="text-lg font-bold text-white">{estatisticas.totalQtd}</span>
              </div>
              <div className="bg-slate-800/60 p-2.5 rounded-lg">
                <span className="text-[11px] text-slate-400 block">Valor Faturado</span>
                <span className="text-lg font-bold text-emerald-400">
                  R$ {estatisticas.valorTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
              </div>
              <div className="bg-slate-800/60 p-2.5 rounded-lg">
                <span className="text-[11px] text-slate-400 block">Quitados (Pagos)</span>
                <span className="text-lg font-bold text-teal-300">{estatisticas.pagosQtd}</span>
              </div>
              <div className="bg-slate-800/60 p-2.5 rounded-lg">
                <span className="text-[11px] text-slate-400 block">Em Aberto / Pendentes</span>
                <span className="text-lg font-bold text-amber-400">
                  {estatisticas.pendentesQtd + estatisticas.atrasadosQtd}
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 mt-3 text-center">
              {formato === 'ofx'
                ? 'Estrutura compatível com extratos de contas a receber e conciliação bancária SGML/XML.'
                : 'Planilha estruturada com cabeçalhos técnicos padronizados para integração contábil.'}
            </p>
          </div>
        </div>

        {/* Rodapé com Ações */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
          >
            Cancelar
          </button>

          <button
            type="button"
            id="btn-confirmar-exportacao-cobrancas"
            onClick={handleExportar}
            disabled={itensFinais.length === 0}
            className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white shadow-sm transition-all cursor-pointer ${
              itensFinais.length > 0
                ? 'bg-emerald-600 hover:bg-emerald-700'
                : 'bg-slate-300 cursor-not-allowed'
            }`}
          >
            <Download className="w-4 h-4" />
            Baixar Arquivo .{formato.toUpperCase()} ({itensFinais.length} itens)
          </button>
        </div>
      </div>
    </div>
  );
};
