import React, { useState, useMemo } from 'react';
import {
  Scale,
  FileDown,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  Building2,
  Calendar,
  Layers,
  ArrowRight,
  HelpCircle,
  Hash,
  ShieldCheck,
  RefreshCw,
  Printer,
  ChevronRight,
  Eye,
  Settings,
  SlidersHorizontal,
} from 'lucide-react';
import { ContaContabil, BemPatrimonial, Empresa, BalanceteData, LinhaBalancete } from '../types';
import {
  gerarBalanceteMensal,
  exportarBalancetePdf,
  formatarMoedaBalancete,
  OpcoesPdfAuditoria,
} from '../utils/balanceteGenerator';

export interface BalanceteMensalProps {
  planoContas: ContaContabil[];
  bens?: BemPatrimonial[];
  empresa?: Empresa;
  onNavigateToPlanoContas?: () => void;
  onNavigateToBalanco?: () => void;
  onNavigateToDre?: () => void;
}

const MESES = [
  { valor: 1, nome: 'Janeiro' },
  { valor: 2, nome: 'Fevereiro' },
  { valor: 3, nome: 'Março' },
  { valor: 4, nome: 'Abril' },
  { valor: 5, nome: 'Maio' },
  { valor: 6, nome: 'Junho' },
  { valor: 7, nome: 'Julho' },
  { valor: 8, nome: 'Agosto' },
  { valor: 9, nome: 'Setembro' },
  { valor: 10, nome: 'Outubro' },
  { valor: 11, nome: 'Novembro' },
  { valor: 12, nome: 'Dezembro' },
];

export const BalanceteMensal: React.FC<BalanceteMensalProps> = ({
  planoContas,
  bens = [],
  empresa,
  onNavigateToPlanoContas,
  onNavigateToBalanco,
  onNavigateToDre,
}) => {
  // Estado de Competência
  const [mesSelecionado, setMesSelecionado] = useState<number>(9); // Setembro/2026
  const [anoSelecionado, setAnoSelecionado] = useState<number>(2026);

  // Filtros
  const [searchTerm, setSearchTerm] = useState('');
  const [filtroGrau, setFiltroGrau] = useState<'todos' | '1' | '2' | '3' | '4'>('todos');
  const [filtroTipo, setFiltroTipo] = useState<'todos' | 'sintetica' | 'analitica'>('todos');
  const [filtroGrupo, setFiltroGrupo] = useState<string>('todos');
  const [ocultarZeradas, setOcultarZeradas] = useState(false);
  const [formatoColunas, setFormatoColunas] = useState<'4colunas' | '6colunas'>('4colunas');

  // Modal de Opções de Auditoria para PDF
  const [modalAuditoriaAberto, setModalAuditoriaAberto] = useState(false);
  const [nomeAuditor, setNomeAuditor] = useState('Dra. Mariana Vasconcelos de Oliveira');
  const [registroAuditor, setRegistroAuditor] = useState('CNAI 4892 / CRC-SP 1SP198422/O-9');
  const [empresaAuditoria, setEmpresaAuditoria] = useState('Deloitte & Touche / Auditoria Independente');
  const [incluirTermoEncerramento, setIncluirTermoEncerramento] = useState(true);
  const [feedbackPdf, setFeedbackPdf] = useState<string | null>(null);

  // Geração do Balancete de Verificação
  const balanceteData: BalanceteData = useMemo(() => {
    return gerarBalanceteMensal(
      planoContas,
      bens,
      empresa?.id || '1',
      mesSelecionado,
      anoSelecionado
    );
  }, [planoContas, bens, empresa, mesSelecionado, anoSelecionado]);

  // Filtragem das linhas em tempo real
  const linhasFiltradas = useMemo(() => {
    return balanceteData.linhas.filter((l) => {
      // 1. Termo de busca
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        const bateu = l.codigo.toLowerCase().includes(q) || l.nome.toLowerCase().includes(q);
        if (!bateu) return false;
      }

      // 2. Grau
      if (filtroGrau !== 'todos' && String(l.grau) !== filtroGrau) {
        return false;
      }

      // 3. Tipo
      if (filtroTipo !== 'todos' && l.tipo !== filtroTipo) {
        return false;
      }

      // 4. Grupo
      if (filtroGrupo !== 'todos') {
        if (filtroGrupo === 'ativo' && l.grupo !== 'ativo') return false;
        if (filtroGrupo === 'passivo' && l.grupo !== 'passivo') return false;
        if (filtroGrupo === 'patrimonio_liquido' && l.grupo !== 'patrimonio_liquido') return false;
        if (filtroGrupo === 'receita' && l.grupo !== 'receita') return false;
        if (filtroGrupo === 'despesa' && l.grupo !== 'despesa' && l.grupo !== 'custo') return false;
      }

      // 5. Ocultar zeradas
      if (ocultarZeradas) {
        if (
          l.saldoAnterior === 0 &&
          l.movimentoDebito === 0 &&
          l.movimentoCredito === 0 &&
          l.saldoAtual === 0
        ) {
          return false;
        }
      }

      return true;
    });
  }, [balanceteData, searchTerm, filtroGrau, filtroTipo, filtroGrupo, ocultarZeradas]);

  // Ação de Exportar PDF para Auditoria Externa
  const handleExportarPdf = () => {
    try {
      const opcoesPdf: OpcoesPdfAuditoria = {
        nomeAuditor,
        registroAuditor,
        empresaAuditoria,
        incluirTermoEncerramento,
        tipoVisualizacao: formatoColunas,
      };

      exportarBalancetePdf(balanceteData, empresa, opcoesPdf);
      setModalAuditoriaAberto(false);
      setFeedbackPdf('PDF oficial do Balancete gerado com sucesso para auditoria externa!');
      setTimeout(() => setFeedbackPdf(null), 5000);
    } catch (err) {
      console.error('Erro ao exportar PDF do balancete:', err);
      setFeedbackPdf('Ocorreu um erro ao gerar o PDF. Verifique os dados e tente novamente.');
      setTimeout(() => setFeedbackPdf(null), 5000);
    }
  };

  const nomeEmpresa = empresa?.razaoSocial || empresa?.nomeFantasia || 'Empresa Selecionada';
  const cnpjEmpresa = empresa?.cnpj || '00.000.000/0001-00';

  return (
    <div className="space-y-6">
      {/* ALERTA DE FEEDBACK */}
      {feedbackPdf && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-xl flex items-center justify-between shadow-xs animate-in fade-in duration-200">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span className="text-sm font-medium">{feedbackPdf}</span>
          </div>
          <button
            onClick={() => setFeedbackPdf(null)}
            className="text-xs text-emerald-700 font-bold hover:underline cursor-pointer"
          >
            Fechar
          </button>
        </div>
      )}

      {/* CABEÇALHO DO BALANCETE */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 text-indigo-700 rounded-lg">
              <Scale className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-2xl font-bold text-slate-900">
                  Balancete Mensal de Verificação
                </h2>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  Auditoria Externa (NBC TG / ITG 1000)
                </span>
              </div>
              <p className="text-sm text-slate-500 mt-0.5">
                Demonstração contábil detalhada com conciliação de saldos anteriores, débitos, créditos e saldos finais em partidas dobradas.
              </p>
            </div>
          </div>
        </div>

        {/* BOTÕES DE AÇÃO */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => setModalAuditoriaAberto(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors cursor-pointer"
            title="Configurar Dados da Auditoria"
          >
            <Settings className="w-4 h-4 text-slate-500" />
            Configurar Auditoria
          </button>

          <button
            onClick={handleExportarPdf}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <FileDown className="w-4 h-4" />
            Exportar PDF para Auditoria
          </button>
        </div>
      </div>

      {/* PAINEL DE CONTROLE DE COMPETÊNCIA & CARDS DE AUDITORIA */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Status de Auditoria */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-2">
            <span>AUDITORIA CONTÁBIL</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-xl font-bold text-emerald-700">Partidas Dobradas OK</span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Diferença Débito/Crédito: <strong className="text-emerald-600">R$ {balanceteData.diferencaMovimento.toFixed(2)}</strong>
          </p>
          <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
            <span>Autenticação:</span>
            <span className="font-mono text-slate-600 font-semibold">{balanceteData.hashAuditoria.slice(0, 16)}...</span>
          </div>
        </div>

        {/* Card 2: Movimentação do Mês */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-2">
            <span>MOVIMENTO DO MÊS</span>
            <RefreshCw className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-600">Débitos no Mês:</span>
              <strong className="text-slate-900 font-mono">{formatarMoedaBalancete(balanceteData.totalMovimentoDebito)}</strong>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-600">Créditos no Mês:</span>
              <strong className="text-slate-900 font-mono">{formatarMoedaBalancete(balanceteData.totalMovimentoCredito)}</strong>
            </div>
          </div>
          <div className="mt-2 pt-2 border-t border-slate-100 text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Total Débito = Total Crédito
          </div>
        </div>

        {/* Card 3: Saldos Finais (Devedores vs Credores) */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-2">
            <span>SALDOS FINAIS APURADOS</span>
            <Scale className="w-4 h-4 text-blue-500" />
          </div>
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-slate-600">Saldos Devedores (D):</span>
              <strong className="text-blue-700 font-mono">{formatarMoedaBalancete(balanceteData.totalSaldoAtualDevedor)}</strong>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-slate-600">Saldos Credores (C):</span>
              <strong className="text-indigo-700 font-mono">{formatarMoedaBalancete(balanceteData.totalSaldoAtualCredor)}</strong>
            </div>
          </div>
          <div className="mt-2 pt-2 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Diferença Final:</span>
            <strong className="text-emerald-600">R$ {balanceteData.diferencaSaldoAtual.toFixed(2)}</strong>
          </div>
        </div>

        {/* Card 4: Empresa & Responsável Técnico */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-semibold mb-2">
            <span>RESPONSABILIDADE TÉCNICA</span>
            <FileCheck className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-xs font-semibold text-slate-900 truncate">
            {balanceteData.contadorResponsavel}
          </div>
          <p className="text-xs text-slate-500">{balanceteData.crcContador}</p>
          <div className="mt-2 pt-2 border-t border-slate-100 text-[11px] text-slate-500 truncate">
            Empresa: <strong className="text-slate-700">{nomeEmpresa}</strong>
          </div>
        </div>
      </div>

      {/* BARRA DE FILTROS, COMPETÊNCIA E BUSCA */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          {/* Seletor de Mês e Ano */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-indigo-600" />
              Competência:
            </span>
            <div className="flex items-center bg-slate-50 border border-slate-300 rounded-lg p-1">
              <select
                value={mesSelecionado}
                onChange={(e) => setMesSelecionado(Number(e.target.value))}
                className="text-xs font-semibold text-slate-800 bg-transparent px-2 py-1 outline-none cursor-pointer"
              >
                {MESES.map((m) => (
                  <option key={m.valor} value={m.valor}>
                    {m.nome}
                  </option>
                ))}
              </select>
              <select
                value={anoSelecionado}
                onChange={(e) => setAnoSelecionado(Number(e.target.value))}
                className="text-xs font-semibold text-slate-800 bg-transparent px-2 py-1 outline-none border-l border-slate-200 cursor-pointer"
              >
                <option value={2026}>2026</option>
                <option value={2025}>2025</option>
              </select>
            </div>
            <span className="text-xs text-slate-500">
              (Período: <strong>{balanceteData.periodoInicio}</strong> a <strong>{balanceteData.periodoFim}</strong>)
            </span>
          </div>

          {/* Formato de Visualização das Colunas */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-600">Visualização:</span>
            <div className="inline-flex rounded-lg border border-slate-300 bg-slate-50 p-0.5 text-xs font-medium">
              <button
                onClick={() => setFormatoColunas('4colunas')}
                className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                  formatoColunas === '4colunas'
                    ? 'bg-white text-indigo-700 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Padrão (4 Colunas)
              </button>
              <button
                onClick={() => setFormatoColunas('6colunas')}
                className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                  formatoColunas === '6colunas'
                    ? 'bg-white text-indigo-700 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Expandido (D/C Separados)
              </button>
            </div>
          </div>
        </div>

        {/* Filtros em Linha: Busca, Grau, Tipo, Grupo e Ocultar Zeradas */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 pt-3 border-t border-slate-100">
          {/* Busca */}
          <div className="relative md:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Buscar por conta ou código (ex: Caixa, 1.1.01)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white"
            />
          </div>

          {/* Grau / Nível */}
          <div>
            <select
              value={filtroGrau}
              onChange={(e) => setFiltroGrau(e.target.value as any)}
              className="w-full text-xs py-1.5 px-2.5 rounded-lg border border-slate-300 bg-white text-slate-700 font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer"
            >
              <option value="todos">Grau: Todos (1 a 4)</option>
              <option value="1">Grau 1 (Classes / Ativo, Passivo)</option>
              <option value="2">Grau 2 (Subgrupos)</option>
              <option value="3">Grau 3 (Contas Coletoras)</option>
              <option value="4">Grau 4 (Analíticas / Lançamentos)</option>
            </select>
          </div>

          {/* Grupo Contábil */}
          <div>
            <select
              value={filtroGrupo}
              onChange={(e) => setFiltroGrupo(e.target.value)}
              className="w-full text-xs py-1.5 px-2.5 rounded-lg border border-slate-300 bg-white text-slate-700 font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer"
            >
              <option value="todos">Grupo: Todos</option>
              <option value="ativo">1. Ativo</option>
              <option value="passivo">2. Passivo</option>
              <option value="patrimonio_liquido">3. Patrimônio Líquido</option>
              <option value="receita">4. Receitas</option>
              <option value="despesa">5. Custos & Despesas</option>
            </select>
          </div>

          {/* Toggle Zeradas */}
          <div className="flex items-center">
            <label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={ocultarZeradas}
                onChange={(e) => setOcultarZeradas(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
              />
              <span>Ocultar Contas Zeradas</span>
            </label>
          </div>
        </div>

        {/* Resumo da Contagem */}
        <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
          <span>
            Exibindo <strong>{linhasFiltradas.length}</strong> de <strong>{balanceteData.linhas.length}</strong> contas contábeis no balancete
          </span>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block"></span>
              <strong>D</strong> = Natureza Devedora
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 inline-block"></span>
              <strong>C</strong> = Natureza Credora
            </span>
          </div>
        </div>
      </div>

      {/* TABELA OFICIAL DO BALANCETE DE VERIFICAÇÃO */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between flex-wrap gap-2">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Scale className="w-4 h-4 text-indigo-600" />
              Balancete de Verificação Analítico
            </h3>
            <p className="text-xs text-slate-500">
              {nomeEmpresa} • CNPJ: {cnpjEmpresa} • Competência: {balanceteData.competenciaTexto}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleExportarPdf}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-lg hover:bg-indigo-100 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              Imprimir / PDF Oficial
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-800 text-white font-semibold text-[11px] uppercase tracking-wider">
                <th className="py-3 px-3 w-28">Código</th>
                <th className="py-3 px-3">Conta Contábil / Classificação</th>
                <th className="py-3 px-2 w-16 text-center">Grau</th>
                <th className="py-3 px-2 w-20 text-center">Tipo</th>
                {formatoColunas === '4colunas' ? (
                  <>
                    <th className="py-3 px-3 text-right w-36">Saldo Anterior</th>
                    <th className="py-3 px-3 text-right w-32">Débito</th>
                    <th className="py-3 px-3 text-right w-32">Crédito</th>
                    <th className="py-3 px-3 text-right w-36">Saldo Atual</th>
                  </>
                ) : (
                  <>
                    <th className="py-3 px-3 text-right w-28 bg-slate-900">Saldo Ant. (D)</th>
                    <th className="py-3 px-3 text-right w-28 bg-slate-900">Saldo Ant. (C)</th>
                    <th className="py-3 px-3 text-right w-28">Débitos (D)</th>
                    <th className="py-3 px-3 text-right w-28">Créditos (C)</th>
                    <th className="py-3 px-3 text-right w-28 bg-slate-900">Saldo Atu. (D)</th>
                    <th className="py-3 px-3 text-right w-28 bg-slate-900">Saldo Atu. (C)</th>
                  </>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {linhasFiltradas.length === 0 ? (
                <tr>
                  <td colSpan={formatoColunas === '4colunas' ? 8 : 10} className="py-12 text-center text-slate-500 font-sans">
                    Nenhuma conta contábil encontrada para os filtros selecionados.
                  </td>
                </tr>
              ) : (
                linhasFiltradas.map((linha) => {
                  const isSintetica = linha.tipo === 'sintetica';
                  const isGrau1 = linha.grau === 1;
                  const isGrau2 = linha.grau === 2;

                  // Cores de fundo e estilos conforme hierarquia
                  let bgClass = 'hover:bg-slate-50/70 transition-colors';
                  if (isGrau1) bgClass = 'bg-slate-100 font-bold text-slate-950 border-t-2 border-slate-200';
                  else if (isGrau2) bgClass = 'bg-slate-50/60 font-semibold text-slate-900';
                  else if (isSintetica) bgClass = 'font-semibold text-slate-800';

                  const indentPadding = Math.max(0, (linha.grau - 1) * 16);

                  return (
                    <tr key={linha.id} className={bgClass}>
                      {/* Código */}
                      <td className="py-2.5 px-3 font-semibold text-slate-700 whitespace-nowrap">
                        {linha.codigo}
                      </td>

                      {/* Nome com Indentação */}
                      <td className="py-2.5 px-3 font-sans" style={{ paddingLeft: `${indentPadding + 12}px` }}>
                        <div className="flex items-center gap-1.5">
                          {isSintetica && <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>}
                          <span className={isGrau1 ? 'text-slate-950 text-xs font-bold' : isSintetica ? 'text-slate-900 font-semibold' : 'text-slate-700'}>
                            {linha.nome}
                          </span>
                        </div>
                      </td>

                      {/* Grau */}
                      <td className="py-2.5 px-2 text-center">
                        <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          isGrau1 ? 'bg-slate-300 text-slate-900' : isSintetica ? 'bg-slate-200 text-slate-700' : 'bg-slate-100 text-slate-600'
                        }`}>
                          G{linha.grau}
                        </span>
                      </td>

                      {/* Tipo */}
                      <td className="py-2.5 px-2 text-center font-sans">
                        <span className={`text-[10px] font-medium ${isSintetica ? 'text-indigo-700 font-semibold' : 'text-slate-500'}`}>
                          {isSintetica ? 'Sintética' : 'Analítica'}
                        </span>
                      </td>

                      {/* Colunas no Modo 4 Colunas */}
                      {formatoColunas === '4colunas' ? (
                        <>
                          {/* Saldo Anterior */}
                          <td className="py-2.5 px-3 text-right">
                            <span className="text-slate-800">
                              {formatarMoedaBalancete(linha.saldoAnterior)}
                            </span>
                            <span className={`ml-1 text-[10px] font-bold ${linha.saldoAnteriorNatureza === 'D' ? 'text-blue-600' : 'text-indigo-600'}`}>
                              {linha.saldoAnteriorNatureza}
                            </span>
                          </td>

                          {/* Movimento Débito */}
                          <td className="py-2.5 px-3 text-right text-slate-700">
                            {linha.movimentoDebito > 0 ? formatarMoedaBalancete(linha.movimentoDebito) : '-'}
                          </td>

                          {/* Movimento Crédito */}
                          <td className="py-2.5 px-3 text-right text-slate-700">
                            {linha.movimentoCredito > 0 ? formatarMoedaBalancete(linha.movimentoCredito) : '-'}
                          </td>

                          {/* Saldo Atual */}
                          <td className="py-2.5 px-3 text-right">
                            <span className={isGrau1 ? 'text-slate-950 font-bold' : 'text-slate-900 font-semibold'}>
                              {formatarMoedaBalancete(linha.saldoAtual)}
                            </span>
                            <span className={`ml-1 text-[10px] font-bold ${linha.saldoAtualNatureza === 'D' ? 'text-blue-600' : 'text-indigo-600'}`}>
                              {linha.saldoAtualNatureza}
                            </span>
                          </td>
                        </>
                      ) : (
                        /* Colunas no Modo 6 Colunas (D e C explícitos) */
                        <>
                          <td className="py-2.5 px-3 text-right text-blue-700">
                            {linha.saldoAnteriorNatureza === 'D' && linha.saldoAnterior > 0
                              ? formatarMoedaBalancete(linha.saldoAnterior)
                              : '-'}
                          </td>
                          <td className="py-2.5 px-3 text-right text-indigo-700">
                            {linha.saldoAnteriorNatureza === 'C' && linha.saldoAnterior > 0
                              ? formatarMoedaBalancete(linha.saldoAnterior)
                              : '-'}
                          </td>
                          <td className="py-2.5 px-3 text-right text-slate-700">
                            {linha.movimentoDebito > 0 ? formatarMoedaBalancete(linha.movimentoDebito) : '-'}
                          </td>
                          <td className="py-2.5 px-3 text-right text-slate-700">
                            {linha.movimentoCredito > 0 ? formatarMoedaBalancete(linha.movimentoCredito) : '-'}
                          </td>
                          <td className="py-2.5 px-3 text-right text-blue-800 font-semibold">
                            {linha.saldoAtualNatureza === 'D' && linha.saldoAtual > 0
                              ? formatarMoedaBalancete(linha.saldoAtual)
                              : '-'}
                          </td>
                          <td className="py-2.5 px-3 text-right text-indigo-800 font-semibold">
                            {linha.saldoAtualNatureza === 'C' && linha.saldoAtual > 0
                              ? formatarMoedaBalancete(linha.saldoAtual)
                              : '-'}
                          </td>
                        </>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>

            {/* TOTALIZADORES GERAIS */}
            <tfoot className="bg-slate-100 border-t-2 border-slate-300 font-mono font-bold text-xs text-slate-900">
              {formatoColunas === '4colunas' ? (
                <tr>
                  <td colSpan={4} className="py-3.5 px-3 text-right font-sans uppercase tracking-wider text-slate-700">
                    TOTAIS DAS PARTIDAS DOBRADAS (D = C):
                  </td>
                  <td className="py-3.5 px-3 text-right text-slate-900">
                    {formatarMoedaBalancete(balanceteData.totalSaldoAnteriorDevedor)}
                    <span className="text-[10px] text-slate-500 ml-1">D=C</span>
                  </td>
                  <td className="py-3.5 px-3 text-right text-emerald-700">
                    {formatarMoedaBalancete(balanceteData.totalMovimentoDebito)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-emerald-700">
                    {formatarMoedaBalancete(balanceteData.totalMovimentoCredito)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-slate-950">
                    {formatarMoedaBalancete(balanceteData.totalSaldoAtualDevedor)}
                    <span className="text-[10px] text-slate-500 ml-1">D=C</span>
                  </td>
                </tr>
              ) : (
                <tr>
                  <td colSpan={4} className="py-3.5 px-3 text-right font-sans uppercase tracking-wider text-slate-700">
                    TOTAIS CONSOLIDADOS:
                  </td>
                  <td className="py-3.5 px-3 text-right text-blue-800">
                    {formatarMoedaBalancete(balanceteData.totalSaldoAnteriorDevedor)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-indigo-800">
                    {formatarMoedaBalancete(balanceteData.totalSaldoAnteriorCredor)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-emerald-700">
                    {formatarMoedaBalancete(balanceteData.totalMovimentoDebito)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-emerald-700">
                    {formatarMoedaBalancete(balanceteData.totalMovimentoCredito)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-blue-900">
                    {formatarMoedaBalancete(balanceteData.totalSaldoAtualDevedor)}
                  </td>
                  <td className="py-3.5 px-3 text-right text-indigo-900">
                    {formatarMoedaBalancete(balanceteData.totalSaldoAtualCredor)}
                  </td>
                </tr>
              )}
            </tfoot>
          </table>
        </div>

        {/* NOTA DE RODAPÉ & INTEGRAÇÃO COM OUTRAS DEMONSTRAÇÕES */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 font-semibold text-emerald-700">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              Equilíbrio Contábil 100% Verificado
            </span>
            <span>•</span>
            <span>Conforme NBC TG 1000 e Lei das S.A. 6.404/76</span>
          </div>

          <div className="flex items-center gap-2">
            {onNavigateToBalanco && (
              <button
                onClick={onNavigateToBalanco}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold inline-flex items-center gap-1 cursor-pointer"
              >
                Ver Balanço Patrimonial <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
            {onNavigateToDre && (
              <button
                onClick={onNavigateToDre}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold inline-flex items-center gap-1 ml-3 cursor-pointer"
              >
                Ver DRE com EBITDA <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* MODAL DE CONFIGURAÇÃO DE AUDITORIA EXTERNA */}
      {modalAuditoriaAberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 max-w-lg w-full p-6 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">
                    Laudo de Auditoria Externa (PDF)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Defina os signatários e termos para o relatório oficial
                  </p>
                </div>
              </div>
              <button
                onClick={() => setModalAuditoriaAberto(false)}
                className="text-slate-400 hover:text-slate-600 text-lg font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nome do Auditor Responsável Técnico / Firma
                </label>
                <input
                  type="text"
                  value={nomeAuditor}
                  onChange={(e) => setNomeAuditor(e.target.value)}
                  placeholder="Ex: Dra. Mariana Vasconcelos de Oliveira"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Registro Profissional do Auditor (CNAI / CRC)
                </label>
                <input
                  type="text"
                  value={registroAuditor}
                  onChange={(e) => setRegistroAuditor(e.target.value)}
                  placeholder="Ex: CNAI 4892 / CRC-SP 1SP198422/O-9"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Firma de Auditoria Externa / Independente
                </label>
                <input
                  type="text"
                  value={empresaAuditoria}
                  onChange={(e) => setEmpresaAuditoria(e.target.value)}
                  placeholder="Ex: KPMG / PwC / EY / Deloitte / BDO / Própria"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-2">
                <label className="flex items-center gap-2 font-semibold text-slate-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={incluirTermoEncerramento}
                    onChange={(e) => setIncluirTermoEncerramento(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                  />
                  <span>Incluir Termo de Encerramento e Assinaturas Formais</span>
                </label>
                <p className="text-[11px] text-slate-500 pl-6">
                  Adiciona campo para assinatura do Contador Responsável, da Diretoria Executiva e visto do Auditor Externo Independente.
                </p>
              </div>

              <div className="bg-indigo-50/60 p-3 rounded-lg border border-indigo-100 text-[11px] text-indigo-900 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-indigo-800">
                  <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                  Conformidade & Autenticidade Digital
                </div>
                <p>
                  O arquivo PDF gerado conterá hash criptográfico de auditoria (<strong>{balanceteData.hashAuditoria}</strong>) para fins de conferência perante bancos, investidores e órgãos fiscalizadores.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
              <button
                onClick={() => setModalAuditoriaAberto(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={handleExportarPdf}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
              >
                <FileDown className="w-4 h-4" />
                Gerar & Baixar PDF Auditado
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
