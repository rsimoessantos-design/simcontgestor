import React, { useState } from 'react';
import { Award, CheckCircle2, AlertTriangle, XCircle, Search, RefreshCw, Plus } from 'lucide-react';
import { Certidao, Empresa } from '../types';

interface CertidoesViewProps {
  certidoes: Certidao[];
  empresas: Empresa[];
  selectedEmpresa?: Empresa;
}

export const CertidoesView: React.FC<CertidoesViewProps> = ({
  certidoes,
  empresas,
  selectedEmpresa,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filtered = certidoes.filter(
    (c) =>
      c.orgao.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.codigo.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getEmpresaName = (empresaId: string) => {
    const emp = empresas.find((e) => e.id === empresaId);
    return emp ? emp.nomeFantasia : 'Todas';
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900">
              Certidões Negativas de Débitos (CNDs)
            </h1>
            <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
              DEMO
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Monitoramento preventivo e automatizado da regularidade fiscal perante órgãos públicos
          </p>
        </div>

        <button
          onClick={() =>
            alert('Emissão e consulta automática de CNDs pronta para integração de robôs.')
          }
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-all"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Consultar Todas na Receita</span>
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar por órgão emissor ou código de controle..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Órgão Competente</th>
                <th className="py-3 px-4">Empresa</th>
                <th className="py-3 px-4">Código / Chave CND</th>
                <th className="py-3 px-4">Emissão</th>
                <th className="py-3 px-4">Data de Validade</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((cert) => (
                <tr key={cert.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-900">{cert.orgao}</div>
                    <div className="text-[10px] text-slate-400">Regularidade Fiscal</div>
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-700">
                    {getEmpresaName(cert.empresaId)}
                  </td>
                  <td className="py-3 px-4 font-mono font-medium text-slate-800">
                    {cert.codigo}
                  </td>
                  <td className="py-3 px-4 font-mono">{cert.dataEmissao}</td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-800">
                    {cert.dataValidade}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        cert.status === 'valida'
                          ? 'bg-emerald-100 text-emerald-800'
                          : cert.status === 'alerta'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {cert.status === 'valida' && <CheckCircle2 className="w-3 h-3" />}
                      {cert.status === 'alerta' && <AlertTriangle className="w-3 h-3" />}
                      {cert.status === 'vencida' && <XCircle className="w-3 h-3" />}
                      <span>{cert.status.toUpperCase()}</span>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
