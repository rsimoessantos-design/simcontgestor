import React, { useState, useEffect, useMemo } from 'react';
import {
  Package,
  Shield,
  FileText,
  TrendingDown,
  Building,
  Plus,
  Search,
  Filter,
  Download,
  Printer,
  QrCode,
  Tag,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RefreshCw,
  ExternalLink,
  Edit3,
  Trash2,
  X,
  FileSpreadsheet,
  Layers,
  Percent,
  Calendar,
  DollarSign,
  ArrowDownRight,
  ArrowUpRight,
  Info,
} from 'lucide-react';
import {
  BemPatrimonial,
  CentroCusto,
  ClassificacaoAtivo,
  StatusBemPatrimonial,
  StatusSeguro,
  Empresa,
} from '../types';
import {
  TABELA_PARAMETROS_ATIVO,
  BENS_PATRIMONIAIS_DEMO,
  CENTROS_CUSTO_DEMO,
  calcularDepreciacaoBem,
} from '../data/demoPatrimonioContabil';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ModalExportacaoPatrimonio } from './ModalExportacaoPatrimonio';

interface ControlePatrimonialViewProps {
  empresas: Empresa[];
  selectedEmpresa?: Empresa;
  onRefresh?: () => void;
  onNavigateToContabilidade?: () => void;
}

export const ControlePatrimonialView: React.FC<ControlePatrimonialViewProps> = ({
  empresas,
  selectedEmpresa,
  onRefresh,
  onNavigateToContabilidade,
}) => {
  // Estado principal
  const [bens, setBens] = useState<BemPatrimonial[]>(BENS_PATRIMONIAIS_DEMO);
  const [centrosCusto, setCentrosCusto] = useState<CentroCusto[]>(CENTROS_CUSTO_DEMO);
  const [loading, setLoading] = useState(false);
  const [empresaFiltro, setEmpresaFiltro] = useState<string>(selectedEmpresa?.id || 'all');
  const [classificacaoFiltro, setClassificacaoFiltro] = useState<string>('all');
  const [statusFiltro, setStatusFiltro] = useState<string>('all');
  const [seguroFiltro, setSeguroFiltro] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Modais
  const [modalCadastroAberto, setModalCadastroAberto] = useState(false);
  const [modalPlaquetaAberto, setModalPlaquetaAberto] = useState(false);
  const [modalDepreciacaoAberto, setModalDepreciacaoAberto] = useState(false);
  const [modalBaixaAberto, setModalBaixaAberto] = useState(false);
  const [modalEtiquetasLoteAberto, setModalEtiquetasLoteAberto] = useState(false);
  const [modalExportarLoteAberto, setModalExportarLoteAberto] = useState(false);
  const [bemSelecionado, setBemSelecionado] = useState<BemPatrimonial | null>(null);

  // Seleção Múltipla para Ações em Lote (Exportação OFX / CSV)
  const [bensSelecionadosIds, setBensSelecionadosIds] = useState<string[]>([]);
  const [feedbackPatrimonio, setFeedbackPatrimonio] = useState<string | null>(null);

  const exibirFeedbackPatrimonio = (msg: string) => {
    setFeedbackPatrimonio(msg);
    setTimeout(() => setFeedbackPatrimonio(null), 4500);
  };

  // Form State para Cadastro / Edição
  const [formModo, setFormModo] = useState<'novo' | 'editar'>('novo');
  const [formEmpresaId, setFormEmpresaId] = useState<string>(selectedEmpresa?.id || '1');
  const [formNumeroPatrimonio, setFormNumeroPatrimonio] = useState('');
  const [formPlacaIdentificacao, setFormPlacaIdentificacao] = useState('');
  const [formDescricao, setFormDescricao] = useState('');
  const [formClassificacao, setFormClassificacao] = useState<ClassificacaoAtivo>('maquinas_equipamentos');
  const [formMarca, setFormMarca] = useState('');
  const [formModelo, setFormModelo] = useState('');
  const [formNumeroSerie, setFormNumeroSerie] = useState('');
  const [formLocalizacao, setFormLocalizacao] = useState('Sede Matriz - Andar 1');
  const [formCentroCustoId, setFormCentroCustoId] = useState('cc-01');
  const [formResponsavel, setFormResponsavel] = useState('');
  const [formStatus, setFormStatus] = useState<StatusBemPatrimonial>('ativo');

  // Aquisição
  const [formDataAquisicao, setFormDataAquisicao] = useState('2024-05-10');
  const [formNumeroNotaFiscal, setFormNumeroNotaFiscal] = useState('');
  const [formSerieNotaFiscal, setFormSerieNotaFiscal] = useState('1');
  const [formFornecedorNome, setFormFornecedorNome] = useState('');
  const [formFornecedorCnpj, setFormFornecedorCnpj] = useState('');
  const [formChaveAcessoNfe, setFormChaveAcessoNfe] = useState('');
  const [formValorAquisicao, setFormValorAquisicao] = useState<number>(15000);
  const [formContratoVinculado, setFormContratoVinculado] = useState('');
  const [formAgio, setFormAgio] = useState<number>(0);
  const [formDesagio, setFormDesagio] = useState<number>(0);

  // Seguro
  const [formTemSeguro, setFormTemSeguro] = useState(false);
  const [formSeguradora, setFormSeguradora] = useState('');
  const [formNumeroApolice, setFormNumeroApolice] = useState('');
  const [formSeguroDataInicio, setFormSeguroDataInicio] = useState('');
  const [formSeguroDataFim, setFormSeguroDataFim] = useState('');
  const [formValorSegurado, setFormValorSegurado] = useState<number>(15000);

  // Depreciação
  const [formTaxaAnual, setFormTaxaAnual] = useState<number>(10);
  const [formVidaUtilAnos, setFormVidaUtilAnos] = useState<number>(10);
  const [formValorResidualPercentual, setFormValorResidualPercentual] = useState<number>(10);
  const [formObservacoes, setFormObservacoes] = useState('');

  // Form Baixa
  const [baixaData, setBaixaData] = useState('2026-09-17');
  const [baixaMotivo, setBaixaMotivo] = useState<'venda' | 'sucateamento' | 'sinistro' | 'doacao'>('venda');
  const [baixaValorVenda, setBaixaValorVenda] = useState<number>(0);
  const [baixaNotaFiscal, setBaixaNotaFiscal] = useState('');
  const [baixaObservacoes, setBaixaObservacoes] = useState('');

  // Atualizar quando selectedEmpresa mudar
  useEffect(() => {
    if (selectedEmpresa) {
      setEmpresaFiltro(selectedEmpresa.id);
      setFormEmpresaId(selectedEmpresa.id);
    }
  }, [selectedEmpresa]);

  // Carregar dados da API
  const carregarBens = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/patrimonio/bens');
      if (res.ok) {
        const data = await res.json();
        setBens(data);
      }
      const resCc = await fetch('/api/patrimonio/centros-custo');
      if (resCc.ok) {
        const dataCc = await resCc.json();
        setCentrosCusto(dataCc);
      }
    } catch (err) {
      console.error('Erro ao buscar dados de patrimônio:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregarBens();
  }, []);

  // Preenchimento automático ao mudar classificação
  const handleClassificacaoChange = (novaClass: ClassificacaoAtivo) => {
    setFormClassificacao(novaClass);
    const param = TABELA_PARAMETROS_ATIVO[novaClass];
    if (param) {
      setFormTaxaAnual(param.taxaAnual);
      setFormVidaUtilAnos(param.vidaUtilAnos);
      setFormValorResidualPercentual(param.sugestaoResidualPercentual);
    }
  };

  // Gerar número de patrimônio e placa automáticos
  const gerarCodigoAutomatico = () => {
    const nextNum = bens.length + 101;
    const ano = new Date().getFullYear();
    setFormNumeroPatrimonio(`PAT-${String(nextNum).padStart(5, '0')}`);
    setFormPlacaIdentificacao(`PLA-SP-${ano}-${String(nextNum).slice(-3)}`);
  };

  // Abrir Modal Novo
  const handleAbrirNovo = () => {
    setFormModo('novo');
    gerarCodigoAutomatico();
    setFormDescricao('');
    setFormClassificacao('maquinas_equipamentos');
    const param = TABELA_PARAMETROS_ATIVO['maquinas_equipamentos'];
    setFormTaxaAnual(param.taxaAnual);
    setFormVidaUtilAnos(param.vidaUtilAnos);
    setFormValorResidualPercentual(param.sugestaoResidualPercentual);
    setFormMarca('');
    setFormModelo('');
    setFormNumeroSerie('');
    setFormLocalizacao('Sede Matriz - Andar 1');
    setFormCentroCustoId(centrosCusto[0]?.id || 'cc-01');
    setFormResponsavel('');
    setFormStatus('ativo');
    setFormDataAquisicao(new Date().toISOString().split('T')[0]);
    setFormNumeroNotaFiscal('');
    setFormSerieNotaFiscal('1');
    setFormFornecedorNome('');
    setFormFornecedorCnpj('');
    setFormChaveAcessoNfe('');
    setFormValorAquisicao(25000);
    setFormContratoVinculado('');
    setFormAgio(0);
    setFormDesagio(0);
    setFormTemSeguro(false);
    setFormSeguradora('');
    setFormNumeroApolice('');
    setFormSeguroDataInicio('');
    setFormSeguroDataFim('');
    setFormValorSegurado(25000);
    setFormObservacoes('');
    setModalCadastroAberto(true);
  };

  // Abrir Modal Edição
  const handleAbrirEdicao = (bem: BemPatrimonial) => {
    setFormModo('editar');
    setBemSelecionado(bem);
    setFormEmpresaId(bem.empresaId);
    setFormNumeroPatrimonio(bem.numeroPatrimonio);
    setFormPlacaIdentificacao(bem.placaIdentificacao);
    setFormDescricao(bem.descricao);
    setFormClassificacao(bem.classificacao);
    setFormMarca(bem.marca || '');
    setFormModelo(bem.modelo || '');
    setFormNumeroSerie(bem.numeroSerie || '');
    setFormLocalizacao(bem.localizacao);
    setFormCentroCustoId(bem.centroCustoId);
    setFormResponsavel(bem.responsavel || '');
    setFormStatus(bem.status);
    setFormDataAquisicao(bem.dataAquisicao);
    setFormNumeroNotaFiscal(bem.numeroNotaFiscal);
    setFormSerieNotaFiscal(bem.serieNotaFiscal || '1');
    setFormFornecedorNome(bem.fornecedorNome);
    setFormFornecedorCnpj(bem.fornecedorCnpj || '');
    setFormChaveAcessoNfe(bem.chaveAcessoNfe || '');
    setFormValorAquisicao(bem.valorAquisicao);
    setFormContratoVinculado(bem.contratoVinculado || '');
    setFormAgio(bem.agio || 0);
    setFormDesagio(bem.desagio || 0);
    setFormTemSeguro(bem.temSeguro);
    setFormSeguradora(bem.seguradora || '');
    setFormNumeroApolice(bem.numeroApolice || '');
    setFormSeguroDataInicio(bem.seguroDataInicio || '');
    setFormSeguroDataFim(bem.seguroDataFim || '');
    setFormValorSegurado(bem.valorSegurado || bem.valorAquisicao);
    setFormTaxaAnual(bem.taxaDepreciacaoAnual);
    setFormVidaUtilAnos(bem.vidaUtilAnos);
    setFormValorResidualPercentual(bem.valorResidualPercentual);
    setFormObservacoes(bem.observacoes || '');
    setModalCadastroAberto(true);
  };

  // Salvar Bem (Novo ou Edição)
  const handleSalvarBem = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        empresaId: formEmpresaId,
        numeroPatrimonio: formNumeroPatrimonio,
        placaIdentificacao: formPlacaIdentificacao,
        descricao: formDescricao,
        classificacao: formClassificacao,
        marca: formMarca,
        modelo: formModelo,
        numeroSerie: formNumeroSerie,
        localizacao: formLocalizacao,
        centroCustoId: formCentroCustoId,
        responsavel: formResponsavel,
        status: formStatus,
        dataAquisicao: formDataAquisicao,
        numeroNotaFiscal: formNumeroNotaFiscal,
        serieNotaFiscal: formSerieNotaFiscal,
        fornecedorNome: formFornecedorNome,
        fornecedorCnpj: formFornecedorCnpj,
        chaveAcessoNfe: formChaveAcessoNfe,
        valorAquisicao: formValorAquisicao,
        contratoVinculado: formContratoVinculado,
        agio: formAgio,
        desagio: formDesagio,
        temSeguro: formTemSeguro,
        seguradora: formSeguradora,
        numeroApolice: formNumeroApolice,
        seguroDataInicio: formSeguroDataInicio,
        seguroDataFim: formSeguroDataFim,
        valorSegurado: formValorSegurado,
        taxaDepreciacaoAnual: formTaxaAnual,
        vidaUtilAnos: formVidaUtilAnos,
        valorResidualPercentual: formValorResidualPercentual,
        observacoes: formObservacoes,
      };

      if (formModo === 'novo') {
        const res = await fetch('/api/patrimonio/bens', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        if (res.ok) {
          const novo = await res.json();
          setBens([novo, ...bens]);
          setModalCadastroAberto(false);
        }
      } else if (bemSelecionado) {
        const res = await fetch(`/api/patrimonio/bens/${bemSelecionado.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        if (res.ok) {
          const atualizado = await res.json();
          setBens(bens.map((b) => (b.id === atualizado.id ? atualizado : b)));
          setModalCadastroAberto(false);
        }
      }
    } catch (err) {
      console.error('Erro ao salvar bem:', err);
    }
  };

  // Efetuar Baixa / Alienação
  const handleConfirmarBaixa = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bemSelecionado) return;
    try {
      const res = await fetch(`/api/patrimonio/bens/${bemSelecionado.id}/baixa`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dataBaixa: baixaData,
          motivoBaixa: baixaMotivo,
          valorVenda: baixaValorVenda,
          notaFiscalBaixa: baixaNotaFiscal,
          observacoesBaixa: baixaObservacoes,
        }),
      });
      if (res.ok) {
        const { bem: baixado } = await res.json();
        setBens(bens.map((b) => (b.id === baixado.id ? baixado : b)));
        setModalBaixaAberto(false);
      }
    } catch (err) {
      console.error('Erro ao registrar baixa:', err);
    }
  };

  // Excluir Bem
  const handleExcluirBem = async (id: string) => {
    if (!confirm('Tem certeza que deseja remover este bem patrimonial?')) return;
    try {
      const res = await fetch(`/api/patrimonio/bens/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setBens(bens.filter((b) => b.id !== id));
      }
    } catch (err) {
      console.error('Erro ao excluir:', err);
    }
  };

  // Filtragem dos Bens
  const bensFiltrados = useMemo(() => {
    return bens.filter((b) => {
      if (empresaFiltro !== 'all' && b.empresaId !== empresaFiltro) return false;
      if (classificacaoFiltro !== 'all' && b.classificacao !== classificacaoFiltro) return false;
      if (statusFiltro !== 'all' && b.status !== statusFiltro) return false;
      if (seguroFiltro !== 'all' && b.seguroStatus !== seguroFiltro) return false;
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        return (
          b.descricao.toLowerCase().includes(q) ||
          b.numeroPatrimonio.toLowerCase().includes(q) ||
          b.placaIdentificacao.toLowerCase().includes(q) ||
          b.numeroNotaFiscal.toLowerCase().includes(q) ||
          (b.marca && b.marca.toLowerCase().includes(q)) ||
          (b.responsavel && b.responsavel.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [bens, empresaFiltro, classificacaoFiltro, statusFiltro, seguroFiltro, searchTerm]);

  // Cálculos do Dashboard Geral
  const metricas = useMemo(() => {
    const ativos = bensFiltrados.filter((b) => b.status !== 'baixado');
    const valorOriginalTotal = ativos.reduce((acc, b) => acc + b.valorAquisicao, 0);
    const depreciacaoAcumuladaTotal = ativos.reduce((acc, b) => acc + b.depreciacaoAcumulada, 0);
    const valorLiquidoTotal = ativos.reduce((acc, b) => acc + b.valorContabilLiquido, 0);
    const bensComSeguro = ativos.filter((b) => b.temSeguro && b.seguroStatus === 'vigente');
    const valorSeguradoTotal = ativos.reduce((acc, b) => (b.temSeguro ? acc + (b.valorSegurado || b.valorAquisicao) : acc), 0);
    const segurosVencendo = ativos.filter((b) => b.seguroStatus === 'vencendo').length;
    const segurosExpirados = ativos.filter((b) => b.seguroStatus === 'expirado').length;
    const bensBaixados = bensFiltrados.filter((b) => b.status === 'baixado').length;

    return {
      totalAtivos: ativos.length,
      valorOriginalTotal,
      depreciacaoAcumuladaTotal,
      valorLiquidoTotal,
      percentualDepreciado: valorOriginalTotal > 0 ? ((depreciacaoAcumuladaTotal / valorOriginalTotal) * 100).toFixed(1) : '0.0',
      bensComSeguroCount: bensComSeguro.length,
      valorSeguradoTotal,
      segurosVencendo,
      segurosExpirados,
      bensBaixados,
    };
  }, [bensFiltrados]);

  // Funções de Seleção de Bens em Lote
  const handleToggleSelectAllBens = () => {
    if (bensSelecionadosIds.length === bensFiltrados.length && bensFiltrados.length > 0) {
      setBensSelecionadosIds([]);
    } else {
      setBensSelecionadosIds(bensFiltrados.map((b) => b.id));
    }
  };

  const handleToggleSelectRowBem = (id: string) => {
    setBensSelecionadosIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleClearSelectionBens = () => {
    setBensSelecionadosIds([]);
  };

  // Formatador de Moeda BRL
  const fmtMoeda = (val: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);

  // Nome da Empresa
  const getNomeEmpresa = (id: string) => {
    const emp = empresas.find((e) => e.id === id);
    return emp ? emp.nomeFantasia || emp.razaoSocial : 'Empresa Matriz';
  };

  // Nome do Centro de Custo
  const getNomeCentroCusto = (id: string) => {
    const cc = centrosCusto.find((c) => c.id === id);
    return cc ? `${cc.codigo} - ${cc.nome}` : 'Administrativo';
  };

  // Badge de Status do Bem
  const renderStatusBadge = (status: StatusBemPatrimonial) => {
    switch (status) {
      case 'ativo':
        return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800">Ativo / Em Operação</span>;
      case 'manutencao':
        return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-100 text-amber-800">Em Manutenção</span>;
      case 'depreciado':
        return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-slate-200 text-slate-700">Totalmente Depreciado</span>;
      case 'baixado':
        return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-rose-100 text-rose-800">Baixado / Alienado</span>;
      case 'doado':
        return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-blue-100 text-blue-800">Doado</span>;
    }
  };

  // Badge de Seguro
  const renderSeguroBadge = (bem: BemPatrimonial) => {
    if (!bem.temSeguro) {
      return (
        <span className="inline-flex items-center gap-1 text-xs text-slate-500 font-medium bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
          <XCircle className="w-3 h-3 text-slate-400" /> Sem Seguro
        </span>
      );
    }
    if (bem.seguroStatus === 'vencendo') {
      return (
        <span className="inline-flex items-center gap-1 text-xs text-amber-800 font-semibold bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
          <AlertTriangle className="w-3 h-3 text-amber-600" /> Vence em breve ({bem.seguroDataFim})
        </span>
      );
    }
    if (bem.seguroStatus === 'expirado') {
      return (
        <span className="inline-flex items-center gap-1 text-xs text-rose-800 font-semibold bg-rose-100 px-2 py-0.5 rounded border border-rose-300">
          <AlertTriangle className="w-3 h-3 text-rose-600" /> Apólice Vencida!
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 text-xs text-emerald-800 font-medium bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
        <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Vigente ({bem.seguradora ? bem.seguradora.split(' ')[0] : 'Assegurado'})
      </span>
    );
  };

  // Exportar Inventário Patrimonial Completo em PDF
  const handleExportarRelatorioPdf = () => {
    const doc = new jsPDF('landscape', 'pt', 'a4');
    const empNome = empresaFiltro !== 'all' ? getNomeEmpresa(empresaFiltro) : 'Todas as Empresas (Consolidado)';

    doc.setFillColor(30, 41, 59);
    doc.rect(0, 0, 842, 60, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('RELATÓRIO GERAL DO ATIVO IMOBILIZADO & INVENTÁRIO PATRIMONIAL', 40, 32);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Empresa: ${empNome}  |  Emissão: 17/09/2026  |  Norma Contábil: NBC TG 27 (CPC 27)`, 40, 48);

    const head = [
      [
        'Patrimônio',
        'Placa',
        'Descrição do Bem',
        'Classificação',
        'NF Compra',
        'Data Aquis.',
        'Valor Aquisição',
        'Deprec. Acum.',
        'Valor Contábil Líq.',
        'Seguro',
        'Status',
      ],
    ];

    const body = bensFiltrados.map((b) => [
      b.numeroPatrimonio,
      b.placaIdentificacao,
      b.descricao.length > 35 ? b.descricao.slice(0, 32) + '...' : b.descricao,
      TABELA_PARAMETROS_ATIVO[b.classificacao]?.nome.split(' ')[0] || b.classificacao,
      b.numeroNotaFiscal,
      b.dataAquisicao,
      fmtMoeda(b.valorAquisicao),
      fmtMoeda(b.depreciacaoAcumulada),
      fmtMoeda(b.valorContabilLiquido),
      b.temSeguro ? (b.seguroStatus === 'vencendo' ? 'Vencendo' : 'Vigente') : 'Sem Seguro',
      b.status.toUpperCase(),
    ]);

    autoTable(doc, {
      head,
      body,
      startY: 75,
      theme: 'grid',
      styles: { fontSize: 8, cellPadding: 4 },
      headStyles: { fillColor: [44, 62, 80], textColor: [255, 255, 255], fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [248, 250, 252] },
    });

    // Totais no rodapé do PDF
    const finalY = (doc as any).lastAutoTable.finalY + 20;
    doc.setFontSize(9);
    doc.setTextColor(51, 65, 85);
    doc.setFont('helvetica', 'bold');
    doc.text(`Total de Bens Listados: ${bensFiltrados.length}`, 40, finalY);
    doc.text(`Valor Original Total: ${fmtMoeda(metricas.valorOriginalTotal)}`, 200, finalY);
    doc.text(`Depreciação Acumulada: ${fmtMoeda(metricas.depreciacaoAcumuladaTotal)}`, 420, finalY);
    doc.text(`Valor Contábil Líquido Total: ${fmtMoeda(metricas.valorLiquidoTotal)}`, 620, finalY);

    doc.save(`Inventario_Patrimonial_${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  return (
    <div className="space-y-6">
      {/* CABEÇALHO DA SEÇÃO */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-50 text-blue-700 rounded-lg">
              <Package className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">
                Controle Patrimonial & Ativo Imobilizado
              </h1>
              <p className="text-sm text-slate-500">
                Cadastro de bens, placas de identificação, apólices de seguro, memória de cálculo de depreciação (CPC 27), baixas e integração contábil.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            id="btn-exportar-lote-patrimonio"
            onClick={() => setModalExportarLoteAberto(true)}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-semibold text-emerald-800 bg-emerald-50 border border-emerald-300 rounded-lg hover:bg-emerald-100 transition-colors shadow-xs cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
            Exportar em Lote (OFX / CSV)
          </button>

          <button
            onClick={onNavigateToContabilidade}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-lg hover:bg-indigo-100 transition-colors"
          >
            <TrendingDown className="w-4 h-4" />
            Ver Integração Contábil & DRE
          </button>

          <button
            onClick={() => setModalEtiquetasLoteAberto(true)}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-xs"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            Imprimir Placas (Lote)
          </button>

          <button
            onClick={handleExportarRelatorioPdf}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors shadow-xs"
          >
            <Download className="w-4 h-4 text-slate-500" />
            Exportar Inventário (PDF)
          </button>

          <button
            onClick={handleAbrirNovo}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Cadastrar Novo Bem
          </button>
        </div>
      </div>

      {/* CARDS DE INDICADORES DO PATRIMÔNIO */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Ativos Cadastrados */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Ativos em Operação</span>
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{metricas.totalAtivos}</span>
            <span className="text-xs text-slate-500">bens registrados</span>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Custo Aquisição Total: <span className="font-semibold text-slate-700">{fmtMoeda(metricas.valorOriginalTotal)}</span>
          </p>
        </div>

        {/* Depreciação Acumulada */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Depreciação Acumulada</span>
            <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-amber-600">{fmtMoeda(metricas.depreciacaoAcumuladaTotal)}</span>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Amortizado: <span className="font-semibold text-amber-700">{metricas.percentualDepreciado}%</span> do custo original
          </p>
        </div>

        {/* Valor Contábil Líquido (Book Value) */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Valor Contábil Líquido</span>
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-emerald-700">{fmtMoeda(metricas.valorLiquidoTotal)}</span>
          </div>
          <p className="text-xs text-slate-500 mt-2">
            Saldo refletido no <span className="font-semibold text-slate-700">Ativo Imobilizado (BP)</span>
          </p>
        </div>

        {/* Cobertura de Seguros & Alertas */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Bens Assegurados</span>
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
              <Shield className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{metricas.bensComSeguroCount}</span>
            <span className="text-xs text-slate-500">de {metricas.totalAtivos} bens</span>
          </div>
          <div className="flex items-center gap-2 mt-2 text-xs">
            {metricas.segurosVencendo > 0 ? (
              <span className="text-amber-700 font-medium bg-amber-50 px-2 py-0.5 rounded flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> {metricas.segurosVencendo} vencendo em 30d
              </span>
            ) : (
              <span className="text-emerald-700 font-medium bg-emerald-50 px-2 py-0.5 rounded flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Apólices regulares
              </span>
            )}
          </div>
        </div>
      </div>

      {/* BARRA DE FILTROS E BUSCA */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2.5 flex-1 w-full flex-wrap">
          {/* Busca Textual */}
          <div className="relative flex-1 min-w-[240px]">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar por descrição, nº patrimônio, placa, NF ou marca..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            />
          </div>

          {/* Filtro Empresa */}
          <select
            value={empresaFiltro}
            onChange={(e) => setEmpresaFiltro(e.target.value)}
            className="text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white text-slate-700 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
          >
            <option value="all">Todas as Empresas</option>
            {empresas.map((emp) => (
              <option key={emp.id} value={emp.id}>
                {emp.nomeFantasia || emp.razaoSocial}
              </option>
            ))}
          </select>

          {/* Filtro Classificação */}
          <select
            value={classificacaoFiltro}
            onChange={(e) => setClassificacaoFiltro(e.target.value)}
            className="text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white text-slate-700 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
          >
            <option value="all">Todas as Classificações</option>
            {Object.entries(TABELA_PARAMETROS_ATIVO).map(([key, val]) => (
              <option key={key} value={key}>
                {val.nome} ({val.taxaAnual}% a.a.)
              </option>
            ))}
          </select>

          {/* Filtro Status */}
          <select
            value={statusFiltro}
            onChange={(e) => setStatusFiltro(e.target.value)}
            className="text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white text-slate-700 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
          >
            <option value="all">Todos os Status</option>
            <option value="ativo">Ativo / Operação</option>
            <option value="manutencao">Em Manutenção</option>
            <option value="depreciado">Totalmente Depreciado</option>
            <option value="baixado">Baixado / Alienado</option>
          </select>

          {/* Filtro Seguro */}
          <select
            value={seguroFiltro}
            onChange={(e) => setSeguroFiltro(e.target.value)}
            className="text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white text-slate-700 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
          >
            <option value="all">Todos os Seguros</option>
            <option value="vigente">Seguro Vigente</option>
            <option value="vencendo">Seguro a Vencer (&lt;45d)</option>
            <option value="expirado">Seguro Expirado</option>
            <option value="sem_seguro">Sem Seguro</option>
          </select>
        </div>

        <button
          onClick={carregarBens}
          title="Recarregar dados"
          className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* FEEDBACK ALERT */}
      {feedbackPatrimonio && (
        <div className="bg-emerald-50 border border-emerald-300 text-emerald-900 px-4 py-3 rounded-xl flex items-center gap-2 shadow-xs text-sm">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{feedbackPatrimonio}</span>
        </div>
      )}

      {/* BARRA DE AÇÕES EM LOTE */}
      {bensSelecionadosIds.length > 0 && (
        <div className="bg-slate-900 text-white px-4 py-3 rounded-xl flex flex-wrap items-center justify-between gap-3 shadow-md animate-in fade-in">
          <div className="flex items-center gap-2 text-sm">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span className="font-bold">
              {bensSelecionadosIds.length} bem(ns) selecionado(s)
            </span>
            <span className="text-slate-300 hidden sm:inline">
              (Total Histórico: {fmtMoeda(bensFiltrados.filter(b => bensSelecionadosIds.includes(b.id)).reduce((acc, b) => acc + b.valorAquisicao, 0))})
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="btn-exportar-selecionados-patrimonio"
              onClick={() => setModalExportarLoteAberto(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-xs font-bold text-white transition-colors cursor-pointer shadow-xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Exportar Selecionados (OFX / CSV)
            </button>
            <button
              onClick={handleClearSelectionBens}
              className="text-xs text-slate-300 hover:text-white underline ml-2 cursor-pointer"
            >
              Limpar seleção
            </button>
          </div>
        </div>
      )}

      {/* TABELA DE BENS PATRIMONIAIS */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-slate-700 text-xs font-semibold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="px-3 py-3 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={
                      bensFiltrados.length > 0 &&
                      bensSelecionadosIds.length === bensFiltrados.length
                    }
                    onChange={handleToggleSelectAllBens}
                    aria-label="Selecionar todos os bens da página"
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                  />
                </th>
                <th className="px-4 py-3">Identificação / Placa</th>
                <th className="px-4 py-3">Descrição & Classificação</th>
                <th className="px-4 py-3">Setor & C. Custo</th>
                <th className="px-4 py-3">NF & Aquisição</th>
                <th className="px-4 py-3">Seguro</th>
                <th className="px-4 py-3 text-right">Custo Histórico</th>
                <th className="px-4 py-3 text-right">Deprec. Acumulada</th>
                <th className="px-4 py-3 text-right">Valor Líquido</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {bensFiltrados.length === 0 ? (
                <tr>
                  <td colSpan={11} className="px-4 py-12 text-center text-slate-400">
                    <Package className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                    Nenhum bem patrimonial localizado para os filtros informados.
                  </td>
                </tr>
              ) : (
                bensFiltrados.map((bem) => {
                  const param = TABELA_PARAMETROS_ATIVO[bem.classificacao];
                  return (
                    <tr
                      key={bem.id}
                      className={`hover:bg-slate-50/70 transition-colors ${
                        bensSelecionadosIds.includes(bem.id) ? 'bg-blue-50/40' : ''
                      }`}
                    >
                      {/* Checkbox de seleção */}
                      <td className="px-3 py-3 text-center">
                        <input
                          type="checkbox"
                          checked={bensSelecionadosIds.includes(bem.id)}
                          onChange={() => handleToggleSelectRowBem(bem.id)}
                          aria-label={`Selecionar bem ${bem.numeroPatrimonio}`}
                          className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
                        />
                      </td>

                      {/* Identificação / Plaqueta */}
                      <td className="px-4 py-3">
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          <Tag className="w-3.5 h-3.5 text-blue-600" />
                          {bem.numeroPatrimonio}
                        </div>
                        <div className="inline-block mt-1 font-mono text-[11px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded border border-slate-300">
                          {bem.placaIdentificacao}
                        </div>
                      </td>

                      {/* Descrição & Classificação */}
                      <td className="px-4 py-3 max-w-[280px]">
                        <div className="font-semibold text-slate-900 truncate" title={bem.descricao}>
                          {bem.descricao}
                        </div>
                        <div className="text-xs text-slate-500 mt-0.5">
                          {bem.marca && <span className="font-medium text-slate-700">{bem.marca} </span>}
                          {bem.modelo && <span>{bem.modelo}</span>}
                          {bem.numeroSerie && <span className="text-[11px] text-slate-400 block">S/N: {bem.numeroSerie}</span>}
                        </div>
                        <div className="text-[11px] text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded mt-1 inline-block">
                          {param?.nome || bem.classificacao} ({bem.taxaDepreciacaoAnual}% a.a.)
                        </div>
                      </td>

                      {/* Setor & Centro de Custo */}
                      <td className="px-4 py-3 text-xs">
                        <div className="text-slate-800 font-medium">{bem.localizacao}</div>
                        <div className="text-slate-500 text-[11px] mt-0.5">{getNomeCentroCusto(bem.centroCustoId)}</div>
                        {bem.responsavel && (
                          <div className="text-[11px] text-slate-400 mt-0.5">Resp: {bem.responsavel}</div>
                        )}
                      </td>

                      {/* NF & Aquisição */}
                      <td className="px-4 py-3 text-xs">
                        <div className="font-semibold text-slate-800">NF: {bem.numeroNotaFiscal}</div>
                        <div className="text-slate-500 text-[11px]">{bem.dataAquisicao}</div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[130px]" title={bem.fornecedorNome}>
                          {bem.fornecedorNome}
                        </div>
                      </td>

                      {/* Seguro */}
                      <td className="px-4 py-3">{renderSeguroBadge(bem)}</td>

                      {/* Custo Histórico */}
                      <td className="px-4 py-3 text-right font-medium text-slate-800">
                        {fmtMoeda(bem.valorAquisicao)}
                        {bem.desagio > 0 && (
                          <span className="block text-[10px] text-amber-600">Deságio: -{fmtMoeda(bem.desagio)}</span>
                        )}
                        {bem.agio > 0 && (
                          <span className="block text-[10px] text-emerald-600">Ágio: +{fmtMoeda(bem.agio)}</span>
                        )}
                      </td>

                      {/* Depreciação Acumulada */}
                      <td className="px-4 py-3 text-right text-xs">
                        <span className="font-semibold text-amber-700">-{fmtMoeda(bem.depreciacaoAcumulada)}</span>
                        <span className="block text-[10px] text-slate-400">
                          {fmtMoeda(bem.depreciacaoMensal)}/mês ({bem.mesesDepreciados}m)
                        </span>
                      </td>

                      {/* Valor Contábil Líquido */}
                      <td className="px-4 py-3 text-right font-bold text-slate-900">
                        {fmtMoeda(bem.valorContabilLiquido)}
                      </td>

                      {/* Status */}
                      <td className="px-4 py-3">{renderStatusBadge(bem.status)}</td>

                      {/* Ações */}
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {/* Ver Plaqueta / Etiqueta */}
                          <button
                            onClick={() => {
                              setBemSelecionado(bem);
                              setModalPlaquetaAberto(true);
                            }}
                            title="Ver Placa / Etiqueta de Identificação"
                            className="p-1.5 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                          >
                            <QrCode className="w-4 h-4" />
                          </button>

                          {/* Memória de Depreciação */}
                          <button
                            onClick={() => {
                              setBemSelecionado(bem);
                              setModalDepreciacaoAberto(true);
                            }}
                            title="Ficha & Memória de Depreciação (CPC 27)"
                            className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded transition-colors"
                          >
                            <TrendingDown className="w-4 h-4" />
                          </button>

                          {/* Registrar Baixa (se ativo) */}
                          {bem.status !== 'baixado' && (
                            <button
                              onClick={() => {
                                setBemSelecionado(bem);
                                setBaixaData('2026-09-17');
                                setBaixaValorVenda(bem.valorContabilLiquido);
                                setModalBaixaAberto(true);
                              }}
                              title="Registrar Baixa / Alienação"
                              className="p-1.5 text-amber-600 hover:bg-amber-50 rounded transition-colors"
                            >
                              <ArrowDownRight className="w-4 h-4" />
                            </button>
                          )}

                          {/* Editar */}
                          <button
                            onClick={() => handleAbrirEdicao(bem)}
                            title="Editar Dados do Bem"
                            className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded transition-colors"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>

                          {/* Excluir */}
                          <button
                            onClick={() => handleExcluirBem(bem.id)}
                            title="Remover Bem"
                            className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ===================================================================== */}
      {/* MODAL 1: CADASTRO / EDIÇÃO DE BEM PATRIMONIAL */}
      {/* ===================================================================== */}
      {modalCadastroAberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-xl max-w-4xl w-full my-8 max-h-[90vh] flex flex-col overflow-hidden">
            {/* Topo Modal */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">
                    {formModo === 'novo' ? 'Cadastro de Bem Patrimonial (Ativo Imobilizado)' : 'Editar Bem Patrimonial'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Preencha os dados do tombamento, placa, seguro e parâmetros de depreciação conforme norma CPC 27.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setModalCadastroAberto(false)}
                className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Conteúdo do Form */}
            <form onSubmit={handleSalvarBem} className="p-6 overflow-y-auto space-y-6">
              {/* BLOCO 1: IDENTIFICAÇÃO BÁSICA & TOMBAMENTO */}
              <div>
                <div className="flex items-center justify-between mb-3 border-b border-slate-100 pb-2">
                  <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
                    <Tag className="w-4 h-4 text-blue-600" />
                    1. Identificação, Placa & Classificação do Ativo
                  </h4>
                  <button
                    type="button"
                    onClick={gerarCodigoAutomatico}
                    className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1"
                  >
                    <RefreshCw className="w-3 h-3" /> Gerar Placa e Número Automáticos
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Empresa Proprietária *
                    </label>
                    <select
                      value={formEmpresaId}
                      onChange={(e) => setFormEmpresaId(e.target.value)}
                      required
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white"
                    >
                      {empresas.map((emp) => (
                        <option key={emp.id} value={emp.id}>
                          {emp.nomeFantasia || emp.razaoSocial}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Número do Patrimônio (Tombamento) *
                    </label>
                    <input
                      type="text"
                      value={formNumeroPatrimonio}
                      onChange={(e) => setFormNumeroPatrimonio(e.target.value)}
                      placeholder="Ex: PAT-00105"
                      required
                      className="w-full text-sm font-mono border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Placa de Identificação Física *
                    </label>
                    <input
                      type="text"
                      value={formPlacaIdentificacao}
                      onChange={(e) => setFormPlacaIdentificacao(e.target.value)}
                      placeholder="Ex: PLA-SP-2024-001"
                      required
                      className="w-full text-sm font-mono border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Classificação do Ativo Imobilizado *
                    </label>
                    <select
                      value={formClassificacao}
                      onChange={(e) => handleClassificacaoChange(e.target.value as ClassificacaoAtivo)}
                      required
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white"
                    >
                      {Object.entries(TABELA_PARAMETROS_ATIVO).map(([key, val]) => (
                        <option key={key} value={key}>
                          {val.nome} (Taxa: {val.taxaAnual}% a.a. | Vida Útil: {val.vidaUtilAnos} anos)
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Descrição Detalhada do Bem *
                    </label>
                    <input
                      type="text"
                      value={formDescricao}
                      onChange={(e) => setFormDescricao(e.target.value)}
                      placeholder="Ex: Servidor Rack Dell PowerEdge R750 32C/64GB"
                      required
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Marca / Fabricante</label>
                    <input
                      type="text"
                      value={formMarca}
                      onChange={(e) => setFormMarca(e.target.value)}
                      placeholder="Ex: Dell / Mercedes / Romi"
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Modelo</label>
                    <input
                      type="text"
                      value={formModelo}
                      onChange={(e) => setFormModelo(e.target.value)}
                      placeholder="Ex: PowerEdge R750"
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Número de Série / Chassi</label>
                    <input
                      type="text"
                      value={formNumeroSerie}
                      onChange={(e) => setFormNumeroSerie(e.target.value)}
                      placeholder="Ex: BR-DELL-884920-X"
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Localização Física / Sala *</label>
                    <input
                      type="text"
                      value={formLocalizacao}
                      onChange={(e) => setFormLocalizacao(e.target.value)}
                      placeholder="Ex: Sede - Sala TI / Andar 2"
                      required
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Centro de Custo Alocado *</label>
                    <select
                      value={formCentroCustoId}
                      onChange={(e) => setFormCentroCustoId(e.target.value)}
                      required
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white"
                    >
                      {centrosCusto.map((cc) => (
                        <option key={cc.id} value={cc.id}>
                          {cc.codigo} - {cc.nome}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Responsável pelo Bem</label>
                    <input
                      type="text"
                      value={formResponsavel}
                      onChange={(e) => setFormResponsavel(e.target.value)}
                      placeholder="Ex: Carlos Alberto Mendes"
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                </div>
              </div>

              {/* BLOCO 2: DADOS DE AQUISIÇÃO, NOTA FISCAL, ÁGIO E DESÁGIO */}
              <div>
                <div className="flex items-center justify-between mb-3 border-b border-slate-100 pb-2">
                  <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
                    <FileText className="w-4 h-4 text-emerald-600" />
                    2. Aquisição, Nota Fiscal, Custo, Ágio e Deságio
                  </h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Data de Aquisição *</label>
                    <input
                      type="date"
                      value={formDataAquisicao}
                      onChange={(e) => setFormDataAquisicao(e.target.value)}
                      required
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Número da Nota Fiscal *</label>
                    <input
                      type="text"
                      value={formNumeroNotaFiscal}
                      onChange={(e) => setFormNumeroNotaFiscal(e.target.value)}
                      placeholder="Ex: 000.412.890"
                      required
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Série da NF</label>
                    <input
                      type="text"
                      value={formSerieNotaFiscal}
                      onChange={(e) => setFormSerieNotaFiscal(e.target.value)}
                      placeholder="1"
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Valor de Aquisição (R$) *</label>
                    <input
                      type="number"
                      step="0.01"
                      value={formValorAquisicao}
                      onChange={(e) => setFormValorAquisicao(parseFloat(e.target.value) || 0)}
                      required
                      className="w-full text-sm font-semibold border border-slate-300 rounded-lg px-3 py-2 text-slate-900"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Fornecedor / Razão Social</label>
                    <input
                      type="text"
                      value={formFornecedorNome}
                      onChange={(e) => setFormFornecedorNome(e.target.value)}
                      placeholder="Ex: Dell Computadores do Brasil Ltda"
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">CNPJ do Fornecedor</label>
                    <input
                      type="text"
                      value={formFornecedorCnpj}
                      onChange={(e) => setFormFornecedorCnpj(e.target.value)}
                      placeholder="00.000.000/0000-00"
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Contrato Vinculado / Aditivo</label>
                    <input
                      type="text"
                      value={formContratoVinculado}
                      onChange={(e) => setFormContratoVinculado(e.target.value)}
                      placeholder="Ex: CONT-TI-2024/02"
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Chave de Acesso NF-e (44 dígitos)</label>
                    <input
                      type="text"
                      maxLength={44}
                      value={formChaveAcessoNfe}
                      onChange={(e) => setFormChaveAcessoNfe(e.target.value)}
                      placeholder="35240372381189000110550010004128901004128905"
                      className="w-full text-xs font-mono border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Ágio na Aquisição / Benfeitoria (R$)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={formAgio}
                      onChange={(e) => setFormAgio(parseFloat(e.target.value) || 0)}
                      placeholder="0.00"
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Deságio / Desconto na Aquisição (R$)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={formDesagio}
                      onChange={(e) => setFormDesagio(parseFloat(e.target.value) || 0)}
                      placeholder="0.00"
                      className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                    />
                  </div>
                </div>
              </div>

              {/* BLOCO 3: SEGURO PATRIMONIAL, APÓLICE E VIGÊNCIAS */}
              <div>
                <div className="flex items-center justify-between mb-3 border-b border-slate-100 pb-2">
                  <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
                    <Shield className="w-4 h-4 text-indigo-600" />
                    3. Seguro Patrimonial & Vigência da Apólice
                  </h4>
                  <label className="flex items-center gap-2 text-xs font-semibold text-indigo-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formTemSeguro}
                      onChange={(e) => setFormTemSeguro(e.target.checked)}
                      className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                    />
                    O bem possui cobertura de seguro ativa
                  </label>
                </div>

                {formTemSeguro && (
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-indigo-50/40 p-4 rounded-xl border border-indigo-100">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Seguradora</label>
                      <input
                        type="text"
                        value={formSeguradora}
                        onChange={(e) => setFormSeguradora(e.target.value)}
                        placeholder="Ex: Porto Seguro / Tokio Marine / Allianz"
                        className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Número da Apólice</label>
                      <input
                        type="text"
                        value={formNumeroApolice}
                        onChange={(e) => setFormNumeroApolice(e.target.value)}
                        placeholder="Ex: APOL-EQUIP-892401"
                        className="w-full text-sm font-mono border border-slate-300 rounded-lg px-3 py-2 bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Vigência (Início e Término)</label>
                      <div className="flex items-center gap-2">
                        <input
                          type="date"
                          value={formSeguroDataInicio}
                          onChange={(e) => setFormSeguroDataInicio(e.target.value)}
                          className="w-full text-xs border border-slate-300 rounded-lg px-2 py-1.5 bg-white"
                        />
                        <span className="text-slate-400">até</span>
                        <input
                          type="date"
                          value={formSeguroDataFim}
                          onChange={(e) => setFormSeguroDataFim(e.target.value)}
                          className="w-full text-xs border border-slate-300 rounded-lg px-2 py-1.5 bg-white"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Valor Segurado (R$)</label>
                      <input
                        type="number"
                        step="0.01"
                        value={formValorSegurado}
                        onChange={(e) => setFormValorSegurado(parseFloat(e.target.value) || 0)}
                        className="w-full text-sm font-semibold border border-slate-300 rounded-lg px-3 py-2 bg-white"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* BLOCO 4: PARÂMETROS DE DEPRECIAÇÃO (CPC 27) */}
              <div>
                <div className="flex items-center justify-between mb-3 border-b border-slate-100 pb-2">
                  <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
                    <TrendingDown className="w-4 h-4 text-amber-600" />
                    4. Parâmetros de Depreciação (CPC 27 / Receita Federal)
                  </h4>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Taxa de Depreciação Anual (% a.a.) *
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={formTaxaAnual}
                      onChange={(e) => setFormTaxaAnual(parseFloat(e.target.value) || 0)}
                      required
                      className="w-full text-sm font-semibold border border-slate-300 rounded-lg px-3 py-2 bg-white"
                    />
                    <span className="text-[11px] text-slate-500 mt-1 block">
                      Tabela SRF: {(formTaxaAnual / 12).toFixed(2)}% ao mês
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Vida Útil Estimada (Anos) *
                    </label>
                    <input
                      type="number"
                      value={formVidaUtilAnos}
                      onChange={(e) => setFormVidaUtilAnos(parseInt(e.target.value) || 1)}
                      required
                      className="w-full text-sm font-semibold border border-slate-300 rounded-lg px-3 py-2 bg-white"
                    />
                    <span className="text-[11px] text-slate-500 mt-1 block">
                      Total de {formVidaUtilAnos * 12} meses de vida útil
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Valor Residual Estimado (%) *
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={formValorResidualPercentual}
                      onChange={(e) => setFormValorResidualPercentual(parseFloat(e.target.value) || 0)}
                      required
                      className="w-full text-sm font-semibold border border-slate-300 rounded-lg px-3 py-2 bg-white"
                    />
                    <span className="text-[11px] text-slate-500 mt-1 block">
                      Valor não depreciável: {fmtMoeda((formValorAquisicao * formValorResidualPercentual) / 100)}
                    </span>
                  </div>
                </div>

                <div className="mt-3">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Observações Adicionais / Garantia</label>
                  <textarea
                    rows={2}
                    value={formObservacoes}
                    onChange={(e) => setFormObservacoes(e.target.value)}
                    placeholder="Informações de garantia, revisões programadas, localização específica..."
                    className="w-full text-sm border border-slate-300 rounded-lg p-2.5"
                  />
                </div>
              </div>

              {/* Botões do Rodapé */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setModalCadastroAberto(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-sm"
                >
                  {formModo === 'novo' ? 'Concluir Cadastro do Bem' : 'Salvar Alterações'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODAL 2: VISUALIZADOR DE PLACA & ETIQUETA DE IDENTIFICAÇÃO DO BEM */}
      {/* ===================================================================== */}
      {modalPlaquetaAberto && bemSelecionado && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <QrCode className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-900">Placa de Identificação Patrimonial</h3>
              </div>
              <button
                onClick={() => setModalPlaquetaAberto(false)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Visual da Plaqueta de Metal Escovado */}
            <div className="bg-linear-to-b from-slate-100 to-slate-200 p-6 rounded-xl border-2 border-slate-400 shadow-md relative">
              {/* Parafusos nos 4 cantos */}
              <div className="absolute top-2 left-2 w-2.5 h-2.5 rounded-full bg-slate-400 border border-slate-600 flex items-center justify-center">
                <div className="w-1.5 h-0.5 bg-slate-600 rotate-45" />
              </div>
              <div className="absolute top-2 right-2 w-2.5 h-2.5 rounded-full bg-slate-400 border border-slate-600 flex items-center justify-center">
                <div className="w-1.5 h-0.5 bg-slate-600 rotate-45" />
              </div>
              <div className="absolute bottom-2 left-2 w-2.5 h-2.5 rounded-full bg-slate-400 border border-slate-600 flex items-center justify-center">
                <div className="w-1.5 h-0.5 bg-slate-600 rotate-45" />
              </div>
              <div className="absolute bottom-2 right-2 w-2.5 h-2.5 rounded-full bg-slate-400 border border-slate-600 flex items-center justify-center">
                <div className="w-1.5 h-0.5 bg-slate-600 rotate-45" />
              </div>

              {/* Cabeçalho da Placa */}
              <div className="text-center border-b border-slate-300 pb-2 mb-3">
                <div className="text-xs font-black tracking-widest text-slate-800 uppercase">
                  {getNomeEmpresa(bemSelecionado.empresaId)}
                </div>
                <div className="text-[10px] text-slate-600 font-semibold tracking-wider uppercase">
                  CONTROLE DE PATRIMÔNIO & ATIVO IMOBILIZADO
                </div>
              </div>

              {/* Corpo da Placa com QR Code e Códigos */}
              <div className="flex items-center justify-between gap-4">
                {/* QR Code Simulado em SVG */}
                <div className="bg-white p-2 rounded-lg border border-slate-300 shadow-xs">
                  <svg className="w-24 h-24" viewBox="0 0 100 100" fill="currentColor">
                    {/* Padrões geométricos estilizados de QR Code */}
                    <rect x="0" y="0" width="30" height="30" fill="#1e293b" />
                    <rect x="5" y="5" width="20" height="20" fill="#ffffff" />
                    <rect x="10" y="10" width="10" height="10" fill="#1e293b" />

                    <rect x="70" y="0" width="30" height="30" fill="#1e293b" />
                    <rect x="75" y="5" width="20" height="20" fill="#ffffff" />
                    <rect x="80" y="10" width="10" height="10" fill="#1e293b" />

                    <rect x="0" y="70" width="30" height="30" fill="#1e293b" />
                    <rect x="5" y="75" width="20" height="20" fill="#ffffff" />
                    <rect x="10" y="80" width="10" height="10" fill="#1e293b" />

                    {/* Matriz de dados */}
                    <rect x="40" y="10" width="10" height="20" fill="#1e293b" />
                    <rect x="40" y="40" width="20" height="20" fill="#1e293b" />
                    <rect x="10" y="40" width="20" height="10" fill="#1e293b" />
                    <rect x="70" y="40" width="20" height="10" fill="#1e293b" />
                    <rect x="40" y="70" width="10" height="20" fill="#1e293b" />
                    <rect x="60" y="70" width="20" height="10" fill="#1e293b" />
                    <rect x="70" y="85" width="10" height="10" fill="#1e293b" />
                  </svg>
                </div>

                <div className="flex-1 space-y-1 text-slate-800">
                  <div className="text-[10px] text-slate-500 uppercase font-semibold">Número do Tombamento</div>
                  <div className="text-xl font-black font-mono tracking-wider text-blue-900">
                    {bemSelecionado.numeroPatrimonio}
                  </div>

                  <div className="text-[10px] text-slate-500 uppercase font-semibold mt-1">Código da Placa Física</div>
                  <div className="text-sm font-black font-mono text-slate-900 bg-white/70 px-2 py-0.5 rounded border border-slate-300 inline-block">
                    {bemSelecionado.placaIdentificacao}
                  </div>

                  <div className="text-[10px] text-slate-600 truncate mt-1" title={bemSelecionado.descricao}>
                    {bemSelecionado.descricao}
                  </div>
                </div>
              </div>

              {/* Código de Barras Simulado */}
              <div className="mt-4 pt-3 border-t border-slate-300 text-center">
                <div className="h-8 flex items-center justify-center gap-[2px] bg-white p-1 rounded border border-slate-300 overflow-hidden">
                  {[3, 1, 2, 4, 1, 3, 2, 1, 4, 2, 3, 1, 2, 4, 1, 3, 2, 1, 4, 2, 1, 3, 2, 4, 1, 2, 3, 4, 1, 2, 3].map((w, i) => (
                    <div key={i} className="bg-slate-900 h-full" style={{ width: `${w * 2}px` }} />
                  ))}
                </div>
                <div className="text-[9px] font-mono tracking-widest text-slate-600 mt-1 uppercase">
                  PROPRIEDADE INALIENÁVEL - RETIRADA PROIBIDA
                </div>
              </div>
            </div>

            {/* Botões de Ação */}
            <div className="flex items-center justify-end gap-2.5 mt-5">
              <button
                onClick={() => window.print()}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              >
                <Printer className="w-4 h-4" />
                Imprimir Plaqueta
              </button>
              <button
                onClick={() => setModalPlaquetaAberto(false)}
                className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODAL 3: FICHA DE DEPRECIAÇÃO & MEMÓRIA DE CÁLCULO (CPC 27) */}
      {/* ===================================================================== */}
      {modalDepreciacaoAberto && bemSelecionado && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-xl max-w-3xl w-full p-6 my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <TrendingDown className="w-5 h-5 text-emerald-600" />
                <div>
                  <h3 className="font-bold text-slate-900">Memória de Depreciação & Ficha Contábil</h3>
                  <p className="text-xs text-slate-500">
                    Cálculo linear de quotas mensais conforme norma contábil CPC 27 e RIR.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setModalDepreciacaoAberto(false)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cabeçalho do Bem */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mb-5 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="text-slate-500 block">Patrimônio / Placa:</span>
                <span className="font-bold text-slate-900">{bemSelecionado.numeroPatrimonio}</span>
                <span className="text-slate-600 block">{bemSelecionado.placaIdentificacao}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Data de Aquisição:</span>
                <span className="font-semibold text-slate-800">{bemSelecionado.dataAquisicao}</span>
                <span className="text-slate-500 block">NF {bemSelecionado.numeroNotaFiscal}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Custo de Aquisição:</span>
                <span className="font-bold text-slate-900">{fmtMoeda(bemSelecionado.valorAquisicao)}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Valor Contábil Líquido:</span>
                <span className="font-bold text-emerald-700">{fmtMoeda(bemSelecionado.valorContabilLiquido)}</span>
              </div>
            </div>

            {/* Parâmetros do CPC 27 */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-5">
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <span className="text-xs text-blue-700 font-semibold block">Taxa Anual de Depreciação</span>
                <span className="text-lg font-bold text-blue-900">{bemSelecionado.taxaDepreciacaoAnual}% a.a.</span>
                <span className="text-[11px] text-blue-600 block">
                  Quota mensal de {(bemSelecionado.taxaDepreciacaoAnual / 12).toFixed(3)}%
                </span>
              </div>
              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
                <span className="text-xs text-amber-700 font-semibold block">Valor Residual Não Depreciável</span>
                <span className="text-lg font-bold text-amber-900">{fmtMoeda(bemSelecionado.valorResidual)}</span>
                <span className="text-[11px] text-amber-600 block">
                  {bemSelecionado.valorResidualPercentual}% do custo histórico
                </span>
              </div>
              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                <span className="text-xs text-emerald-700 font-semibold block">Quota Mensal de Depreciação</span>
                <span className="text-lg font-bold text-emerald-900">{fmtMoeda(bemSelecionado.depreciacaoMensal)}</span>
                <span className="text-[11px] text-emerald-600 block">
                  Lançamento: D - Despesa / C - Deprec. Acum.
                </span>
              </div>
            </div>

            {/* Grade de Amortização dos Últimos 12 Meses */}
            <div>
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Evolução Contábil Recente (Mês a Mês)
              </h4>
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs text-slate-600">
                  <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="px-3 py-2">Competência</th>
                      <th className="px-3 py-2 text-right">Quota Mensal</th>
                      <th className="px-3 py-2 text-right">Deprec. Acumulada</th>
                      <th className="px-3 py-2 text-right">Saldo Residual Contábil</th>
                      <th className="px-3 py-2 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {['09/2026', '08/2026', '07/2026', '06/2026', '05/2026', '04/2026', '03/2026'].map((comp, idx) => {
                      const acumulada = Math.max(0, bemSelecionado.depreciacaoAcumulada - idx * bemSelecionado.depreciacaoMensal);
                      const saldo = Math.max(bemSelecionado.valorResidual, bemSelecionado.valorAquisicao - acumulada);
                      return (
                        <tr key={comp} className={idx === 0 ? 'bg-emerald-50/50 font-semibold' : ''}>
                          <td className="px-3 py-2">{comp} {idx === 0 && '(Atual)'}</td>
                          <td className="px-3 py-2 text-right text-amber-700">-{fmtMoeda(bemSelecionado.depreciacaoMensal)}</td>
                          <td className="px-3 py-2 text-right font-mono text-slate-700">{fmtMoeda(acumulada)}</td>
                          <td className="px-3 py-2 text-right font-mono font-bold text-slate-900">{fmtMoeda(saldo)}</td>
                          <td className="px-3 py-2 text-center">
                            <span className="text-[10px] text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                              Lançado
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Contas Contábeis Envolvidas */}
            <div className="mt-5 p-3.5 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1.5">
              <span className="font-bold text-slate-800 block">Contas Contábeis Vinculadas (Plano de Contas):</span>
              <div className="text-slate-600 flex items-center justify-between">
                <span>Ativo Não Circulante (Custo):</span>
                <span className="font-mono font-semibold">{TABELA_PARAMETROS_ATIVO[bemSelecionado.classificacao]?.contaAtivoCusto}</span>
              </div>
              <div className="text-slate-600 flex items-center justify-between">
                <span>(-) Depreciação Acumulada (Redutora do Ativo):</span>
                <span className="font-mono font-semibold text-amber-700">{TABELA_PARAMETROS_ATIVO[bemSelecionado.classificacao]?.contaDepreciacaoAcumulada}</span>
              </div>
              <div className="text-slate-600 flex items-center justify-between">
                <span>Despesa Operacional de Depreciação (DRE):</span>
                <span className="font-mono font-semibold text-blue-700">{TABELA_PARAMETROS_ATIVO[bemSelecionado.classificacao]?.contaDespesaDepreciacao}</span>
              </div>
            </div>

            <div className="flex justify-end mt-5">
              <button
                onClick={() => setModalDepreciacaoAberto(false)}
                className="px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
              >
                Concluir Visualização
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODAL 4: REGISTRAR BAIXA / ALIENAÇÃO DO BEM (GANHO/PERDA DE CAPITAL) */}
      {/* ===================================================================== */}
      {modalBaixaAberto && bemSelecionado && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <ArrowDownRight className="w-5 h-5 text-amber-600" />
                <h3 className="font-bold text-slate-900">Registrar Baixa / Alienação</h3>
              </div>
              <button
                onClick={() => setModalBaixaAberto(false)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmarBaixa} className="space-y-4">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                <span className="text-slate-500 block">Bem a ser baixado:</span>
                <span className="font-bold text-slate-900 text-sm">{bemSelecionado.numeroPatrimonio} - {bemSelecionado.descricao}</span>
                <div className="flex justify-between mt-2 pt-2 border-t border-slate-200">
                  <span className="text-slate-600">Valor Contábil Líquido Atual:</span>
                  <span className="font-bold text-slate-900">{fmtMoeda(bemSelecionado.valorContabilLiquido)}</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Data da Baixa *</label>
                <input
                  type="date"
                  value={baixaData}
                  onChange={(e) => setBaixaData(e.target.value)}
                  required
                  className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Motivo da Baixa *</label>
                <select
                  value={baixaMotivo}
                  onChange={(e) => setBaixaMotivo(e.target.value as any)}
                  required
                  className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white"
                >
                  <option value="venda">Venda / Alienação a Terceiros</option>
                  <option value="sucateamento">Sucateamento / Obsolescência Tecnológica</option>
                  <option value="sinistro">Sinistro / Perda Total (Seguro Acionado)</option>
                  <option value="doacao">Doação / Destinação Social</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Valor de Venda / Indenização Recebida (R$)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={baixaValorVenda}
                  onChange={(e) => setBaixaValorVenda(parseFloat(e.target.value) || 0)}
                  className="w-full text-sm font-semibold border border-slate-300 rounded-lg px-3 py-2"
                />
              </div>

              {/* Apuração de Ganho ou Perda de Capital */}
              <div
                className={`p-3 rounded-lg border text-xs ${
                  baixaValorVenda - bemSelecionado.valorContabilLiquido >= 0
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                    : 'bg-rose-50 border-rose-200 text-rose-900'
                }`}
              >
                <div className="flex justify-between font-bold">
                  <span>Resultado na Alienação:</span>
                  <span>
                    {baixaValorVenda - bemSelecionado.valorContabilLiquido >= 0
                      ? `Ganho de Capital: ${fmtMoeda(baixaValorVenda - bemSelecionado.valorContabilLiquido)}`
                      : `Perda de Capital: ${fmtMoeda(Math.abs(baixaValorVenda - bemSelecionado.valorContabilLiquido))}`}
                  </span>
                </div>
                <span className="text-[11px] block mt-1 opacity-80">
                  (Valor de Venda {fmtMoeda(baixaValorVenda)} - Valor Líquido {fmtMoeda(bemSelecionado.valorContabilLiquido)})
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">NF-e de Baixa / Saída</label>
                <input
                  type="text"
                  value={baixaNotaFiscal}
                  onChange={(e) => setBaixaNotaFiscal(e.target.value)}
                  placeholder="Ex: NF-e 000.012.345"
                  className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Observações da Baixa</label>
                <textarea
                  rows={2}
                  value={baixaObservacoes}
                  onChange={(e) => setBaixaObservacoes(e.target.value)}
                  placeholder="Informações do comprador, laudo de sucata, sinistro seguradora..."
                  className="w-full text-sm border border-slate-300 rounded-lg p-2"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setModalBaixaAberto(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-lg shadow-xs"
                >
                  Confirmar Baixa do Bem
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODAL 5: IMPRESSÃO DE ETIQUETAS EM LOTE PARA PLAQUEAMENTO */}
      {/* ===================================================================== */}
      {modalEtiquetasLoteAberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-xl max-w-4xl w-full p-6 my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-blue-600" />
                <div>
                  <h3 className="font-bold text-slate-900">Grade de Etiquetas para Plaqueamento em Lote</h3>
                  <p className="text-xs text-slate-500">
                    Formato para folha A4 adesiva / etiquetas metálicas para fixação nos equipamentos.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setModalEtiquetasLoteAberto(false)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Grid com Etiquetas */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {bensFiltrados.slice(0, 9).map((b) => (
                <div
                  key={b.id}
                  className="border-2 border-dashed border-slate-300 p-3 rounded-lg bg-slate-50 flex flex-col justify-between"
                >
                  <div className="text-center border-b border-slate-200 pb-1 mb-2">
                    <span className="text-[10px] font-bold text-slate-700 uppercase tracking-wider block truncate">
                      {getNomeEmpresa(b.empresaId)}
                    </span>
                    <span className="text-[8px] text-slate-500 font-semibold uppercase">
                      ATIVO PATRIMONIAL
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    {/* Mini QR Code */}
                    <div className="bg-white p-1 rounded border border-slate-300 shrink-0">
                      <svg className="w-12 h-12" viewBox="0 0 100 100" fill="#0f172a">
                        <rect x="0" y="0" width="30" height="30" />
                        <rect x="70" y="0" width="30" height="30" />
                        <rect x="0" y="70" width="30" height="30" />
                        <rect x="40" y="40" width="20" height="20" />
                      </svg>
                    </div>

                    <div className="space-y-0.5 text-right flex-1 min-w-0">
                      <div className="text-xs font-black font-mono text-blue-900 truncate">
                        {b.numeroPatrimonio}
                      </div>
                      <div className="text-[10px] font-mono text-slate-700 bg-white px-1 py-0.5 rounded border border-slate-200 inline-block">
                        {b.placaIdentificacao}
                      </div>
                      <div className="text-[9px] text-slate-500 truncate" title={b.descricao}>
                        {b.descricao}
                      </div>
                    </div>
                  </div>

                  <div className="mt-2 pt-1 border-t border-slate-200 text-center text-[8px] text-slate-500 font-mono">
                    PROPRIEDADE INALIENÁVEL
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-200">
              <span className="text-xs text-slate-500">
                Mostrando etiquetas de {Math.min(bensFiltrados.length, 9)} bens selecionados.
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                >
                  <Printer className="w-4 h-4" />
                  Imprimir Folha de Etiquetas
                </button>
                <button
                  onClick={() => setModalEtiquetasLoteAberto(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Exportação em Lote do Patrimônio (OFX / CSV) */}
      <ModalExportacaoPatrimonio
        isOpen={modalExportarLoteAberto}
        onClose={() => setModalExportarLoteAberto(false)}
        bensTotais={bens}
        bensFiltrados={bensFiltrados}
        bensSelecionadosIds={bensSelecionadosIds}
        empresas={empresas}
        centrosCusto={centrosCusto}
        onFeedback={exibirFeedbackPatrimonio}
      />
    </div>
  );
};
