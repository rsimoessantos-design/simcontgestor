import React, { useState } from 'react';
import { CheckSquare, Clock, Plus, Search, CheckCircle2, User, Building } from 'lucide-react';
import { Tarefa, Empresa } from '../types';

interface TarefasViewProps {
  tarefas: Tarefa[];
  empresas: Empresa[];
  selectedEmpresa?: Empresa;
  onUpdateStatus: (id: string, status: Tarefa['status']) => void;
}

export const TarefasView: React.FC<TarefasViewProps> = ({
  tarefas,
  empresas,
  selectedEmpresa,
  onUpdateStatus,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPrioridade, setFilterPrioridade] = useState('todas');
  const [filterStatus, setFilterStatus] = useState('todas');

  const filtered = tarefas.filter((t) => {
    const matchesSearch =
      t.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.descricao.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.responsavel.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPrioridade = filterPrioridade === 'todas' || t.prioridade === filterPrioridade;
    const matchesStatus = filterStatus === 'todas' || t.status === filterStatus;
    return matchesSearch && matchesPrioridade && matchesStatus;
  });

  const getEmpresaName = (empresaId: string) => {
    const emp = empresas.find((e) => e.id === empresaId);
    return emp ? emp.nomeFantasia : 'Todas';
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900">
              Tarefas & Fluxos Operacionais Contábeis
            </h1>
            <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
              DEMO
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {selectedEmpresa
              ? `Demandas internas e conciliações para: ${selectedEmpresa.nomeFantasia}`
              : 'Distribuição e controle de prazos da equipe contábil'}
          </p>
        </div>

        <button
          onClick={() => alert('Criação de tarefa pronta para integração com o quadro Kanban.')}
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Nova Tarefa</span>
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Pesquisar tarefas por título, descrição ou responsável..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
          />
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span>Prioridade:</span>
            <select
              value={filterPrioridade}
              onChange={(e) => setFilterPrioridade(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg py-1.5 px-2 bg-slate-50"
            >
              <option value="todas">Todas</option>
              <option value="urgente">Urgente</option>
              <option value="alta">Alta</option>
              <option value="media">Média</option>
              <option value="baixa">Baixa</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span>Status:</span>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg py-1.5 px-2 bg-slate-50"
            >
              <option value="todas">Todos</option>
              <option value="a_fazer">A Fazer</option>
              <option value="em_andamento">Em Andamento</option>
              <option value="concluida">Concluída</option>
            </select>
          </div>
        </div>
      </div>

      {/* Tasks Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((t) => (
          <div
            key={t.id}
            className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-all"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    t.prioridade === 'urgente'
                      ? 'bg-rose-100 text-rose-800'
                      : t.prioridade === 'alta'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {t.prioridade.toUpperCase()}
                </span>
                <span className="text-[11px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                  {getEmpresaName(t.empresaId)}
                </span>
              </div>

              <h3 className="font-bold text-slate-900 text-sm">{t.titulo}</h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">{t.descricao}</p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <div className="space-y-0.5">
                <div className="text-slate-500 text-[11px] flex items-center gap-1">
                  <User className="w-3.5 h-3.5" />
                  <span>{t.responsavel}</span>
                </div>
                <div className="text-slate-700 font-mono text-[11px] font-semibold">
                  Prazo: {t.dataVencimento}
                </div>
              </div>

              <div className="flex items-center gap-2">
                {t.status !== 'concluida' ? (
                  <button
                    onClick={() => onUpdateStatus(t.id, 'concluida')}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors"
                  >
                    Concluir
                  </button>
                ) : (
                  <button
                    onClick={() => onUpdateStatus(t.id, 'em_andamento')}
                    className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors"
                  >
                    Reabrir
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
