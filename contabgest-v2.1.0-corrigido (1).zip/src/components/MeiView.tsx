import React, { useState, useEffect, useMemo } from 'react';
import {
  Store,
  Calendar,
  DollarSign,
  FileText,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Printer,
  QrCode,
  Copy,
  Check,
  Send,
  RefreshCw,
  TrendingUp,
  UserCheck,
  FileCheck,
  Eye,
  Info,
  ChevronRight,
  ShieldCheck,
  AlertCircle,
  PlusCircle,
  X,
  CreditCard,
  Percent,
  Receipt,
} from 'lucide-react';
import {
  Empresa,
  GuiaDasMei,
  DeclaracaoAnualMei,
  ResumoFaturamentoMei,
  NotaFiscal,
  User,
} from '../types';
import {
  SALARIO_MINIMO_VIGENTE,
  LIMITE_ANUAL_MEI_PADRAO,
  LIMITE_MENSAL_MEI,
  NOMES_MESES,
} from '../utils/meiCalculator';

interface MeiViewProps {
  selectedEmpresa?: Empresa;
  empresas: Empresa[];
  notasFiscais?: NotaFiscal[];
  currentUser?: User;
  onRefresh?: () => void;
}

export const MeiView: React.FC<MeiViewProps> = ({
  selectedEmpresa,
  empresas,
  currentUser,
  onRefresh,
}) => {
  // Filtra apenas empresas cujo regime é MEI
  const empresasMei = useMemo(
    () => empresas.filter((e) => e.regimeTributario === 'MEI'),
    [empresas]
  );

  // Estado da empresa selecionada (prioriza a ativa se for MEI, senão a primeira MEI)
  const [activeEmpresaId, setActiveEmpresaId] = useState<string>(() => {
    if (selectedEmpresa && selectedEmpresa.regimeTributario === 'MEI') {
      return selectedEmpresa.id;
    }
    return empresasMei.length > 0 ? empresasMei[0].id : '';
  });

  // Atualiza se a prop externa mudar para uma MEI
  useEffect(() => {
    if (selectedEmpresa && selectedEmpresa.regimeTributario === 'MEI') {
      setActiveEmpresaId(selectedEmpresa.id);
    }
  }, [selectedEmpresa]);

  const activeEmpresa = useMemo(() => {
    return empresas.find((e) => e.id === activeEmpresaId);
  }, [empresas, activeEmpresaId]);

  // Ano de apuração e controle
  const currentYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState<number>(currentYear);

  // Abas da tela: 'faturamento_limites' | 'pgmei_guias' | 'dasn_anual'
  const [activeTab, setActiveTab] = useState<'faturamento_limites' | 'pgmei_guias' | 'dasn_anual'>(
    'faturamento_limites'
  );

  // Estados de dados da API
  const [loading, setLoading] = useState<boolean>(false);
  const [resumo, setResumo] = useState<ResumoFaturamentoMei | null>(null);
  const [guias, setGuias] = useState<GuiaDasMei[]>([]);
  const [declaracoes, setDeclaracoes] = useState<DeclaracaoAnualMei[]>([]);

  // Modais
  const [guiaImpressao, setGuiaImpressao] = useState<GuiaDasMei | null>(null);
  const [modalNovaDasn, setModalNovaDasn] = useState<boolean>(false);
  const [declaracaoVisualizacao, setDeclaracaoVisualizacao] = useState<DeclaracaoAnualMei | null>(null);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Formulário Nova DASN
  const [novaDasnAno, setNovaDasnAno] = useState<number>(currentYear - 1);
  const [novaDasnEmpregado, setNovaDasnEmpregado] = useState<boolean>(false);
  const [novaDasnTipo, setNovaDasnTipo] = useState<'original' | 'retificadora'>('original');
  const [rascunhoDasnCalculada, setRascunhoDasnCalculada] = useState<DeclaracaoAnualMei | null>(null);
  const [submittingDasn, setSubmittingDasn] = useState<boolean>(false);

  // Carrega dados da empresa e ano selecionados
  const carregarDados = async () => {
    if (!activeEmpresaId) return;
    setLoading(true);
    try {
      // 1. Resumo de faturamento e limites
      const resResumo = await fetch(`/api/mei/resumo/${activeEmpresaId}/${selectedYear}`);
      if (resResumo.ok) {
        const dataResumo = await resResumo.json();
        setResumo(dataResumo);
      }

      // 2. Guias DAS-MEI (PGMEI)
      const resGuias = await fetch(`/api/mei/guias/${activeEmpresaId}/${selectedYear}`);
      if (resGuias.ok) {
        const dataGuias = await resGuias.json();
        setGuias(dataGuias);
      }

      // 3. Declarações anuais (DASN-SIMEI)
      const resDecl = await fetch(`/api/mei/declaracoes?empresaId=${activeEmpresaId}`);
      if (resDecl.ok) {
        const dataDecl = await resDecl.json();
        setDeclaracoes(dataDecl);
      }
    } catch (err) {
      console.error('Erro ao carregar dados do MEI:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregarDados();
  }, [activeEmpresaId, selectedYear]);

  // Alterna status de pagamento da guia
  const handleTogglePagamentoGuia = async (guia: GuiaDasMei) => {
    try {
      const novoStatusPago = guia.status !== 'pago';
      const res = await fetch(`/api/mei/guias/${guia.id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pago: novoStatusPago,
          dataPagamento: novoStatusPago ? new Date().toISOString() : undefined,
        }),
      });
      if (res.ok) {
        const guiaAtualizada = await res.json();
        setGuias((prev) => prev.map((g) => (g.id === guia.id ? guiaAtualizada : g)));
      }
    } catch (err) {
      console.error('Erro ao atualizar guia:', err);
    }
  };

  // Prepara rascunho de DASN-SIMEI
  const handlePrepararDasn = async () => {
    if (!activeEmpresaId) return;
    setSubmittingDasn(true);
    try {
      const res = await fetch('/api/mei/declaracoes/preparar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          empresaId: activeEmpresaId,
          anoCalendario: novaDasnAno,
          possuiuEmpregado: novaDasnEmpregado,
          tipoDeclaracao: novaDasnTipo,
        }),
      });
      if (res.ok) {
        const calculada = await res.json();
        setRascunhoDasnCalculada(calculada);
      }
    } catch (err) {
      console.error('Erro ao preparar DASN-SIMEI:', err);
    } finally {
      setSubmittingDasn(false);
    }
  };

  // Salva rascunho ou transmite a DASN
  const handleSalvarOuTransmitirDasn = async (transmitirImediatamente: boolean) => {
    if (!rascunhoDasnCalculada) return;
    setSubmittingDasn(true);
    try {
      // 1. Salva no banco
      const resSalva = await fetch('/api/mei/declaracoes/salvar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(rascunhoDasnCalculada),
      });

      if (!resSalva.ok) throw new Error('Falha ao salvar declaração.');
      const salva = await resSalva.json();

      if (transmitirImediatamente) {
        const resTrans = await fetch(`/api/mei/declaracoes/transmitir/${salva.id}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            usuarioNome: currentUser?.nome || 'Carlos Eduardo Silveira',
          }),
        });
        if (resTrans.ok) {
          const resultado = await resTrans.json();
          setDeclaracaoVisualizacao(resultado.declaracao);
        }
      }

      setModalNovaDasn(false);
      setRascunhoDasnCalculada(null);
      await carregarDados();
      if (onRefresh) onRefresh();
    } catch (err) {
      console.error('Erro ao salvar/transmitir declaração:', err);
    } finally {
      setSubmittingDasn(false);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2500);
  };

  const formatCurrency = (val?: number) => {
    return (val || 0).toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    });
  };

  const formatDate = (isoStr?: string) => {
    if (!isoStr) return '-';
    try {
      const parts = isoStr.slice(0, 10).split('-');
      if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
      return isoStr;
    } catch {
      return isoStr;
    }
  };

  // SE NÃO HOUVER EMPRESAS MEI CADASTRADAS
  if (empresasMei.length === 0) {
    return (
      <div className="p-8 max-w-5xl mx-auto text-center">
        <div className="w-16 h-16 bg-amber-100 dark:bg-amber-950/50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Store className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100">
          Nenhuma Empresa com Regime MEI Encontrada
        </h2>
        <p className="text-slate-600 dark:text-slate-400 mt-2 max-w-md mx-auto">
          Para acessar o fechamento, PGMEI e Declaração Anual (DASN-SIMEI), altere o regime tributário de uma empresa para <strong>MEI</strong> no módulo de Empresas.
        </p>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* CABEÇALHO DO MÓDULO */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-xl">
            <Store className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-slate-900 dark:text-white">
                Gestão & Fechamento MEI
              </h1>
              <span className="px-2 py-0.5 text-xs font-semibold bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-200 rounded-full border border-amber-300 dark:border-amber-700">
                SIMEI / PGMEI
              </span>
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400">
              Controle de faturamento, monitoramento de limites, emissão de guias DAS-MEI e Declaração Anual (DASN-SIMEI).
            </p>
          </div>
        </div>

        {/* CONTROLES: SELETOR DE EMPRESA MEI & ANO */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-900/50 p-1.5 rounded-lg border border-slate-200 dark:border-slate-700">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400 pl-2">MEI:</span>
            <select
              value={activeEmpresaId}
              onChange={(e) => setActiveEmpresaId(e.target.value)}
              className="bg-transparent text-sm font-semibold text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer pr-2"
            >
              {empresasMei.map((emp) => (
                <option key={emp.id} value={emp.id} className="bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200">
                  {emp.nomeFantasia || emp.razaoSocial} ({emp.cnpj})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-900/50 p-1.5 rounded-lg border border-slate-200 dark:border-slate-700">
            <Calendar className="w-4 h-4 text-slate-400 ml-2" />
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(parseInt(e.target.value, 10))}
              className="bg-transparent text-sm font-semibold text-slate-800 dark:text-slate-200 focus:outline-none cursor-pointer pr-2"
            >
              <option value={2026} className="bg-white dark:bg-slate-800">Ano 2026</option>
              <option value={2025} className="bg-white dark:bg-slate-800">Ano 2025</option>
              <option value={2024} className="bg-white dark:bg-slate-800">Ano 2024</option>
            </select>
          </div>

          <button
            onClick={carregarDados}
            disabled={loading}
            title="Atualizar dados"
            className="p-2 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-amber-500' : ''}`} />
          </button>
        </div>
      </div>

      {/* CARD DE DETALHES DA EMPRESA MEI ATIVA */}
      {activeEmpresa && (
        <div className="bg-gradient-to-r from-amber-500/5 via-slate-50 to-transparent dark:from-amber-950/20 dark:via-slate-800/40 dark:to-slate-800/10 p-4 rounded-xl border border-amber-200/60 dark:border-amber-900/40 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-500 text-white flex items-center justify-center font-bold text-sm shadow-sm">
              MEI
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-900 dark:text-white">
                  {activeEmpresa.razaoSocial}
                </span>
                <span className="px-2 py-0.5 text-xs rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-medium">
                  {activeEmpresa.status.toUpperCase()}
                </span>
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 flex flex-wrap items-center gap-3 mt-0.5">
                <span>CNPJ: {activeEmpresa.cnpj}</span>
                <span>•</span>
                <span>
                  Atividade:{' '}
                  <strong className="text-slate-700 dark:text-slate-300 uppercase">
                    {activeEmpresa.tipoAtividadeMei === 'comercio'
                      ? 'Comércio (ICMS R$ 1,00)'
                      : activeEmpresa.tipoAtividadeMei === 'servicos'
                      ? 'Serviços (ISS R$ 5,00)'
                      : activeEmpresa.tipoAtividadeMei === 'comercio_e_servicos'
                      ? 'Comércio e Serviços (ICMS R$ 1 + ISS R$ 5)'
                      : 'Transporte Autônomo / Caminhoneiro'}
                  </strong>
                </span>
                <span>•</span>
                <span>
                  Funcionários: {activeEmpresa.qtdeFuncionarios > 0 ? '1 Registrado' : 'Nenhum'}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <div className="text-right">
              <div className="text-slate-400 dark:text-slate-500">Salário Mínimo Vigente</div>
              <div className="font-semibold text-slate-800 dark:text-slate-200">
                {formatCurrency(SALARIO_MINIMO_VIGENTE)}
              </div>
            </div>
            <div className="h-7 w-px bg-slate-200 dark:bg-slate-700" />
            <div className="text-right">
              <div className="text-slate-400 dark:text-slate-500">DAS-MEI Mensal Fixo</div>
              <div className="font-bold text-amber-600 dark:text-amber-400">
                {activeEmpresa.tipoAtividadeMei === 'comercio'
                  ? 'R$ 76,90'
                  : activeEmpresa.tipoAtividadeMei === 'servicos'
                  ? 'R$ 80,90'
                  : activeEmpresa.tipoAtividadeMei === 'comercio_e_servicos'
                  ? 'R$ 81,90'
                  : 'R$ 188,16'}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ABAS DE NAVEGAÇÃO */}
      <div className="flex border-b border-slate-200 dark:border-slate-700 gap-2">
        <button
          onClick={() => setActiveTab('faturamento_limites')}
          className={`flex items-center gap-2 pb-3 px-3 font-medium text-sm border-b-2 transition-all ${
            activeTab === 'faturamento_limites'
              ? 'border-amber-500 text-amber-600 dark:text-amber-400 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          Faturamento & Termômetro de Limites
        </button>

        <button
          onClick={() => setActiveTab('pgmei_guias')}
          className={`flex items-center gap-2 pb-3 px-3 font-medium text-sm border-b-2 transition-all ${
            activeTab === 'pgmei_guias'
              ? 'border-amber-500 text-amber-600 dark:text-amber-400 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300'
          }`}
        >
          <Receipt className="w-4 h-4" />
          PGMEI (Guias DAS-MEI Mensais)
          <span className="ml-1 px-2 py-0.2 text-xs rounded-full bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
            {guias.filter((g) => g.status === 'pago').length}/{guias.length} Pagas
          </span>
        </button>

        <button
          onClick={() => setActiveTab('dasn_anual')}
          className={`flex items-center gap-2 pb-3 px-3 font-medium text-sm border-b-2 transition-all ${
            activeTab === 'dasn_anual'
              ? 'border-amber-500 text-amber-600 dark:text-amber-400 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          Declaração Anual (DASN-SIMEI)
          {declaracoes.length > 0 && (
            <span className="ml-1 px-1.5 py-0.5 text-xs rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 font-bold">
              {declaracoes.length}
            </span>
          )}
        </button>
      </div>

      {/* ========================================================================= */}
      {/* ABA 1: FATURAMENTO & LIMITES (TERMÔMETRO & BREAKDOWN)                     */}
      {/* ========================================================================= */}
      {activeTab === 'faturamento_limites' && (
        <div className="space-y-6">
          {/* CARDS DE INDICADORES PRINCIPAIS */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* 1. Limite Anual Proporcional */}
            <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
                <span className="text-xs font-medium uppercase tracking-wider">Limite Anual MEI</span>
                <ShieldCheck className="w-4 h-4 text-slate-400" />
              </div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white">
                {formatCurrency(resumo?.limiteAnual || LIMITE_ANUAL_MEI_PADRAO)}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Ref. R$ 6.750,00/mês {resumo?.mesesAtividadeNoAno && resumo.mesesAtividadeNoAno < 12 ? `(${resumo.mesesAtividadeNoAno} meses de atividade)` : '(12 meses completos)'}
              </div>
            </div>

            {/* 2. Faturamento Acumulado no Ano */}
            <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
                <span className="text-xs font-medium uppercase tracking-wider">Receita Bruta Acumulada</span>
                <DollarSign className="w-4 h-4 text-amber-500" />
              </div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white">
                {formatCurrency(resumo?.totalFaturadoAno || 0)}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 flex items-center justify-between">
                <span>Comércio: {formatCurrency(resumo?.totalComercioAno || 0)}</span>
                <span>Serviços: {formatCurrency(resumo?.totalServicosAno || 0)}</span>
              </div>
            </div>

            {/* 3. Saldo Restante até o Limite */}
            <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
                <span className="text-xs font-medium uppercase tracking-wider">Saldo até o Teto</span>
                <Percent className="w-4 h-4 text-emerald-500" />
              </div>
              <div
                className={`text-2xl font-bold ${
                  (resumo?.saldoRestante || 0) > 0
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                {formatCurrency(resumo?.saldoRestante || 0)}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                {(resumo?.percentualAtingido || 0).toFixed(1)}% do teto atingido
              </div>
            </div>

            {/* 4. Limite de Compras (Art. 18-A LC 123/2006) */}
            <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
                <span className="text-xs font-medium uppercase tracking-wider">Compras no Ano (DF-e)</span>
                <CreditCard className="w-4 h-4 text-indigo-500" />
              </div>
              <div className="text-2xl font-bold text-slate-900 dark:text-white">
                {formatCurrency(resumo?.totalComprasAno || 0)}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1">
                {resumo?.alertaCompras ? (
                  <span className="text-rose-600 font-semibold flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" /> Excede 80% das receitas!
                  </span>
                ) : (
                  <span className="text-emerald-600 font-medium flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Dentro do limite legal de 80%
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* BARRA DO TERMÔMETRO DE ENQUADRAMENTO */}
          <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  Termômetro de Enquadramento MEI ({selectedYear})
                  <span
                    className={`px-2 py-0.5 text-xs font-bold rounded-full ${
                      resumo?.situacaoLimite === 'normal'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : resumo?.situacaoLimite === 'alerta_80'
                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        : resumo?.situacaoLimite === 'excesso_ate_20'
                        ? 'bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300'
                        : 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                    }`}
                  >
                    {resumo?.situacaoLimite === 'normal' && 'SITUAÇÃO NORMAL'}
                    {resumo?.situacaoLimite === 'alerta_80' && 'ATENÇÃO: > 80% DO TETO'}
                    {resumo?.situacaoLimite === 'excesso_ate_20' && 'EXCESSO DE ATÉ 20% (DESENQUADRAMENTO PRÓXIMO ANO)'}
                    {resumo?.situacaoLimite === 'excesso_acima_20' && 'EXCESSO GRAVE > 20% (DESENQUADRAMENTO RETROATIVO)'}
                  </span>
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Artigos 18-A e 18-C da LC nº 123/2006. Faturamento acumulado de {formatCurrency(resumo?.totalFaturadoAno)} em relação ao teto de {formatCurrency(resumo?.limiteAnual)}.
                </p>
              </div>
              <div className="text-right">
                <span className="text-xl font-extrabold text-slate-900 dark:text-white">
                  {(resumo?.percentualAtingido || 0).toFixed(1)}%
                </span>
                <span className="text-xs text-slate-400 dark:text-slate-500 block">do teto utilizado</span>
              </div>
            </div>

            {/* Barra de progresso customizada */}
            <div className="space-y-1.5">
              <div className="w-full h-4 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden p-0.5 flex">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    (resumo?.percentualAtingido || 0) <= 80
                      ? 'bg-emerald-500'
                      : (resumo?.percentualAtingido || 0) <= 100
                      ? 'bg-amber-500'
                      : (resumo?.percentualAtingido || 0) <= 120
                      ? 'bg-orange-500'
                      : 'bg-rose-600'
                  }`}
                  style={{ width: `${Math.min(resumo?.percentualAtingido || 0, 100)}%` }}
                />
              </div>

              {/* Marcadores de régua */}
              <div className="flex justify-between text-[11px] text-slate-400 dark:text-slate-500 px-1">
                <span>R$ 0,00 (0%)</span>
                <span>R$ 64.800 (80% - Faixa de Alerta)</span>
                <span className="font-bold text-slate-700 dark:text-slate-300">R$ 81.000 (100% - Teto MEI)</span>
                <span className="text-rose-500">R$ 97.200 (120% - Limite Máx.)</span>
              </div>
            </div>

            {/* BOX DE ALERTA DE EXCESSO QUANDO APLICÁVEL */}
            {resumo && resumo.excedeuLimite && (
              <div className="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-lg flex items-start gap-3 text-rose-800 dark:text-rose-200 text-sm">
                <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold">Atenção: Limite Anual do MEI Ultrapassado!</div>
                  <p className="text-xs text-rose-700 dark:text-rose-300 mt-1 leading-relaxed">
                    A empresa faturou <strong>{formatCurrency(resumo.totalFaturadoAno)}</strong>, excedendo o teto legal em <strong>{formatCurrency(resumo.valorExcedente)}</strong> (+{resumo.percentualExcesso.toFixed(2)}%).
                    {resumo.situacaoLimite === 'excesso_ate_20' ? (
                      <span> A empresa permanecerá recolhendo o DAS-MEI normalmente até 31/12 e deverá recolher o DAS complementar sobre o excedente na Declaração Anual (DASN-SIMEI), sendo desenquadrada do MEI a partir de 01/01 do ano subsequente.</span>
                    ) : (
                      <span> O excesso superou 20%, o que acarreta o <strong>desenquadramento retroativo imediato</strong> a 01/01 deste ano-calendário, passando a apurar pelas tabelas dos Anexos do Simples Nacional com juros e multas de mora.</span>
                    )}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* TABELA DE FATURAMENTO MENSAL (12 MESES) */}
          <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm">
                  Demonstrativo Mensal de Receitas Brutas ({selectedYear})
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Valores apurados automaticamente a partir das notas fiscais e cupons fiscais emitidos.
                </p>
              </div>
              <div className="text-xs text-slate-500 bg-slate-100 dark:bg-slate-700 px-2.5 py-1 rounded-md">
                12 Meses
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 dark:bg-slate-900/50 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  <tr>
                    <th className="py-3 px-4">Mês / Competência</th>
                    <th className="py-3 px-4 text-right">Comércio (Vendas)</th>
                    <th className="py-3 px-4 text-right">Serviços Prestados</th>
                    <th className="py-3 px-4 text-right">Receita Total Mês</th>
                    <th className="py-3 px-4 text-right">Compras (NF-e Entrada)</th>
                    <th className="py-3 px-4 text-center">Teto Médio (R$ 6.750)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {resumo?.detalheMeses.map((m) => {
                    const excedeuMes = m.total > LIMITE_MENSAL_MEI;
                    return (
                      <tr key={m.mes} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
                        <td className="py-3 px-4 font-medium text-slate-800 dark:text-slate-200">
                          {String(m.mes).padStart(2, '0')} - {NOMES_MESES[m.mes - 1]}
                        </td>
                        <td className="py-3 px-4 text-right text-slate-600 dark:text-slate-300">
                          {formatCurrency(m.comercio)}
                        </td>
                        <td className="py-3 px-4 text-right text-slate-600 dark:text-slate-300">
                          {formatCurrency(m.servicos)}
                        </td>
                        <td className="py-3 px-4 text-right font-bold text-slate-900 dark:text-white">
                          {formatCurrency(m.total)}
                        </td>
                        <td className="py-3 px-4 text-right text-slate-500 dark:text-slate-400">
                          {formatCurrency(m.compras)}
                        </td>
                        <td className="py-3 px-4 text-center">
                          {m.total === 0 ? (
                            <span className="text-xs text-slate-400">-</span>
                          ) : excedeuMes ? (
                            <span className="inline-flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400 font-medium">
                              <AlertTriangle className="w-3 h-3" /> Acima da média
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                              <Check className="w-3 h-3" /> Normal
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot className="bg-slate-50 dark:bg-slate-900/60 font-bold text-slate-900 dark:text-white border-t border-slate-200 dark:border-slate-700">
                  <tr>
                    <td className="py-3 px-4">TOTAL ANUAL ({selectedYear})</td>
                    <td className="py-3 px-4 text-right">{formatCurrency(resumo?.totalComercioAno)}</td>
                    <td className="py-3 px-4 text-right">{formatCurrency(resumo?.totalServicosAno)}</td>
                    <td className="py-3 px-4 text-right text-amber-600 dark:text-amber-400 text-base">
                      {formatCurrency(resumo?.totalFaturadoAno)}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-700 dark:text-slate-300">
                      {formatCurrency(resumo?.totalComprasAno)}
                    </td>
                    <td className="py-3 px-4 text-center text-xs text-slate-500">
                      Teto: {formatCurrency(resumo?.limiteAnual)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ABA 2: PGMEI (GUIAS DAS-MEI MENSAIS E IMPRESSÃO)                         */}
      {/* ========================================================================= */}
      {activeTab === 'pgmei_guias' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="font-bold text-slate-800 dark:text-slate-100 text-base flex items-center gap-2">
                <Receipt className="w-5 h-5 text-amber-500" />
                Programa Gerador do DAS para o MEI (PGMEI) - {selectedYear}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Grade de recolhimento das 12 guias mensais com código de barras, linha digitável e PIX oficial.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 dark:text-slate-400">
                Vencimento oficial: todo dia 20 (ou próximo dia útil).
              </span>
            </div>
          </div>

          {/* TABELA DAS 12 GUIAS */}
          <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-50 dark:bg-slate-900/50 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  <tr>
                    <th className="py-3.5 px-4">Competência</th>
                    <th className="py-3.5 px-4">Vencimento</th>
                    <th className="py-3.5 px-4 text-right">INSS (5%/12%)</th>
                    <th className="py-3.5 px-4 text-right">ICMS (Est.)</th>
                    <th className="py-3.5 px-4 text-right">ISS (Mun.)</th>
                    <th className="py-3.5 px-4 text-right">Valor Total</th>
                    <th className="py-3.5 px-4 text-center">Status</th>
                    <th className="py-3.5 px-4 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {guias.map((guia) => (
                    <tr
                      key={guia.id}
                      className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors"
                    >
                      <td className="py-3.5 px-4 font-bold text-slate-800 dark:text-slate-200">
                        {guia.competencia}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                        {formatDate(guia.dataVencimento)}
                      </td>
                      <td className="py-3.5 px-4 text-right text-slate-600 dark:text-slate-300">
                        {formatCurrency(guia.valorInss)}
                      </td>
                      <td className="py-3.5 px-4 text-right text-slate-600 dark:text-slate-300">
                        {formatCurrency(guia.valorIcms)}
                      </td>
                      <td className="py-3.5 px-4 text-right text-slate-600 dark:text-slate-300">
                        {formatCurrency(guia.valorIss)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-extrabold text-slate-900 dark:text-white">
                        {formatCurrency(guia.valorTotal)}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        {guia.status === 'pago' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Pago
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                            <Clock className="w-3.5 h-3.5" /> A Pagar
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleTogglePagamentoGuia(guia)}
                            title={guia.status === 'pago' ? 'Marcar como não paga' : 'Confirmar pagamento'}
                            className={`px-2.5 py-1 text-xs font-medium rounded transition-colors ${
                              guia.status === 'pago'
                                ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-700 dark:hover:bg-slate-600 dark:text-slate-200'
                                : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:hover:bg-emerald-900 dark:text-emerald-300'
                            }`}
                          >
                            {guia.status === 'pago' ? 'Desmarcar' : 'Dar Baixa'}
                          </button>

                          <button
                            onClick={() => setGuiaImpressao(guia)}
                            className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded text-xs font-semibold shadow-sm transition-colors"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            Imprimir DAS-MEI
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ABA 3: DECLARAÇÃO ANUAL DO MEI (DASN-SIMEI)                                */}
      {/* ========================================================================= */}
      {activeTab === 'dasn_anual' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900 dark:text-white">
                  DASN-SIMEI - Declaração Anual Simplificada para o MEI
                </h2>
                <span className="px-2 py-0.5 text-xs font-semibold rounded bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                  Prazo: 31 de Maio
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Apresentação obrigatória da receita bruta anual auferida no ano-calendário anterior e informação sobre empregado contratado.
              </p>
            </div>

            <button
              onClick={() => {
                setRascunhoDasnCalculada(null);
                setModalNovaDasn(true);
              }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-sm font-semibold shadow-sm transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              Fazer Apuração / Nova DASN-SIMEI
            </button>
          </div>

          {/* LISTA DE DECLARAÇÕES TRANSMITIDAS E RASCUNHOS */}
          <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-700">
              <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100">
                Histórico de Declarações Anuais
              </h3>
            </div>

            {declaracoes.length === 0 ? (
              <div className="p-10 text-center text-slate-400">
                <FileCheck className="w-10 h-10 mx-auto mb-2 opacity-50" />
                <p className="text-sm font-medium">Nenhuma Declaração Anual transmitida ainda.</p>
                <p className="text-xs mt-1">
                  Clique no botão acima para apurar os faturamentos do ano e gerar a DASN-SIMEI.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 dark:bg-slate-900/50 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Ano-Calendário</th>
                      <th className="py-3 px-4">Tipo</th>
                      <th className="py-3 px-4 text-right">Rec. Bruta Comércio</th>
                      <th className="py-3 px-4 text-right">Rec. Bruta Serviços</th>
                      <th className="py-3 px-4 text-right">Receita Total</th>
                      <th className="py-3 px-4 text-center">Empregado?</th>
                      <th className="py-3 px-4 text-center">Status</th>
                      <th className="py-3 px-4 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {declaracoes.map((decl) => (
                      <tr key={decl.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
                        <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white">
                          {decl.anoCalendario}
                        </td>
                        <td className="py-3.5 px-4 capitalize text-slate-600 dark:text-slate-300">
                          {decl.tipoDeclaracao}
                        </td>
                        <td className="py-3.5 px-4 text-right text-slate-600 dark:text-slate-300">
                          {formatCurrency(decl.receitaBrutaComercio)}
                        </td>
                        <td className="py-3.5 px-4 text-right text-slate-600 dark:text-slate-300">
                          {formatCurrency(decl.receitaBrutaServicos)}
                        </td>
                        <td className="py-3.5 px-4 text-right font-extrabold text-amber-600 dark:text-amber-400">
                          {formatCurrency(decl.receitaBrutaTotal)}
                        </td>
                        <td className="py-3.5 px-4 text-center text-xs">
                          {decl.possuiuEmpregado ? (
                            <span className="text-indigo-600 font-semibold">Sim (1)</span>
                          ) : (
                            <span className="text-slate-400">Não</span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          {decl.status === 'transmitida' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs font-bold rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Transmitida
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs font-semibold rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                              <Clock className="w-3.5 h-3.5" /> Rascunho
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <button
                            onClick={() => setDeclaracaoVisualizacao(decl)}
                            className="inline-flex items-center gap-1 px-3 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 text-xs font-medium rounded transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            Ver Recibo Oficial
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: IMPRESSÃO DA GUIA DAS-MEI (LAYOUT OFICIAL RECEITA FEDERAL)       */}
      {/* ========================================================================= */}
      {guiaImpressao && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white text-slate-900 w-full max-w-3xl rounded-xl shadow-2xl overflow-hidden my-8">
            {/* BARRA DE AÇÕES DO MODAL */}
            <div className="bg-slate-800 text-white px-6 py-3.5 flex items-center justify-between print:hidden">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-amber-400" />
                <span className="font-semibold text-sm">
                  Espelho da Guia de Arrecadação DAS-MEI ({guiaImpressao.competencia})
                </span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded text-xs font-bold shadow transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Imprimir Documento
                </button>
                <button
                  onClick={() => setGuiaImpressao(null)}
                  className="p-1 hover:bg-slate-700 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* DOCUMENTO OFICIAL DAS-MEI (ESTILO RECEITA FEDERAL) */}
            <div className="p-8 space-y-6 text-xs font-mono select-text bg-white">
              {/* CABEÇALHO OFICIAL */}
              <div className="border-2 border-slate-900 p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 border-2 border-slate-900 rounded-full flex items-center justify-center font-bold text-sm bg-slate-100">
                    RFB
                  </div>
                  <div>
                    <h4 className="font-bold text-sm uppercase tracking-wide">
                      Ministério da Fazenda - Secretaria Especial da Receita Federal do Brasil
                    </h4>
                    <h5 className="font-extrabold text-base text-slate-950">
                      DAS - DOCUMENTO DE ARRECADAÇÃO DO SIMPLES NACIONAL (MEI)
                    </h5>
                    <p className="text-[11px] text-slate-600">
                      PGMEI - Programa Gerador do DAS para o Microempreendedor Individual
                    </p>
                  </div>
                </div>
                <div className="text-right border-l-2 border-slate-900 pl-4">
                  <div className="text-[10px] text-slate-500 uppercase">Período de Apuração</div>
                  <div className="text-base font-bold">{guiaImpressao.competencia}</div>
                  <div className="text-[10px] text-slate-500 uppercase mt-1">Data de Vencimento</div>
                  <div className="text-base font-extrabold text-slate-950">
                    {formatDate(guiaImpressao.dataVencimento)}
                  </div>
                </div>
              </div>

              {/* DADOS DO CONTRIBUINTE */}
              <div className="grid grid-cols-3 gap-2 border-2 border-slate-900 p-3">
                <div className="col-span-2">
                  <div className="text-[10px] text-slate-500 uppercase">Razão Social / Nome Empresarial</div>
                  <div className="font-bold text-sm">{activeEmpresa?.razaoSocial}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">CNPJ</div>
                  <div className="font-bold text-sm">{activeEmpresa?.cnpj}</div>
                </div>
                <div className="col-span-2">
                  <div className="text-[10px] text-slate-500 uppercase">Número do Documento</div>
                  <div className="font-semibold">{guiaImpressao.numeroDocumento || 'DASMEI-2026-OFICIAL'}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">Valor Total do Documento</div>
                  <div className="text-lg font-extrabold text-slate-950">
                    {formatCurrency(guiaImpressao.valorTotal)}
                  </div>
                </div>
              </div>

              {/* COMPOSIÇÃO DOS TRIBUTOS */}
              <div className="border-2 border-slate-900 overflow-hidden">
                <div className="bg-slate-100 font-bold px-3 py-1.5 border-b border-slate-900 text-[11px]">
                  DISCRIMINAÇÃO DOS TRIBUTOS ARRECADADOS NESTA GUIA
                </div>
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-900 bg-slate-50 font-semibold">
                    <tr>
                      <th className="p-2">Tributo</th>
                      <th className="p-2">Ente Federativo</th>
                      <th className="p-2">Alíquota / Valor Fixo</th>
                      <th className="p-2 text-right">Valor Apurado</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    <tr>
                      <td className="p-2 font-bold">INSS / Previdência Social</td>
                      <td className="p-2">União Federal</td>
                      <td className="p-2">5% do Salário Mínimo (R$ 1.518,00)</td>
                      <td className="p-2 text-right font-bold">{formatCurrency(guiaImpressao.valorInss)}</td>
                    </tr>
                    <tr>
                      <td className="p-2 font-bold">ICMS</td>
                      <td className="p-2">Governo Estadual</td>
                      <td className="p-2">Fixo R$ 1,00 (Comércio e Indústria)</td>
                      <td className="p-2 text-right font-bold">{formatCurrency(guiaImpressao.valorIcms)}</td>
                    </tr>
                    <tr>
                      <td className="p-2 font-bold">ISSQN</td>
                      <td className="p-2">Prefeitura Municipal</td>
                      <td className="p-2">Fixo R$ 5,00 (Prestadores de Serviços)</td>
                      <td className="p-2 text-right font-bold">{formatCurrency(guiaImpressao.valorIss)}</td>
                    </tr>
                  </tbody>
                  <tfoot className="border-t-2 border-slate-900 font-extrabold bg-slate-50">
                    <tr>
                      <td colSpan={3} className="p-2 text-right">TOTAL A PAGAR:</td>
                      <td className="p-2 text-right text-sm">{formatCurrency(guiaImpressao.valorTotal)}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* PIX E CÓDIGO DE BARRAS */}
              <div className="border-2 border-slate-900 p-4 flex flex-col md:flex-row items-center gap-6">
                <div className="flex flex-col items-center justify-center p-3 bg-slate-50 border border-slate-300 rounded shrink-0">
                  <div className="w-28 h-28 bg-white border border-slate-400 p-1 flex items-center justify-center">
                    <QrCode className="w-24 h-24 text-slate-900" />
                  </div>
                  <span className="text-[10px] font-bold text-slate-700 mt-1">PAGUE COM PIX</span>
                </div>

                <div className="flex-1 space-y-3 w-full">
                  <div>
                    <div className="text-[10px] text-slate-500 uppercase font-semibold">Linha Digitável</div>
                    <div className="p-2 bg-slate-100 border border-slate-300 rounded text-xs font-bold text-slate-900 break-all flex items-center justify-between">
                      <span>{guiaImpressao.linhaDigitavel}</span>
                      <button
                        onClick={() => copyToClipboard(guiaImpressao.linhaDigitavel || '', 'linha')}
                        className="ml-2 text-amber-600 hover:text-amber-800 text-[11px] flex items-center gap-1 shrink-0 print:hidden"
                      >
                        {copiedText === 'linha' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        Copiar
                      </button>
                    </div>
                  </div>

                  <div>
                    <div className="text-[10px] text-slate-500 uppercase font-semibold">Código Copia e Cola (PIX)</div>
                    <div className="p-2 bg-slate-100 border border-slate-300 rounded text-[11px] text-slate-700 truncate flex items-center justify-between">
                      <span className="truncate">{guiaImpressao.pixQrCodePayload}</span>
                      <button
                        onClick={() => copyToClipboard(guiaImpressao.pixQrCodePayload || '', 'pix')}
                        className="ml-2 text-amber-600 hover:text-amber-800 text-[11px] flex items-center gap-1 shrink-0 print:hidden"
                      >
                        {copiedText === 'pix' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        Copiar
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* CÓDIGO DE BARRAS GRÁFICO (REPRESENTAÇÃO VISUAL) */}
              <div className="pt-2 text-center">
                <div className="h-10 bg-slate-900 flex items-stretch justify-center gap-0.5 px-4 overflow-hidden">
                  {Array.from({ length: 95 }).map((_, i) => (
                    <div
                      key={i}
                      className={`h-full ${i % 3 === 0 ? 'w-1 bg-white' : i % 5 === 0 ? 'w-2 bg-slate-900' : 'w-0.5 bg-white'}`}
                    />
                  ))}
                </div>
                <div className="text-[10px] text-slate-500 mt-1">{guiaImpressao.codigoBarras}</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: NOVA APURAÇÃO / PREPARAÇÃO DA DASN-SIMEI                         */}
      {/* ========================================================================= */}
      {modalNovaDasn && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-800 w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden my-8 border border-slate-200 dark:border-slate-700">
            <div className="p-6 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-lg text-slate-900 dark:text-white flex items-center gap-2">
                  <FileCheck className="w-5 h-5 text-amber-500" />
                  Apuração da Declaração Anual do MEI (DASN-SIMEI)
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Preenchimento dos campos obrigatórios da declaração anual com base nos registros do sistema.
                </p>
              </div>
              <button
                onClick={() => setModalNovaDasn(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5 text-sm">
              {/* PARÂMETROS DA DECLARAÇÃO */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Ano-Calendário:
                  </label>
                  <select
                    value={novaDasnAno}
                    onChange={(e) => setNovaDasnAno(parseInt(e.target.value, 10))}
                    className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-sm text-slate-800 dark:text-slate-200 font-medium"
                  >
                    <option value={2025}>2025 (Ano Anterior)</option>
                    <option value={2026}>2026 (Ano Corrente)</option>
                    <option value={2024}>2024</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Tipo de Declaração:
                  </label>
                  <select
                    value={novaDasnTipo}
                    onChange={(e) => setNovaDasnTipo(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-sm text-slate-800 dark:text-slate-200 font-medium"
                  >
                    <option value="original">Original</option>
                    <option value="retificadora">Retificadora</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Possuiu Empregado?
                  </label>
                  <select
                    value={novaDasnEmpregado ? 'sim' : 'nao'}
                    onChange={(e) => setNovaDasnEmpregado(e.target.value === 'sim')}
                    className="w-full p-2 bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-lg text-sm text-slate-800 dark:text-slate-200 font-medium"
                  >
                    <option value="nao">Não</option>
                    <option value="sim">Sim (1 funcionário registrado)</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={handlePrepararDasn}
                  disabled={submittingDasn}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 text-white rounded-lg text-xs font-bold transition-colors"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${submittingDasn ? 'animate-spin' : ''}`} />
                  Puxar e Apurar Faturamento das Notas
                </button>
              </div>

              {/* RESULTADO DA APURAÇÃO DAS NOTAS FISCAIS */}
              {rascunhoDasnCalculada && (
                <div className="border border-slate-200 dark:border-slate-700 rounded-xl p-4 bg-slate-50 dark:bg-slate-900/60 space-y-4">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-600 dark:text-slate-300">
                    Discriminação dos Valores Apurados para o Ano {rascunhoDasnCalculada.anoCalendario}
                  </h4>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-2.5 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
                      <div>
                        <div className="font-semibold text-slate-800 dark:text-slate-200">
                          1. Receita Bruta de Comércio, Indústria e Transporte
                        </div>
                        <div className="text-xs text-slate-400">Venda de mercadorias (NF-e, NFC-e)</div>
                      </div>
                      <span className="font-bold text-slate-900 dark:text-white">
                        {formatCurrency(rascunhoDasnCalculada.receitaBrutaComercio)}
                      </span>
                    </div>

                    <div className="flex justify-between items-center p-2.5 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
                      <div>
                        <div className="font-semibold text-slate-800 dark:text-slate-200">
                          2. Receita Bruta de Prestação de Serviços
                        </div>
                        <div className="text-xs text-slate-400">Serviços de qualquer natureza (NFS-e)</div>
                      </div>
                      <span className="font-bold text-slate-900 dark:text-white">
                        {formatCurrency(rascunhoDasnCalculada.receitaBrutaServicos)}
                      </span>
                    </div>

                    <div className="flex justify-between items-center p-3 bg-amber-50 dark:bg-amber-950/40 rounded-lg border border-amber-200 dark:border-amber-900/50">
                      <div>
                        <div className="font-bold text-amber-950 dark:text-amber-200">
                          3. Receita Bruta Total Auferida no Ano
                        </div>
                        <div className="text-xs text-amber-800 dark:text-amber-300">
                          Limite aplicável: {formatCurrency(rascunhoDasnCalculada.limiteAnual)}
                        </div>
                      </div>
                      <span className="text-base font-extrabold text-amber-600 dark:text-amber-400">
                        {formatCurrency(rascunhoDasnCalculada.receitaBrutaTotal)}
                      </span>
                    </div>
                  </div>

                  {/* SITUAÇÃO DE EXCESSO */}
                  {rascunhoDasnCalculada.excedeuLimite ? (
                    <div className="p-3 bg-rose-100 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-900 rounded-lg text-rose-800 dark:text-rose-200 text-xs">
                      <strong>Aviso: Faturamento excedeu o limite do MEI em {formatCurrency(rascunhoDasnCalculada.valorExcedente)}.</strong>
                      <div className="mt-1">
                        DAS Complementar Estimado sobre o excedente: <strong>{formatCurrency(rascunhoDasnCalculada.dasComplementarEstimado)}</strong>.
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 bg-emerald-100 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-900 rounded-lg text-emerald-800 dark:text-emerald-200 text-xs flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Receita bruta dentro do limite legal de R$ 81.000,00. Nenhuma guia complementar necessária.
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="p-6 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50 flex flex-wrap items-center justify-between gap-3">
              <button
                onClick={() => setModalNovaDasn(false)}
                className="px-4 py-2 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg text-xs font-semibold"
              >
                Cancelar
              </button>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => handleSalvarOuTransmitirDasn(false)}
                  disabled={!rascunhoDasnCalculada || submittingDasn}
                  className="px-4 py-2 border border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-lg text-xs font-semibold disabled:opacity-50"
                >
                  Salvar Rascunho
                </button>

                <button
                  onClick={() => handleSalvarOuTransmitirDasn(true)}
                  disabled={!rascunhoDasnCalculada || submittingDasn}
                  className="inline-flex items-center gap-2 px-5 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-xs font-bold shadow transition-colors disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  Transmitir à Receita Federal
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: RECIBO OFICIAL DE ENTREGA DA DASN-SIMEI                         */}
      {/* ========================================================================= */}
      {declaracaoVisualizacao && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white text-slate-900 w-full max-w-3xl rounded-xl shadow-2xl overflow-hidden my-8">
            <div className="bg-slate-800 text-white px-6 py-3.5 flex items-center justify-between print:hidden">
              <div className="flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-emerald-400" />
                <span className="font-semibold text-sm">
                  Recibo Oficial de Entrega da DASN-SIMEI ({declaracaoVisualizacao.anoCalendario})
                </span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-bold shadow transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Imprimir Recibo
                </button>
                <button
                  onClick={() => setDeclaracaoVisualizacao(null)}
                  className="p-1 hover:bg-slate-700 rounded text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* RECIBO OFICIAL SIMEI */}
            <div className="p-8 space-y-6 text-xs font-mono select-text bg-white">
              {/* CABEÇALHO DO RECIBO */}
              <div className="border-2 border-slate-900 p-4 text-center space-y-1">
                <div className="text-[11px] font-bold uppercase">Secretaria Especial da Receita Federal do Brasil</div>
                <div className="text-sm font-extrabold text-slate-950">
                  SIMEI - SISTEMA DE RECOLHIMENTO EM VALORES FIXOS MENSAIS DO SIMPLES NACIONAL
                </div>
                <div className="text-xs font-bold text-slate-800">
                  RECIBO DE ENTREGA DA DECLARAÇÃO ANUAL SIMPLIFICADA PARA O MEI (DASN-SIMEI)
                </div>
              </div>

              {/* IDENTIFICAÇÃO DO RECIBO */}
              <div className="grid grid-cols-2 gap-3 border-2 border-slate-900 p-3">
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">Número do Recibo de Entrega</div>
                  <div className="font-extrabold text-sm text-slate-950">
                    {declaracaoVisualizacao.reciboEntrega || 'REC-SIMEI-PENDENTE'}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">Protocolo de Transmissão</div>
                  <div className="font-bold text-sm">
                    {declaracaoVisualizacao.protocoloTransmissao || 'DASN-SIMEI-PROTOCOLO'}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">Data e Hora da Transmissão</div>
                  <div className="font-semibold">
                    {declaracaoVisualizacao.dataTransmissao
                      ? new Date(declaracaoVisualizacao.dataTransmissao).toLocaleString('pt-BR')
                      : '-'}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">Tipo de Declaração</div>
                  <div className="font-semibold uppercase">{declaracaoVisualizacao.tipoDeclaracao}</div>
                </div>
              </div>

              {/* DADOS CADASTRAIS DO MEI */}
              <div className="border-2 border-slate-900 p-3 space-y-2">
                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-2">
                    <div className="text-[10px] text-slate-500 uppercase">Nome Empresarial</div>
                    <div className="font-bold">{activeEmpresa?.razaoSocial}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500 uppercase">CNPJ</div>
                    <div className="font-bold">{activeEmpresa?.cnpj}</div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 border-t border-slate-200 pt-2">
                  <div>
                    <div className="text-[10px] text-slate-500 uppercase">Ano-Calendário Declarado</div>
                    <div className="font-bold text-sm">{declaracaoVisualizacao.anoCalendario}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500 uppercase">Possuiu Empregado?</div>
                    <div className="font-semibold">
                      {declaracaoVisualizacao.possuiuEmpregado ? 'SIM (1 Empregado)' : 'NÃO'}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500 uppercase">Situação Perante o Limite</div>
                    <div className="font-bold uppercase text-emerald-700">
                      {declaracaoVisualizacao.excedeuLimite ? 'LIMITE EXCEDIDO' : 'DENTRO DO LIMITE'}
                    </div>
                  </div>
                </div>
              </div>

              {/* DEMONSTRATIVO DE RECEITAS DECLARADAS */}
              <div className="border-2 border-slate-900 overflow-hidden">
                <div className="bg-slate-100 font-bold px-3 py-1.5 border-b border-slate-900 text-[11px]">
                  VALORES DE RECEITA BRUTA DECLARADOS À RECEITA FEDERAL
                </div>
                <table className="w-full text-left text-xs">
                  <tbody className="divide-y divide-slate-200">
                    <tr>
                      <td className="p-2.5 text-slate-700">
                        1. Receita bruta auferida com venda de mercadorias (comércio / indústria / transporte)
                      </td>
                      <td className="p-2.5 text-right font-bold">
                        {formatCurrency(declaracaoVisualizacao.receitaBrutaComercio)}
                      </td>
                    </tr>
                    <tr>
                      <td className="p-2.5 text-slate-700">
                        2. Receita bruta auferida com prestação de serviços de qualquer natureza
                      </td>
                      <td className="p-2.5 text-right font-bold">
                        {formatCurrency(declaracaoVisualizacao.receitaBrutaServicos)}
                      </td>
                    </tr>
                    <tr className="bg-slate-50 font-extrabold text-sm border-t-2 border-slate-900">
                      <td className="p-2.5">3. RECEITA BRUTA TOTAL AUFERIDA NO ANO-CALENDÁRIO</td>
                      <td className="p-2.5 text-right text-emerald-700">
                        {formatCurrency(declaracaoVisualizacao.receitaBrutaTotal)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* HASH E AUTENTICIDADE */}
              <div className="border border-slate-300 p-3 bg-slate-50 text-[10px] text-slate-600 space-y-1">
                <div>
                  <strong>Hash de Autenticidade Digital:</strong>{' '}
                  <span className="break-all font-mono">{declaracaoVisualizacao.hashAutenticidade}</span>
                </div>
                <div>
                  Declaração transmitida com base na Lei Complementar nº 123/2006. Documento comprobatório de cumprimento da obrigação acessória perante a Receita Federal do Brasil.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
