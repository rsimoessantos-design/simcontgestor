import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Search,
  X,
  ChevronRight,
  ChevronDown,
  Building2,
  FileText,
  Users,
  Calculator,
  TrendingUp,
  Printer,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  Clock,
  ArrowDownToLine,
  FileCode,
  Calendar,
  Layers,
  Database,
  Receipt,
  Download,
  Copy,
  Check,
} from 'lucide-react';

interface ManualDoUsuarioModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialSection?: 'primeiros_passos' | 'notas_fiscais' | 'rh_dp' | 'fechamento_impostos' | 'analises_contabeis';
}

type SectionKey =
  | 'primeiros_passos'
  | 'notas_fiscais'
  | 'rh_dp'
  | 'fechamento_impostos'
  | 'analises_contabeis';

interface TopicItem {
  id: string;
  titulo: string;
  descricao: string;
  passos: string[];
  dica?: string;
  legislacao?: string;
  tags: string[];
}

interface SectionData {
  key: SectionKey;
  titulo: string;
  subtitulo: string;
  icon: any;
  cor: string;
  topicos: TopicItem[];
}

const MANUAL_SECTIONS: SectionData[] = [
  {
    key: 'primeiros_passos',
    titulo: 'Primeiros Passos',
    subtitulo: 'Configurações iniciais, multi-empresas e segurança',
    icon: Building2,
    cor: 'text-indigo-600 bg-indigo-50 border-indigo-200',
    topicos: [
      {
        id: 'cadastro_empresas',
        titulo: 'Cadastro e Gestão de Empresas Clientes',
        descricao: 'Cadastre suas empresas clientes com dados completos de CNPJ, Inscrição Estadual, Inscrição Municipal, CNAE principal e enquadramento tributário.',
        passos: [
          'Acesse o menu "Empresas" na barra lateral e clique em "+ Nova Empresa".',
          'Preencha o CNPJ para consulta automática ou digite a Razão Social, Nome Fantasia e CNAE.',
          'Defina o Regime Tributário correto: Simples Nacional, Lucro Presumido, Lucro Real ou MEI.',
          'Selecione a empresa no seletor global do cabeçalho para filtrar todos os relatórios, notas e obrigações para ela.',
        ],
        dica: 'Utilize o seletor "🏢 Todas as Empresas (Visão Consolidada)" no topo para ter um panorama geral do escritório.',
        legislacao: 'Lei Complementar nº 123/2006 (Estatuto da Micro e Pequena Empresa) e Instrução Normativa RFB.',
        tags: ['empresa', 'cnpj', 'regime', 'cadastro', 'cnae', 'inicio'],
      },
      {
        id: 'certificados_digitais',
        titulo: 'Instalação e Validade de Certificados Digitais (A1 / A3)',
        descricao: 'Configure os certificados digitais modelo A1 (.PFX/.P12) para possibilitar a assinatura automática de NF-e, consulta à SEFAZ DF-e e e-CAC.',
        passos: [
          'Acesse o menu "Certificados Digitais" na barra lateral.',
          'Clique em "Novo Certificado A1" e selecione o arquivo .pfx ou .p12 do seu computador.',
          'Informe a senha privada do certificado para homologação do chaveamento criptográfico.',
          'O sistema testará a comunicação e validará a cadeia de certificados da ICP-Brasil.',
        ],
        dica: 'O sistema emite alertas automáticos 30 e 15 dias antes do vencimento do certificado digital.',
        legislacao: 'Padrão ICP-Brasil (Medida Provisória nº 2.200-2/2001).',
        tags: ['certificado', 'a1', 'a3', 'icp-brasil', 'pfx', 'seguranca', 'sefaz'],
      },
      {
        id: 'backup_seguranca',
        titulo: 'Backups Automáticos e Recuperação de Dados',
        descricao: 'Garanta a integridade contábil agendando backups periódicos dos dados e exportando cópias de segurança em JSON ou CSV.',
        passos: [
          'Acesse o menu "Banco de Dados" ou "Configurações".',
          'Defina a frequência do backup (Diário, Semanal ou Mensal) e o formato desejado (JSON ou CSV).',
          'Clique em "Executar Backup Agora" para gerar um dump imediato com cálculo de hash SHA-256 de integridade.',
          'Faça o download do arquivo gerado para armazenamento em repositório externo ou nuvem.',
        ],
        dica: 'Mantenha cópias de backup fora do ambiente de trabalho para conformidade com a LGPD e normas do CFC.',
        legislacao: 'NBC TG Geral (Conselho Federal de Contabilidade) e Lei 13.709/2018 (LGPD).',
        tags: ['backup', 'dados', 'csv', 'json', 'recuperacao', 'seguranca'],
      },
    ],
  },
  {
    key: 'notas_fiscais',
    titulo: 'Gestão de Notas Fiscais',
    subtitulo: 'Captura SEFAZ DF-e, importação de XMLs modelo 55, emissão e DANFE',
    icon: FileText,
    cor: 'text-emerald-600 bg-emerald-50 border-emerald-200',
    topicos: [
      {
        id: 'importacao_xml_saida_55',
        titulo: 'Importação de XMLs de Saída Modelo 55 (Outro ERP) para Apuração do Simples',
        descricao: 'Capture todas as notas fiscais eletrônicas de saída emitidas pelo cliente em seu próprio sistema emissor externo para poder apurar faturamento e gerar o DAS no Simples Nacional.',
        passos: [
          'No menu "Notas Fiscais (NF-e)", clique no botão "Importar XML Saída (Mod. 55)".',
          'Arraste um ou múltiplos arquivos .XML gerados pelo ERP do cliente ou selecione uma pasta inteira.',
          'O parser inteligente do ContabGest lê a chave de 44 dígitos, número, série, data de emissão, CFOPs, valor total dos produtos e destinatário.',
          'Clique em "Importar e Persistir Documentos". As notas serão gravadas com a identificação "Mod. 55 (Outro ERP)" e integradas imediatamente ao painel de faturamento e à apuração do Simples Nacional (PGDAS).',
        ],
        dica: 'Após a importação, acesse a aba "Estatísticas XMLs Saída" para conferir o total faturado no mês e os maiores clientes da empresa.',
        legislacao: 'Ajuste SINIEF 07/05 e Resolução CGSN nº 140/2018.',
        tags: ['xml', 'saida', 'modelo 55', 'outro erp', 'importar', 'simples nacional', 'nfe'],
      },
      {
        id: 'estatisticas_saida_painel',
        titulo: 'Painel Estatístico de XMLs de Saída (Recharts)',
        descricao: 'Visualize gráficos dinâmicos de faturamento acumulado, notas por mês, top 10 clientes e estimativa do Simples Nacional.',
        passos: [
          'No módulo de Notas Fiscais, acesse a aba "Estatísticas XMLs Saída".',
          'Analise o gráfico de Área/Barra com a receita bruta mês a mês para cálculo do RBT12.',
          'Consulte o ranking Top 10 Clientes por volume de faturamento com percentual de representatividade.',
          'Verifique a distribuição de CFOPs (vendas estaduais, interestaduais, remessas e devoluções).',
        ],
        dica: 'O cálculo do RBT12 exibido no painel utiliza as notas de saída acumuladas nos últimos 12 meses para projetar a alíquota efetiva do PGDAS.',
        legislacao: 'Artigo 18 da Lei Complementar nº 123/2006.',
        tags: ['estatisticas', 'recharts', 'graficos', 'faturamento', 'top 10', 'simples'],
      },
      {
        id: 'captura_sefaz_dfe',
        titulo: 'Captura Automática SEFAZ DF-e (Entradas contra CNPJ)',
        descricao: 'Monitore todas as notas fiscais emitidas contra o CNPJ da empresa cliente em âmbito nacional (integração estilo fsist / Quive).',
        passos: [
          'Acesse a aba "Captura SEFAZ DF-e (Entradas contra CNPJ)".',
          'Clique em "Sincronizar SEFAZ DF-e" para varrer os servidores da Receita e Fazendas Estaduais.',
          'Realize a Manifestação do Destinatário (Ciência da Emissão, Confirmação da Operação ou Desconhecimento).',
          'Baixe o XML completo e o DANFE com 1 clique.',
        ],
        dica: 'A Ciência da Emissão permite baixar o XML completo da nota antes mesmo da chegada física da mercadoria.',
        legislacao: 'Nota Técnica 2014/002 e Ajuste SINIEF 07/2005.',
        tags: ['sefaz', 'dfe', 'entradas', 'manifestacao', 'quive', 'fsist', 'download'],
      },
      {
        id: 'emissao_e_danfe',
        titulo: 'Emissão de NF-e e Impressão de DANFE em Lote (.PDF)',
        descricao: 'Emita notas de mercadorias ou serviços e imprima múltiplos DANFEs consolidados em um único arquivo PDF.',
        passos: [
          'Para emitir: clique em "Emitir Nova Nota Fiscal", selecione cliente, natureza de operação e itens.',
          'Para imprimir em lote: marque os checkboxes das notas desejadas na listagem.',
          'Clique em "Imprimir DANFEs (.PDF)" para abrir a impressão ou gerar o documento consolidado.',
          'Para exportar tudo para a contabilidade, use o botão "Exportar Lote .ZIP" que compacta os XMLs e gera o manifesto fiscal.',
        ],
        dica: 'Você pode filtrar as notas por período, status (autorizada/cancelada) e emitente antes de gerar o lote.',
        legislacao: 'Convênio SINIEF s/nº de 1970 e Manual de Orientação do Contribuinte (MOC).',
        tags: ['danfe', 'pdf', 'lote', 'zip', 'emissao', 'impressao', 'manifesto'],
      },
    ],
  },
  {
    key: 'rh_dp',
    titulo: 'RH e Departamento Pessoal',
    subtitulo: 'Colaboradores, Ponto REP-P, Folha, Férias, Rescisão, Turnover e eSocial',
    icon: Users,
    cor: 'text-purple-600 bg-purple-50 border-purple-200',
    topicos: [
      {
        id: 'painel_turnover_cargos',
        titulo: 'Painel de Turnover & Distribuição de Cargos por Departamento',
        descricao: 'Monitore a rotatividade de colaboradores (turnover), taxa de retenção de talentos e o headcount por área em gráficos interativos do Recharts.',
        passos: [
          'Acesse o módulo "RH & DP" e clique na aba "Turnover & Cargos por Depto".',
          'Verifique o Índice de Turnover Anual (meta ideal de mercado contábil: 5% a 15%).',
          'Analise o gráfico de evolução mensal comparando admissões, desligamentos e o saldo líquido de vagas.',
          'Consulte a distribuição de colaboradores e folha salarial por departamento (Contábil, Fiscal, Pessoal, TI).',
        ],
        dica: 'O custo de substituição de um colaborador em escritório contábil gira em torno de 1,5x a 2x o salário bruto. Monitore de perto setores com turnover superior a 20%.',
        legislacao: 'Consolidação das Leis do Trabalho (CLT) e Resolução Normativa do MTE.',
        tags: ['turnover', 'rotatividade', 'cargos', 'departamentos', 'recharts', 'rh', 'headcount'],
      },
      {
        id: 'ponto_rep_p',
        titulo: 'Ponto Eletrônico REP-P e Espelho de Ponto',
        descricao: 'Gestão de jornada de trabalho em conformidade com a Portaria 671/2021 MTE, com registro digital e espelho de ponto.',
        passos: [
          'Na aba "Ponto Eletrônico", visualize os registros diários (entrada, intervalo e saída) de cada empregado.',
          'Gere o "Espelho de Ponto" mensal com apuração automática de horas extras (50% e 100%) e banco de horas.',
          'Emita o comprovante de registro de ponto assinado digitalmente.',
        ],
        dica: 'O espelho de ponto deve ser colhido e assinado pelo colaborador até o 5º dia útil subsequente ao mês trabalhado.',
        legislacao: 'Portaria MTE nº 671/2021 (Regulamenta o Registro Eletrônico de Ponto - REP).',
        tags: ['ponto', 'rep-p', 'portaria 671', 'horas extras', 'jornada', 'espelho'],
      },
      {
        id: 'folha_e_holerites',
        titulo: 'Cálculo de Folha de Pagamento e Emissão de Holerites em Lote',
        descricao: 'Simulação e processamento de salários com tabelas progressivas de INSS e IRRF 2026, FGTS e geração de holerites em PDF.',
        passos: [
          'Acesse a aba "Folha & Simulação".',
          'Selecione a competência e verifique os proventos (salário base, adicionais, DSR) e descontos (INSS, IRRF, VT).',
          'Clique em "Calcular Folha" para consolidar os encargos patronais (INSS Patronal, RAT/FAP, Terceiros/Outras Entidades).',
          'Use o botão "Imprimir Holerites em Lote (.PDF)" para gerar todos os contracheques dos funcionários.',
        ],
        dica: 'Para empresas do Simples Nacional enquadradas no Anexo I, II, III e V, não incide a cota patronal de 20% do INSS na folha.',
        legislacao: 'Tabela de Contribuição Previdenciária e Tabela Progressiva do IRPF vigente.',
        tags: ['folha', 'holerite', 'inss', 'irrf', 'salario', 'pdf', 'proventos'],
      },
      {
        id: 'esocial_eventos',
        titulo: 'Transmissão de Eventos ao eSocial (S-1000 a S-1299)',
        descricao: 'Envio seguro dos eventos de tabela, não periódicos e periódicos para o ambiente oficial do eSocial nacional.',
        passos: [
          'Acesse a aba "eSocial & SST" para consultar o painel de mensageria.',
          'Eventos Iniciais/Tabelas: S-1000 (Empregador), S-1005 (Estabelecimentos), S-1010 (Rubricas) e S-1020 (Lotações).',
          'Eventos Não Periódicos: S-2200 (Admissão), S-2206 (Alteração Contratual), S-2230 (Afastamentos) e S-2299 (Desligamento).',
          'Eventos Periódicos: S-1200 (Remuneração) e S-1299 (Fechamento da Folha).',
        ],
        dica: 'O fechamento da folha (S-1299) alimenta diretamente a DCTFWeb da Receita Federal para emissão da guia DARF Previdenciário.',
        legislacao: 'Manual de Orientação do eSocial (MOS) Versão S-1.2.',
        tags: ['esocial', 's-1000', 's-1200', 's-1299', 'dctfweb', 'sst', 'transmissao'],
      },
    ],
  },
  {
    key: 'fechamento_impostos',
    titulo: 'Fechamento de Impostos',
    subtitulo: 'Simples Nacional, PGDAS-D, MEI, Lucro Presumido e Conformidade Fiscal',
    icon: Calculator,
    cor: 'text-amber-600 bg-amber-50 border-amber-200',
    topicos: [
      {
        id: 'simples_nacional_pgdas',
        titulo: 'Apuração do Simples Nacional (PGDAS-D) e Cálculo do Fator R',
        descricao: 'Apure o DAS mensal das empresas optantes pelo Simples utilizando o faturamento das notas de saída e o cálculo automático do Fator R.',
        passos: [
          'Acesse o menu "Simples Nacional & PGDAS-D" na barra lateral.',
          'Selecione a empresa e a competência de apuração.',
          'O sistema soma todas as notas de saída (emitidas internamente ou importadas de XML modelo 55) dos últimos 12 meses (RBT12).',
          'Para prestadores de serviço, o sistema calcula a relação Folha / Faturamento: se Fator R >= 28%, a empresa é tributada pelo Anexo III (alíquota inicial 6%); caso contrário, Anexo V (alíquota inicial 15,5%).',
          'Gere a memória de cálculo analítica e a guia DAS para pagamento.',
        ],
        dica: 'Importe os XMLs de saída de todo o ano para que o RBT12 seja calculado com precisão cirúrgica.',
        legislacao: 'Lei Complementar nº 123/2006, art. 18, § 5º-J.',
        tags: ['simples', 'pgdas', 'fator r', 'das', 'anexo iii', 'anexo v', 'rbt12'],
      },
      {
        id: 'fechamento_mei',
        titulo: 'Fechamento MEI e Declaração Anual (DASN-SIMEI)',
        descricao: 'Gerenciamento de Microempreendedores Individuais, controle do limite de R$ 81.000,00 anuais e guias DAS-MEI.',
        passos: [
          'Acesse o menu "Fechamento MEI & DASN".',
          'Verifique o termômetro de faturamento acumulado e a margem restante para não ultrapassar o teto anual.',
          'Emita as guias DAS-MEI mensais de INSS + ICMS / ISS.',
          'Ao término do exercício, utilize o gerador da Declaração Anual DASN-SIMEI.',
        ],
        dica: 'Caso o MEI fature entre R$ 81.000,00 e R$ 97.200,00 (excesso de até 20%), recolhe-se DAS complementar no ano seguinte e desenquadra-se para ME a partir de janeiro.',
        legislacao: 'Resolução CGSN nº 140/2018 (Capítulo MEI).',
        tags: ['mei', 'dasn', 'simei', 'limite 81k', 'guia das', 'microempreendedor'],
      },
      {
        id: 'radar_conformidade',
        titulo: 'Radar de Conformidade Fiscal e Alertas de Alvarás',
        descricao: 'Monitoramento contínuo de certidões negativas (CND Federal, Estadual, FGTS, Trabalhista) e controle de vencimento de alvarás.',
        passos: [
          'Acesse o "Radar de Conformidade Fiscal" no menu lateral.',
          'Verifique o status de todas as CNDs das empresas clientes.',
          'Confira os alvarás com vencimento nos próximos 30 dias destacados no banner superior.',
          'Inicie pedidos de renovação antes do vencimento para evitar desenquadramento do Simples ou multas.',
        ],
        dica: 'O ContabGest avisa com antecedência de 30 dias para você solicitar a renovação do AVCB e Alvará Sanitário junto aos órgãos públicos.',
        legislacao: 'Decreto Federal nº 9.283/2018 e legislações municipais de licenciamento.',
        tags: ['conformidade', 'alvara', 'cnd', 'vencimento', '30 dias', 'fiscal'],
      },
    ],
  },
  {
    key: 'analises_contabeis',
    titulo: 'Análises Contábeis & Auditoria',
    subtitulo: 'DRE, Balanço Patrimonial, Índices de Liquidez e Auditoria de Registros',
    icon: TrendingUp,
    cor: 'text-blue-600 bg-blue-50 border-blue-200',
    topicos: [
      {
        id: 'dre_balanco',
        titulo: 'Demonstração do Resultado (DRE) e Balanço Patrimonial',
        descricao: 'Emissão de demonstrativos contábeis em conformidade com as Normas Brasileiras de Contabilidade (NBC TG).',
        passos: [
          'Acesse "Contabilidade & Análises" na barra lateral.',
          'Selecione a empresa e o período (Mensal, Trimestral ou Anual).',
          'Visualize a DRE estruturada: Receita Bruta (-) Deduções (=) Receita Líquida (-) CPV (=) Lucro Bruto (-) Despesas Operacionais (=) Lucro Líquido.',
          'Acesse a aba do Balanço Patrimonial para analisar Ativo Circulante, Ativo Não Circulante, Passivo e Patrimônio Líquido equilibrados.',
        ],
        dica: 'Use a opção de exportar o relatório contábil em PDF para anexar aos balancetes entregues aos sócios e bancos.',
        legislacao: 'Lei das S.A. nº 6.404/1976 (artigos 176 a 192) e NBC TG 1000.',
        tags: ['dre', 'balanco', 'lucro', 'patrimonio', 'demonstrativos', 'nbc'],
      },
      {
        id: 'indices_liquidez',
        titulo: 'Índices Financeiros e Análise de Liquidez',
        descricao: 'Cálculo automatizado dos índices fundamentais de solvência da empresa cliente.',
        passos: [
          'No painel contábil, consulte os 4 índices de liquidez calculados em tempo real:',
          '• Liquidez Corrente = Ativo Circulante / Passivo Circulante (Capacidade a curto prazo; ideal > 1,00).',
          '• Liquidez Seca = (Ativo Circulante - Estoques) / Passivo Circulante (Sem depender das vendas).',
          '• Liquidez Imediata = Disponibilidades (Caixa/Bancos) / Passivo Circulante.',
          '• Liquidez Geral = (Ativo Circulante + RLP) / (Passivo Circulante + Passivo Não Circulante).',
        ],
        dica: 'Índice de Liquidez Corrente acima de 1,5 indica excelente folga de capital de giro.',
        legislacao: 'Análise das Demonstrações Contábeis (CFC).',
        tags: ['liquidez', 'indices', 'solvencia', 'capital de giro', 'analise'],
      },
      {
        id: 'conciliacao_auditoria',
        titulo: 'Conciliação Bancária e Auditoria de Registros',
        descricao: 'Importação de extratos bancários (OFX / Excel), conciliação com contas a pagar/receber e trilha de auditoria completa.',
        passos: [
          'Acesse o módulo "Financeiro" e selecione "Conciliação Bancária".',
          'Faça o upload do extrato bancário oficial da empresa cliente.',
          'O sistema cruza automaticamente os lançamentos pelo valor e data aproximada.',
          'Confirme as baixas contábeis para alimentar os saldos de caixa e DRE.',
        ],
        dica: 'Lançamentos conciliados garantem que a DRE reflita a movimentação bancária real, prevenindo fiscalizações da Receita sobre omissão de receitas.',
        legislacao: 'NBC ITG 2000 (R1) - Escrituração Contábil.',
        tags: ['conciliacao', 'banco', 'ofx', 'auditoria', 'financeiro', 'extrato'],
      },
    ],
  },
];

export const ManualDoUsuarioModal: React.FC<ManualDoUsuarioModalProps> = ({
  isOpen,
  onClose,
  initialSection = 'primeiros_passos',
}) => {
  const [activeSection, setActiveSection] = useState<SectionKey>(initialSection);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTopicId, setSelectedTopicId] = useState<string | null>(null);
  const [copiedTopicId, setCopiedTopicId] = useState<string | null>(null);

  // Filtragem por busca em todas as seções
  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return null;
    const query = searchQuery.toLowerCase().trim();

    const results: { section: SectionData; topic: TopicItem }[] = [];
    MANUAL_SECTIONS.forEach((sec) => {
      sec.topicos.forEach((top) => {
        const matchesTitle = top.titulo.toLowerCase().includes(query);
        const matchesDesc = top.descricao.toLowerCase().includes(query);
        const matchesTags = top.tags.some((t) => t.toLowerCase().includes(query));
        const matchesPassos = top.passos.some((p) => p.toLowerCase().includes(query));

        if (matchesTitle || matchesDesc || matchesTags || matchesPassos) {
          results.push({ section: sec, topic: top });
        }
      });
    });

    return results;
  }, [searchQuery]);

  const currentSectionData = useMemo(() => {
    return MANUAL_SECTIONS.find((s) => s.key === activeSection) || MANUAL_SECTIONS[0];
  }, [activeSection]);

  const handleCopyLink = (topicId: string) => {
    setCopiedTopicId(topicId);
    setTimeout(() => setCopiedTopicId(null), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  if (!isOpen) return null;

  return (
    <div
      id="manual-do-usuario-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/70 backdrop-blur-sm animate-in fade-in"
    >
      <div
        id="manual-do-usuario-container"
        className="bg-white w-full max-w-5xl h-[90vh] rounded-3xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden text-slate-800"
      >
        {/* Header do Manual */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-md">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold">Manual do Usuário ContabGest</h2>
                <span className="bg-indigo-500/30 text-indigo-300 border border-indigo-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  Guia Oficial v2.0
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Documentação operacional passo a passo para escritórios contábeis e gestores financeiros
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors hidden sm:flex items-center gap-1.5 text-xs font-semibold"
              title="Imprimir ou Salvar Manual em PDF"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimir</span>
            </button>
            <button
              id="btn-fechar-manual"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
              aria-label="Fechar Manual"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Barra de Busca Global no Manual */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 shrink-0">
          <div className="relative max-w-2xl mx-auto">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id="input-busca-manual"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Pesquise por recurso: 'XML saída 55', 'Fator R', 'Folha', 'Turnover', 'SEFAZ DF-e', 'DRE'..."
              className="w-full pl-10 pr-10 py-2.5 bg-white border border-slate-300 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-2xs placeholder-slate-400 font-medium"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Corpo: Navegação Lateral + Conteúdo */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Navegação Lateral de Seções */}
          <div className="w-full md:w-72 bg-slate-50/80 border-r border-slate-200 p-3 overflow-y-auto shrink-0 flex md:flex-col gap-1.5">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 px-3 py-1 hidden md:block">
              Seções do Manual
            </span>

            {MANUAL_SECTIONS.map((sec) => {
              const Icon = sec.icon;
              const isActive = activeSection === sec.key && !searchResults;

              return (
                <button
                  key={sec.key}
                  id={`tab-manual-${sec.key}`}
                  onClick={() => {
                    setActiveSection(sec.key);
                    setSearchQuery('');
                  }}
                  className={`w-full text-left p-2.5 rounded-xl transition-all flex items-center gap-3 ${
                    isActive
                      ? 'bg-white text-indigo-700 font-bold shadow-xs border border-indigo-200'
                      : 'text-slate-600 hover:bg-slate-200/60 font-semibold'
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      isActive ? 'bg-indigo-600 text-white' : 'bg-slate-200/80 text-slate-600'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="truncate">
                    <p className="text-xs truncate">{sec.titulo}</p>
                    <span className="text-[10px] text-slate-400 font-normal block truncate">
                      {sec.topicos.length} tópicos
                    </span>
                  </div>
                </button>
              );
            })}

            <div className="mt-auto pt-4 border-t border-slate-200 hidden md:block px-2">
              <div className="bg-indigo-50 border border-indigo-200/80 rounded-xl p-3 text-indigo-900 text-xs">
                <span className="font-bold flex items-center gap-1.5 text-indigo-800">
                  <Sparkles className="w-3.5 h-3.5" /> Dica de Produtividade
                </span>
                <p className="text-[11px] text-indigo-700 mt-1 leading-relaxed">
                  Use o atalho global do cabeçalho para acessar a documentação a qualquer momento sem perder seus dados.
                </p>
              </div>
            </div>
          </div>

          {/* Área de Conteúdo Principal */}
          <div className="flex-1 p-5 sm:p-8 overflow-y-auto bg-white">
            {/* Modo de Resultados de Busca */}
            {searchResults ? (
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                  <div>
                    <h3 className="text-base font-bold text-slate-900">
                      Resultados da Pesquisa: "{searchQuery}"
                    </h3>
                    <p className="text-xs text-slate-500">
                      {searchResults.length}{' '}
                      {searchResults.length === 1 ? 'tópico encontrado' : 'tópicos encontrados'}
                    </p>
                  </div>
                  <button
                    onClick={() => setSearchQuery('')}
                    className="text-xs text-indigo-600 font-semibold hover:underline"
                  >
                    Limpar pesquisa
                  </button>
                </div>

                {searchResults.length === 0 ? (
                  <div className="py-12 text-center text-slate-400">
                    <HelpCircle className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="text-sm font-semibold text-slate-700">Nenhum resultado encontrado</p>
                    <p className="text-xs text-slate-500 mt-1">
                      Tente buscar por termos como "XML", "Simples", "Ponto", "Turnover", "Balanço".
                    </p>
                  </div>
                ) : (
                  <div className="space-y-5">
                    {searchResults.map(({ section, topic }) => (
                      <TopicCard
                        key={topic.id}
                        topic={topic}
                        sectionTitle={section.titulo}
                        onCopy={() => handleCopyLink(topic.id)}
                        copied={copiedTopicId === topic.id}
                      />
                    ))}
                  </div>
                )}
              </div>
            ) : (
              /* Modo de Visualização da Seção Ativa */
              <div className="space-y-6">
                {/* Header da Seção */}
                <div className="flex items-start justify-between pb-4 border-b border-slate-100">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600">
                      Módulo do Sistema
                    </span>
                    <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5">
                      {currentSectionData.titulo}
                    </h2>
                    <p className="text-xs text-slate-500 mt-1 max-w-2xl leading-relaxed">
                      {currentSectionData.subtitulo}
                    </p>
                  </div>

                  <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-full text-xs font-semibold shrink-0">
                    {currentSectionData.topicos.length} Tópicos
                  </span>
                </div>

                {/* Lista de Tópicos da Seção */}
                <div className="space-y-6">
                  {currentSectionData.topicos.map((topic) => (
                    <TopicCard
                      key={topic.id}
                      topic={topic}
                      onCopy={() => handleCopyLink(topic.id)}
                      copied={copiedTopicId === topic.id}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer do Modal */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shrink-0 text-xs text-slate-500">
          <span>ContabGest Sistema de Gestão Contábil • Versão 2.0.0</span>
          <div className="flex items-center gap-3">
            <span>Suporte Contábil: <strong>contato@contabgest.com.br</strong></span>
            <button
              onClick={onClose}
              className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-semibold transition-colors"
            >
              Fechar Guia
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Subcomponente de Card de Tópico
interface TopicCardProps {
  topic: TopicItem;
  sectionTitle?: string;
  onCopy: () => void;
  copied: boolean;
}

const TopicCard: React.FC<TopicCardProps> = ({ topic, sectionTitle, onCopy, copied }) => {
  return (
    <div
      id={`topico-${topic.id}`}
      className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-xs transition-shadow p-5 sm:p-6"
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          {sectionTitle && (
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100 inline-block mb-1.5">
              {sectionTitle}
            </span>
          )}
          <h3 className="text-base font-bold text-slate-900">{topic.titulo}</h3>
          <p className="text-xs text-slate-600 mt-1 leading-relaxed">{topic.descricao}</p>
        </div>

        <button
          onClick={onCopy}
          className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors shrink-0"
          title="Copiar referência do tópico"
        >
          {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
        </button>
      </div>

      {/* Passo a Passo */}
      <div className="mt-4 pt-4 border-t border-slate-100">
        <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          <span>Passo a Passo Operacional</span>
        </h4>
        <ol className="space-y-2 text-xs text-slate-700">
          {topic.passos.map((passo, idx) => (
            <li key={idx} className="flex items-start gap-2.5">
              <span className="w-5 h-5 rounded-full bg-indigo-50 text-indigo-700 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5 border border-indigo-200">
                {idx + 1}
              </span>
              <span className="leading-relaxed">{passo}</span>
            </li>
          ))}
        </ol>
      </div>

      {/* Dica Operacional e Legislação */}
      {(topic.dica || topic.legislacao) && (
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-100">
          {topic.dica && (
            <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-xl p-3 text-emerald-950 text-xs">
              <span className="font-bold flex items-center gap-1.5 text-emerald-800">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" /> Dica Prática
              </span>
              <p className="text-[11px] text-emerald-900 mt-1 leading-relaxed">{topic.dica}</p>
            </div>
          )}

          {topic.legislacao && (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-800 text-xs">
              <span className="font-bold flex items-center gap-1.5 text-slate-700">
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" /> Base Legal & Normativa
              </span>
              <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">{topic.legislacao}</p>
            </div>
          )}
        </div>
      )}

      {/* Tags */}
      <div className="mt-3 flex flex-wrap gap-1.5">
        {topic.tags.map((tag) => (
          <span
            key={tag}
            className="text-[10px] font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md"
          >
            #{tag}
          </span>
        ))}
      </div>
    </div>
  );
};
