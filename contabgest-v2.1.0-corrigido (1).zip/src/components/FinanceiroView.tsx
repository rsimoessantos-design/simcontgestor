import React, { useState } from 'react';
import {
  DollarSign,
  ArrowUpRight,
  ArrowDownLeft,
  Calendar,
  Search,
  Plus,
  Filter,
  CheckCircle2,
  Clock,
  AlertTriangle,
} from 'lucide-react';
import { ContaPagar, ContaReceber, CategoriaFinanceira, Empresa } from '../types';

interface FinanceiroViewProps {
  contasPagar: ContaPagar[];
  contasReceber: ContaReceber[];
  categorias: CategoriaFinanceira[];
  empresas: Empresa[];
  selectedEmpresa?: Empresa;
}

export const FinanceiroView: React.FC<FinanceiroViewProps> = ({
  contasPagar,
  contasReceber,
  categorias,
  empresas,
  selectedEmpresa,
}) => {
  const [activeTab, setActiveTab] = useState<'pagar' | 'receber'>('pagar');
  const [searchTerm, setSearchTerm] = useState('');

  const formatCurrency = (val: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);

  const getCategoria = (catId: string) => {
    return categorias.find((c) => c.id === catId);
  };

  const getEmpresaName = (empresaId: string) => {
    const emp = empresas.find((e) => e.id === empresaId);
    return emp ? emp.nomeFantasia : 'Empresa';
  };

  const totalPagar = contasPagar.reduce((acc, curr) => acc + curr.valor, 0);
  const totalReceber = contasReceber.reduce((acc, curr) => acc + curr.valor, 0);
  const saldoProjetado = totalReceber - totalPagar;

  const filteredPagar = contasPagar.filter(
    (cp) =>
      cp.descricao.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cp.beneficiario.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredReceber = contasReceber.filter(
    (cr) =>
      cr.descricao.toLowerCase().includes(searchTerm.toLowerCase()) ||
      cr.pagador.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900">
              Gestão Financeira & Fluxo de Caixa
            </h1>
            <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
              DEMO
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {selectedEmpresa
              ? `Contas a pagar e receber da empresa: ${selectedEmpresa.nomeFantasia}`
              : 'Visão financeira consolidada de contas a pagar, receber e conciliação'}
          </p>
        </div>

        <button
          onClick={() => alert('Lançamento financeiro pronto para integração contábil.')}
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Novo Lançamento</span>
        </button>
      </div>

      {/* Financial Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase">
              Total a Receber
            </span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 border border-emerald-200">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-emerald-700 mt-2">
            {formatCurrency(totalReceber)}
          </div>
          <p className="text-xs text-slate-500 mt-1">{contasReceber.length} títulos previstos</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase">
              Total a Pagar
            </span>
            <div className="p-2 rounded-lg bg-rose-50 text-rose-600 border border-rose-200">
              <ArrowDownLeft className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-rose-700 mt-2">
            {formatCurrency(totalPagar)}
          </div>
          <p className="text-xs text-slate-500 mt-1">{contasPagar.length} despesas provisionadas</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase">
              Resultado Projetado
            </span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600 border border-blue-200">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div
            className={`text-2xl font-bold mt-2 ${
              saldoProjetado >= 0 ? 'text-blue-700' : 'text-rose-700'
            }`}
          >
            {formatCurrency(saldoProjetado)}
          </div>
          <p className="text-xs text-slate-500 mt-1">Saldo líquido estimado</p>
        </div>
      </div>

      {/* Tabs & Search */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="inline-flex rounded-lg bg-slate-100 p-1 border border-slate-200 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('pagar')}
              className={`px-4 py-2 rounded-md transition-all flex items-center gap-2 ${
                activeTab === 'pagar'
                  ? 'bg-white text-rose-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowDownLeft className="w-4 h-4" />
              <span>Contas a Pagar ({contasPagar.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('receber')}
              className={`px-4 py-2 rounded-md transition-all flex items-center gap-2 ${
                activeTab === 'receber'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>Contas a Receber ({contasReceber.length})</span>
            </button>
          </div>

          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder={`Filtrar ${activeTab === 'pagar' ? 'pagamentos' : 'recebimentos'}...`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
            />
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto border border-slate-100 rounded-lg">
          {activeTab === 'pagar' ? (
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Descrição da Despesa</th>
                  <th className="py-3 px-4">Empresa</th>
                  <th className="py-3 px-4">Categoria</th>
                  <th className="py-3 px-4">Beneficiário</th>
                  <th className="py-3 px-4">Vencimento</th>
                  <th className="py-3 px-4">Valor</th>
                  <th className="py-3 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredPagar.map((cp) => {
                  const cat = getCategoria(cp.categoriaId);
                  return (
                    <tr key={cp.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-semibold text-slate-900">
                        {cp.descricao}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-700">
                        {getEmpresaName(cp.empresaId)}
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700">
                          {cat?.nome || 'Geral'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-600">{cp.beneficiario}</td>
                      <td className="py-3 px-4 font-mono font-medium">{cp.dataVencimento}</td>
                      <td className="py-3 px-4 font-bold text-rose-600">
                        {formatCurrency(cp.valor)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            cp.status === 'pago'
                              ? 'bg-emerald-100 text-emerald-800'
                              : cp.status === 'vencido'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {cp.status.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Descrição da Receita</th>
                  <th className="py-3 px-4">Empresa</th>
                  <th className="py-3 px-4">Categoria</th>
                  <th className="py-3 px-4">Pagador</th>
                  <th className="py-3 px-4">Vencimento</th>
                  <th className="py-3 px-4">Valor</th>
                  <th className="py-3 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredReceber.map((cr) => {
                  const cat = getCategoria(cr.categoriaId);
                  return (
                    <tr key={cr.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-semibold text-slate-900">
                        {cr.descricao}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-700">
                        {getEmpresaName(cr.empresaId)}
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700">
                          {cat?.nome || 'Receita'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-600">{cr.pagador}</td>
                      <td className="py-3 px-4 font-mono font-medium">{cr.dataVencimento}</td>
                      <td className="py-3 px-4 font-bold text-emerald-600">
                        {formatCurrency(cr.valor)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            cr.status === 'recebido'
                              ? 'bg-emerald-100 text-emerald-800'
                              : cr.status === 'vencido'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {cr.status.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
