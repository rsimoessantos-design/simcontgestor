import React, { useState } from 'react';
import {
  CalendarCheck,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Filter,
  Search,
  Building2,
  Send,
  FileCheck,
  ChevronRight,
  Calendar,
  Layers,
  Sparkles,
  X,
  Upload,
} from 'lucide-react';
import { Obrigacao, Empresa, Tarefa } from '../types';
import { api } from '../services/api';

interface ControleEntregasViewProps {
  selectedEmpresa?: Empresa;
  empresas: Empresa[];
  obrigacoes: Obrigacao[];
  tarefas: Tarefa[];
  onRefresh: () => void;
}

export const ControleEntregasView: React.FC<ControleEntregasViewProps> = ({
  selectedEmpresa,
  empresas,
  obrigacoes,
  tarefas,
  onRefresh,
}) => {
  const [selectedMes, setSelectedMes] = useState('09/2026');
  const [viewMode, setViewMode] = useState<'pipeline' | 'matriz'>('pipeline');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRegime, setFilterRegime] = useState('todos');
  const [selectedObrigacaoForEntrega, setSelectedObrigacaoForEntrega] = useState<Obrigacao | null>(null);
  const [protocoloRecibo, setProtocoloRecibo] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Filtragem
  const filteredObrigacoes = obrigacoes.filter((ob) => {
    const emp = empresas.find((e) => e.id === ob.empresaId);
    const matchesSearch =
      ob.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ob.tipo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp?.razaoSocial.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesRegime = filterRegime === 'todos' || emp?.regimeTributario === filterRegime;

    return matchesSearch && matchesRegime;
  });

  // Estatísticas de Entregas
  const total = filteredObrigacoes.length;
  const entregues = filteredObrigacoes.filter((o) => o.status === 'concluida').length;
  const vencendo = filteredObrigacoes.filter((o) => o.status === 'vencendo').length;
  const atrasadas = filteredObrigacoes.filter((o) => o.status === 'atrasada').length;
  const pendentes = filteredObrigacoes.filter((o) => o.status === 'pendente').length;

  const percentualEntregue = total > 0 ? Math.round((entregues / total) * 100) : 100;

  // Pipeline Stages
  const stages = [
    {
      id: 'coleta',
      title: '1. Coleta de Documentos',
      desc: 'Extratos, notas fiscais e folha',
      badgeColor: 'bg-slate-100 text-slate-700',
      items: filteredObrigacoes.filter((o) => o.status === 'pendente'),
    },
    {
      id: 'apuracao',
      title: '2. Apuração & Vencendo',
      desc: 'Cálculo de guias e declarações',
      badgeColor: 'bg-amber-100 text-amber-800',
      items: filteredObrigacoes.filter((o) => o.status === 'vencendo'),
    },
    {
      id: 'atrasadas',
      title: '3. Atrasadas / Urgentes',
      desc: 'Expiradas sem recibo oficial',
      badgeColor: 'bg-rose-100 text-rose-800',
      items: filteredObrigacoes.filter((o) => o.status === 'atrasada'),
    },
    {
      id: 'entregues',
      title: '4. Transmitidas / Entregues',
      desc: 'Recibo gerado e guia enviada',
      badgeColor: 'bg-emerald-100 text-emerald-800',
      items: filteredObrigacoes.filter((o) => o.status === 'concluida'),
    },
  ];

  // Avançar obrigação para concluída com recibo
  const handleConfirmarEntrega = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedObrigacaoForEntrega) return;

    setIsSubmitting(true);
    try {
      await api.updateDatabaseRecord('obrigacoes', selectedObrigacaoForEntrega.id, {
        status: 'concluida',
        dataConclusao: new Date().toISOString(),
        protocoloRecibo: protocoloRecibo || `REC-${Date.now()}`,
      });
      setSelectedObrigacaoForEntrega(null);
      setProtocoloRecibo('');
      onRefresh();
    } catch (err: any) {
      alert('Erro ao confirmar entrega da obrigação: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleMudarStatusRapido = async (ob: Obrigacao, novoStatus: 'pendente' | 'vencendo' | 'concluida') => {
    try {
      await api.updateDatabaseRecord('obrigacoes', ob.id, {
        status: novoStatus,
        dataConclusao: novoStatus === 'concluida' ? new Date().toISOString() : undefined,
      });
      onRefresh();
    } catch (err: any) {
      alert('Erro ao atualizar status: ' + err.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <CalendarCheck className="w-7 h-7 text-purple-600" />
            Controle de Tarefas & Entregas de Obrigações Fiscais
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Gestão operacional de prazos, conciliações, apurações e transmissão de recibos SEFAZ / RFB
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Switch Pipeline / Matriz */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setViewMode('pipeline')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                viewMode === 'pipeline'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Pipeline de Entrega
            </button>
            <button
              onClick={() => setViewMode('matriz')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                viewMode === 'matriz'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Matriz Geral por Empresa
            </button>
          </div>
        </div>
      </div>

      {/* Progress & KPI Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Taxa de Cumprimento de Entregas ({selectedMes})
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-3xl font-black text-slate-900">{percentualEntregue}%</span>
              <span className="text-xs text-slate-500">
                ({entregues} de {total} obrigações concluídas)
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <span className="text-xs text-slate-500 block">Competência:</span>
              <select
                value={selectedMes}
                onChange={(e) => setSelectedMes(e.target.value)}
                className="text-xs font-bold text-slate-900 bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 focus:outline-none"
              >
                <option value="09/2026">Setembro / 2026 (Atual)</option>
                <option value="08/2026">Agosto / 2026</option>
                <option value="07/2026">Julho / 2026</option>
              </select>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden flex">
          <div
            style={{ width: `${percentualEntregue}%` }}
            className="bg-emerald-500 h-full transition-all duration-500"
          ></div>
          <div
            style={{ width: `${total > 0 ? (vencendo / total) * 100 : 0}%` }}
            className="bg-amber-400 h-full transition-all duration-500"
          ></div>
          <div
            style={{ width: `${total > 0 ? (atrasadas / total) * 100 : 0}%` }}
            className="bg-rose-500 h-full transition-all duration-500"
          ></div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-4 text-xs flex-wrap">
          <span className="flex items-center gap-1.5 text-slate-600">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            Entregues: <strong>{entregues}</strong>
          </span>
          <span className="flex items-center gap-1.5 text-slate-600">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            Vencendo nos próximos 5 dias: <strong>{vencendo}</strong>
          </span>
          <span className="flex items-center gap-1.5 text-slate-600">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
            Atrasadas / Não Entregues: <strong>{atrasadas}</strong>
          </span>
          <span className="flex items-center gap-1.5 text-slate-600">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-300"></span>
            Em Coleta / Pendentes: <strong>{pendentes}</strong>
          </span>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Buscar por obrigação ou empresa..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={filterRegime}
              onChange={(e) => setFilterRegime(e.target.value)}
              className="bg-transparent border-none focus:outline-none text-xs text-slate-700 font-medium"
            >
              <option value="todos">Todos os Regimes</option>
              <option value="Simples Nacional">Simples Nacional</option>
              <option value="Lucro Presumido">Lucro Presumido</option>
              <option value="Lucro Real">Lucro Real</option>
            </select>
          </div>
        </div>
      </div>

      {/* VIEW 1: PIPELINE KANBAN DE ENTREGAS */}
      {viewMode === 'pipeline' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {stages.map((stage) => (
            <div
              key={stage.id}
              className="bg-slate-50/80 rounded-2xl border border-slate-200 p-4 flex flex-col h-full"
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                    {stage.title}
                  </h3>
                  <p className="text-[11px] text-slate-500">{stage.desc}</p>
                </div>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${stage.badgeColor}`}
                >
                  {stage.items.length}
                </span>
              </div>

              {/* Cards in column */}
              <div className="mt-3 space-y-3 flex-1 overflow-y-auto max-h-[580px] pr-1">
                {stage.items.length === 0 ? (
                  <div className="p-4 text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-xl">
                    Nenhuma obrigação nesta etapa
                  </div>
                ) : (
                  stage.items.map((ob) => {
                    const emp = empresas.find((e) => e.id === ob.empresaId);
                    return (
                      <div
                        key={ob.id}
                        className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-sm hover:shadow transition-shadow space-y-2.5"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <span className="text-[10px] font-bold uppercase text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded">
                              {ob.tipo}
                            </span>
                            <h4 className="text-xs font-bold text-slate-900 mt-1">{ob.nome}</h4>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {ob.competencia}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5 text-xs text-slate-600">
                          <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="truncate">{emp?.razaoSocial || 'Empresa do Grupo'}</span>
                        </div>

                        <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-100">
                          <span className="text-slate-500 text-[11px]">
                            Venc: <strong>{new Date(ob.dataVencimento).toLocaleDateString('pt-BR')}</strong>
                          </span>

                          {ob.status !== 'concluida' ? (
                            <button
                              id={`btn-entregar-${ob.id}`}
                              onClick={() => setSelectedObrigacaoForEntrega(ob)}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-semibold rounded-md shadow-xs transition-colors flex items-center gap-1"
                            >
                              <FileCheck className="w-3 h-3" />
                              Entregar
                            </button>
                          ) : (
                            <span className="text-[11px] font-bold text-emerald-600 flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" /> Transmitido
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* VIEW 2: MATRIZ DE ENTREGAS POR EMPRESA */}
      {viewMode === 'matriz' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600 uppercase tracking-wider">
                <tr>
                  <th className="px-5 py-3">Empresa / CNPJ</th>
                  <th className="px-5 py-3">Regime Tributário</th>
                  <th className="px-5 py-3">Obrigação Fiscal</th>
                  <th className="px-5 py-3">Competência</th>
                  <th className="px-5 py-3">Vencimento</th>
                  <th className="px-5 py-3">Status de Entrega</th>
                  <th className="px-5 py-3 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredObrigacoes.map((ob) => {
                  const emp = empresas.find((e) => e.id === ob.empresaId);
                  return (
                    <tr key={ob.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-5 py-3.5">
                        <p className="font-semibold text-slate-900">{emp?.razaoSocial || 'Empresa'}</p>
                        <p className="text-xs text-slate-500 font-mono">{emp?.cnpj}</p>
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="text-xs font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                          {emp?.regimeTributario}
                        </span>
                      </td>
                      <td className="px-5 py-3.5">
                        <p className="font-semibold text-slate-900">{ob.nome}</p>
                        <span className="text-[11px] text-slate-400">{ob.tipo}</span>
                      </td>
                      <td className="px-5 py-3.5 text-xs text-slate-600 font-mono">{ob.competencia}</td>
                      <td className="px-5 py-3.5 text-xs font-medium text-slate-800">
                        {new Date(ob.dataVencimento).toLocaleDateString('pt-BR')}
                      </td>
                      <td className="px-5 py-3.5">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
                            ob.status === 'concluida'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : ob.status === 'vencendo'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : ob.status === 'atrasada'
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : 'bg-slate-100 text-slate-700 border border-slate-200'
                          }`}
                        >
                          {ob.status === 'concluida' ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Transmitida
                            </>
                          ) : ob.status === 'vencendo' ? (
                            <>
                              <Clock className="w-3.5 h-3.5 text-amber-600" /> Vencendo
                            </>
                          ) : ob.status === 'atrasada' ? (
                            <>
                              <AlertTriangle className="w-3.5 h-3.5 text-rose-600" /> Atrasada
                            </>
                          ) : (
                            'Pendente'
                          )}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        {ob.status !== 'concluida' ? (
                          <button
                            onClick={() => setSelectedObrigacaoForEntrega(ob)}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors inline-flex items-center gap-1"
                          >
                            <FileCheck className="w-3.5 h-3.5" />
                            Registrar Entrega
                          </button>
                        ) : (
                          <button
                            onClick={() => handleMudarStatusRapido(ob, 'pendente')}
                            className="text-xs text-slate-400 hover:text-slate-600 hover:underline"
                          >
                            Reabrir
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Registrar Entrega de Obrigação */}
      {selectedObrigacaoForEntrega && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-purple-50 text-purple-600 rounded-lg">
                  <FileCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Registrar Entrega Oficial</h3>
                  <p className="text-xs text-slate-500">Transmissão com protocolo de entrega</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedObrigacaoForEntrega(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1 text-xs">
              <p className="font-bold text-slate-900">{selectedObrigacaoForEntrega.nome}</p>
              <p className="text-slate-600">Competência: {selectedObrigacaoForEntrega.competencia}</p>
              <p className="text-slate-600">
                Prazo Oficial:{' '}
                {new Date(selectedObrigacaoForEntrega.dataVencimento).toLocaleDateString('pt-BR')}
              </p>
            </div>

            <form onSubmit={handleConfirmarEntrega} className="mt-4 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Número do Recibo / Protocolo de Transmissão
                </label>
                <input
                  type="text"
                  value={protocoloRecibo}
                  onChange={(e) => setProtocoloRecibo(e.target.value)}
                  placeholder="Ex: REC-DCTF-2026.983.120"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedObrigacaoForEntrega(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-colors disabled:opacity-50"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {isSubmitting ? 'Salvando...' : 'Confirmar Entrega'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
