import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Bell,
  BellRing,
  AlertTriangle,
  Clock,
  ShieldAlert,
  CheckCircle2,
  X,
  ChevronUp,
  ChevronDown,
  ExternalLink,
  Volume2,
  VolumeX,
  Radio,
  FileText,
  Building2,
  EyeOff,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { Obrigacao, PendenciaEcac, Empresa, NavSection } from '../types';

interface FooterNotificationToastProps {
  obrigacoes: Obrigacao[];
  pendenciasEcac: PendenciaEcac[];
  empresas: Empresa[];
  onNavigate: (section: NavSection) => void;
}

export interface AlertaItem {
  id: string;
  tipo: 'obrigacao_48h' | 'ecac_pendencia';
  titulo: string;
  detalhe: string;
  empresaNome: string;
  empresaId: string;
  severidade: 'critica' | 'alta' | 'media' | 'baixa';
  prazoTexto?: string;
  horasRestantes?: number;
  orgao?: string;
  valor?: number;
  dataReferencia: string;
  targetSection: NavSection;
}

// Emissão de som discreto via Web Audio API (sem dependência de assets de áudio externos)
const playChime = () => {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    gain1.gain.setValueAtTime(0.08, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.25);

    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(880.0, now + 0.12); // A5
    gain2.gain.setValueAtTime(0.08, now + 0.12);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.12);
    osc2.stop(now + 0.4);
  } catch (e) {
    // Audio Context may be restricted before user interaction
  }
};

export function FooterNotificationToast({
  obrigacoes,
  pendenciasEcac,
  empresas,
  onNavigate,
}: FooterNotificationToastProps) {
  // Controle de visibilidade e modo
  const [isOpen, setIsOpen] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const [activeTab, setActiveTab] = useState<'todos' | 'obrigacoes' | 'ecac'>('todos');
  const [somHabilitado, setSomHabilitado] = useState<boolean>(() => {
    return localStorage.getItem('contabgest_alert_sound') !== 'disabled';
  });

  // Alertas dispensados individualmente
  const [dismissedIds, setDismissedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('contabgest_dismissed_alert_ids');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Silenciador temporário (timestamp de fim)
  const [silencedUntil, setSilencedUntil] = useState<number | null>(() => {
    try {
      const saved = localStorage.getItem('contabgest_silenced_until');
      return saved ? Number(saved) : null;
    } catch {
      return null;
    }
  });

  // Notificações nativas do navegador (Web Push / Desktop Notification API)
  const [pushStatus, setPushStatus] = useState<NotificationPermission>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'denied';
  });
  const [pushBannerMsg, setPushBannerMsg] = useState<string | null>(null);

  // Mapear empresas por ID
  const empresaMap = useMemo(() => {
    const map: Record<string, string> = {};
    empresas.forEach((e) => {
      map[e.id] = e.nomeFantasia || e.razaoSocial;
    });
    return map;
  }, [empresas]);

  // Cálculo das obrigações com vencimento em até 48 horas (ou vencidas recentes e pendentes)
  // e das pendências ativas do e-CAC
  const { alertasObrigacoes, alertasEcac, todosAlertas } = useMemo(() => {
    const hoje = new Date();
    const agoraMs = hoje.getTime();

    // 1. Obrigações Fiscais em até 48h
    const listaObrigacoes: AlertaItem[] = [];

    obrigacoes
      .filter((o) => o.status !== 'concluida')
      .forEach((o) => {
        if (!o.dataVencimento) return;

        // Vencimento até o fim do dia
        const dtVenc = new Date(`${o.dataVencimento}T23:59:59`);
        if (isNaN(dtVenc.getTime())) return;

        const diffMs = dtVenc.getTime() - agoraMs;
        const diffHoras = Math.round(diffMs / (1000 * 60 * 60));

        // Considerar vencendo em até 48h (ou atrasada em até 72h para não perder a criticidade)
        if (diffHoras <= 48 && diffHoras >= -72) {
          let prazoTexto = '';
          let severidade: 'critica' | 'alta' | 'media' | 'baixa' = 'alta';

          if (diffHoras < 0) {
            prazoTexto = `Vencida há ${Math.abs(Math.round(diffHoras / 24))} dia(s)`;
            severidade = 'critica';
          } else if (diffHoras <= 12) {
            prazoTexto = `Vence hoje (em ~${diffHoras}h)`;
            severidade = 'critica';
          } else if (diffHoras <= 24) {
            prazoTexto = `Vence em ~24 horas`;
            severidade = 'alta';
          } else {
            prazoTexto = `Vence em até 48 horas (${o.dataVencimento})`;
            severidade = 'media';
          }

          listaObrigacoes.push({
            id: `obrigacao-${o.id}`,
            tipo: 'obrigacao_48h',
            titulo: o.titulo,
            detalhe: `Competência ${o.competencia} • Responsável: ${o.responsavel}`,
            empresaNome: empresaMap[o.empresaId] || 'Empresa Geral',
            empresaId: o.empresaId,
            severidade,
            prazoTexto,
            horasRestantes: diffHoras,
            valor: o.valorTributo,
            dataReferencia: o.dataVencimento,
            targetSection: 'obrigacoes',
          });
        }
      });

    // Ordenar obrigações pela mais urgente (menor horasRestantes)
    listaObrigacoes.sort((a, b) => (a.horasRestantes ?? 0) - (b.horasRestantes ?? 0));

    // 2. Pendências e-CAC ativas (não resolvidas)
    const listaEcac: AlertaItem[] = [];

    pendenciasEcac
      .filter((p) => p.status !== 'resolvida')
      .forEach((p) => {
        let severidade: 'critica' | 'alta' | 'media' | 'baixa' = p.gravidade || 'alta';
        listaEcac.push({
          id: `ecac-${p.id}`,
          tipo: 'ecac_pendencia',
          titulo: p.titulo,
          detalhe: p.descricao,
          empresaNome: empresaMap[p.empresaId] || 'Empresa Geral',
          empresaId: p.empresaId,
          severidade,
          prazoTexto: `Detectado em ${p.dataDeteccao}`,
          orgao: p.orgao,
          valor: p.valorEnvolvido,
          dataReferencia: p.dataDeteccao,
          targetSection: 'ecac_pendencias',
        });
      });

    // Ordenar e-CAC por criticidade (crítica > alta > media > baixa)
    const pesoSev = { critica: 4, alta: 3, media: 2, baixa: 1 };
    listaEcac.sort((a, b) => (pesoSev[b.severidade] || 0) - (pesoSev[a.severidade] || 0));

    // Combinar
    const todos = [...listaObrigacoes, ...listaEcac];

    return {
      alertasObrigacoes: listaObrigacoes,
      alertasEcac: listaEcac,
      todosAlertas: todos,
    };
  }, [obrigacoes, pendenciasEcac, empresaMap]);

  // Filtrar apenas os alertas que não foram dispensados pelo usuário
  const alertasAtivos = useMemo(() => {
    return todosAlertas.filter((a) => !dismissedIds.includes(a.id));
  }, [todosAlertas, dismissedIds]);

  const obrigacoesAtivas = useMemo(() => {
    return alertasObrigacoes.filter((a) => !dismissedIds.includes(a.id));
  }, [alertasObrigacoes, dismissedIds]);

  const ecacAtivos = useMemo(() => {
    return alertasEcac.filter((a) => !dismissedIds.includes(a.id));
  }, [alertasEcac, dismissedIds]);

  // Lista a exibir de acordo com a aba selecionada
  const alertasExibidos = useMemo(() => {
    if (activeTab === 'obrigacoes') return obrigacoesAtivas;
    if (activeTab === 'ecac') return ecacAtivos;
    return alertasAtivos;
  }, [activeTab, alertasAtivos, obrigacoesAtivas, ecacAtivos]);

  // Verificar se o sistema está em silêncio temporário
  const isSilenced = useMemo(() => {
    if (!silencedUntil) return false;
    return Date.now() < silencedUntil;
  }, [silencedUntil]);

  // Tocar aviso sonoro quando houver alerta crítico e o som estiver habilitado
  useEffect(() => {
    if (somHabilitado && !isSilenced && alertasAtivos.length > 0) {
      // Pequeno debounce no mount
      const timer = setTimeout(() => {
        playChime();
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, [somHabilitado, isSilenced, alertasAtivos.length]);

  // Tentar emitir notificação nativa do navegador se autorizada
  const emitPushNotification = useCallback(
    (titulo: string, corpo: string) => {
      if (
        typeof window !== 'undefined' &&
        'Notification' in window &&
        Notification.permission === 'granted'
      ) {
        try {
          new Notification(titulo, {
            body: corpo,
            icon: '/favicon.ico',
            tag: 'contabgest-fiscal-alert',
          });
        } catch (err) {
          console.warn('Erro ao emitir Notificação do navegador:', err);
        }
      }
    },
    []
  );

  // Solicitar permissão de push do navegador
  const handleRequestPushPermission = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setPushBannerMsg('Notificações push não suportadas neste navegador.');
      return;
    }

    try {
      const permission = await Notification.requestPermission();
      setPushStatus(permission);

      if (permission === 'granted') {
        setPushBannerMsg('Notificações push ativadas com sucesso no seu navegador!');
        emitPushNotification(
          'ContabGest: Monitoramento Fiscal Ativo',
          'Você receberá alertas automáticos sobre prazos fiscais de 48h e pendências do e-CAC.'
        );
      } else if (permission === 'denied') {
        setPushBannerMsg('Permissão negada no navegador. Habilite nas configurações do site.');
      }
    } catch (err) {
      console.error('Erro ao solicitar permissão de push:', err);
    }
  };

  const handleTestPush = () => {
    if (pushStatus === 'granted') {
      const primeiro = alertasAtivos[0];
      const msg = primeiro
        ? `Atenção: ${primeiro.titulo} (${primeiro.prazoTexto})`
        : 'Sistema operacional: Nenhuma pendência crítica no momento.';
      emitPushNotification('ContabGest: Teste de Alerta Fiscal', msg);
      setPushBannerMsg('Notificação teste enviada para sua área de trabalho!');
    } else {
      handleRequestPushPermission();
    }
  };

  // Dispensar um alerta específico
  const handleDismissSingle = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const updated = [...dismissedIds, id];
    setDismissedIds(updated);
    localStorage.setItem('contabgest_dismissed_alert_ids', JSON.stringify(updated));
  };

  // Dispensar todos os alertas ativos
  const handleDismissAll = () => {
    const allIds = todosAlertas.map((a) => a.id);
    const combined = Array.from(new Set([...dismissedIds, ...allIds]));
    setDismissedIds(combined);
    localStorage.setItem('contabgest_dismissed_alert_ids', JSON.stringify(combined));
    setIsDismissed(true);
    setIsOpen(false);
  };

  // Restaurar alertas dispensados
  const handleRestoreDismissed = () => {
    setDismissedIds([]);
    localStorage.removeItem('contabgest_dismissed_alert_ids');
    setIsDismissed(false);
  };

  // Silenciar por 1 hora
  const handleSilence1Hour = () => {
    const umAHora = Date.now() + 60 * 60 * 1000;
    setSilencedUntil(umAHora);
    localStorage.setItem('contabgest_silenced_until', String(umAHora));
    setIsDismissed(true);
    setIsOpen(false);
  };

  const toggleSom = () => {
    const novoValor = !somHabilitado;
    setSomHabilitado(novoValor);
    localStorage.setItem('contabgest_alert_sound', novoValor ? 'enabled' : 'disabled');
  };

  const formatCurrency = (val?: number) => {
    if (val === undefined || val === null || val === 0) return null;
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
  };

  // Se não houver alertas e o usuário não abriu manualmente, ocultar toast principal
  const hasAlerts = alertasAtivos.length > 0;
  const countCriticos = alertasAtivos.filter((a) => a.severidade === 'critica').length;

  return (
    <>
      {/* 1. DOCK / TOAST FLUTUANTE NO CANTO INFERIOR DIREITO (RODAPÉ) */}
      <div
        id="footer-notification-system"
        className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 max-w-sm sm:max-w-md w-[calc(100vw-2rem)] pointer-events-none"
      >
        {/* Painel Expandido de Notificações */}
        {isOpen && (
          <div className="pointer-events-auto bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden mb-3 animate-in fade-in slide-in-from-bottom-3 duration-200">
            {/* Header do Painel */}
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-rose-500/20 text-rose-400 rounded-lg border border-rose-500/30">
                  <BellRing className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-sm tracking-tight text-white">
                      Alertas Fiscais & e-CAC
                    </h4>
                    {alertasAtivos.length > 0 && (
                      <span className="text-[10px] bg-rose-500 text-white font-bold px-1.5 py-0.5 rounded-full">
                        {alertasAtivos.length}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Monitoramento contínuo em tempo real (Prazos 48h & RFB)
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={toggleSom}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  title={somHabilitado ? 'Silenciar som de alerta' : 'Ativar som de alerta'}
                >
                  {somHabilitado ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </button>
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  title="Recolher painel"
                >
                  <ChevronDown className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Banner de Notificações Push do Navegador */}
            <div className="bg-slate-50 border-b border-slate-100 px-4 py-2.5 flex items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 text-slate-700">
                <Radio className={`w-3.5 h-3.5 ${pushStatus === 'granted' ? 'text-emerald-500' : 'text-amber-500'}`} />
                <span className="text-[11px] font-medium">
                  {pushStatus === 'granted'
                    ? 'Push no Navegador: Ativo'
                    : 'Push no Navegador: Não ativado'}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                {pushStatus === 'granted' ? (
                  <button
                    type="button"
                    onClick={handleTestPush}
                    className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-2 py-1 rounded transition-colors"
                  >
                    Testar Push
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleRequestPushPermission}
                    className="text-[10px] font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 px-2 py-1 rounded shadow-2xs transition-colors"
                  >
                    Ativar Push
                  </button>
                )}
              </div>
            </div>

            {pushBannerMsg && (
              <div className="bg-emerald-50 text-emerald-900 border-b border-emerald-100 px-4 py-1.5 text-[11px] flex items-center justify-between">
                <span>{pushBannerMsg}</span>
                <button
                  type="button"
                  onClick={() => setPushBannerMsg(null)}
                  className="text-emerald-700 hover:text-emerald-900 ml-2"
                >
                  ✕
                </button>
              </div>
            )}

            {/* Abas de Filtro */}
            <div className="flex border-b border-slate-100 bg-slate-50/50 p-1.5 gap-1 text-xs">
              <button
                type="button"
                onClick={() => setActiveTab('todos')}
                className={`flex-1 py-1.5 px-2 rounded-lg font-semibold text-center transition-all ${
                  activeTab === 'todos'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Todos ({alertasAtivos.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('obrigacoes')}
                className={`flex-1 py-1.5 px-2 rounded-lg font-semibold text-center transition-all ${
                  activeTab === 'obrigacoes'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Obrigações &lt; 48h ({obrigacoesAtivas.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('ecac')}
                className={`flex-1 py-1.5 px-2 rounded-lg font-semibold text-center transition-all ${
                  activeTab === 'ecac'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                e-CAC RFB ({ecacAtivos.length})
              </button>
            </div>

            {/* Lista com scroll de alertas */}
            <div className="max-h-80 overflow-y-auto p-3 space-y-2.5 divide-y divide-slate-100">
              {alertasExibidos.length === 0 ? (
                <div className="py-8 text-center text-slate-400 space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                  <p className="text-xs font-semibold text-slate-700">Tudo em dia!</p>
                  <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                    Nenhum alerta de obrigação fiscal vencendo em 48h ou pendência e-CAC não resolvida.
                  </p>
                  {dismissedIds.length > 0 && (
                    <button
                      type="button"
                      onClick={handleRestoreDismissed}
                      className="mt-2 text-xs font-medium text-emerald-600 hover:text-emerald-700 underline flex items-center gap-1 mx-auto"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Restaurar {dismissedIds.length} alertas dispensados</span>
                    </button>
                  )}
                </div>
              ) : (
                alertasExibidos.map((alerta) => (
                  <div
                    key={alerta.id}
                    className={`pt-2.5 first:pt-0 rounded-xl p-2.5 transition-all border ${
                      alerta.severidade === 'critica'
                        ? 'bg-rose-50/50 border-rose-200'
                        : alerta.severidade === 'alta'
                        ? 'bg-amber-50/40 border-amber-200'
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {alerta.tipo === 'obrigacao_48h' ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 border border-blue-200">
                            <Clock className="w-3 h-3" />
                            OBRIGAÇÃO FISCAL
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-100 text-purple-800 border border-purple-200">
                            <ShieldAlert className="w-3 h-3" />
                            e-CAC RFB {alerta.orgao ? `• ${alerta.orgao}` : ''}
                          </span>
                        )}

                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            alerta.severidade === 'critica'
                              ? 'bg-rose-600 text-white'
                              : alerta.severidade === 'alta'
                              ? 'bg-amber-500 text-white'
                              : 'bg-slate-200 text-slate-700'
                          }`}
                        >
                          {alerta.prazoTexto || alerta.severidade.toUpperCase()}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={(e) => handleDismissSingle(alerta.id, e)}
                        className="text-slate-400 hover:text-slate-600 p-0.5 rounded transition-colors"
                        title="Dispensar este alerta"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <h5 className="font-bold text-xs text-slate-900 leading-snug">
                      {alerta.titulo}
                    </h5>

                    <p className="text-[11px] text-slate-600 line-clamp-2 mt-0.5">
                      {alerta.detalhe}
                    </p>

                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100/80 text-[11px]">
                      <span className="font-medium text-slate-500 truncate max-w-[150px]">
                        {alerta.empresaNome}
                      </span>

                      {alerta.valor ? (
                        <span className="font-semibold text-slate-800">
                          {formatCurrency(alerta.valor)}
                        </span>
                      ) : null}

                      <button
                        type="button"
                        onClick={() => {
                          onNavigate(alerta.targetSection);
                          setIsOpen(false);
                        }}
                        className="font-bold text-emerald-600 hover:text-emerald-700 hover:underline flex items-center gap-1 ml-auto"
                      >
                        <span>Ver no Sistema</span>
                        <ExternalLink className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Rodapé de Ações do Painel */}
            <div className="bg-slate-50 p-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={handleSilence1Hour}
                  className="text-[11px] font-medium text-slate-600 hover:text-slate-900 px-2 py-1 rounded hover:bg-slate-200/60 transition-colors"
                >
                  Silenciar 1h
                </button>
                {dismissedIds.length > 0 && (
                  <button
                    type="button"
                    onClick={handleRestoreDismissed}
                    className="text-[11px] font-medium text-emerald-600 hover:text-emerald-800 px-2 py-1 rounded hover:bg-emerald-50 transition-colors"
                  >
                    Restaurar ({dismissedIds.length})
                  </button>
                )}
              </div>

              {alertasAtivos.length > 0 && (
                <button
                  type="button"
                  onClick={handleDismissAll}
                  className="text-[11px] font-semibold text-rose-600 hover:text-rose-700 px-2 py-1 rounded hover:bg-rose-50 transition-colors"
                >
                  Dispensar Todas
                </button>
              )}
            </div>
          </div>
        )}

        {/* Alerta Toast Compacto / Botão Flutuante quando fechado */}
        <div className="pointer-events-auto flex flex-col items-end gap-2">
          {/* Toast Banner Flutuante (mostrado se houver alertas ativos e não dispensado pelo usuário) */}
          {!isOpen && !isDismissed && hasAlerts && (
            <div
              onClick={() => setIsOpen(true)}
              className="group cursor-pointer bg-slate-900/95 backdrop-blur text-white p-3 sm:p-3.5 rounded-2xl shadow-xl border border-slate-700 hover:border-slate-500 transition-all flex items-start gap-3 w-full animate-in fade-in slide-in-from-bottom-2 duration-200"
            >
              <div className="relative mt-0.5">
                <div
                  className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                    countCriticos > 0
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                      : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  }`}
                >
                  <BellRing className="w-4 h-4 animate-bounce" />
                </div>
                <span
                  className={`absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 border-slate-900 ${
                    countCriticos > 0 ? 'bg-rose-500' : 'bg-amber-500'
                  }`}
                />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400">
                    {countCriticos > 0 ? 'Alerta Crítico Iminente' : 'Prazos Fiscais & e-CAC'}
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsDismissed(true);
                    }}
                    className="text-slate-400 hover:text-white p-0.5 rounded transition-colors"
                    title="Fechar banner"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                <p className="font-semibold text-xs text-white truncate mt-0.5">
                  {alertasAtivos[0]?.titulo}
                </p>

                <p className="text-[11px] text-slate-300 mt-0.5">
                  <span className="font-medium text-amber-300">
                    {alertasAtivos[0]?.prazoTexto}
                  </span>
                  {alertasAtivos.length > 1 && (
                    <span className="text-slate-400">
                      {' '}
                      • +{alertasAtivos.length - 1} outro(s) alerta(s)
                    </span>
                  )}
                </p>

                <div className="flex items-center gap-2 mt-2">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onNavigate(alertasAtivos[0].targetSection);
                    }}
                    className="text-[10px] font-bold bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1 shadow-xs"
                  >
                    <span>Resolver Agora</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsOpen(true);
                    }}
                    className="text-[10px] font-semibold text-slate-300 hover:text-white underline"
                  >
                    Ver todos ({alertasAtivos.length})
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Botão Flutuante de Gatilho / Dock (sempre disponível para reabrir) */}
          <button
            type="button"
            id="btn-footer-notification-dock"
            onClick={() => {
              setIsOpen(!isOpen);
              setIsDismissed(false);
            }}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-full shadow-lg border transition-all font-semibold text-xs ${
              isOpen
                ? 'bg-slate-900 text-white border-slate-700'
                : hasAlerts
                ? countCriticos > 0
                  ? 'bg-rose-600 text-white border-rose-500 hover:bg-rose-700 shadow-rose-500/20'
                  : 'bg-amber-600 text-white border-amber-500 hover:bg-amber-700 shadow-amber-500/20'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>Alertas</span>
            {alertasAtivos.length > 0 && (
              <span className="bg-white/20 px-1.5 py-0.2 rounded-full text-[10px] font-bold">
                {alertasAtivos.length}
              </span>
            )}
            {isOpen ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
    </>
  );
}
