import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Building2,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FolderArchive,
  ArrowUpRight,
  ArrowDownLeft,
  TrendingUp,
  Calendar,
  Filter,
  CheckSquare,
  Award,
  RefreshCw,
  ExternalLink,
  ChevronRight,
  FileText,
  ShieldCheck,
  ShieldAlert,
  Activity,
  CalendarCheck,
  FileBadge,
  Users,
  UserCheck,
  UserPlus,
  Briefcase,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
  Legend,
} from 'recharts';
import { DashboardMetrics, Empresa, Obrigacao, Tarefa, NavSection, Funcionario, AlvaraLicenca } from '../types';
import { api } from '../services/api';
import { AlvaraVencimentoBanner } from './AlvaraVencimentoBanner';

interface DashboardViewProps {
  metrics: DashboardMetrics;
  selectedEmpresa?: Empresa;
  obrigacoes: Obrigacao[];
  tarefas: Tarefa[];
  onNavigate: (section: NavSection) => void;
  onRefresh: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  metrics,
  selectedEmpresa,
  obrigacoes,
  tarefas,
  onNavigate,
  onRefresh,
}) => {
  const [activePeriod, setActivePeriod] = useState<'mes_atual' | 'trimestre' | 'ano'>('mes_atual');
  const [hoveredMonthIndex, setHoveredMonthIndex] = useState<number | null>(null);

  // Estado e dados de Recursos Humanos (RH)
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([]);
  const [loadingRh, setLoadingRh] = useState<boolean>(true);
  const [rhViewMode, setRhViewMode] = useState<'geral' | 'departamento'>('geral');
  const [alvaras, setAlvaras] = useState<AlvaraLicenca[]>([]);

  const loadAlvaras = useCallback(async () => {
    try {
      const data = await api.getAlvaras(selectedEmpresa?.id);
      setAlvaras(data || []);
    } catch (err) {
      console.error('Erro ao carregar alvarás:', err);
    }
  }, [selectedEmpresa?.id]);

  useEffect(() => {
    loadAlvaras();
  }, [loadAlvaras]);

  const loadFuncionarios = useCallback(async () => {
    try {
      setLoadingRh(true);
      const data = await api.getFuncionarios(selectedEmpresa?.id);
      setFuncionarios(data || []);
    } catch (err) {
      console.error('Erro ao carregar colaboradores do RH:', err);
    } finally {
      setLoadingRh(false);
    }
  }, [selectedEmpresa?.id]);

  useEffect(() => {
    loadFuncionarios();
  }, [loadFuncionarios]);

  // Cálculo da distribuição de colaboradores em Período de Experiência vs. Efetivos
  const rhDataCalculada = useMemo(() => {
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);

    // Considerar apenas colaboradores ativos e não desligados
    const ativos = funcionarios.filter((f) => f.status !== 'desligado');

    // Em Período de Experiência: possui data de término de experiência vigente (hoje ou futuro)
    const emExperiencia = ativos.filter((f) => {
      if (!f.terminoExperiencia) return false;
      const expDate = new Date(f.terminoExperiencia + 'T23:59:59');
      return !isNaN(expDate.getTime()) && expDate.getTime() >= hoje.getTime();
    });

    // Efetivos: colaboradores ativos regularizados (fora do período de experiência probatório)
    const efetivos = ativos.filter((f) => !emExperiencia.some((exp) => exp.id === f.id));

    const totalAtivos = ativos.length;
    const totalExperiencia = emExperiencia.length;
    const totalEfetivos = efetivos.length;

    const pctExperiencia = totalAtivos > 0 ? Math.round((totalExperiencia / totalAtivos) * 100) : 0;
    const pctEfetivos = totalAtivos > 0 ? Math.round((totalEfetivos / totalAtivos) * 100) : 0;

    // Dados para o Recharts BarChart (Visão Geral Comparativa)
    const dadosGerais = [
      {
        name: 'Efetivos',
        categoria: 'Efetivos (CLT Indeterminado)',
        quantidade: totalEfetivos,
        percentual: pctEfetivos,
        cor: '#10b981',
        descricao: 'Colaboradores regularizados no quadro efetivo permanente',
      },
      {
        name: 'Em Experiência',
        categoria: 'Em Experiência (Art. 445 CLT)',
        quantidade: totalExperiencia,
        percentual: pctExperiencia,
        cor: '#f59e0b',
        descricao: 'Colaboradores em período probatório de até 90 dias',
      },
    ];

    // Distribuição por departamento (Grouped Bar Chart)
    const deptosMap: Record<string, { departamento: string; efetivos: number; experiencia: number; total: number }> = {};
    ativos.forEach((f) => {
      const depto = f.departamento || 'Geral';
      if (!deptosMap[depto]) {
        deptosMap[depto] = { departamento: depto, efetivos: 0, experiencia: 0, total: 0 };
      }
      deptosMap[depto].total += 1;
      if (emExperiencia.some((exp) => exp.id === f.id)) {
        deptosMap[depto].experiencia += 1;
      } else {
        deptosMap[depto].efetivos += 1;
      }
    });

    const dadosDepartamentos = Object.values(deptosMap).sort((a, b) => b.total - a.total);

    // Lista de colaboradores em experiência com cálculo dos dias restantes
    const vencimentosProximos = emExperiencia
      .map((f) => {
        const expDate = new Date(f.terminoExperiencia + 'T23:59:59');
        const diffDays = Math.ceil((expDate.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
        return {
          ...f,
          diasRestantes: diffDays,
        };
      })
      .sort((a, b) => a.diasRestantes - b.diasRestantes);

    return {
      totalAtivos,
      totalExperiencia,
      totalEfetivos,
      pctExperiencia,
      pctEfetivos,
      dadosGerais,
      dadosDepartamentos,
      vencimentosProximos,
      emExperiencia,
      efetivos,
    };
  }, [funcionarios]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  // 7 requested cards
  const kpiCards = [
    {
      id: 'kpi-total-empresas',
      title: 'Total de Empresas',
      value: metrics.totalEmpresas,
      subtitle: selectedEmpresa ? 'Empresa selecionada' : 'Cadastradas no escritório',
      icon: Building2,
      color: 'emerald',
      bgColor: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
      badgeText: selectedEmpresa ? '1 Ativa' : `${metrics.empresasAtivas} Ativas`,
      onClick: () => onNavigate('empresas'),
    },
    {
      id: 'kpi-empresas-ativas',
      title: 'Empresas Ativas',
      value: metrics.empresasAtivas,
      subtitle: 'Em operação regular',
      icon: CheckCircle2,
      color: 'teal',
      bgColor: 'bg-teal-500/10 text-teal-600 border-teal-500/20',
      badgeText: 'Status Regular',
      onClick: () => onNavigate('empresas'),
    },
    {
      id: 'kpi-obrigacoes-pendentes',
      title: 'Obrigações Pendentes',
      value: metrics.obrigacoesPendentes,
      subtitle: 'Exigem apuração ou envio',
      icon: AlertTriangle,
      color: 'rose',
      bgColor: 'bg-rose-500/10 text-rose-600 border-rose-500/20',
      badgeText: 'Atenção',
      onClick: () => onNavigate('obrigacoes'),
    },
    {
      id: 'kpi-obrigacoes-vencendo',
      title: 'Obrigações Vencendo',
      value: metrics.obrigacoesVencendo,
      subtitle: 'Vencimento nos próx. 7 dias',
      icon: Clock,
      color: 'amber',
      bgColor: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
      badgeText: 'Próximos 7 dias',
      onClick: () => onNavigate('obrigacoes'),
    },
    {
      id: 'kpi-documentos-pendentes',
      title: 'Documentos Pendentes',
      value: metrics.documentosPendentes,
      subtitle: 'Aguardando validação fiscal',
      icon: FolderArchive,
      color: 'blue',
      bgColor: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
      badgeText: 'Entrada pendente',
      onClick: () => onNavigate('documentos'),
    },
    {
      id: 'kpi-contas-pagar',
      title: 'Contas a Pagar',
      value: formatCurrency(metrics.valorContasPagar),
      subtitle: `${metrics.totalContasPagar} títulos em aberto`,
      icon: ArrowDownLeft,
      color: 'orange',
      bgColor: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
      badgeText: 'Despesas',
      onClick: () => onNavigate('financeiro'),
    },
    {
      id: 'kpi-contas-receber',
      title: 'Contas a Receber',
      value: formatCurrency(metrics.valorContasReceber),
      subtitle: `${metrics.totalContasReceber} faturas a receber`,
      icon: ArrowUpRight,
      color: 'indigo',
      bgColor: 'bg-indigo-500/10 text-indigo-600 border-indigo-500/20',
      badgeText: 'Receitas',
      onClick: () => onNavigate('financeiro'),
    },
  ];

  // Calculations for Financial Bar Chart
  const maxFinancialValue = Math.max(
    ...metrics.monthlyFlow.map((m) => Math.max(m.receber, m.pagar)),
    100000
  );

  // Status breakdown total
  const totalStatus =
    metrics.statusObrigacoes.concluidas +
    metrics.statusObrigacoes.pendentes +
    metrics.statusObrigacoes.vencendo +
    metrics.statusObrigacoes.atrasadas;

  return (
    <div className="space-y-6 pb-12">
      {/* Lembrete Automático: Alvarás e Licenças Vencendo em até 30 dias */}
      <AlvaraVencimentoBanner
        alvaras={alvaras}
        onNavigateToAlvaras={() => onNavigate('alvaras_licencas')}
      />

      {/* View Header & Quick Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-4 sm:p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              {selectedEmpresa
                ? `${selectedEmpresa.nomeFantasia}`
                : 'Painel Contábil Consolidado'}
            </h1>
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
              DEMO
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {selectedEmpresa
              ? `CNPJ ${selectedEmpresa.cnpj} • Regime: ${selectedEmpresa.regimeTributario} • Cidade: ${selectedEmpresa.cidade}/${selectedEmpresa.uf}`
              : 'Visão executiva integrada de todas as empresas e clientes assessorados'}
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="inline-flex rounded-lg bg-slate-100 p-1 border border-slate-200 text-xs font-semibold">
            <button
              onClick={() => setActivePeriod('mes_atual')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activePeriod === 'mes_atual'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mês Vigente (Set/26)
            </button>
            <button
              onClick={() => setActivePeriod('trimestre')}
              className={`px-3 py-1.5 rounded-md transition-all ${
                activePeriod === 'trimestre'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              3º Trimestre
            </button>
          </div>

          <button
            onClick={() => {
              onRefresh();
              loadFuncionarios();
            }}
            className="p-2 rounded-lg border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors"
            title="Atualizar indicadores"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 7 KPI Metric Cards Grid */}
      <div>
        <div className="flex items-center justify-between mb-3 px-0.5">
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500">
            Indicadores Chave de Desempenho (KPIs) [DEMO]
          </h2>
          <span className="text-[11px] text-slate-400">
            Atualizado em tempo real via API
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {kpiCards.map((kpi) => {
            const Icon = kpi.icon;
            return (
              <div
                key={kpi.id}
                id={kpi.id}
                onClick={kpi.onClick}
                className="bg-white rounded-xl p-4 sm:p-5 border border-slate-200 shadow-xs hover:shadow-md hover:border-slate-300 transition-all cursor-pointer group flex flex-col justify-between"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1">
                    <span className="text-xs font-medium text-slate-500 block">
                      {kpi.title}
                    </span>
                    <div className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight group-hover:text-emerald-600 transition-colors">
                      {kpi.value}
                    </div>
                  </div>
                  <div className={`p-2.5 rounded-xl border ${kpi.bgColor} shrink-0`}>
                    <Icon className="w-5 h-5" />
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500 truncate">{kpi.subtitle}</span>
                  <span className="font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[10px] shrink-0 border border-emerald-100">
                    {kpi.badgeText}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* MÓDULOS FISCAIS & VELOCÍMETRO RECEITA FEDERAL (E-CAC) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                Central de Conformidade Fiscal & Conexão Receita Federal (e-CAC)
              </h3>
              <p className="text-xs text-slate-500">
                Velocímetro de regularidade em tempo real, emissão de NF-e e controle de certificados digitais
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
            <button
              onClick={() => onNavigate('conformidade_fiscal')}
              className="text-xs font-semibold px-2.5 py-1.5 rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-300 flex items-center gap-1.5 transition"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>Radar de Conformidade</span>
            </button>
            <button
              onClick={() => onNavigate('ecac_pendencias')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              <span>Acessar e-CAC</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          {/* Mini Velocímetro (0 a 100%) */}
          <div className="md:col-span-4 bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col items-center justify-center text-center">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Velocímetro e-CAC (0 a 100%)
            </span>
            <div className="relative w-44 h-24 flex items-center justify-center">
              <svg viewBox="0 0 200 120" className="w-full h-full">
                <defs>
                  <linearGradient id="dashSpeedometerGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#ef4444" />
                    <stop offset="40%" stopColor="#f59e0b" />
                    <stop offset="75%" stopColor="#3b82f6" />
                    <stop offset="100%" stopColor="#10b981" />
                  </linearGradient>
                </defs>
                <path
                  d="M 20 105 A 80 80 0 0 1 180 105"
                  fill="none"
                  stroke="#e2e8f0"
                  strokeWidth="16"
                  strokeLinecap="round"
                />
                <path
                  d="M 20 105 A 80 80 0 0 1 180 105"
                  fill="none"
                  stroke="url(#dashSpeedometerGrad)"
                  strokeWidth="16"
                  strokeLinecap="round"
                  strokeDasharray="251.32"
                  strokeDashoffset={
                    251.32 - ((metrics.pendenciasEcacResolvidasPercentual ?? 80) / 100) * 251.32
                  }
                  style={{ transition: 'stroke-dashoffset 0.8s ease' }}
                />
                <circle cx="100" cy="105" r="7" fill="#1e293b" />
                {/* Needle */}
                <g
                  transform={`rotate(${
                    -90 + ((metrics.pendenciasEcacResolvidasPercentual ?? 80) / 100) * 180
                  } 100 105)`}
                  style={{ transition: 'transform 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)' }}
                >
                  <polygon points="97,105 103,105 101,35 99,35" fill="#0f172a" />
                  <circle cx="100" cy="35" r="2.5" fill="#10b981" />
                </g>
              </svg>
              <div className="absolute bottom-0 text-center">
                <span className="text-2xl font-black text-slate-900 leading-none">
                  {metrics.pendenciasEcacResolvidasPercentual ?? 80}%
                </span>
              </div>
            </div>
            <p className="text-[11px] text-slate-600 mt-1">
              <strong>{metrics.pendenciasEcacPendentes ?? 1}</strong> pendência(s) em aberto na RFB
            </p>
          </div>

          {/* 4 Quick Access Cards */}
          <div className="md:col-span-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Notas Fiscais */}
            <div
              onClick={() => onNavigate('notas_fiscais')}
              className="p-3.5 bg-emerald-50/50 border border-emerald-200 rounded-xl hover:bg-emerald-50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between mb-2">
                <FileText className="w-5 h-5 text-emerald-600" />
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                  SEFAZ
                </span>
              </div>
              <h4 className="text-xs font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
                Emissor de NF-e
              </h4>
              <p className="text-[11px] text-slate-600 mt-0.5">
                {metrics.totalNotasEmitidas ?? 4} notas emitidas no mês
              </p>
              <span className="text-[11px] font-semibold text-emerald-700 mt-2 inline-flex items-center gap-0.5">
                Emitir Nova <ChevronRight className="w-3 h-3" />
              </span>
            </div>

            {/* Certificados Digitais */}
            <div
              onClick={() => onNavigate('certificados_digitais')}
              className="p-3.5 bg-indigo-50/50 border border-indigo-200 rounded-xl hover:bg-indigo-50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between mb-2">
                <ShieldCheck className="w-5 h-5 text-indigo-600" />
                <span className="text-[10px] font-bold text-indigo-700 bg-indigo-100 px-1.5 py-0.5 rounded">
                  ICP-Brasil
                </span>
              </div>
              <h4 className="text-xs font-bold text-slate-900 group-hover:text-indigo-700 transition-colors">
                Certificados Digitais
              </h4>
              <p className="text-[11px] text-slate-600 mt-0.5">
                {metrics.certificadosAlerta ?? 2} requerem atenção
              </p>
              <span className="text-[11px] font-semibold text-indigo-700 mt-2 inline-flex items-center gap-0.5">
                Instalador A1 <ChevronRight className="w-3 h-3" />
              </span>
            </div>

            {/* Alvarás e Licenças */}
            <div
              onClick={() => onNavigate('alvaras_licencas')}
              className="p-3.5 bg-amber-50/50 border border-amber-200 rounded-xl hover:bg-amber-50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between mb-2">
                <FileBadge className="w-5 h-5 text-amber-600" />
                <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded">
                  Imobiliário
                </span>
              </div>
              <h4 className="text-xs font-bold text-slate-900 group-hover:text-amber-800 transition-colors">
                Alvarás & AVCB
              </h4>
              <p className="text-[11px] text-slate-600 mt-0.5">
                VISA, Bombeiros e IPTU
              </p>
              <span className="text-[11px] font-semibold text-amber-700 mt-2 inline-flex items-center gap-0.5">
                Gerenciar <ChevronRight className="w-3 h-3" />
              </span>
            </div>

            {/* Controle de Entregas */}
            <div
              onClick={() => onNavigate('controle_entregas')}
              className="p-3.5 bg-purple-50/50 border border-purple-200 rounded-xl hover:bg-purple-50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center justify-between mb-2">
                <CalendarCheck className="w-5 h-5 text-purple-600" />
                <span className="text-[10px] font-bold text-purple-700 bg-purple-100 px-1.5 py-0.5 rounded">
                  Fiscais
                </span>
              </div>
              <h4 className="text-xs font-bold text-slate-900 group-hover:text-purple-700 transition-colors">
                Controle de Entregas
              </h4>
              <p className="text-[11px] text-slate-600 mt-0.5">
                Pipeline & Matriz mensal
              </p>
              <span className="text-[11px] font-semibold text-purple-700 mt-2 inline-flex items-center gap-0.5">
                Acompanhar <ChevronRight className="w-3 h-3" />
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* CHARTS SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart: Financial Comparison (Receitas vs Despesas) */}
        <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 mb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-900 text-base">
                  Fluxo Financeiro Mensal (Receber vs Pagar)
                </h3>
                <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
                  DEMO
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Comparativo histórico de contas a receber e contas a pagar nos últimos 6 meses
              </p>
            </div>

            <div className="flex items-center gap-4 text-xs font-medium">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-sm bg-emerald-500"></span>
                <span className="text-slate-600">A Receber</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-sm bg-rose-500"></span>
                <span className="text-slate-600">A Pagar</span>
              </div>
            </div>
          </div>

          {/* Bar Chart Visualization */}
          <div className="h-64 sm:h-72 w-full flex flex-col justify-end pt-4">
            <div className="h-full flex items-end justify-between gap-2 sm:gap-4 px-2">
              {metrics.monthlyFlow.map((item, idx) => {
                const receberHeight = Math.max(
                  Math.round((item.receber / maxFinancialValue) * 100),
                  8
                );
                const pagarHeight = Math.max(
                  Math.round((item.pagar / maxFinancialValue) * 100),
                  8
                );
                const isHovered = hoveredMonthIndex === idx;

                return (
                  <div
                    key={item.mes}
                    className="flex-1 flex flex-col items-center h-full justify-end group relative"
                    onMouseEnter={() => setHoveredMonthIndex(idx)}
                    onMouseLeave={() => setHoveredMonthIndex(null)}
                  >
                    {/* Tooltip on hover */}
                    {isHovered && (
                      <div className="absolute -top-16 z-20 bg-slate-900 text-white rounded-lg p-2 text-[11px] shadow-lg pointer-events-none whitespace-nowrap min-w-[140px] text-center">
                        <p className="font-bold text-slate-200 border-b border-slate-700 pb-1 mb-1">
                          {item.mes} [DEMO]
                        </p>
                        <p className="text-emerald-400">
                          Rec: {formatCurrency(item.receber)}
                        </p>
                        <p className="text-rose-400">
                          Pag: {formatCurrency(item.pagar)}
                        </p>
                        <p className="text-slate-300 font-semibold pt-0.5">
                          Saldo: {formatCurrency(item.saldo)}
                        </p>
                      </div>
                    )}

                    {/* Bars Container */}
                    <div className="w-full flex items-end justify-center gap-1 sm:gap-2 h-48">
                      {/* Receber Bar */}
                      <div
                        style={{ height: `${receberHeight}%` }}
                        className="w-1/2 max-w-[28px] bg-emerald-500 hover:bg-emerald-400 rounded-t-md transition-all duration-300 relative"
                      ></div>
                      {/* Pagar Bar */}
                      <div
                        style={{ height: `${pagarHeight}%` }}
                        className="w-1/2 max-w-[28px] bg-rose-500 hover:bg-rose-400 rounded-t-md transition-all duration-300 relative"
                      ></div>
                    </div>

                    {/* Month Label */}
                    <span className="text-[11px] font-semibold text-slate-500 mt-2 text-center truncate w-full">
                      {item.mes}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Secondary Chart: Obligations Status Breakdown */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-slate-900 text-base">
                  Status das Obrigações Fiscais
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Conformidade tributária geral
                </p>
              </div>
              <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
                DEMO
              </span>
            </div>

            {/* Compliance Circular / Progress Indicator */}
            <div className="mt-5 p-4 rounded-xl bg-slate-50 border border-slate-200 text-center">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Taxa de Entregas no Prazo
              </span>
              <div className="text-3xl font-extrabold text-emerald-600 mt-1">
                {metrics.taxaConformidade}%
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2.5 mt-2.5 overflow-hidden">
                <div
                  className="bg-emerald-500 h-2.5 rounded-full transition-all duration-500"
                  style={{ width: `${metrics.taxaConformidade}%` }}
                ></div>
              </div>
            </div>

            {/* Status Breakdown List */}
            <div className="mt-5 space-y-2.5 text-xs">
              <div className="flex items-center justify-between p-2 rounded-lg bg-emerald-50/70 border border-emerald-100">
                <div className="flex items-center gap-2 font-medium text-emerald-800">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                  <span>Concluídas e Transmitidas</span>
                </div>
                <span className="font-bold text-emerald-900">
                  {metrics.statusObrigacoes.concluidas}
                </span>
              </div>

              <div className="flex items-center justify-between p-2 rounded-lg bg-amber-50/70 border border-amber-100">
                <div className="flex items-center gap-2 font-medium text-amber-800">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                  <span>Vencendo nos Próximos 7 Dias</span>
                </div>
                <span className="font-bold text-amber-900">
                  {metrics.statusObrigacoes.vencendo}
                </span>
              </div>

              <div className="flex items-center justify-between p-2 rounded-lg bg-blue-50/70 border border-blue-100">
                <div className="flex items-center gap-2 font-medium text-blue-800">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
                  <span>Pendentes de Apuração</span>
                </div>
                <span className="font-bold text-blue-900">
                  {metrics.statusObrigacoes.pendentes}
                </span>
              </div>

              <div className="flex items-center justify-between p-2 rounded-lg bg-rose-50/70 border border-rose-100">
                <div className="flex items-center gap-2 font-medium text-rose-800">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                  <span>Atrasadas (Alerta Imediato)</span>
                </div>
                <span className="font-bold text-rose-900">
                  {metrics.statusObrigacoes.atrasadas}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigate('obrigacoes')}
            className="w-full mt-4 py-2 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 transition-colors flex items-center justify-center gap-1.5"
          >
            <span>Ver calendário completo de obrigações</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* GESTÃO DE CAPITAL HUMANO: GRÁFICO DE BARRAS EXPERIÊNCIA VS. EFETIVOS (MÓDULO DE RH) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-900 text-base">
                  Quadro de Colaboradores: Período de Experiência vs. Efetivos
                </h3>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded border border-emerald-200">
                  MÓDULO RH
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Monitoramento estatístico de contratos probatórios CLT (Art. 445 e 451) e efetivação do quadro funcional
                {selectedEmpresa ? ` • ${selectedEmpresa.nomeFantasia}` : ' • Todas as Empresas'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            {/* View Mode Switcher */}
            <div className="inline-flex rounded-lg bg-slate-100 p-0.5 border border-slate-200 text-xs font-medium">
              <button
                type="button"
                onClick={() => setRhViewMode('geral')}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  rhViewMode === 'geral'
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Comparativo Geral
              </button>
              <button
                type="button"
                onClick={() => setRhViewMode('departamento')}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  rhViewMode === 'departamento'
                    ? 'bg-white text-slate-900 shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Por Departamento
              </button>
            </div>

            <button
              onClick={() => onNavigate('rh')}
              className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 ml-1 hover:underline"
            >
              <span>Acessar RH</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Layout: 8 cols Chart + 4 cols Alertas & Indicadores */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Main Chart Column */}
          <div className="lg:col-span-8 flex flex-col justify-between">
            {loadingRh ? (
              <div className="h-64 flex flex-col items-center justify-center text-slate-400 gap-2">
                <RefreshCw className="w-6 h-6 animate-spin text-emerald-600" />
                <span className="text-xs font-medium">Carregando dados funcionais do RH...</span>
              </div>
            ) : rhDataCalculada.totalAtivos === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center text-slate-400 gap-2 bg-slate-50 rounded-xl border border-dashed border-slate-200 p-6 text-center">
                <Users className="w-8 h-8 text-slate-300" />
                <p className="text-xs font-medium text-slate-600">
                  Nenhum colaborador ativo cadastrado para a empresa selecionada.
                </p>
                <button
                  onClick={() => onNavigate('rh')}
                  className="mt-2 text-xs font-semibold text-emerald-600 hover:text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200"
                >
                  Cadastrar no Módulo de RH
                </button>
              </div>
            ) : (
              <div>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    {rhViewMode === 'geral' ? (
                      <BarChart
                        data={rhDataCalculada.dadosGerais}
                        margin={{ top: 20, right: 25, left: -10, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis
                          dataKey="name"
                          tick={{ fill: '#334155', fontSize: 13, fontWeight: 600 }}
                          axisLine={{ stroke: '#cbd5e1' }}
                          tickLine={false}
                        />
                        <YAxis
                          allowDecimals={false}
                          tick={{ fill: '#64748b', fontSize: 12 }}
                          axisLine={{ stroke: '#cbd5e1' }}
                          tickLine={false}
                        />
                        <Tooltip
                          content={({ active, payload }) => {
                            if (active && payload && payload.length) {
                              const d = payload[0].payload;
                              return (
                                <div className="bg-slate-900 text-white p-3 rounded-lg shadow-xl text-xs border border-slate-700 min-w-[210px]">
                                  <div className="flex items-center gap-2 pb-1.5 border-b border-slate-700 mb-2">
                                    <span
                                      className="w-2.5 h-2.5 rounded-full shrink-0"
                                      style={{ backgroundColor: d.cor }}
                                    />
                                    <span className="font-bold text-slate-100 text-sm">{d.categoria}</span>
                                  </div>
                                  <p className="text-slate-300 text-[11px] mb-2">{d.descricao}</p>
                                  <div className="space-y-1 pt-1 border-t border-slate-800 text-[11px]">
                                    <div className="flex justify-between items-center text-slate-300">
                                      <span>Quantidade:</span>
                                      <span className="font-bold text-white text-xs">
                                        {d.quantidade} colaborador{d.quantidade !== 1 ? 'es' : ''}
                                      </span>
                                    </div>
                                    <div className="flex justify-between items-center text-slate-300">
                                      <span>Percentual:</span>
                                      <span className="font-bold text-emerald-400 text-xs">
                                        {d.percentual}% do total
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Bar
                          dataKey="quantidade"
                          radius={[8, 8, 0, 0]}
                          barSize={64}
                        >
                          {rhDataCalculada.dadosGerais.map((entry, index) => (
                            <Cell key={`rh-cell-${index}`} fill={entry.cor} />
                          ))}
                        </Bar>
                      </BarChart>
                    ) : (
                      <BarChart
                        data={rhDataCalculada.dadosDepartamentos}
                        margin={{ top: 20, right: 25, left: -10, bottom: 25 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis
                          dataKey="departamento"
                          tick={{ fill: '#475569', fontSize: 11 }}
                          interval={0}
                          angle={-15}
                          textAnchor="end"
                          axisLine={{ stroke: '#cbd5e1' }}
                          tickLine={false}
                        />
                        <YAxis
                          allowDecimals={false}
                          tick={{ fill: '#64748b', fontSize: 12 }}
                          axisLine={{ stroke: '#cbd5e1' }}
                          tickLine={false}
                        />
                        <Tooltip
                          content={({ active, payload, label }) => {
                            if (active && payload && payload.length) {
                              return (
                                <div className="bg-slate-900 text-white p-3 rounded-lg shadow-xl text-xs border border-slate-700 min-w-[200px]">
                                  <p className="font-bold text-slate-100 text-xs pb-1.5 border-b border-slate-700 mb-2">
                                    {label}
                                  </p>
                                  <div className="space-y-1.5 text-[11px]">
                                    {payload.map((item: any, idx: number) => (
                                      <div key={idx} className="flex justify-between items-center">
                                        <div className="flex items-center gap-1.5">
                                          <span
                                            className="w-2 h-2 rounded-full shrink-0"
                                            style={{ backgroundColor: item.color }}
                                          />
                                          <span className="text-slate-300">{item.name}:</span>
                                        </div>
                                        <span className="font-bold text-white">
                                          {item.value} colaborador{item.value !== 1 ? 'es' : ''}
                                        </span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Legend
                          verticalAlign="top"
                          align="right"
                          iconSize={10}
                          wrapperStyle={{ paddingBottom: '10px', fontSize: '11px' }}
                        />
                        <Bar
                          name="Efetivos"
                          dataKey="efetivos"
                          fill="#10b981"
                          radius={[4, 4, 0, 0]}
                          barSize={20}
                        />
                        <Bar
                          name="Em Experiência"
                          dataKey="experiencia"
                          fill="#f59e0b"
                          radius={[4, 4, 0, 0]}
                          barSize={20}
                        />
                      </BarChart>
                    )}
                  </ResponsiveContainer>
                </div>

                {/* Badges de Resumo do Gráfico */}
                <div className="grid grid-cols-3 gap-3 pt-3 mt-2 border-t border-slate-100 text-center">
                  <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                    <span className="text-[11px] font-semibold text-slate-500 uppercase block">
                      Total Ativos
                    </span>
                    <span className="text-lg font-bold text-slate-900 mt-0.5 block">
                      {rhDataCalculada.totalAtivos}
                    </span>
                    <span className="text-[10px] text-slate-400">Headcount Ativo</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-emerald-50/70 border border-emerald-100">
                    <span className="text-[11px] font-semibold text-emerald-800 uppercase block">
                      Efetivos
                    </span>
                    <span className="text-lg font-bold text-emerald-700 mt-0.5 block">
                      {rhDataCalculada.totalEfetivos}
                    </span>
                    <span className="text-[10px] font-medium text-emerald-600">
                      {rhDataCalculada.pctEfetivos}% do quadro
                    </span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-amber-50/70 border border-amber-100">
                    <span className="text-[11px] font-semibold text-amber-800 uppercase block">
                      Em Experiência
                    </span>
                    <span className="text-lg font-bold text-amber-700 mt-0.5 block">
                      {rhDataCalculada.totalExperiencia}
                    </span>
                    <span className="text-[10px] font-medium text-amber-600">
                      {rhDataCalculada.pctExperiencia}% em avaliação
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Side Info & Alert Panel Column */}
          <div className="lg:col-span-4 bg-slate-50 rounded-xl p-4 border border-slate-200 flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-200 mb-2">
                <div className="flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-amber-600" />
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                    Vencimentos de Experiência
                  </span>
                </div>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200">
                  {rhDataCalculada.totalExperiencia} Ativo{rhDataCalculada.totalExperiencia !== 1 ? 's' : ''}
                </span>
              </div>

              {rhDataCalculada.vencimentosProximos.length > 0 ? (
                <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                  {rhDataCalculada.vencimentosProximos.map((f) => (
                    <div
                      key={f.id}
                      className="bg-white p-2.5 rounded-lg border border-slate-200 shadow-2xs space-y-1 text-xs"
                    >
                      <div className="flex items-start justify-between gap-1">
                        <div>
                          <p className="font-semibold text-slate-900 leading-snug">{f.nomeCompleto}</p>
                          <p className="text-[11px] text-slate-500">{f.cargoNome}</p>
                        </div>
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded shrink-0 ${
                            f.diasRestantes <= 10
                              ? 'bg-rose-100 text-rose-800 border border-rose-200 animate-pulse'
                              : f.diasRestantes <= 30
                              ? 'bg-amber-100 text-amber-800 border border-amber-200'
                              : 'bg-blue-100 text-blue-800 border border-blue-200'
                          }`}
                        >
                          {f.diasRestantes <= 0
                            ? 'Vence hoje'
                            : `${f.diasRestantes} dia${f.diasRestantes > 1 ? 's' : ''}`}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-slate-600 pt-1 border-t border-slate-100">
                        <span>Término: <strong>{f.terminoExperiencia}</strong></span>
                        <span className="text-slate-400">{f.departamento}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-6 text-center text-slate-500 space-y-1.5">
                  <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto" />
                  <p className="text-xs font-medium text-slate-700">
                    Nenhum contrato em experiência pendente.
                  </p>
                  <p className="text-[11px] text-slate-400">
                    100% dos colaboradores ativos estão regularizados no quadro efetivo.
                  </p>
                </div>
              )}
            </div>

            {/* CLT Guideline Box */}
            <div className="p-2.5 rounded-lg bg-amber-50/70 border border-amber-200 text-[11px] text-amber-900 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-amber-800">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                <span>Atenção Contábil & Trabalhista</span>
              </div>
              <p className="text-[10px] text-amber-700 leading-tight">
                Pelo Art. 451 da CLT, contratos de experiência não rescindidos até o termo final convertem-se automaticamente em prazo indeterminado.
              </p>
            </div>

            <button
              onClick={() => onNavigate('rh')}
              className="w-full py-2 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 transition-colors flex items-center justify-center gap-1.5"
            >
              <span>Gerenciar Contratos no RH</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* QUICK WORKSPACE PANELS: Prioritized Obligations & Open Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Urgent Obligations Panel */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                Obrigações Críticas e Próximos Vencimentos
              </h3>
              <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
                DEMO
              </span>
            </div>
            <button
              onClick={() => onNavigate('obrigacoes')}
              className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
            >
              <span>Gerenciar</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {obrigacoes.slice(0, 4).map((ob) => (
              <div
                key={ob.id}
                className="py-3 flex items-start justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-900">{ob.titulo}</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        ob.status === 'concluida'
                          ? 'bg-emerald-100 text-emerald-800'
                          : ob.status === 'atrasada'
                          ? 'bg-rose-100 text-rose-800'
                          : ob.status === 'vencendo'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {ob.status.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-slate-500 text-[11px]">
                    Competência: <strong className="text-slate-700">{ob.competencia}</strong> • Vence em:{' '}
                    <strong className="text-slate-700">{ob.dataVencimento}</strong> • Responsável:{' '}
                    {ob.responsavel}
                  </p>
                </div>

                <div className="text-right shrink-0">
                  {ob.valorTributo ? (
                    <span className="font-bold text-slate-900 block">
                      {formatCurrency(ob.valorTributo)}
                    </span>
                  ) : (
                    <span className="text-slate-400 text-[11px]">Declaração sem valor</span>
                  )}
                  <span className="text-[10px] text-slate-400">
                    {ob.guiaEmitida ? '✓ Guia Gerada' : 'Pendente de Guia'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Accounting Tasks Panel */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                Tarefas Operacionais do Escritório
              </h3>
              <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
                DEMO
              </span>
            </div>
            <button
              onClick={() => onNavigate('tarefas')}
              className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1"
            >
              <span>Ver todas</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {tarefas.slice(0, 4).map((t) => (
              <div
                key={t.id}
                className="py-3 flex items-start justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-900">{t.titulo}</span>
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        t.prioridade === 'urgente'
                          ? 'bg-rose-100 text-rose-800'
                          : t.prioridade === 'alta'
                          ? 'bg-orange-100 text-orange-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {t.prioridade.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-slate-500 text-[11px] line-clamp-1">{t.descricao}</p>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[11px] text-slate-600 font-medium block">
                    {t.responsavel}
                  </span>
                  <span className="text-[10px] text-slate-400">Prazo: {t.dataVencimento}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
