import React, { useState, useEffect, useMemo } from 'react';
import {
  Users,
  Briefcase,
  DollarSign,
  Calendar,
  ShieldCheck,
  Search,
  Plus,
  Filter,
  RefreshCw,
  FileText,
  Trash2,
  Edit,
  Eye,
  Umbrella,
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Download,
  Building,
  Check,
  UserCheck,
  LayoutDashboard,
  Calculator,
  TrendingUp,
} from 'lucide-react';
import {
  Funcionario,
  FuncaoRH,
  Empresa,
  HoleriteCalculado,
  StatusFuncionario,
} from '../types';
import { api } from '../services/api';
import { RHMetricsHeader } from './rh/RHMetricsHeader';
import { RHDashboard } from './rh/RHDashboard';
import { TurnoverCargosPanel } from './rh/TurnoverCargosPanel';
import { FuncionarioModal } from './rh/FuncionarioModal';
import { FuncaoModal } from './rh/FuncaoModal';
import { HoleriteModal } from './rh/HoleriteModal';
import { FeriasAfastamentoModal } from './rh/FeriasAfastamentoModal';
import { FuncionarioDossieModal } from './rh/FuncionarioDossieModal';
import { FolhaPagamentoModule } from './rh/FolhaPagamentoModule';
import { PontoEletronicoModule } from './rh/PontoEletronicoModule';
import { ControleFeriasDashboard } from './rh/ControleFeriasDashboard';
import { RescisaoModule } from './rh/RescisaoModule';
import { EspelhoPontoModal } from './rh/EspelhoPontoModal';
import { ESocialConfigModule } from './rh/ESocialConfigModule';

interface RHViewProps {
  selectedEmpresa?: Empresa | null;
  empresas: Empresa[];
  onRefresh?: () => void;
}

type TabType = 'dashboard' | 'turnover' | 'colaboradores' | 'funcoes' | 'ponto' | 'folha' | 'ferias' | 'rescisao' | 'esocial';

export const RHView: React.FC<RHViewProps> = ({
  selectedEmpresa,
  empresas,
  onRefresh,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([]);
  const [funcoes, setFuncoes] = useState<FuncaoRH[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('todos');
  const [departamentoFilter, setDepartamentoFilter] = useState<string>('todos');
  const [competenciaFolha, setCompetenciaFolha] = useState<string>('09/2026');

  // Modals state
  const [isFuncionarioModalOpen, setIsFuncionarioModalOpen] = useState(false);
  const [funcionarioToEdit, setFuncionarioToEdit] = useState<Funcionario | null>(null);

  const [isFuncaoModalOpen, setIsFuncaoModalOpen] = useState(false);
  const [funcaoToEdit, setFuncaoToEdit] = useState<FuncaoRH | null>(null);

  const [isHoleriteModalOpen, setIsHoleriteModalOpen] = useState(false);
  const [selectedHoleriteFuncionario, setSelectedHoleriteFuncionario] = useState<Funcionario | null>(null);
  const [calculatedHolerite, setCalculatedHolerite] = useState<HoleriteCalculado | null>(null);

  const [isFeriasModalOpen, setIsFeriasModalOpen] = useState(false);
  const [feriasMode, setFeriasMode] = useState<'ferias' | 'afastamento'>('ferias');
  const [targetFeriasFuncionario, setTargetFeriasFuncionario] = useState<Funcionario | null>(null);

  const [isDossieModalOpen, setIsDossieModalOpen] = useState(false);
  const [targetDossieFuncionario, setTargetDossieFuncionario] = useState<Funcionario | null>(null);

  // Espelho de Ponto Individual (PDF) State
  const [isEspelhoModalOpen, setIsEspelhoModalOpen] = useState(false);
  const [targetEspelhoFuncionario, setTargetEspelhoFuncionario] = useState<Funcionario | null>(null);

  // Folha Simulada State
  const [folhaSimulada, setFolhaSimulada] = useState<any | null>(null);

  // Carregar dados
  const loadRHData = async () => {
    try {
      setLoading(true);
      const empId = selectedEmpresa ? selectedEmpresa.id : 'todas';
      const [funcsData, funcoesData] = await Promise.all([
        api.getFuncionarios(empId),
        api.getFuncoes(empId),
      ]);
      setFuncionarios(funcsData);
      setFuncoes(funcoesData);

      // Carregar folha
      try {
        const folha = await api.getFolhaPagamentoSimulada(empId, competenciaFolha);
        setFolhaSimulada(folha);
      } catch (err) {
        console.error('Erro ao carregar folha simulada:', err);
      }
    } catch (err) {
      console.error('Erro ao carregar módulo RH:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRHData();
  }, [selectedEmpresa, competenciaFolha]);

  // Departamentos disponíveis
  const departamentos = useMemo(() => {
    const deps = new Set<string>();
    funcionarios.forEach((f) => {
      if (f.departamento) deps.add(f.departamento);
    });
    funcoes.forEach((fn) => {
      if (fn.departamento) deps.add(fn.departamento);
    });
    return Array.from(deps);
  }, [funcionarios, funcoes]);

  // Colaboradores filtrados
  const filteredFuncionarios = useMemo(() => {
    const term = searchTerm.toLowerCase().trim();
    return funcionarios.filter((f) => {
      const matchSearch =
        !term ||
        (f.nomeCompleto || '').toLowerCase().includes(term) ||
        (f.cpf || '').includes(term) ||
        (f.cargoNome || '').toLowerCase().includes(term) ||
        (f.matricula ? f.matricula.toLowerCase().includes(term) : false);

      const matchStatus = statusFilter === 'todos' || f.status === statusFilter;
      const matchDept = departamentoFilter === 'todos' || f.departamento === departamentoFilter;

      return matchSearch && matchStatus && matchDept;
    });
  }, [funcionarios, searchTerm, statusFilter, departamentoFilter]);

  // Funções filtradas
  const filteredFuncoes = useMemo(() => {
    const term = searchTerm.toLowerCase().trim();
    return funcoes.filter((fn) => {
      const matchSearch =
        !term ||
        (fn.titulo || '').toLowerCase().includes(term) ||
        (fn.cbo || '').includes(term) ||
        (fn.departamento || '').toLowerCase().includes(term);
      const matchDept = departamentoFilter === 'todos' || fn.departamento === departamentoFilter;
      return matchSearch && matchDept;
    });
  }, [funcoes, searchTerm, departamentoFilter]);

  // Total folha salarial mensal bruta
  const totalFolhaBruta = useMemo(() => {
    return funcionarios
      .filter((f) => f.status !== 'desligado')
      .reduce((acc, f) => acc + (f.salarioBase || 0) + (f.adicionaisTotal || 0), 0);
  }, [funcionarios]);

  // Handlers Funcionário
  const handleSaveFuncionario = async (dados: Omit<Funcionario, 'id' | 'isDemo'>) => {
    if (funcionarioToEdit) {
      await api.updateFuncionario(funcionarioToEdit.id, dados);
    } else {
      await api.createFuncionario(dados);
    }
    await loadRHData();
    if (onRefresh) onRefresh();
  };

  const handleDeleteFuncionario = async (id: string, nome: string) => {
    if (window.confirm(`Confirma a exclusão do cadastro do colaborador ${nome}?`)) {
      await api.deleteFuncionario(id);
      await loadRHData();
      if (onRefresh) onRefresh();
    }
  };

  const handleOpenHolerite = async (func: Funcionario) => {
    setSelectedHoleriteFuncionario(func);
    try {
      const res = await api.getHoleriteFuncionario(func.id, competenciaFolha);
      setCalculatedHolerite(res.holerite);
      setIsHoleriteModalOpen(true);
    } catch (err) {
      alert('Erro ao calcular demonstrativo de pagamento');
    }
  };

  // Handlers Função
  const handleSaveFuncao = async (dados: Omit<FuncaoRH, 'id' | 'isDemo'>) => {
    if (funcaoToEdit) {
      await api.updateFuncao(funcaoToEdit.id, dados);
    } else {
      await api.createFuncao(dados);
    }
    await loadRHData();
  };

  const handleDeleteFuncao = async (id: string, titulo: string) => {
    if (window.confirm(`Confirma a exclusão do cargo/função "${titulo}"?`)) {
      await api.deleteFuncao(id);
      await loadRHData();
    }
  };

  // Handlers Férias e Afastamento
  const handleSaveFerias = async (id: string, dias: number, dataInicio: string, dataFim: string) => {
    await api.registrarFeriasFuncionario(id, dias, dataInicio, dataFim);
    await loadRHData();
  };

  const handleSaveFeriasAvancado = async (dados: any) => {
    await api.registrarPeriodoGozo(dados);
    await loadRHData();
  };

  const handleSaveAfastamento = async (id: string, motivo: string) => {
    await api.registrarAfastamentoFuncionario(id, motivo);
    await loadRHData();
  };

  const statusBadges: Record<StatusFuncionario, { label: string; class: string }> = {
    ativo: { label: 'Ativo', class: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
    ferias: { label: 'Em Férias', class: 'bg-amber-50 text-amber-700 border-amber-200' },
    afastado: { label: 'Afastado', class: 'bg-rose-50 text-rose-700 border-rose-200' },
    aviso_previo: { label: 'Aviso Prévio', class: 'bg-orange-50 text-orange-700 border-orange-200' },
    desligado: { label: 'Desligado', class: 'bg-slate-100 text-slate-700 border-slate-200' },
  };

  return (
    <div className="space-y-6">
      {/* Header View */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-sm">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">
                Recursos Humanos & Departamento Pessoal
              </h1>
              <p className="text-sm text-slate-500">
                {selectedEmpresa
                  ? `Gestão de Pessoas: ${selectedEmpresa.razaoSocial}`
                  : 'Gestão consolidada de colaboradores, funções, eSocial e folha'}
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadRHData}
            disabled={loading}
            className="p-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 transition-colors"
            title="Recarregar Dados"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-indigo-600' : ''}`} />
          </button>

          <button
            onClick={() => {
              setFuncaoToEdit(null);
              setIsFuncaoModalOpen(true);
            }}
            className="px-4 py-2 text-sm font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl flex items-center gap-2 shadow-sm transition-colors"
          >
            <Briefcase className="w-4 h-4 text-slate-500" />
            <span>Nova Função / Cargo</span>
          </button>

          <button
            onClick={() => {
              setFuncionarioToEdit(null);
              setIsFuncionarioModalOpen(true);
            }}
            className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl flex items-center gap-2 shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Novo Colaborador</span>
          </button>
        </div>
      </div>

      {/* KPI Cards: Shown on sub-tabs for quick overview */}
      {activeTab !== 'dashboard' && (
        <RHMetricsHeader
          funcionarios={funcionarios}
          funcoes={funcoes}
          folhaTotal={totalFolhaBruta}
        />
      )}

      {/* Navigation Tabs */}
      <div className="flex border-b border-slate-200 gap-2 overflow-x-auto">
        {[
          { id: 'dashboard', label: 'Dashboard & Indicadores', icon: LayoutDashboard },
          { id: 'turnover', label: 'Turnover & Cargos por Depto', icon: TrendingUp },
          { id: 'colaboradores', label: `Colaboradores (${funcionarios.length})`, icon: Users },
          { id: 'funcoes', label: `Cargos & Funções (${funcoes.length})`, icon: Briefcase },
          { id: 'ponto', label: 'Ponto Eletrônico (REP-P)', icon: Clock },
          { id: 'folha', label: 'Folha & Simulação', icon: DollarSign },
          { id: 'ferias', label: 'Férias & Afastamentos', icon: Calendar },
          { id: 'rescisao', label: 'Cálculo de Rescisão & TRCT', icon: Calculator },
          { id: 'esocial', label: 'eSocial & SST', icon: ShieldCheck },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              className={`py-3 px-4 text-sm font-semibold whitespace-nowrap border-b-2 flex items-center gap-2 transition-colors ${
                active
                  ? 'border-indigo-600 text-indigo-600 bg-white'
                  : 'border-transparent text-slate-500 hover:text-slate-800 hover:border-slate-300'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* TAB 0: DASHBOARD */}
      {/* ========================================================================= */}
      {activeTab === 'dashboard' && (
        <RHDashboard
          funcionarios={funcionarios}
          funcoes={funcoes}
          empresas={empresas}
          selectedEmpresa={selectedEmpresa}
          onOpenDossieModal={(func) => {
            setTargetDossieFuncionario(func);
            setIsDossieModalOpen(true);
          }}
          onOpenFuncionarioModal={(func) => {
            setFuncionarioToEdit(func || null);
            setIsFuncionarioModalOpen(true);
          }}
          onNavigateTab={(tab, filterStatus) => {
            setActiveTab(tab);
            if (filterStatus) {
              setStatusFilter(filterStatus);
            }
          }}
        />
      )}

      {/* ========================================================================= */}
      {/* TAB 0.5: TURNOVER & CARGOS POR DEPARTAMENTO */}
      {/* ========================================================================= */}
      {activeTab === 'turnover' && (
        <TurnoverCargosPanel
          funcionarios={funcionarios}
          funcoes={funcoes}
          empresas={empresas}
          selectedEmpresa={selectedEmpresa}
          onOpenFuncionarioModal={(func) => {
            setFuncionarioToEdit(func || null);
            setIsFuncionarioModalOpen(true);
          }}
        />
      )}

      {/* Search & Filter Toolbar */}
      {(activeTab === 'colaboradores' || activeTab === 'funcoes') && (
        <div className="flex flex-col md:flex-row gap-3 items-center justify-between bg-white p-3 rounded-xl border border-slate-200">
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={
                activeTab === 'colaboradores'
                  ? 'Buscar por nome, CPF, cargo, matrícula...'
                  : 'Buscar cargo, CBO ou departamento...'
              }
              className="w-full pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto">
            {activeTab === 'colaboradores' && (
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 text-xs font-medium border border-slate-200 rounded-lg bg-white"
              >
                <option value="todos">Status: Todos</option>
                <option value="ativo">Ativos</option>
                <option value="ferias">Em Férias</option>
                <option value="afastado">Afastados</option>
                <option value="desligado">Desligados</option>
              </select>
            )}

            <select
              value={departamentoFilter}
              onChange={(e) => setDepartamentoFilter(e.target.value)}
              className="px-3 py-2 text-xs font-medium border border-slate-200 rounded-lg bg-white"
            >
              <option value="todos">Departamento: Todos</option>
              {departamentos.map((dept) => (
                <option key={dept} value={dept}>
                  {dept}
                </option>
              ))}
            </select>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 1: COLABORADORES */}
      {/* ========================================================================= */}
      {activeTab === 'colaboradores' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs font-bold uppercase tracking-wider">
                  <th className="py-3 px-4">Colaborador</th>
                  <th className="py-3 px-4">Cargo / Depto</th>
                  <th className="py-3 px-4">Empresa</th>
                  <th className="py-3 px-4">Admissão / Contrato</th>
                  <th className="py-3 px-4 text-right">Salário Base</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredFuncionarios.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400">
                      <Users className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                      <p>Nenhum colaborador encontrado.</p>
                      <p className="text-xs text-slate-400 mt-1">
                        Cadastre o primeiro colaborador clicando em "Novo Colaborador".
                      </p>
                    </td>
                  </tr>
                ) : (
                  filteredFuncionarios.map((func) => {
                    const emp = empresas.find((e) => e.id === func.empresaId);
                    const badge = statusBadges[func.status] || statusBadges.ativo;
                    return (
                      <tr key={func.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-full bg-indigo-100 text-indigo-700 font-bold text-xs flex items-center justify-center shrink-0">
                              {func.nomeCompleto.substring(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <p className="font-semibold text-slate-900">{func.nomeCompleto}</p>
                              <p className="text-xs text-slate-400 font-mono">
                                CPF: {func.cpf} • Matrícula {func.matricula}
                              </p>
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-4">
                          <p className="font-medium text-slate-800">{func.cargoNome}</p>
                          <p className="text-xs text-slate-500">
                            {func.departamento} {func.cbo ? `(CBO ${func.cbo})` : ''}
                          </p>
                        </td>

                        <td className="py-3 px-4">
                          <span className="text-xs font-medium text-slate-700">
                            {emp ? emp.razaoSocial : 'Empresa não identificada'}
                          </span>
                        </td>

                        <td className="py-3 px-4">
                          <p className="text-xs font-medium text-slate-800">
                            {func.dataAdmissao
                              ? new Date(func.dataAdmissao).toLocaleDateString('pt-BR')
                              : '---'}
                          </p>
                          <p className="text-[11px] text-slate-400">{func.tipoContrato}</p>
                        </td>

                        <td className="py-3 px-4 text-right">
                          <p className="font-bold text-slate-900">
                            {func.salarioBase.toLocaleString('pt-BR', {
                              style: 'currency',
                              currency: 'BRL',
                            })}
                          </p>
                          {Boolean(func.adicionaisTotal) && (
                            <p className="text-[11px] text-indigo-600 font-medium">
                              + {func.adicionaisTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} adic.
                            </p>
                          )}
                        </td>

                        <td className="py-3 px-4 text-center">
                          <span
                            className={`inline-block px-2.5 py-0.5 text-xs font-semibold rounded-full border ${badge.class}`}
                          >
                            {badge.label}
                          </span>
                        </td>

                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              onClick={() => {
                                setTargetDossieFuncionario(func);
                                setIsDossieModalOpen(true);
                              }}
                              className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                              title="Ver Ficha / Dossiê do Colaborador"
                            >
                              <Eye className="w-4 h-4" />
                            </button>

                            <button
                              id={`btn_espelho_pdf_rh_${func.id}`}
                              onClick={() => {
                                setTargetEspelhoFuncionario(func);
                                setIsEspelhoModalOpen(true);
                              }}
                              className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
                              title="Gerar Espelho de Ponto Individual em PDF (REP-P)"
                            >
                              <Clock className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => handleOpenHolerite(func)}
                              className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                              title="Gerar Holerite / Recibo"
                            >
                              <FileText className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => {
                                setActiveTab('rescisao');
                              }}
                              className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                              title="Calcular Rescisão Contratual & TRCT"
                            >
                              <Calculator className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => {
                                setTargetFeriasFuncionario(func);
                                setFeriasMode('ferias');
                                setIsFeriasModalOpen(true);
                              }}
                              className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                              title="Registrar Férias"
                            >
                              <Umbrella className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => {
                                setTargetFeriasFuncionario(func);
                                setFeriasMode('afastamento');
                                setIsFeriasModalOpen(true);
                              }}
                              className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                              title="Registrar Afastamento (INSS / Licença)"
                            >
                              <ShieldAlert className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => {
                                setFuncionarioToEdit(func);
                                setIsFuncionarioModalOpen(true);
                              }}
                              className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                              title="Editar Cadastro"
                            >
                              <Edit className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => handleDeleteFuncionario(func.id, func.nomeCompleto)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                              title="Excluir Colaborador"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: CARGOS & FUNÇÕES */}
      {/* ========================================================================= */}
      {activeTab === 'funcoes' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredFuncoes.length === 0 ? (
            <div className="col-span-full py-12 text-center text-slate-400 bg-white rounded-xl border border-slate-200">
              <Briefcase className="w-8 h-8 mx-auto mb-2 text-slate-300" />
              <p>Nenhuma função/cargo cadastrada.</p>
              <p className="text-xs text-slate-400 mt-1">
                Clique em "Nova Função / Cargo" para cadastrar a estrutura de cargos.
              </p>
            </div>
          ) : (
            filteredFuncoes.map((fn) => {
              const contagemOcupantes = funcionarios.filter(
                (f) => f.funcaoId === fn.id || f.cargoNome === fn.titulo
              ).length;
              return (
                <div
                  key={fn.id}
                  className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between hover:border-indigo-200 transition-colors"
                >
                  <div>
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 font-bold text-[10px] rounded-md border border-indigo-100">
                          CBO {fn.cbo}
                        </span>
                        <h3 className="text-base font-bold text-slate-900 mt-1">{fn.titulo}</h3>
                        <p className="text-xs text-slate-500 font-medium">{fn.departamento}</p>
                      </div>
                      <div className="flex gap-1">
                        <button
                          onClick={() => {
                            setFuncaoToEdit(fn);
                            setIsFuncaoModalOpen(true);
                          }}
                          className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteFuncao(fn.id, fn.titulo)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 mt-3 line-clamp-2">
                      {fn.descricao || 'Sem descrição cadastrada.'}
                    </p>

                    <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-slate-400 block text-[11px]">Nível:</span>
                        <span className="font-semibold text-slate-800">{fn.nivel || 'Pleno'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Jornada Semanal:</span>
                        <span className="font-semibold text-slate-800">{fn.cargaHorariaSemanal}h</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Piso Salarial:</span>
                        <span className="font-bold text-emerald-600">
                          {fn.salarioBase.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Colaboradores:</span>
                        <span className="font-bold text-indigo-600">{contagemOcupantes} vinculados</span>
                      </div>
                    </div>

                    {(fn.adicionalPericulosidade || fn.adicionalInsalubridade !== 'nenhum') && (
                      <div className="mt-2 flex gap-1 flex-wrap">
                        {fn.adicionalPericulosidade && (
                          <span className="px-1.5 py-0.5 bg-rose-50 text-rose-700 font-semibold text-[10px] rounded border border-rose-200">
                            Periculosidade (+30%)
                          </span>
                        )}
                        {fn.adicionalInsalubridade !== 'nenhum' && (
                          <span className="px-1.5 py-0.5 bg-amber-50 text-amber-700 font-semibold text-[10px] rounded border border-amber-200">
                            Insalubridade ({fn.adicionalInsalubridade})
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: PONTO ELETRÔNICO & AUDITORIA DE JORNADA (REP-P) */}
      {/* ========================================================================= */}
      {activeTab === 'ponto' && (
        <PontoEletronicoModule
          empresaId={selectedEmpresa?.id}
          empresaNome={selectedEmpresa?.razaoSocial || 'Todas as Empresas'}
          funcionarios={funcionarios}
        />
      )}

      {/* ========================================================================= */}
      {/* TAB 4: FOLHA DE PAGAMENTO & SIMULAÇÃO */}
      {/* ========================================================================= */}
      {activeTab === 'folha' && (
        <FolhaPagamentoModule
          empresaId={selectedEmpresa?.id}
          empresaNome={selectedEmpresa?.razaoSocial || 'Todas as Empresas'}
          funcionarios={funcionarios}
        />
      )}

      {/* ========================================================================= */}
      {/* TAB 4: FÉRIAS & AFASTAMENTOS */}
      {/* ========================================================================= */}
      {activeTab === 'ferias' && (
        <ControleFeriasDashboard
          funcionarios={funcionarios}
          empresas={empresas}
          selectedEmpresa={selectedEmpresa || null}
          onRefreshRH={loadRHData}
        />
      )}

      {/* ========================================================================= */}
      {/* TAB 5: CÁLCULO DE RESCISÃO CONTRATUAL & TRCT OFICIAL (CLT) */}
      {/* ========================================================================= */}
      {activeTab === 'rescisao' && (
        <RescisaoModule
          empresas={empresas}
          empresaSelecionada={selectedEmpresa?.id || 'todas'}
        />
      )}

      {/* ========================================================================= */}
      {/* TAB 5: ESOCIAL & SST */}
      {/* ========================================================================= */}
      {activeTab === 'esocial' && (
        <div className="space-y-6">
          <ESocialConfigModule
            empresas={empresas}
            empresaSelecionadaId={selectedEmpresa?.id || empresas[0]?.id || 'emp_1'}
          />

          <div className="bg-white p-6 rounded-xl border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              Controle de Exames Médicos Ocupacionais (ASO / SST - Eventos S-2220 e S-2240)
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Monitoramento dos atestados de saúde ocupacional conforme Norma Regulamentadora NR-7 e envio ao eSocial.
            </p>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs font-bold uppercase">
                    <th className="py-3 px-4">Colaborador</th>
                    <th className="py-3 px-4">Cargo / CBO</th>
                    <th className="py-3 px-4">Último Exame</th>
                    <th className="py-3 px-4">Validade do ASO</th>
                    <th className="py-3 px-4 text-center">Status SST</th>
                    <th className="py-3 px-4 text-right">Evento eSocial</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {funcionarios.map((f) => {
                    const hoje = new Date();
                    const validade = f.dataValidadeAso ? new Date(f.dataValidadeAso) : null;
                    const vencido = validade && validade < hoje;
                    const vencendo =
                      validade &&
                      !vencido &&
                      (validade.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24) <= 30;

                    return (
                      <tr key={f.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-semibold text-slate-900">{f.nomeCompleto}</td>
                        <td className="py-3 px-4 text-xs text-slate-600">
                          {f.cargoNome} ({f.cbo})
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-700">
                          {f.dataUltimoAso ? new Date(f.dataUltimoAso).toLocaleDateString('pt-BR') : '---'}
                        </td>
                        <td className="py-3 px-4 text-xs">
                          {validade ? (
                            <span
                              className={`font-semibold ${
                                vencido
                                  ? 'text-rose-600'
                                  : vencendo
                                  ? 'text-amber-600'
                                  : 'text-slate-800'
                              }`}
                            >
                              {validade.toLocaleDateString('pt-BR')}
                            </span>
                          ) : (
                            'Não informado'
                          )}
                        </td>
                        <td className="py-3 px-4 text-center">
                          {vencido ? (
                            <span className="px-2 py-0.5 bg-rose-100 text-rose-800 text-xs font-bold rounded-full">
                              Vencido
                            </span>
                          ) : vencendo ? (
                            <span className="px-2 py-0.5 bg-amber-100 text-amber-800 text-xs font-bold rounded-full">
                              Vencendo em 30d
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-medium rounded-full">
                              Regular (Válido)
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <span className="inline-block px-2 py-0.5 bg-slate-100 text-slate-700 font-mono text-[11px] rounded border border-slate-200">
                            S-2220 Emitido
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODALS */}
      {/* ========================================================================= */}

      {/* Modal Cadastro/Edição de Funcionário */}
      <FuncionarioModal
        isOpen={isFuncionarioModalOpen}
        onClose={() => {
          setIsFuncionarioModalOpen(false);
          setFuncionarioToEdit(null);
        }}
        onSave={handleSaveFuncionario}
        funcionarioToEdit={funcionarioToEdit}
        empresas={empresas}
        funcoes={funcoes}
        selectedEmpresaId={selectedEmpresa?.id}
      />

      {/* Modal Cadastro/Edição de Função / Cargo */}
      <FuncaoModal
        isOpen={isFuncaoModalOpen}
        onClose={() => {
          setIsFuncaoModalOpen(false);
          setFuncaoToEdit(null);
        }}
        onSave={handleSaveFuncao}
        funcaoToEdit={funcaoToEdit}
        empresas={empresas}
        selectedEmpresaId={selectedEmpresa?.id}
      />

      {/* Modal Holerite / Recibo de Pagamento */}
      <HoleriteModal
        isOpen={isHoleriteModalOpen}
        onClose={() => {
          setIsHoleriteModalOpen(false);
          setSelectedHoleriteFuncionario(null);
          setCalculatedHolerite(null);
        }}
        funcionario={selectedHoleriteFuncionario}
        empresa={
          selectedHoleriteFuncionario
            ? empresas.find((e) => e.id === selectedHoleriteFuncionario.empresaId) || null
            : null
        }
        holerite={calculatedHolerite}
      />

      {/* Modal Férias / Afastamento */}
      <FeriasAfastamentoModal
        isOpen={isFeriasModalOpen}
        onClose={() => {
          setIsFeriasModalOpen(false);
          setTargetFeriasFuncionario(null);
        }}
        funcionario={targetFeriasFuncionario}
        mode={feriasMode}
        onSaveFerias={handleSaveFerias}
        onSaveFeriasAvancado={handleSaveFeriasAvancado}
        onSaveAfastamento={handleSaveAfastamento}
      />

      {/* Modal Dossiê / Ficha do Colaborador */}
      <FuncionarioDossieModal
        isOpen={isDossieModalOpen}
        onClose={() => {
          setIsDossieModalOpen(false);
          setTargetDossieFuncionario(null);
        }}
        funcionario={targetDossieFuncionario}
        empresa={
          targetDossieFuncionario
            ? empresas.find((e) => e.id === targetDossieFuncionario.empresaId) || null
            : null
        }
        onAbrirHolerite={() => {
          if (targetDossieFuncionario) {
            setIsDossieModalOpen(false);
            handleOpenHolerite(targetDossieFuncionario);
          }
        }}
        onAbrirFerias={() => {
          if (targetDossieFuncionario) {
            setIsDossieModalOpen(false);
            setTargetFeriasFuncionario(targetDossieFuncionario);
            setFeriasMode('ferias');
            setIsFeriasModalOpen(true);
          }
        }}
      />

      {/* Modal Gerador de Espelho de Ponto Individual (PDF) */}
      {isEspelhoModalOpen && targetEspelhoFuncionario && (
        <EspelhoPontoModal
          funcionarioId={targetEspelhoFuncionario.id}
          funcionarios={funcionarios}
          initialCompetencia={competenciaFolha}
          onClose={() => {
            setIsEspelhoModalOpen(false);
            setTargetEspelhoFuncionario(null);
          }}
        />
      )}
    </div>
  );
};
