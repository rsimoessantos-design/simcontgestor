import React, { useState } from 'react';
import JSZip from 'jszip';
import {
  FileText,
  Plus,
  Search,
  Filter,
  Download,
  Printer,
  Ban,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Send,
  Eye,
  Building2,
  DollarSign,
  Receipt,
  Layers,
  X,
  Calendar,
  SlidersHorizontal,
  RotateCcw,
  ChevronDown,
  ChevronUp,
  Archive,
  CheckSquare,
  Square,
  Check,
  Loader2,
  ArrowDownToLine,
  ShieldCheck,
  BarChart3,
  FileCode,
} from 'lucide-react';
import { NotaFiscal, Empresa, Cliente } from '../types';
import { api } from '../services/api';
import {
  gerarDanfePdf,
  gerarLoteDanfePdf,
  getDanfePdfBlob,
} from '../utils/danfePdfGenerator';
import { CapturaSefazView } from './CapturaSefazView';
import { ImportarXmlSaidaModal } from './ImportarXmlSaidaModal';
import { EstatisticasXmlSaidaPanel } from './EstatisticasXmlSaidaPanel';

interface NotasFiscaisViewProps {
  selectedEmpresa?: Empresa;
  empresas: Empresa[];
  clientes: Cliente[];
  notasFiscais: NotaFiscal[];
  onRefresh: () => void;
  initialTab?: 'emitidas' | 'entradas_sefaz' | 'estatisticas_saida';
}

export const NotasFiscaisView: React.FC<NotasFiscaisViewProps> = ({
  selectedEmpresa,
  empresas,
  clientes,
  notasFiscais,
  onRefresh,
  initialTab = 'entradas_sefaz',
}) => {
  const [activeTab, setActiveTab] = useState<'emitidas' | 'entradas_sefaz' | 'estatisticas_saida'>(initialTab);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTipo, setSelectedTipo] = useState<string>('todos');
  const [selectedStatus, setSelectedStatus] = useState<string>('todos');
  const [selectedOrigem, setSelectedOrigem] = useState<'todos' | 'importado_erp' | 'sistema'>('todos');
  const [isImportXmlModalOpen, setIsImportXmlModalOpen] = useState(false);

  // Estados da Busca Avançada
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [filtroEmitente, setFiltroEmitente] = useState('');
  const [filtroCnpj, setFiltroCnpj] = useState('');
  const [filtroDataInicio, setFiltroDataInicio] = useState('');
  const [filtroDataFim, setFiltroDataFim] = useState('');

  // Estados de Seleção e Exportação em Lote (.ZIP)
  const [selectedNotaIds, setSelectedNotaIds] = useState<string[]>([]);
  const [isExportingZip, setIsExportingZip] = useState(false);
  const [isPrintingPdf, setIsPrintingPdf] = useState(false);
  const [exportSuccessMsg, setExportSuccessMsg] = useState('');

  const [isEmitirModalOpen, setIsEmitirModalOpen] = useState(false);
  const [selectedNotaForDanfe, setSelectedNotaForDanfe] = useState<NotaFiscal | null>(null);
  const [selectedNotaForCancel, setSelectedNotaForCancel] = useState<NotaFiscal | null>(null);
  const [cancelMotivo, setCancelMotivo] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  // Form State for new NF-e
  const [formData, setFormData] = useState({
    empresaId: selectedEmpresa?.id || (empresas[0]?.id || ''),
    tipo: 'NFe' as 'NFe' | 'NFSe' | 'NFCe',
    serie: '1',
    naturezaOperacao: '5.102 - Venda de mercadorias no estado',
    destinatarioNome: '',
    destinatarioCpfCnpj: '',
    destinatarioEmail: '',
    descricaoItem: '',
    quantidade: 1,
    valorUnitario: 0,
    aliquotaIcms: 12,
    aliquotaIss: 5,
    aliquotaPis: 0.65,
    aliquotaCofins: 3.0,
  });

  // Função auxiliar para obter os dados da empresa emitente
  const getEmpresaEmitente = (empresaId: string): Empresa | undefined => {
    return empresas.find((e) => e.id === empresaId);
  };

  // Filter list com suporte à busca rápida e busca avançada (Emitente, CNPJ e Intervalo de Datas)
  const filteredNotas = notasFiscais.filter((nota) => {
    const emitente = getEmpresaEmitente(nota.empresaId);
    const emitenteNome = emitente?.razaoSocial || emitente?.nomeFantasia || (nota as any).emitenteNome || '';
    const emitenteCnpj = emitente?.cnpj || (nota as any).emitenteCnpj || '';

    // Busca rápida geral
    const term = searchTerm.trim().toLowerCase();
    const matchesSearch =
      !term ||
      nota.destinatarioNome.toLowerCase().includes(term) ||
      nota.destinatarioCpfCnpj.includes(term) ||
      nota.numero.toString().includes(term) ||
      nota.chaveAcesso.includes(term) ||
      emitenteNome.toLowerCase().includes(term) ||
      emitenteCnpj.includes(term);

    // Filtros de modelo e status
    const matchesTipo = selectedTipo === 'todos' || nota.tipo === selectedTipo;
    const matchesStatus = selectedStatus === 'todos' || nota.status === selectedStatus;

    // Filtro Avançado 1: Nome do Emitente
    const matchesFiltroEmitente =
      !filtroEmitente.trim() ||
      emitenteNome.toLowerCase().includes(filtroEmitente.trim().toLowerCase());

    // Filtro Avançado 2: CNPJ (compara com emitente ou destinatário)
    let matchesFiltroCnpj = true;
    if (filtroCnpj.trim()) {
      const cleanFiltro = filtroCnpj.replace(/\D/g, '');
      const cleanEmitente = emitenteCnpj.replace(/\D/g, '');
      const cleanDestinatario = (nota.destinatarioCpfCnpj || '').replace(/\D/g, '');

      if (cleanFiltro.length > 0) {
        matchesFiltroCnpj =
          cleanEmitente.includes(cleanFiltro) ||
          cleanDestinatario.includes(cleanFiltro);
      } else {
        matchesFiltroCnpj =
          emitenteCnpj.toLowerCase().includes(filtroCnpj.toLowerCase()) ||
          nota.destinatarioCpfCnpj.toLowerCase().includes(filtroCnpj.toLowerCase());
      }
    }

    // Filtro Avançado 3: Intervalo de Datas de Emissão
    let matchesDataInicio = true;
    let matchesDataFim = true;
    if (filtroDataInicio || filtroDataFim) {
      const notaDateStr = nota.dataEmissao.split('T')[0];
      if (filtroDataInicio) {
        matchesDataInicio = notaDateStr >= filtroDataInicio;
      }
      if (filtroDataFim) {
        matchesDataFim = notaDateStr <= filtroDataFim;
      }
    }

    const matchesOrigem =
      selectedOrigem === 'todos' ||
      (selectedOrigem === 'importado_erp' && nota.origem === 'importado_erp') ||
      (selectedOrigem === 'sistema' && nota.origem !== 'importado_erp');

    return (
      matchesSearch &&
      matchesTipo &&
      matchesStatus &&
      matchesOrigem &&
      matchesFiltroEmitente &&
      matchesFiltroCnpj &&
      matchesDataInicio &&
      matchesDataFim
    );
  });

  // Atalhos rápidos de período
  const aplicarAtalhoPeriodo = (tipo: 'hoje' | '7dias' | 'mes_atual' | '30dias') => {
    const agora = new Date();
    const formatYmd = (d: Date) => d.toISOString().split('T')[0];

    if (tipo === 'hoje') {
      const hoje = formatYmd(agora);
      setFiltroDataInicio(hoje);
      setFiltroDataFim(hoje);
    } else if (tipo === '7dias') {
      const past = new Date(agora);
      past.setDate(past.getDate() - 7);
      setFiltroDataInicio(formatYmd(past));
      setFiltroDataFim(formatYmd(agora));
    } else if (tipo === 'mes_atual') {
      const primeiroDia = new Date(agora.getFullYear(), agora.getMonth(), 1);
      const ultimoDia = new Date(agora.getFullYear(), agora.getMonth() + 1, 0);
      setFiltroDataInicio(formatYmd(primeiroDia));
      setFiltroDataFim(formatYmd(ultimoDia));
    } else if (tipo === '30dias') {
      const past = new Date(agora);
      past.setDate(past.getDate() - 30);
      setFiltroDataInicio(formatYmd(past));
      setFiltroDataFim(formatYmd(agora));
    }
  };

  const handleLimparFiltrosAvancados = () => {
    setFiltroEmitente('');
    setFiltroCnpj('');
    setFiltroDataInicio('');
    setFiltroDataFim('');
  };

  const totalFiltrosAvancadosAtivos = [
    Boolean(filtroEmitente.trim()),
    Boolean(filtroCnpj.trim()),
    Boolean(filtroDataInicio),
    Boolean(filtroDataFim),
  ].filter(Boolean).length;

  // Statistics
  const totalFaturado = notasFiscais
    .filter((n) => n.status === 'autorizada')
    .reduce((acc, curr) => acc + curr.valorTotal, 0);

  const totalAutorizadas = notasFiscais.filter((n) => n.status === 'autorizada').length;
  const totalCanceladas = notasFiscais.filter((n) => n.status === 'cancelada').length;

  const handleClienteSelect = (clienteId: string) => {
    const cli = clientes.find((c) => c.id === clienteId);
    if (cli) {
      setFormData((prev) => ({
        ...prev,
        destinatarioNome: cli.razaoSocial,
        destinatarioCpfCnpj: cli.cnpjCpf,
        destinatarioEmail: cli.email || '',
      }));
    }
  };

  const handleEmitirNota = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!formData.destinatarioNome.trim() || !formData.destinatarioCpfCnpj.trim()) {
      setFormError('Informe a razão social/nome e o CPF/CNPJ do destinatário.');
      return;
    }

    if (!formData.descricaoItem.trim() || formData.valorUnitario <= 0) {
      setFormError('Informe a descrição do item e um valor unitário válido.');
      return;
    }

    setIsSubmitting(true);
    try {
      const valorTotalItem = formData.quantidade * formData.valorUnitario;
      const icms = (valorTotalItem * (formData.aliquotaIcms || 0)) / 100;
      const iss = formData.tipo === 'NFSe' ? (valorTotalItem * (formData.aliquotaIss || 0)) / 100 : 0;
      const pis = (valorTotalItem * (formData.aliquotaPis || 0)) / 100;
      const cofins = (valorTotalItem * (formData.aliquotaCofins || 0)) / 100;

      const proximoNumero =
        notasFiscais.length > 0
          ? Math.max(...notasFiscais.map((n) => n.numero)) + 1
          : 1500;

      await api.createNotaFiscal({
        empresaId: formData.empresaId,
        numero: proximoNumero,
        serie: formData.serie,
        tipo: formData.tipo,
        naturezaOperacao: formData.naturezaOperacao,
        destinatarioNome: formData.destinatarioNome,
        destinatarioCpfCnpj: formData.destinatarioCpfCnpj,
        destinatarioEmail: formData.destinatarioEmail,
        valorTotal: valorTotalItem,
        valorServicosOuProdutos: valorTotalItem,
        impostos: {
          icms: formData.tipo === 'NFe' ? icms : undefined,
          iss: formData.tipo === 'NFSe' ? iss : undefined,
          pis,
          cofins,
        },
        itens: [
          {
            descricao: formData.descricaoItem,
            quantidade: formData.quantidade,
            valorUnitario: formData.valorUnitario,
            valorTotal: valorTotalItem,
          },
        ],
        dataEmissao: new Date().toISOString(),
        status: 'autorizada',
      });

      setIsEmitirModalOpen(false);
      onRefresh();
    } catch (err: any) {
      setFormError(err.message || 'Erro ao emitir a nota fiscal.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmarCancelamento = async () => {
    if (!selectedNotaForCancel) return;
    if (cancelMotivo.trim().length < 15) {
      alert('A justificativa de cancelamento deve conter no mínimo 15 caracteres conforme exigência legal da SEFAZ.');
      return;
    }

    setIsSubmitting(true);
    try {
      await api.cancelarNotaFiscal(selectedNotaForCancel.id, cancelMotivo);
      setSelectedNotaForCancel(null);
      setCancelMotivo('');
      onRefresh();
    } catch (err: any) {
      alert(err.message || 'Erro ao cancelar a nota fiscal.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Funções de Seleção de Notas Fiscais em Lote
  const toggleSelectNota = (id: string) => {
    setSelectedNotaIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const visibleIds = filteredNotas.map((n) => n.id);
  const isAllFilteredSelected =
    visibleIds.length > 0 && visibleIds.every((id) => selectedNotaIds.includes(id));
  const isSomeFilteredSelected =
    visibleIds.some((id) => selectedNotaIds.includes(id)) && !isAllFilteredSelected;

  const handleToggleSelectAllFiltered = () => {
    if (isAllFilteredSelected) {
      setSelectedNotaIds((prev) => prev.filter((id) => !visibleIds.includes(id)));
    } else {
      setSelectedNotaIds((prev) => Array.from(new Set([...prev, ...visibleIds])));
    }
  };

  const handleLimparSelecao = () => {
    setSelectedNotaIds([]);
  };

  // Gerador padrão do XML de NF-e estruturado para download individual ou arquivo ZIP
  const generateXmlContent = (nota: NotaFiscal): string => {
    const emitente = getEmpresaEmitente(nota.empresaId) || selectedEmpresa;
    return `<?xml version="1.0" encoding="UTF-8"?>
<nfeProc xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00">
  <NFe>
    <infNFe Id="NFe${nota.chaveAcesso}" versao="4.00">
      <ide>
        <cUF>${emitente?.uf === 'SP' ? '35' : '33'}</cUF>
        <cNF>${nota.numero.toString().padStart(8, '0')}</cNF>
        <natOp>${nota.naturezaOperacao}</natOp>
        <mod>55</mod>
        <serie>${nota.serie}</serie>
        <nNF>${nota.numero}</nNF>
        <dhEmi>${nota.dataEmissao}</dhEmi>
        <tpNF>1</tpNF>
        <idDest>1</idDest>
        <cMunFG>3550308</cMunFG>
        <tpImp>1</tpImp>
        <tpEmis>1</tpEmis>
        <tpAmb>1</tpAmb>
        <finNFe>1</finNFe>
      </ide>
      <emit>
        <CNPJ>${(emitente?.cnpj || '').replace(/\D/g, '') || '12345678000190'}</CNPJ>
        <xNome>${emitente?.razaoSocial || 'EMPRESA EMITENTE'}</xNome>
        <xFant>${emitente?.nomeFantasia || emitente?.razaoSocial || 'EMPRESA'}</xFant>
        <enderEmit>
          <xLgr>Avenida Paulista</xLgr>
          <nro>1000</nro>
          <xBairro>Bela Vista</xBairro>
          <cMun>3550308</cMun>
          <xMun>${emitente?.cidade || 'São Paulo'}</xMun>
          <UF>${emitente?.uf || 'SP'}</UF>
          <CEP>01310100</CEP>
        </enderEmit>
      </emit>
      <dest>
        <xNome>${nota.destinatarioNome}</xNome>
        <CNPJ>${nota.destinatarioCpfCnpj.replace(/\D/g, '')}</CNPJ>
        <email>${nota.destinatarioEmail || ''}</email>
      </dest>
      <det nItem="1">
        <prod>
          <cProd>001</cProd>
          <cEAN>SEM GTIN</cEAN>
          <xProd>${nota.itens[0]?.descricao || 'Item Faturado'}</xProd>
          <NCM>99000000</NCM>
          <CFOP>5102</CFOP>
          <uCom>UN</uCom>
          <qCom>${nota.itens[0]?.quantidade || 1}</qCom>
          <vUnCom>${(nota.itens[0]?.valorUnitario || nota.valorTotal).toFixed(2)}</vUnCom>
          <vProd>${nota.valorTotal.toFixed(2)}</vProd>
        </prod>
      </det>
      <total>
        <ICMSTot>
          <vNF>${nota.valorTotal.toFixed(2)}</vNF>
          <vICMS>${(nota.impostos.icms || 0).toFixed(2)}</vICMS>
          <vPIS>${(nota.impostos.pis || 0).toFixed(2)}</vPIS>
          <vCOFINS>${(nota.impostos.cofins || 0).toFixed(2)}</vCOFINS>
        </ICMSTot>
      </total>
    </infNFe>
  </NFe>
  <protNFe versao="4.00">
    <infProt>
      <tpAmb>1</tpAmb>
      <chNFe>${nota.chaveAcesso}</chNFe>
      <dhRecbto>${nota.dataEmissao}</dhRecbto>
      <nProt>${nota.protocoloAutorizacao || '135260049281729'}</nProt>
      <cStat>100</cStat>
      <xMotivo>Autorizado o uso da NF-e</xMotivo>
    </infProt>
  </protNFe>
</nfeProc>`;
  };

  // Exportação em Lote (.ZIP) para Arquivamento Contábil
  const handleExportarLoteZip = async (notasEspecificas?: NotaFiscal[]) => {
    let lista = notasEspecificas;

    if (!lista) {
      if (selectedNotaIds.length === 0) {
        if (filteredNotas.length > 0) {
          const confirmar = confirm(
            `Nenhuma nota individual foi marcada no checkbox. Deseja exportar o arquivo .ZIP com todas as ${filteredNotas.length} notas fiscais filtradas no momento?`
          );
          if (confirmar) {
            lista = filteredNotas;
          } else {
            return;
          }
        } else {
          alert('Selecione ao menos uma nota fiscal na lista para exportar o arquivo compactado (.zip).');
          return;
        }
      } else {
        lista = notasFiscais.filter((n) => selectedNotaIds.includes(n.id));
      }
    }

    if (!lista || lista.length === 0) {
      alert('Nenhuma nota fiscal disponível para exportação.');
      return;
    }

    setIsExportingZip(true);
    try {
      const zip = new JSZip();
      const pastaXml = zip.folder('XMLs_NFe');
      const pastaPdf = zip.folder('DANFEs_PDF');

      lista.forEach((nota) => {
        const xml = generateXmlContent(nota);
        pastaXml?.file(`NFe_${nota.chaveAcesso}.xml`, xml);

        // Inclui cópia em PDF do DANFE para arquivamento contábil imediato
        try {
          const emit = getEmpresaEmitente(nota.empresaId) || selectedEmpresa;
          const pdfBlob = getDanfePdfBlob(nota, emit);
          pastaPdf?.file(`DANFE_NFe_${String(nota.numero).padStart(8, '0')}_Serie_${nota.serie}.pdf`, pdfBlob);
        } catch (pdfErr) {
          console.warn('Não foi possível gerar DANFE em PDF para a nota', nota.numero, pdfErr);
        }
      });

      // Manifesto e relatório detalhado de conferência para o escritório contábil
      const manifesto = {
        titulo: 'Arquivo em Lote de Documentos Fiscais Eletrônicos (NF-e)',
        dataExportacao: new Date().toISOString(),
        geradoPor: 'ContabGest ERP - Arquivamento Fiscal Contábil',
        totalDocumentos: lista.length,
        valorTotalLote: lista.reduce((acc, curr) => acc + curr.valorTotal, 0),
        resumoImpostos: {
          totalIcms: lista.reduce((acc, curr) => acc + (curr.impostos.icms || 0), 0),
          totalPis: lista.reduce((acc, curr) => acc + (curr.impostos.pis || 0), 0),
          totalCofins: lista.reduce((acc, curr) => acc + (curr.impostos.cofins || 0), 0),
          totalIss: lista.reduce((acc, curr) => acc + (curr.impostos.iss || 0), 0),
        },
        documentos: lista.map((n) => {
          const emit = getEmpresaEmitente(n.empresaId);
          return {
            chaveAcesso: n.chaveAcesso,
            numero: n.numero,
            serie: n.serie,
            modelo: n.tipo,
            dataEmissao: n.dataEmissao,
            statusSefaz: n.status,
            emitenteRazaoSocial: emit?.razaoSocial || 'N/A',
            emitenteCnpj: emit?.cnpj || 'N/A',
            destinatarioNome: n.destinatarioNome,
            destinatarioCpfCnpj: n.destinatarioCpfCnpj,
            valorTotal: n.valorTotal,
            protocoloAutorizacao: n.protocoloAutorizacao || '135260049281729',
          };
        }),
      };

      zip.file('manifesto_remessa_contabil.json', JSON.stringify(manifesto, null, 2));

      const blob = await zip.generateAsync({ type: 'blob' });
      const dataStr = new Date().toISOString().split('T')[0];
      const fileName = `Lote_XMLs_e_DANFEs_NFe_${dataStr}_(${lista.length}_notas).zip`;

      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setExportSuccessMsg(`Pacote .ZIP com ${lista.length} XML(s) e ${lista.length} DANFE(s) em PDF baixado com sucesso!`);
      setTimeout(() => setExportSuccessMsg(''), 6000);
    } catch (err: any) {
      console.error('Erro ao gerar arquivo zip:', err);
      alert('Ocorreu um erro ao compactar os arquivos XML e PDFs para exportação.');
    } finally {
      setIsExportingZip(false);
    }
  };

  // Impressor de DANFE em .PDF individual (impressão direta no navegador ou download de arquivo .pdf)
  const handleImprimirDanfePdf = (nota: NotaFiscal, printDirectly = false) => {
    try {
      setIsPrintingPdf(true);
      const emitente = getEmpresaEmitente(nota.empresaId) || selectedEmpresa;
      gerarDanfePdf(nota, emitente, {
        autoDownload: !printDirectly,
        printDirectly: printDirectly,
      });

      setExportSuccessMsg(
        printDirectly
          ? `Disparando impressão do DANFE da NF-e Nº ${nota.numero}...`
          : `DANFE da NF-e Nº ${nota.numero} (Série ${nota.serie}) gerado em arquivo .PDF com sucesso!`
      );
      setTimeout(() => setExportSuccessMsg(''), 5000);
    } catch (err: any) {
      console.error('Erro ao gerar DANFE em PDF:', err);
      alert('Ocorreu um erro ao imprimir o DANFE em PDF.');
    } finally {
      setIsPrintingPdf(false);
    }
  };

  // Impressor de Lote de DANFEs em .PDF consolidado (todas as selecionadas ou filtradas)
  const handleImprimirLotePdf = (printDirectly = false) => {
    let lista: NotaFiscal[] = [];
    if (selectedNotaIds.length === 0) {
      if (filteredNotas.length > 0) {
        const confirmar = confirm(
          `Nenhuma nota fiscal foi marcada individualmente. Deseja gerar o arquivo .PDF com os DANFEs de todas as ${filteredNotas.length} notas fiscais filtradas?`
        );
        if (confirmar) {
          lista = filteredNotas;
        } else {
          return;
        }
      } else {
        alert('Selecione ao menos uma nota fiscal na lista para imprimir em lote.');
        return;
      }
    } else {
      lista = notasFiscais.filter((n) => selectedNotaIds.includes(n.id));
    }

    if (lista.length === 0) return;

    try {
      setIsPrintingPdf(true);
      gerarLoteDanfePdf(lista, (empresaId) => getEmpresaEmitente(empresaId) || selectedEmpresa, {
        autoDownload: !printDirectly,
        printDirectly: printDirectly,
      });

      setExportSuccessMsg(
        printDirectly
          ? `Enviando ${lista.length} DANFEs para a fila de impressão...`
          : `Arquivo .PDF com ${lista.length} DANFEs consolidado gerado com sucesso!`
      );
      setTimeout(() => setExportSuccessMsg(''), 6000);
    } catch (err: any) {
      console.error('Erro ao gerar lote de DANFEs em PDF:', err);
      alert('Ocorreu um erro ao gerar os DANFEs em PDF em lote.');
    } finally {
      setIsPrintingPdf(false);
    }
  };

  const downloadXml = (nota: NotaFiscal) => {
    const xmlContent = generateXmlContent(nota);
    const blob = new Blob([xmlContent], { type: 'application/xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `NFe_${nota.chaveAcesso}.xml`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Navegação Superior entre Módulos de Notas Fiscais */}
      <div className="bg-white p-1.5 rounded-2xl border border-slate-200/80 shadow-sm flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <button
            id="tab-btn-entradas-sefaz"
            type="button"
            onClick={() => setActiveTab('entradas_sefaz')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeTab === 'entradas_sefaz'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <ArrowDownToLine className="w-4 h-4" />
            <span>Captura SEFAZ DF-e (Entradas contra CNPJ)</span>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                activeTab === 'entradas_sefaz'
                  ? 'bg-indigo-500/40 text-white'
                  : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
              }`}
            >
              fsist / Quive
            </span>
          </button>

          <button
            id="tab-btn-notas-emitidas"
            type="button"
            onClick={() => setActiveTab('emitidas')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeTab === 'emitidas'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Notas Emitidas (Saída)</span>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                activeTab === 'emitidas'
                  ? 'bg-emerald-500/40 text-white'
                  : 'bg-slate-100 text-slate-600'
              }`}
            >
              {notasFiscais.length}
            </span>
          </button>

          <button
            id="tab-btn-estatisticas-saida"
            type="button"
            onClick={() => setActiveTab('estatisticas_saida')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeTab === 'estatisticas_saida'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Estatísticas XMLs Saída</span>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                activeTab === 'estatisticas_saida'
                  ? 'bg-blue-500/40 text-white'
                  : 'bg-blue-50 text-blue-700 border border-blue-200'
              }`}
            >
              Simples Nacional
            </span>
          </button>
        </div>

        {selectedEmpresa && (
          <div className="hidden lg:flex items-center gap-2 text-xs text-slate-500 px-3">
            <Building2 className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-semibold text-slate-700">{selectedEmpresa.razaoSocial}</span>
            <span className="font-mono text-slate-400">({selectedEmpresa.cnpj})</span>
          </div>
        )}
      </div>

      {activeTab === 'entradas_sefaz' ? (
        <CapturaSefazView
          selectedEmpresa={selectedEmpresa}
          empresas={empresas}
          onRefreshParent={onRefresh}
        />
      ) : activeTab === 'estatisticas_saida' ? (
        <EstatisticasXmlSaidaPanel
          notasFiscais={notasFiscais}
          empresas={empresas}
          selectedEmpresa={selectedEmpresa}
          onOpenImportModal={() => setIsImportXmlModalOpen(true)}
        />
      ) : (
        <>
          {/* Toast / Alerta de Sucesso na Exportação */}
          {exportSuccessMsg && (
            <div className="bg-emerald-50 border border-emerald-300 text-emerald-800 px-4 py-3 rounded-xl text-xs flex items-center justify-between shadow-sm animate-in fade-in">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="font-semibold">{exportSuccessMsg}</span>
              </div>
              <button
                type="button"
                onClick={() => setExportSuccessMsg('')}
                className="text-emerald-700 hover:text-emerald-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Header & Main Actions */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <FileText className="w-7 h-7 text-emerald-600" />
            Emissor de Notas Fiscais Eletrônicas
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            {selectedEmpresa
              ? `Emissão e acompanhamento de NF-e, NFS-e e NFC-e para ${selectedEmpresa.razaoSocial}`
              : 'Emissão e gestão integrada de documentos fiscais eletrônicos'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Botão de Exportação em Lote .ZIP */}
          <button
            id="btn-exportar-lote-xml-zip"
            type="button"
            disabled={isExportingZip}
            onClick={() => handleExportarLoteZip()}
            className="inline-flex items-center justify-center gap-2 px-3.5 py-2.5 bg-white hover:bg-slate-50 text-slate-700 text-sm font-semibold rounded-lg border border-slate-300 shadow-sm transition-colors disabled:opacity-60"
            title={
              selectedNotaIds.length > 0
                ? `Baixar .ZIP com ${selectedNotaIds.length} XMLs marcados`
                : 'Baixar arquivo .ZIP com XMLs para arquivamento contábil'
            }
          >
            {isExportingZip ? (
              <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
            ) : (
              <Archive className="w-4 h-4 text-emerald-600" />
            )}
            <span>Exportar XMLs (.ZIP)</span>
            {selectedNotaIds.length > 0 && (
              <span className="bg-emerald-600 text-white text-[11px] font-bold px-2 py-0.5 rounded-full">
                {selectedNotaIds.length}
              </span>
            )}
          </button>

          {/* Botão de Impressão / Exportação de DANFEs em .PDF */}
          <button
            id="btn-imprimir-lote-danfe-pdf"
            type="button"
            disabled={isPrintingPdf}
            onClick={() => handleImprimirLotePdf(false)}
            className="inline-flex items-center justify-center gap-2 px-3.5 py-2.5 bg-white hover:bg-slate-50 text-slate-700 text-sm font-semibold rounded-lg border border-slate-300 shadow-sm transition-colors disabled:opacity-60"
            title={
              selectedNotaIds.length > 0
                ? `Gerar e baixar PDF com ${selectedNotaIds.length} DANFEs selecionados`
                : 'Gerar e baixar lote com todos os DANFEs em .PDF'
            }
          >
            {isPrintingPdf ? (
              <Loader2 className="w-4 h-4 animate-spin text-emerald-600" />
            ) : (
              <Printer className="w-4 h-4 text-emerald-600" />
            )}
            <span>Imprimir DANFEs (.PDF)</span>
            {selectedNotaIds.length > 0 && (
              <span className="bg-emerald-600 text-white text-[11px] font-bold px-2 py-0.5 rounded-full">
                {selectedNotaIds.length}
              </span>
            )}
          </button>

          <button
            id="btn-abrir-importar-xml-saida"
            onClick={() => setIsImportXmlModalOpen(true)}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors"
            title="Importar XMLs de notas fiscais modelo 55 emitidas por outros ERPs"
          >
            <FileCode className="w-4 h-4" />
            Importar XML Saída (Mod. 55)
          </button>

          <button
            id="btn-abrir-emissao-nfe"
            onClick={() => setIsEmitirModalOpen(true)}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            Emitir Nova Nota Fiscal
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Total Faturado no Mês
            </span>
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">
            R$ {totalFaturado.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </p>
          <p className="text-xs text-slate-500 mt-1">Somatório das notas fiscais autorizadas</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Notas Autorizadas
            </span>
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{totalAutorizadas}</p>
          <p className="text-xs text-slate-500 mt-1">Transmitidas com sucesso na SEFAZ</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Canceladas / Rejeitadas
            </span>
            <div className="p-2 bg-rose-50 text-rose-600 rounded-lg">
              <Ban className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{totalCanceladas}</p>
          <p className="text-xs text-slate-500 mt-1">Com evento de cancelamento registrado</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm space-y-3">
        <div className="flex flex-col lg:flex-row gap-3 items-center justify-between">
          <div className="relative w-full lg:w-96">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="input-busca-nfe"
              type="text"
              placeholder="Busca rápida por número, chave ou participantes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto justify-start lg:justify-end">
            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                id="select-modelo-nfe"
                value={selectedTipo}
                onChange={(e) => setSelectedTipo(e.target.value)}
                className="bg-transparent border-none focus:outline-none text-xs text-slate-700 font-medium"
              >
                <option value="todos">Todos os Modelos</option>
                <option value="NFe">NF-e (Mercadorias)</option>
                <option value="NFSe">NFS-e (Serviços)</option>
                <option value="NFCe">NFC-e (Consumidor)</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600">
              <select
                id="select-status-nfe"
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="bg-transparent border-none focus:outline-none text-xs text-slate-700 font-medium"
              >
                <option value="todos">Todos os Status</option>
                <option value="autorizada">Autorizadas</option>
                <option value="cancelada">Canceladas</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600">
              <select
                id="select-origem-nfe"
                value={selectedOrigem}
                onChange={(e) => setSelectedOrigem(e.target.value as any)}
                className="bg-transparent border-none focus:outline-none text-xs text-slate-700 font-medium"
              >
                <option value="todos">Todas as Origens</option>
                <option value="importado_erp">Importadas de Outro ERP (Mod. 55)</option>
                <option value="sistema">Emitidas no ContabGest</option>
              </select>
            </div>

            {/* Botão de Toggle da Busca Avançada */}
            <button
              id="btn-toggle-busca-avancada"
              type="button"
              onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
              className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                showAdvancedFilters || totalFiltrosAvancadosAtivos > 0
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Busca Avançada</span>
              {totalFiltrosAvancadosAtivos > 0 && (
                <span className="inline-flex items-center justify-center bg-emerald-600 text-white rounded-full text-[10px] w-4 h-4 font-bold">
                  {totalFiltrosAvancadosAtivos}
                </span>
              )}
              {showAdvancedFilters ? (
                <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              )}
            </button>
          </div>
        </div>

        {/* Painel Expansível de Filtros Avançados */}
        {showAdvancedFilters && (
          <div
            id="painel-busca-avancada"
            className="pt-3 mt-3 border-t border-slate-100 bg-slate-50/80 rounded-xl p-4 border border-slate-200 space-y-4 animate-in fade-in duration-150"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-emerald-600" />
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Critérios de Busca Avançada
                </h4>
              </div>
              {totalFiltrosAvancadosAtivos > 0 && (
                <button
                  type="button"
                  onClick={handleLimparFiltrosAvancados}
                  className="inline-flex items-center gap-1.5 text-xs text-rose-600 hover:text-rose-700 font-medium transition-colors"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Limpar Filtros Avançados
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Filtro 1: Nome do Emitente */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-slate-500" />
                  Nome do Emitente
                </label>
                <div className="relative">
                  <input
                    id="input-filtro-emitente"
                    type="text"
                    list="lista-emitentes-sugestoes"
                    placeholder="Razão social ou nome fantasia..."
                    value={filtroEmitente}
                    onChange={(e) => setFiltroEmitente(e.target.value)}
                    className="w-full text-xs pl-3 pr-8 py-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                  {filtroEmitente && (
                    <button
                      type="button"
                      onClick={() => setFiltroEmitente('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                  <datalist id="lista-emitentes-sugestoes">
                    {empresas.map((emp) => (
                      <option key={emp.id} value={emp.razaoSocial}>
                        {emp.nomeFantasia ? `${emp.nomeFantasia} (${emp.cnpj})` : emp.cnpj}
                      </option>
                    ))}
                  </datalist>
                </div>
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Filtra pelo emitente responsável pelo faturamento
                </span>
              </div>

              {/* Filtro 2: CNPJ */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <Search className="w-3.5 h-3.5 text-slate-500" />
                  CNPJ (Emitente ou Destinatário)
                </label>
                <div className="relative">
                  <input
                    id="input-filtro-cnpj"
                    type="text"
                    placeholder="Ex: 12.345.678/0001-90 ou dígitos..."
                    value={filtroCnpj}
                    onChange={(e) => setFiltroCnpj(e.target.value)}
                    className="w-full text-xs pl-3 pr-8 py-2 bg-white border border-slate-300 rounded-lg font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                  {filtroCnpj && (
                    <button
                      type="button"
                      onClick={() => setFiltroCnpj('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Busca CNPJ com ou sem formatação de pontos e traços
                </span>
              </div>

              {/* Filtro 3: Intervalo de Datas de Emissão */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-500" />
                  Intervalo de Datas de Emissão
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="relative">
                    <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-semibold pointer-events-none">
                      De
                    </span>
                    <input
                      id="input-filtro-data-inicio"
                      type="date"
                      value={filtroDataInicio}
                      onChange={(e) => setFiltroDataInicio(e.target.value)}
                      className="w-full text-xs pl-8 pr-2 py-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div className="relative">
                    <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-semibold pointer-events-none">
                      Até
                    </span>
                    <input
                      id="input-filtro-data-fim"
                      type="date"
                      value={filtroDataFim}
                      onChange={(e) => setFiltroDataFim(e.target.value)}
                      className="w-full text-xs pl-8 pr-2 py-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Filtra o período exato de emissão da NF perante a SEFAZ
                </span>
              </div>
            </div>

            {/* Atalhos Rápidos de Período */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200">
              <div className="flex flex-wrap items-center gap-1.5 text-xs">
                <span className="text-slate-500 text-[11px] font-medium mr-1">Atalhos de Período:</span>
                <button
                  type="button"
                  onClick={() => aplicarAtalhoPeriodo('hoje')}
                  className="px-2 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded text-[11px] font-medium transition-colors"
                >
                  Hoje
                </button>
                <button
                  type="button"
                  onClick={() => aplicarAtalhoPeriodo('7dias')}
                  className="px-2 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded text-[11px] font-medium transition-colors"
                >
                  Últimos 7 dias
                </button>
                <button
                  type="button"
                  onClick={() => aplicarAtalhoPeriodo('mes_atual')}
                  className="px-2 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded text-[11px] font-medium transition-colors"
                >
                  Mês Atual
                </button>
                <button
                  type="button"
                  onClick={() => aplicarAtalhoPeriodo('30dias')}
                  className="px-2 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded text-[11px] font-medium transition-colors"
                >
                  Últimos 30 dias
                </button>
                {(filtroDataInicio || filtroDataFim) && (
                  <button
                    type="button"
                    onClick={() => {
                      setFiltroDataInicio('');
                      setFiltroDataFim('');
                    }}
                    className="px-2 py-1 text-slate-500 hover:text-slate-700 text-[11px] font-medium underline transition-colors"
                  >
                    Limpar datas
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Resumo de Filtros Ativos & Contagem */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs text-slate-600">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-slate-500 font-medium">Exibindo:</span>
            <span className="font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded-full text-xs">
              {filteredNotas.length} de {notasFiscais.length} notas fiscais
            </span>

            {/* Chips de filtros ativos */}
            {filtroEmitente && (
              <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-full text-[11px]">
                <Building2 className="w-3 h-3 text-emerald-600" />
                Emitente: <strong className="font-semibold">{filtroEmitente}</strong>
                <button
                  type="button"
                  onClick={() => setFiltroEmitente('')}
                  className="hover:text-emerald-900"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {filtroCnpj && (
              <span className="inline-flex items-center gap-1 bg-blue-50 text-blue-800 border border-blue-200 px-2 py-0.5 rounded-full text-[11px]">
                CNPJ: <strong className="font-semibold font-mono">{filtroCnpj}</strong>
                <button
                  type="button"
                  onClick={() => setFiltroCnpj('')}
                  className="hover:text-blue-900"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {(filtroDataInicio || filtroDataFim) && (
              <span className="inline-flex items-center gap-1 bg-purple-50 text-purple-800 border border-purple-200 px-2 py-0.5 rounded-full text-[11px]">
                <Calendar className="w-3 h-3 text-purple-600" />
                Emissão:{' '}
                <strong className="font-semibold">
                  {filtroDataInicio ? new Date(filtroDataInicio + 'T12:00:00Z').toLocaleDateString('pt-BR') : 'Início'}
                  {' até '}
                  {filtroDataFim ? new Date(filtroDataFim + 'T12:00:00Z').toLocaleDateString('pt-BR') : 'Hoje'}
                </strong>
                <button
                  type="button"
                  onClick={() => {
                    setFiltroDataInicio('');
                    setFiltroDataFim('');
                  }}
                  className="hover:text-purple-900"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {selectedTipo !== 'todos' && (
              <span className="inline-flex items-center gap-1 bg-slate-100 text-slate-800 border border-slate-200 px-2 py-0.5 rounded-full text-[11px]">
                Modelo: {selectedTipo}
                <button
                  type="button"
                  onClick={() => setSelectedTipo('todos')}
                  className="hover:text-slate-950"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {selectedStatus !== 'todos' && (
              <span className="inline-flex items-center gap-1 bg-slate-100 text-slate-800 border border-slate-200 px-2 py-0.5 rounded-full text-[11px]">
                Status: {selectedStatus}
                <button
                  type="button"
                  onClick={() => setSelectedStatus('todos')}
                  className="hover:text-slate-950"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {searchTerm && (
              <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded-full text-[11px]">
                Busca: "{searchTerm}"
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="hover:text-amber-950"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}
          </div>

          {(totalFiltrosAvancadosAtivos > 0 ||
            searchTerm ||
            selectedTipo !== 'todos' ||
            selectedStatus !== 'todos') && (
            <button
              type="button"
              onClick={() => {
                setSearchTerm('');
                setSelectedTipo('todos');
                setSelectedStatus('todos');
                handleLimparFiltrosAvancados();
              }}
              className="text-xs text-slate-500 hover:text-slate-700 underline font-medium transition-colors"
            >
              Limpar todos os filtros
            </button>
          )}
        </div>
      </div>

      {/* Barra de Ações em Lote para Arquivamento Contábil */}
      {selectedNotaIds.length > 0 && (
        <div
          id="barra-acoes-em-lote"
          className="bg-emerald-900 text-white px-5 py-3.5 rounded-xl shadow-lg flex flex-col sm:flex-row items-center justify-between gap-3 border border-emerald-800 animate-in fade-in slide-in-from-top-2"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-800 rounded-lg shrink-0">
              <Archive className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <p className="text-sm font-bold text-emerald-100 flex items-center gap-2">
                <span>
                  {selectedNotaIds.length}{' '}
                  {selectedNotaIds.length === 1
                    ? 'nota fiscal selecionada'
                    : 'notas fiscais selecionadas'}
                </span>
                <span className="text-[11px] bg-emerald-800 text-emerald-200 px-2 py-0.5 rounded-full font-medium">
                  Pronto para arquivamento
                </span>
              </p>
              <p className="text-xs text-emerald-300 mt-0.5">
                O arquivo compactado .ZIP conterá os XMLs individuais de cada nota fiscal e o manifesto contábil com totais de impostos.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={handleLimparSelecao}
              className="px-3 py-2 text-xs font-medium text-emerald-200 hover:text-white hover:bg-emerald-800/80 rounded-lg transition-colors"
            >
              Desmarcar todas
            </button>

            <button
              id="btn-imprimir-lote-selecionadas"
              type="button"
              disabled={isPrintingPdf}
              onClick={() => handleImprimirLotePdf(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-800 hover:bg-emerald-700 text-white font-semibold text-xs rounded-lg border border-emerald-700 shadow-sm transition-colors disabled:opacity-60"
              title="Disparar impressora para os DANFEs selecionados"
            >
              {isPrintingPdf ? (
                <Loader2 className="w-4 h-4 animate-spin text-emerald-300" />
              ) : (
                <Printer className="w-4 h-4 text-emerald-300" />
              )}
              <span>Imprimir DANFEs (.PDF)</span>
            </button>

            <button
              id="btn-baixar-pdf-lote-selecionadas"
              type="button"
              disabled={isPrintingPdf}
              onClick={() => handleImprimirLotePdf(false)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs rounded-lg border border-emerald-600 shadow-sm transition-colors disabled:opacity-60"
              title="Baixar arquivo consolidado em PDF com todos os DANFEs"
            >
              <FileText className="w-4 h-4 text-emerald-300" />
              <span>Baixar .PDF ({selectedNotaIds.length})</span>
            </button>

            <button
              id="btn-baixar-zip-lote-ativo"
              type="button"
              disabled={isExportingZip}
              onClick={() => handleExportarLoteZip()}
              className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-400 hover:bg-emerald-300 text-emerald-950 font-bold text-xs rounded-lg shadow-sm transition-colors disabled:opacity-60"
            >
              {isExportingZip ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Compactando Lote...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Baixar Pacote .ZIP</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Table of Issued Notes */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600 uppercase tracking-wider">
              <tr>
                <th className="w-12 px-3 py-3 text-center">
                  <input
                    id="checkbox-selecionar-todas-notas"
                    type="checkbox"
                    title={
                      isAllFilteredSelected
                        ? 'Desmarcar todas as notas fiscais'
                        : 'Marcar todas as notas fiscais para exportação em lote'
                    }
                    checked={isAllFilteredSelected}
                    ref={(input) => {
                      if (input) {
                        input.indeterminate = isSomeFilteredSelected;
                      }
                    }}
                    onChange={handleToggleSelectAllFiltered}
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer"
                  />
                </th>
                <th className="px-5 py-3">Modelo / Nº</th>
                <th className="px-5 py-3">Emitente & Destinatário</th>
                <th className="px-5 py-3">Emissão</th>
                <th className="px-5 py-3">Valor Total</th>
                <th className="px-5 py-3">Status SEFAZ</th>
                <th className="px-5 py-3 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredNotas.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-slate-400">
                    <div className="max-w-sm mx-auto space-y-2">
                      <Search className="w-8 h-8 mx-auto text-slate-300" />
                      <p className="text-sm font-semibold text-slate-700">
                        Nenhuma nota fiscal encontrada
                      </p>
                      <p className="text-xs text-slate-500">
                        Nenhum documento atende aos critérios de emitente, CNPJ ou intervalo de datas informados.
                      </p>
                      {(totalFiltrosAvancadosAtivos > 0 || searchTerm) && (
                        <button
                          type="button"
                          onClick={() => {
                            setSearchTerm('');
                            handleLimparFiltrosAvancados();
                          }}
                          className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          Redefinir Filtros de Busca
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                filteredNotas.map((nota) => {
                  const emitente = getEmpresaEmitente(nota.empresaId);
                  const emitenteNome = emitente?.razaoSocial || emitente?.nomeFantasia || (nota as any).emitenteNome || 'Empresa Emitente';
                  const emitenteCnpj = emitente?.cnpj || (nota as any).emitenteCnpj || '';
                  const isSelected = selectedNotaIds.includes(nota.id);

                  return (
                    <tr
                      key={nota.id}
                      className={`transition-colors ${
                        isSelected
                          ? 'bg-emerald-50/60 hover:bg-emerald-50'
                          : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="w-12 px-3 py-4 text-center">
                        <input
                          id={`checkbox-nota-${nota.id}`}
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelectNota(nota.id)}
                          className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer"
                        />
                      </td>
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2 py-0.5 rounded text-xs font-bold uppercase ${
                              nota.tipo === 'NFe'
                                ? 'bg-blue-100 text-blue-800'
                                : nota.tipo === 'NFSe'
                                ? 'bg-purple-100 text-purple-800'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {nota.tipo}
                          </span>
                          <span className="font-semibold text-slate-900">
                            {nota.numero} (Série {nota.serie})
                          </span>
                          {nota.origem === 'importado_erp' && (
                            <span
                              className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200"
                              title="Nota capturada de XML gerado por outro ERP (Mod. 55) para cálculo do Simples Nacional"
                            >
                              Mod. 55 (Outro ERP)
                            </span>
                          )}
                        </div>
                        <span className="text-xs text-slate-400 font-mono block mt-0.5">
                          {nota.chaveAcesso.slice(0, 4)}...{nota.chaveAcesso.slice(-6)}
                        </span>
                      </td>
                      <td className="px-5 py-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                              EMIT
                            </span>
                            <span className="font-semibold text-slate-800 text-xs truncate max-w-[200px]" title={emitenteNome}>
                              {emitenteNome}
                            </span>
                            {emitenteCnpj && (
                              <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">
                                ({emitenteCnpj})
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              DEST
                            </span>
                            <span className="font-medium text-slate-900 text-xs truncate max-w-[200px]" title={nota.destinatarioNome}>
                              {nota.destinatarioNome}
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono hidden sm:inline">
                              ({nota.destinatarioCpfCnpj})
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-4 text-xs text-slate-600">
                        {new Date(nota.dataEmissao).toLocaleDateString('pt-BR')} às{' '}
                        {new Date(nota.dataEmissao).toLocaleTimeString('pt-BR', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="px-5 py-4 font-semibold text-slate-900">
                        R$ {nota.valorTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="px-5 py-4">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${
                            nota.status === 'autorizada'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}
                        >
                          {nota.status === 'autorizada' ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              Autorizada
                            </>
                          ) : (
                            <>
                              <Ban className="w-3.5 h-3.5 text-rose-600" />
                              Cancelada
                            </>
                          )}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            title="Visualizar DANFE"
                            onClick={() => setSelectedNotaForDanfe(nota)}
                            className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            title="Imprimir DANFE em .PDF"
                            onClick={() => handleImprimirDanfePdf(nota, true)}
                            className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                          <button
                            title="Baixar XML"
                            onClick={() => downloadXml(nota)}
                            className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
                          >
                            <Download className="w-4 h-4" />
                          </button>
                          {nota.status === 'autorizada' && (
                            <button
                              title="Cancelar NF-e"
                              onClick={() => setSelectedNotaForCancel(nota)}
                              className="p-1.5 text-slate-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors"
                            >
                              <Ban className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Emitir Nova Nota Fiscal */}
      {isEmitirModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full p-6 my-8 border border-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                  <Receipt className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">Emissão de Nota Fiscal Eletrônica</h3>
                  <p className="text-xs text-slate-500">Transmissão com validação de impostos e protocolo SEFAZ</p>
                </div>
              </div>
              <button
                onClick={() => setIsEmitirModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="mt-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                {formError}
              </div>
            )}

            <form onSubmit={handleEmitirNota} className="mt-4 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Empresa Emitente *
                  </label>
                  <select
                    value={formData.empresaId}
                    onChange={(e) => setFormData({ ...formData, empresaId: e.target.value })}
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    required
                  >
                    {empresas.map((emp) => (
                      <option key={emp.id} value={emp.id}>
                        {emp.razaoSocial}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Modelo de Nota *
                  </label>
                  <select
                    value={formData.tipo}
                    onChange={(e) =>
                      setFormData({ ...formData, tipo: e.target.value as 'NFe' | 'NFSe' | 'NFCe' })
                    }
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="NFe">NF-e (Mercadorias / Modelo 55)</option>
                    <option value="NFSe">NFS-e (Serviços Municipais)</option>
                    <option value="NFCe">NFC-e (Consumidor / Modelo 65)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Série</label>
                  <input
                    type="text"
                    value={formData.serie}
                    onChange={(e) => setFormData({ ...formData, serie: e.target.value })}
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Natureza da Operação / CFOP *
                </label>
                <input
                  type="text"
                  value={formData.naturezaOperacao}
                  onChange={(e) => setFormData({ ...formData, naturezaOperacao: e.target.value })}
                  placeholder="Ex: 5.102 - Venda de mercadoria adquirida de terceiros"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>

              {/* Destinatário */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Dados do Destinatário / Tomador
                  </span>
                  {clientes.length > 0 && (
                    <select
                      onChange={(e) => handleClienteSelect(e.target.value)}
                      className="text-xs px-2 py-1 bg-white border border-slate-300 rounded-md focus:outline-none"
                      defaultValue=""
                    >
                      <option value="" disabled>
                        Puxar cliente cadastrado...
                      </option>
                      {clientes.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.razaoSocial}
                        </option>
                      ))}
                    </select>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">Nome / Razão Social *</label>
                    <input
                      type="text"
                      value={formData.destinatarioNome}
                      onChange={(e) => setFormData({ ...formData, destinatarioNome: e.target.value })}
                      placeholder="Nome completo ou Razão Social"
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">CPF / CNPJ *</label>
                    <input
                      type="text"
                      value={formData.destinatarioCpfCnpj}
                      onChange={(e) => setFormData({ ...formData, destinatarioCpfCnpj: e.target.value })}
                      placeholder="00.000.000/0001-00"
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-slate-600 mb-1">E-mail para envio do XML e DANFE</label>
                  <input
                    type="email"
                    value={formData.destinatarioEmail}
                    onChange={(e) => setFormData({ ...formData, destinatarioEmail: e.target.value })}
                    placeholder="financeiro@empresa.com.br"
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Itens & Valores */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider block">
                  Item da Operação (Produto / Serviço)
                </span>

                <div>
                  <label className="block text-xs text-slate-600 mb-1">Descrição do Produto ou Serviço *</label>
                  <input
                    type="text"
                    value={formData.descricaoItem}
                    onChange={(e) => setFormData({ ...formData, descricaoItem: e.target.value })}
                    placeholder="Ex: Consultoria Contábil Especializada ou Notebook i7"
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white focus:outline-none"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">Quantidade</label>
                    <input
                      type="number"
                      min="1"
                      value={formData.quantidade}
                      onChange={(e) => setFormData({ ...formData, quantidade: Number(e.target.value) })}
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">Valor Unitário (R$)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      value={formData.valorUnitario || ''}
                      onChange={(e) => setFormData({ ...formData, valorUnitario: Number(e.target.value) })}
                      placeholder="0,00"
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">
                      {formData.tipo === 'NFSe' ? 'Alíq. ISS (%)' : 'Alíq. ICMS (%)'}
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={formData.tipo === 'NFSe' ? formData.aliquotaIss : formData.aliquotaIcms}
                      onChange={(e) =>
                        formData.tipo === 'NFSe'
                          ? setFormData({ ...formData, aliquotaIss: Number(e.target.value) })
                          : setFormData({ ...formData, aliquotaIcms: Number(e.target.value) })
                      }
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg bg-white focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">Subtotal da Nota</label>
                    <div className="w-full text-xs px-3 py-2 bg-slate-200 border border-slate-300 rounded-lg font-bold text-slate-900">
                      R${' '}
                      {(formData.quantidade * (formData.valorUnitario || 0)).toLocaleString('pt-BR', {
                        minimumFractionDigits: 2,
                      })}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEmitirModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-colors disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  {isSubmitting ? 'Transmitindo para a SEFAZ...' : 'Transmitir e Emitir NF-e'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Espelho DANFE */}
      {selectedNotaForDanfe && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full p-6 my-6 border border-slate-300 text-slate-900 font-sans">
            <div className="flex items-center justify-between pb-3 border-b border-slate-300">
              <span className="text-xs font-bold uppercase tracking-widest text-slate-500">
                DOCUMENTO AUXILIAR DA NOTA FISCAL ELETRÔNICA (DANFE)
              </span>
              <div className="flex items-center gap-2">
                <button
                  id="btn-modal-imprimir-danfe-pdf"
                  type="button"
                  disabled={isPrintingPdf}
                  onClick={() => handleImprimirDanfePdf(selectedNotaForDanfe, true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold rounded-lg text-white shadow-sm transition-colors disabled:opacity-50"
                  title="Disparar impressão do DANFE oficial em PDF"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Imprimir (.PDF)
                </button>
                <button
                  id="btn-modal-baixar-danfe-pdf"
                  type="button"
                  disabled={isPrintingPdf}
                  onClick={() => handleImprimirDanfePdf(selectedNotaForDanfe, false)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-xs font-semibold rounded-lg text-slate-700 transition-colors disabled:opacity-50"
                  title="Baixar arquivo .PDF do DANFE"
                >
                  <FileText className="w-3.5 h-3.5 text-slate-600" />
                  Baixar .PDF
                </button>
                <button
                  onClick={() => downloadXml(selectedNotaForDanfe)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-xs font-semibold rounded-lg text-emerald-700 transition-colors"
                  title="Baixar arquivo XML da NF-e"
                >
                  <Download className="w-3.5 h-3.5" />
                  XML
                </button>
                <button
                  onClick={() => setSelectedNotaForDanfe(null)}
                  className="p-1 text-slate-400 hover:text-slate-600 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* DANFE Box */}
            <div className="mt-4 border-2 border-slate-800 p-4 space-y-4 text-xs">
              {/* Top Header */}
              {(() => {
                const danfeEmitente = empresas.find((e) => e.id === selectedNotaForDanfe.empresaId) || selectedEmpresa;
                return (
                  <div className="grid grid-cols-12 gap-3 border-b border-slate-800 pb-3">
                    <div className="col-span-5 border-r border-slate-300 pr-3">
                      <h4 className="text-sm font-black uppercase text-slate-900">
                        {danfeEmitente?.razaoSocial || 'EMPRESA EMITENTE LTDA'}
                      </h4>
                      <p className="text-[11px] text-slate-600 mt-0.5">
                        CNPJ: {danfeEmitente?.cnpj || '12.345.678/0001-90'}
                      </p>
                      <p className="text-[11px] text-slate-600">
                        {danfeEmitente?.cidade || 'São Paulo'} - {danfeEmitente?.uf || 'SP'}
                      </p>
                    </div>
                    <div className="col-span-3 text-center border-r border-slate-300 pr-3">
                      <span className="block font-black text-sm">DANFE</span>
                      <span className="text-[10px] text-slate-500 block">Documento Auxiliar da NF-e</span>
                      <div className="mt-1 font-mono font-bold text-xs bg-slate-100 p-1 border border-slate-300">
                        Nº {selectedNotaForDanfe.numero}
                        <br />
                        SÉRIE {selectedNotaForDanfe.serie}
                      </div>
                    </div>
                    <div className="col-span-4 pl-1">
                      <span className="text-[10px] font-bold block uppercase text-slate-500">
                        Chave de Acesso Oficial (44 Dígitos)
                      </span>
                      <p className="font-mono text-[10px] font-bold tracking-tight text-slate-900 break-all bg-slate-50 p-1.5 border border-slate-300 rounded">
                        {selectedNotaForDanfe.chaveAcesso}
                      </p>
                      <p className="text-[10px] text-slate-500 mt-1">
                        Protocolo: {selectedNotaForDanfe.protocoloAutorizacao || '135260049281729'}
                      </p>
                    </div>
                  </div>
                );
              })()}

              {/* Destinatário */}
              <div className="border border-slate-800 p-2.5">
                <span className="font-bold uppercase text-[10px] text-slate-600 block mb-1">
                  DESTINATÁRIO / REMETENTE
                </span>
                <div className="grid grid-cols-12 gap-2 text-xs">
                  <div className="col-span-8">
                    <span className="text-slate-500 text-[10px] block">Nome / Razão Social:</span>
                    <span className="font-bold">{selectedNotaForDanfe.destinatarioNome}</span>
                  </div>
                  <div className="col-span-4">
                    <span className="text-slate-500 text-[10px] block">CNPJ / CPF:</span>
                    <span className="font-mono font-bold">{selectedNotaForDanfe.destinatarioCpfCnpj}</span>
                  </div>
                </div>
              </div>

              {/* Itens */}
              <div>
                <span className="font-bold uppercase text-[10px] text-slate-600 block mb-1">
                  DADOS DOS PRODUTOS / SERVIÇOS
                </span>
                <table className="w-full text-left border border-slate-800 text-[11px]">
                  <thead className="bg-slate-100 border-b border-slate-800 font-bold">
                    <tr>
                      <th className="p-1.5">Descrição</th>
                      <th className="p-1.5 text-center">Qtd</th>
                      <th className="p-1.5 text-right">Valor Unit.</th>
                      <th className="p-1.5 text-right">Valor Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-300">
                    {selectedNotaForDanfe.itens.map((item, idx) => (
                      <tr key={idx}>
                        <td className="p-1.5">{item.descricao}</td>
                        <td className="p-1.5 text-center">{item.quantidade}</td>
                        <td className="p-1.5 text-right">
                          R$ {item.valorUnitario.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="p-1.5 text-right font-semibold">
                          R$ {item.valorTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Cálculo do Imposto */}
              <div className="border border-slate-800 p-2.5 bg-slate-50">
                <span className="font-bold uppercase text-[10px] text-slate-600 block mb-1">
                  CÁLCULO DO IMPOSTO
                </span>
                <div className="grid grid-cols-4 gap-2 text-center text-xs">
                  <div className="border border-slate-300 p-1.5 bg-white">
                    <span className="text-[10px] text-slate-500 block">ICMS</span>
                    <span className="font-bold">
                      R${' '}
                      {(selectedNotaForDanfe.impostos.icms || 0).toLocaleString('pt-BR', {
                        minimumFractionDigits: 2,
                      })}
                    </span>
                  </div>
                  <div className="border border-slate-300 p-1.5 bg-white">
                    <span className="text-[10px] text-slate-500 block">PIS</span>
                    <span className="font-bold">
                      R${' '}
                      {(selectedNotaForDanfe.impostos.pis || 0).toLocaleString('pt-BR', {
                        minimumFractionDigits: 2,
                      })}
                    </span>
                  </div>
                  <div className="border border-slate-300 p-1.5 bg-white">
                    <span className="text-[10px] text-slate-500 block">COFINS</span>
                    <span className="font-bold">
                      R${' '}
                      {(selectedNotaForDanfe.impostos.cofins || 0).toLocaleString('pt-BR', {
                        minimumFractionDigits: 2,
                      })}
                    </span>
                  </div>
                  <div className="border border-emerald-500 bg-emerald-50 p-1.5 text-emerald-900">
                    <span className="text-[10px] text-emerald-700 block font-bold">TOTAL DA NOTA</span>
                    <span className="font-extrabold text-sm">
                      R${' '}
                      {selectedNotaForDanfe.valorTotal.toLocaleString('pt-BR', {
                        minimumFractionDigits: 2,
                      })}
                    </span>
                  </div>
                </div>
              </div>

              {/* Status footer */}
              <div className="text-center text-[10px] text-slate-500">
                {selectedNotaForDanfe.status === 'cancelada' ? (
                  <span className="text-rose-700 font-bold uppercase text-xs">
                    *** NOTA FISCAL CANCELADA - MOTIVO: {selectedNotaForDanfe.motivoCancelamento} ***
                  </span>
                ) : (
                  <span>
                    Documento emitido por ambiente em produção/homologação de software contábil com certificado digital
                    válido ICP-Brasil.
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Cancelar NF-e */}
      {selectedNotaForCancel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 border border-slate-200">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="p-2.5 bg-rose-50 rounded-xl">
                <Ban className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Cancelar Nota Fiscal</h3>
                <p className="text-xs text-slate-500">
                  NF-e Nº {selectedNotaForCancel.numero} (Série {selectedNotaForCancel.serie})
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-600 mt-4 leading-relaxed">
              O cancelamento de uma NF-e perante a Secretaria da Fazenda exige justificativa detalhada com no mínimo 15
              caracteres. Este evento é irreversível.
            </p>

            <div className="mt-3">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Justificativa Legal de Cancelamento *
              </label>
              <textarea
                value={cancelMotivo}
                onChange={(e) => setCancelMotivo(e.target.value)}
                placeholder="Informe o motivo (mínimo 15 caracteres)..."
                rows={3}
                className="w-full text-xs p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-rose-500 focus:outline-none"
              />
              <span className="text-[10px] text-slate-400 block mt-1">
                Caracteres digitados: {cancelMotivo.length} / mínimo 15
              </span>
            </div>

            <div className="flex items-center justify-end gap-3 mt-5">
              <button
                type="button"
                onClick={() => {
                  setSelectedNotaForCancel(null);
                  setCancelMotivo('');
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Voltar
              </button>
              <button
                type="button"
                disabled={isSubmitting || cancelMotivo.length < 15}
                onClick={handleConfirmarCancelamento}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-sm transition-colors disabled:opacity-50"
              >
                {isSubmitting ? 'Cancelando...' : 'Confirmar Cancelamento'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Importação de XMLs de Saída Modelo 55 (Outro ERP) */}
      <ImportarXmlSaidaModal
        isOpen={isImportXmlModalOpen}
        onClose={() => setIsImportXmlModalOpen(false)}
        onSuccess={() => {
          onRefresh();
        }}
        empresas={empresas}
        selectedEmpresa={selectedEmpresa}
      />
        </>
      )}
    </div>
  );
};
