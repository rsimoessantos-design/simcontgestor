import React from 'react';
import {
  LayoutDashboard,
  Building2,
  Users,
  CalendarCheck2,
  FolderArchive,
  Award,
  CheckSquare,
  Calendar,
  DollarSign,
  BarChart3,
  Settings,
  Database,
  FileText,
  ShieldCheck,
  Activity,
  CalendarCheck,
  FileBadge,
  UserCheck,
  Calculator,
  ChevronLeft,
  ChevronRight,
  X,
  ArrowDownToLine,
  Receipt,
  Store,
  ShieldAlert,
  Package,
  TrendingDown,
  BookOpen,
} from 'lucide-react';
import { NavSection, User } from '../types';

interface SidebarProps {
  currentSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  user: User;
  pendingObligationsCount?: number;
  pendingTasksCount?: number;
  onOpenManual?: () => void;
}

interface MenuItem {
  id: NavSection;
  label: string;
  icon: React.ElementType;
  badge?: number | string;
  badgeColor?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentSection,
  onSelectSection,
  collapsed,
  onToggleCollapse,
  mobileOpen,
  onCloseMobile,
  user,
  pendingObligationsCount = 4,
  pendingTasksCount = 3,
}) => {
  const menuItems: MenuItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    {
      id: 'conformidade_fiscal',
      label: 'Conformidade Fiscal',
      icon: ShieldAlert,
      badge: 'Radar',
      badgeColor: 'bg-indigo-600 text-white',
    },
    { id: 'empresas', label: 'Empresas', icon: Building2 },
    { id: 'clientes', label: 'Clientes', icon: Users },
    {
      id: 'simulador_tributario',
      label: 'Simulador Tributário',
      icon: Calculator,
    },
    {
      id: 'obrigacoes',
      label: 'Obrigações',
      icon: CalendarCheck2,
      badge: pendingObligationsCount,
      badgeColor: 'bg-rose-500 text-white',
    },
    { id: 'controle_entregas', label: 'Controle de Entregas', icon: CalendarCheck },
    { id: 'notas_fiscais', label: 'Notas Fiscais (NF-e)', icon: FileText },
    {
      id: 'simples_nacional',
      label: 'Simples Nacional & PGDAS-D',
      icon: Receipt,
      badge: 'DAS',
      badgeColor: 'bg-emerald-600 text-white',
    },
    {
      id: 'mei',
      label: 'Fechamento MEI & DASN',
      icon: Store,
      badge: 'MEI',
      badgeColor: 'bg-amber-600 text-white',
    },
    {
      id: 'captura_sefaz',
      label: 'Captura SEFAZ (DF-e)',
      icon: ArrowDownToLine,
      badge: 'DF-e',
      badgeColor: 'bg-indigo-600 text-white',
    },
    { id: 'certificados_digitais', label: 'Certificados Digitais', icon: ShieldCheck },
    { id: 'alvaras_licencas', label: 'Alvarás e Licenças', icon: FileBadge },
    { id: 'ecac_pendencias', label: 'e-CAC & Pendências', icon: Activity },
    { id: 'documentos', label: 'Documentos', icon: FolderArchive },
    { id: 'certidoes', label: 'Certidões', icon: Award },
    {
      id: 'tarefas',
      label: 'Tarefas',
      icon: CheckSquare,
      badge: pendingTasksCount,
      badgeColor: 'bg-amber-500 text-white',
    },
    { id: 'agenda', label: 'Agenda', icon: Calendar },
    { id: 'financeiro', label: 'Financeiro', icon: DollarSign },
    {
      id: 'cobrancas',
      label: 'Cobranças & Honorários',
      icon: Receipt,
      badge: 'Contratos',
      badgeColor: 'bg-emerald-600 text-white',
    },
    {
      id: 'patrimonio',
      label: 'Controle Patrimonial',
      icon: Package,
      badge: 'Ativos',
      badgeColor: 'bg-blue-600 text-white',
    },
    {
      id: 'contabilidade',
      label: 'Contabilidade & Análises',
      icon: TrendingDown,
      badge: 'DRE/BP',
      badgeColor: 'bg-indigo-600 text-white',
    },
    { id: 'rh', label: 'RH & DP (Colaboradores)', icon: UserCheck },
    { id: 'relatorios', label: 'Relatórios', icon: BarChart3 },
    { id: 'configuracoes', label: 'Configurações', icon: Settings },
    {
      id: 'banco_dados',
      label: 'Banco de Dados',
      icon: Database,
      badgeColor: 'bg-emerald-500 text-slate-900',
    },
  ];

  const handleItemClick = (id: NavSection) => {
    onSelectSection(id);
    onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Container */}
      <aside
        id="app-sidebar"
        className={`fixed lg:sticky top-0 left-0 z-50 h-screen flex flex-col bg-slate-900 text-slate-300 border-r border-slate-800 transition-all duration-300 ease-in-out ${
          collapsed ? 'lg:w-20' : 'lg:w-64'
        } ${
          mobileOpen ? 'translate-x-0 w-72' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Header / Logo */}
        <div className="h-16 px-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center text-white shrink-0 shadow-md shadow-emerald-900/40">
              <Building2 className="w-5 h-5" />
            </div>
            {(!collapsed || mobileOpen) && (
              <div className="flex flex-col truncate">
                <span className="font-bold text-white text-base tracking-tight leading-tight">
                  Contab<span className="text-emerald-400">Gest</span>
                </span>
                <span className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">
                  SaaS Contábil
                </span>
              </div>
            )}
          </div>

          {/* Close button on mobile */}
          <button
            onClick={onCloseMobile}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden"
            aria-label="Fechar menu"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Desktop Collapse Toggle */}
          <button
            onClick={onToggleCollapse}
            className="hidden lg:flex p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title={collapsed ? 'Expandir menu lateral' : 'Recolher menu lateral'}
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation Items */}
        <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1 scrollbar-thin scrollbar-thumb-slate-700">
          <div className="px-3 pb-2">
            {(!collapsed || mobileOpen) && (
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Menu Principal
              </p>
            )}
          </div>

          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentSection === item.id;

            return (
              <button
                key={item.id}
                id={`sidebar-item-${item.id}`}
                onClick={() => handleItemClick(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-emerald-600/15 text-emerald-400 border border-emerald-500/30'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white border border-transparent'
                } ${collapsed && !mobileOpen ? 'justify-center px-0' : ''}`}
                title={collapsed && !mobileOpen ? item.label : undefined}
              >
                <Icon className={`w-5 h-5 shrink-0 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                {(!collapsed || mobileOpen) && (
                  <span className="truncate text-left flex-1">{item.label}</span>
                )}
                {(!collapsed || mobileOpen) && item.badge && (typeof item.badge === 'string' || item.badge > 0) ? (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      item.badgeColor || 'bg-slate-700 text-slate-200'
                    }`}
                  >
                    {item.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>

        {/* Office & User Information Footer */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/40">
          {(!collapsed || mobileOpen) ? (
            <div className="flex items-center gap-3 p-2 rounded-lg bg-slate-800/60 border border-slate-700/60">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold shrink-0">
                {user.nome.substring(0, 2).toUpperCase()}
              </div>
              <div className="truncate flex-1">
                <p className="text-xs font-semibold text-white truncate">{user.nome}</p>
                <p className="text-[10px] text-slate-400 truncate">{user.cargo}</p>
              </div>
            </div>
          ) : (
            <div className="flex justify-center">
              <div
                className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xs font-bold"
                title={`${user.nome} (${user.cargo})`}
              >
                {user.nome.substring(0, 2).toUpperCase()}
              </div>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
