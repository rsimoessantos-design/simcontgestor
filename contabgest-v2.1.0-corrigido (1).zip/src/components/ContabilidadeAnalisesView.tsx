import React, { useState, useEffect, useMemo } from 'react';
import {
  FileSpreadsheet,
  TrendingUp,
  BarChart3,
  DollarSign,
  Building2,
  FolderTree,
  Download,
  Printer,
  Calendar,
  Layers,
  Percent,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ChevronRight,
  X,
  Package,
  Scale,
  ShieldCheck,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import {
  BalancoPatrimonialData,
  DreData,
  DfcData,
  IndicadoresContabeis,
  ContaContabil,
  CentroCusto,
  Empresa,
  BemPatrimonial,
} from '../types';
import {
  PLANO_CONTAS_DEMO,
  CENTROS_CUSTO_DEMO,
  BENS_PATRIMONIAIS_DEMO,
  gerarBalancoPatrimonial,
  gerarDre,
  gerarDfc,
  calcularIndicadoresContabeis,
} from '../data/demoPatrimonioContabil';
import { GraficoEvolucaoEbitdaFluxoCaixa } from './GraficoEvolucaoEbitdaFluxoCaixa';
import { BalanceteMensal } from './BalanceteMensal';
export { BalanceteMensal } from './BalanceteMensal';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface ContabilidadeAnalisesViewProps {
  empresas: Empresa[];
  selectedEmpresa?: Empresa;
  onNavigateToPatrimonio?: () => void;
}

type TabContabil = 'visao_geral' | 'balancete' | 'balanco' | 'dre' | 'dfc' | 'analises' | 'plano_contas' | 'centros_custo';

export const ContabilidadeAnalisesView: React.FC<ContabilidadeAnalisesViewProps> = ({
  empresas,
  selectedEmpresa,
  onNavigateToPatrimonio,
}) => {
  const [activeTab, setActiveTab] = useState<TabContabil>('visao_geral');
  const [empresaId, setEmpresaId] = useState<string>(selectedEmpresa?.id || '1');
  const [bens, setBens] = useState<BemPatrimonial[]>(BENS_PATRIMONIAIS_DEMO);
  const [planoContas, setPlanoContas] = useState<ContaContabil[]>(PLANO_CONTAS_DEMO);
  const [centrosCusto, setCentrosCusto] = useState<CentroCusto[]>(CENTROS_CUSTO_DEMO);

  // Modais de Criação
  const [modalNovaConta, setModalNovaConta] = useState(false);
  const [modalNovoCentroCusto, setModalNovoCentroCusto] = useState(false);

  // Form Nova Conta Contábil
  const [formContaCodigo, setFormContaCodigo] = useState('');
  const [formContaNome, setFormContaNome] = useState('');
  const [formContaTipo, setFormContaTipo] = useState<'sintetica' | 'analitica'>('analitica');
  const [formContaNatureza, setFormContaNatureza] = useState<'devedora' | 'credora'>('devedora');
  const [formContaGrupo, setFormContaGrupo] = useState<'ativo' | 'passivo' | 'patrimonio_liquido' | 'receita' | 'custo' | 'despesa'>('ativo');
  const [formContaGrau, setFormContaGrau] = useState<number>(4);
  const [formContaVinculo, setFormContaVinculo] = useState<any>('nenhum');

  // Form Novo Centro de Custo
  const [formCcCodigo, setFormCcCodigo] = useState('');
  const [formCcNome, setFormCcNome] = useState('');
  const [formCcResponsavel, setFormCcResponsavel] = useState('');
  const [formCcOrcamento, setFormCcOrcamento] = useState<number>(30000);

  // Busca e Filtros
  const [searchPlano, setSearchPlano] = useState('');
  const [filtroGrupoConta, setFiltroGrupoConta] = useState<string>('all');

  useEffect(() => {
    if (selectedEmpresa) {
      setEmpresaId(selectedEmpresa.id);
    }
  }, [selectedEmpresa]);

  // Carregar dados da API
  const carregarDados = async () => {
    try {
      const resBens = await fetch(`/api/patrimonio/bens?empresaId=${empresaId}`);
      if (resBens.ok) {
        const dataBens = await resBens.json();
        setBens(dataBens);
      }
      const resPc = await fetch('/api/contabilidade/plano-contas');
      if (resPc.ok) {
        const dataPc = await resPc.json();
        setPlanoContas(dataPc);
      }
      const resCc = await fetch(`/api/patrimonio/centros-custo?empresaId=${empresaId}`);
      if (resCc.ok) {
        const dataCc = await resCc.json();
        setCentrosCusto(dataCc);
      }
    } catch (err) {
      console.error('Erro ao carregar demonstrações contábeis:', err);
    }
  };

  useEffect(() => {
    carregarDados();
  }, [empresaId]);

  // Geração dinâmica das demonstrações a partir dos dados em tempo real
  const balanco: BalancoPatrimonialData = useMemo(() => {
    return gerarBalancoPatrimonial(bens, empresaId);
  }, [bens, empresaId]);

  const dre: DreData = useMemo(() => {
    return gerarDre(bens, empresaId);
  }, [bens, empresaId]);

  const dfc: DfcData = useMemo(() => {
    return gerarDfc(dre, bens, empresaId);
  }, [dre, bens, empresaId]);

  const indicadores: IndicadoresContabeis = useMemo(() => {
    return calcularIndicadoresContabeis(balanco, dre);
  }, [balanco, dre]);

  // Formatador de Moeda
  const fmtMoeda = (val: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);

  // Formatador de Percentual
  const fmtPct = (val: number) => `${(val || 0).toFixed(1)}%`;

  // Obter nome da empresa
  const empresaAtual = empresas.find((e) => e.id === empresaId);
  const nomeEmpresa = empresaAtual ? empresaAtual.nomeFantasia || empresaAtual.razaoSocial : 'Empresa Selecionada';

  // Submissão Nova Conta Contábil
  const handleSalvarNovaConta = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        codigo: formContaCodigo,
        nome: formContaNome,
        tipo: formContaTipo,
        natureza: formContaNatureza,
        grupo: formContaGrupo,
        grau: formContaGrau,
        saldoAtual: 0,
        vinculoPatrimonio: formContaVinculo,
      };
      const res = await fetch('/api/contabilidade/plano-contas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const nova = await res.json();
        setPlanoContas([...planoContas, nova].sort((a, b) => a.codigo.localeCompare(b.codigo)));
        setModalNovaConta(false);
        setFormContaCodigo('');
        setFormContaNome('');
      }
    } catch (err) {
      console.error('Erro ao salvar conta:', err);
    }
  };

  // Submissão Novo Centro de Custo
  const handleSalvarNovoCentroCusto = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        empresaId,
        codigo: formCcCodigo,
        nome: formCcNome,
        responsavel: formCcResponsavel,
        orcamentoMensal: formCcOrcamento,
      };
      const res = await fetch('/api/patrimonio/centros-custo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (res.ok) {
        const novo = await res.json();
        setCentrosCusto([...centrosCusto, novo]);
        setModalNovoCentroCusto(false);
        setFormCcCodigo('');
        setFormCcNome('');
        setFormCcResponsavel('');
      }
    } catch (err) {
      console.error('Erro ao salvar centro de custo:', err);
    }
  };

  // Exportar Relatório Contábil Consolidado (PDF)
  const handleExportarDemonstracoesPdf = () => {
    const doc = new jsPDF('portrait', 'pt', 'a4');
    doc.setFillColor(30, 41, 59);
    doc.rect(0, 0, 595, 60, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('CADERNO DE DEMONSTRAÇÕES CONTÁBEIS & ANÁLISE FINANCEIRA', 30, 30);
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text(`Empresa: ${nomeEmpresa}  |  Exercício: 2026 / 2025  |  Padrão NBC TG / IFRS`, 30, 46);

    // 1. DRE
    doc.setTextColor(30, 41, 59);
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('1. DEMONSTRAÇÃO DO RESULTADO DO EXERCÍCIO (DRE)', 30, 85);

    const dreBody = dre.linhas.map((l) => [
      l.descricao,
      fmtMoeda(l.valor2025),
      fmtMoeda(l.valor2026),
      fmtPct(l.analiseVertical),
      fmtPct(l.analiseHorizontal),
    ]);

    autoTable(doc, {
      head: [['Linha da DRE', '2025', '2026', 'AV (%)', 'AH (%)']],
      body: dreBody,
      startY: 95,
      theme: 'striped',
      styles: { fontSize: 8, cellPadding: 3.5 },
      headStyles: { fillColor: [44, 62, 80], textColor: [255, 255, 255] },
    });

    // 2. Indicadores
    const finalY = (doc as any).lastAutoTable.finalY + 20;
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('2. PRINCIPAIS INDICADORES ECONÔMICO-FINANCEIROS', 30, finalY);

    const indBody = [
      ['Margem EBITDA', fmtPct(indicadores.margemEbitda), 'Grau de Endividamento Geral', fmtPct(indicadores.endividamentoGeral)],
      ['Margem Líquida', fmtPct(indicadores.margemLiquida), 'Composição do Endividamento (CP)', fmtPct(indicadores.composicaoEndividamento)],
      ['Retorno s/ Patrimônio Líquido (ROE)', fmtPct(indicadores.roe), 'Liquidez Corrente', indicadores.liquidezCorrente.toFixed(2)],
      ['Retorno s/ Ativo Total (ROA)', fmtPct(indicadores.roa), 'Liquidez Geral', indicadores.liquidezGeral.toFixed(2)],
    ];

    autoTable(doc, {
      head: [['Indicador de Rentabilidade', 'Valor', 'Indicador Estrutural / Liquidez', 'Valor']],
      body: indBody,
      startY: finalY + 8,
      theme: 'grid',
      styles: { fontSize: 8, cellPadding: 4 },
      headStyles: { fillColor: [15, 23, 42], textColor: [255, 255, 255] },
    });

    doc.save(`Demonstracoes_Contabeis_${nomeEmpresa.replace(/\s+/g, '_')}_2026.pdf`);
  };

  // Dados para gráficos de evolução
  const dadosGraficoDre = [
    {
      periodo: '2025',
      ReceitaLiquida: dre.linhas.find((l) => l.codigo === '3.01')?.valor2025 || dre.receitaLiquida * 0.88,
      EBITDA: dre.ebitda * 0.86,
      Depreciacao: dre.despesaDepreciacao * 0.85,
      LucroLiquido: dre.lucroLiquido * 0.82,
    },
    {
      periodo: '2026',
      ReceitaLiquida: dre.receitaLiquida,
      EBITDA: dre.ebitda,
      Depreciacao: dre.despesaDepreciacao,
      LucroLiquido: dre.lucroLiquido,
    },
  ];

  return (
    <div className="space-y-6">
      {/* CABEÇALHO */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 text-indigo-700 rounded-lg">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">
                Contabilidade Gerencial & Demonstrações Financeiras
              </h1>
              <p className="text-sm text-slate-500">
                Balanço Patrimonial, DRE com EBITDA, DFC, Análise Vertical/Horizontal, Plano de Contas e Centros de Custo integrados ao Patrimônio.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Seletor de Empresa */}
          <select
            value={empresaId}
            onChange={(e) => setEmpresaId(e.target.value)}
            className="text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white text-slate-700 font-semibold focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
          >
            {empresas.map((emp) => (
              <option key={emp.id} value={emp.id}>
                {emp.nomeFantasia || emp.razaoSocial}
              </option>
            ))}
          </select>

          <button
            onClick={onNavigateToPatrimonio}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-blue-700 bg-blue-50 border border-blue-200 rounded-lg hover:bg-blue-100 transition-colors"
          >
            <Package className="w-4 h-4" />
            Ver Gestão de Bens Patrimoniais
          </button>

          <button
            onClick={() => setActiveTab('balancete')}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 transition-colors shadow-2xs cursor-pointer"
          >
            <Scale className="w-4 h-4 text-emerald-600" />
            Balancete Mensal
          </button>

          <button
            onClick={handleExportarDemonstracoesPdf}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-sm"
          >
            <Download className="w-4 h-4" />
            Exportar Caderno Contábil (PDF)
          </button>
        </div>
      </div>

      {/* TABS DE NAVEGAÇÃO */}
      <div className="flex items-center gap-1 border-b border-slate-200 bg-white px-4 rounded-xl shadow-xs overflow-x-auto">
        <button
          id="tab-contabil-visao-geral"
          onClick={() => setActiveTab('visao_geral')}
          className={`flex items-center gap-2 px-4 py-3.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'visao_geral'
              ? 'border-indigo-600 text-indigo-600 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <BarChart3 className="w-4 h-4 text-indigo-600" />
          Visão Geral & Tendências
          <span className="ml-1 px-2 py-0.5 text-[10px] font-bold rounded-full bg-indigo-100 text-indigo-700">
            12 Meses
          </span>
        </button>

        <button
          id="tab-contabil-balancete"
          onClick={() => setActiveTab('balancete')}
          className={`flex items-center gap-2 px-4 py-3.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'balancete'
              ? 'border-indigo-600 text-indigo-600 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Scale className="w-4 h-4 text-indigo-600" />
          Balancete Mensal
          <span className="ml-1 px-2 py-0.5 text-[10px] font-bold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
            Auditoria
          </span>
        </button>

        <button
          onClick={() => setActiveTab('balanco')}
          className={`flex items-center gap-2 px-4 py-3.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'balanco'
              ? 'border-indigo-600 text-indigo-600 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Layers className="w-4 h-4" />
          Balanço Patrimonial (BP)
        </button>

        <button
          onClick={() => setActiveTab('dre')}
          className={`flex items-center gap-2 px-4 py-3.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'dre'
              ? 'border-indigo-600 text-indigo-600 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          DRE & EBITDA
        </button>

        <button
          onClick={() => setActiveTab('dfc')}
          className={`flex items-center gap-2 px-4 py-3.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'dfc'
              ? 'border-indigo-600 text-indigo-600 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          Fluxo de Caixa (DFC)
        </button>

        <button
          onClick={() => setActiveTab('analises')}
          className={`flex items-center gap-2 px-4 py-3.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'analises'
              ? 'border-indigo-600 text-indigo-600 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          Análises & Indicadores (AV/AH)
        </button>

        <button
          onClick={() => setActiveTab('plano_contas')}
          className={`flex items-center gap-2 px-4 py-3.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'plano_contas'
              ? 'border-indigo-600 text-indigo-600 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <FolderTree className="w-4 h-4" />
          Plano de Contas
        </button>

        <button
          onClick={() => setActiveTab('centros_custo')}
          className={`flex items-center gap-2 px-4 py-3.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeTab === 'centros_custo'
              ? 'border-indigo-600 text-indigo-600 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Building2 className="w-4 h-4" />
          Centros de Custo
        </button>
      </div>

      {/* ===================================================================== */}
      {/* ABA 0 (PÁGINA INICIAL): VISÃO GERAL - EVOLUÇÃO EBITDA & FLUXO DE CAIXA */}
      {/* ===================================================================== */}
      {activeTab === 'visao_geral' && (
        <div className="space-y-6">
          <GraficoEvolucaoEbitdaFluxoCaixa
            dre={dre}
            bens={bens}
            empresaId={empresaId}
            empresaSelecionada={empresas.find((e) => e.id === empresaId)}
            onNavigateToDre={() => setActiveTab('dre')}
            onNavigateToDfc={() => setActiveTab('dfc')}
          />
        </div>
      )}

      {/* ===================================================================== */}
      {/* ABA BALANCETE: BALANCETE MENSAL DE VERIFICAÇÃO PARA AUDITORIA EXTERNA */}
      {/* ===================================================================== */}
      {activeTab === 'balancete' && (
        <BalanceteMensal
          planoContas={planoContas}
          bens={bens}
          empresa={empresaAtual}
          onNavigateToPlanoContas={() => setActiveTab('plano_contas')}
          onNavigateToBalanco={() => setActiveTab('balanco')}
          onNavigateToDre={() => setActiveTab('dre')}
        />
      )}

      {/* ===================================================================== */}
      {/* ABA 1: BALANÇO PATRIMONIAL (BP) COM ANÁLISE VERTICAL E HORIZONTAL */}
      {/* ===================================================================== */}
      {activeTab === 'balanco' && (
        <div className="space-y-6">
          {/* Banner de Acesso Rápido ao Gráfico de Evolução 12M */}
          <div className="bg-gradient-to-r from-indigo-50/90 via-white to-indigo-50/50 border border-indigo-200/80 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
            <div className="flex items-center gap-3 text-xs text-indigo-950">
              <div className="p-2 bg-indigo-600 text-white rounded-lg shadow-xs shrink-0">
                <TrendingUp className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-slate-900">
                  Evolução do EBITDA & Fluxo de Caixa (12 Meses):
                </span>
                <span className="text-slate-600 ml-1">
                  Confira a curva mensal integrada com margem operacional, conversão de liquidez e diagnóstico de tendências.
                </span>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('visao_geral')}
              className="px-3.5 py-1.5 text-xs font-bold text-indigo-700 bg-white border border-indigo-200 rounded-lg hover:bg-indigo-50 transition-colors shadow-2xs cursor-pointer whitespace-nowrap shrink-0"
            >
              Abrir Gráfico Completo (12M) →
            </button>
          </div>

          {/* Card Informativo de Equilíbrio Contábil */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <div>
                <span className="text-sm font-bold text-emerald-900">
                  Equilíbrio Patrimonial Verificado (Ativo = Passivo + Patrimônio Líquido)
                </span>
                <p className="text-xs text-emerald-700">
                  Total do Ativo: <span className="font-bold">{fmtMoeda(balanco.ativoTotal)}</span> | Total Passivo + PL: <span className="font-bold">{fmtMoeda(balanco.passivoTotalComPl)}</span>
                </p>
              </div>
            </div>
            <span className="text-xs font-semibold bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded">
              Diferença: R$ 0,00
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* LADO ESQUERDO: ATIVO */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="bg-slate-50 px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
                <h3 className="font-bold text-slate-900 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                  1. ATIVO TOTAL
                </h3>
                <span className="text-sm font-bold text-blue-900 font-mono">
                  {fmtMoeda(balanco.ativoTotal)}
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-600">
                  <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-2.5">Conta Patrimonial</th>
                      <th className="px-3 py-2.5 text-right">Saldo 2025</th>
                      <th className="px-3 py-2.5 text-right">Saldo 2026</th>
                      <th className="px-3 py-2.5 text-right">AV %</th>
                      <th className="px-3 py-2.5 text-right">AH %</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {balanco.linhas
                      .filter((l) => l.grupo === 'ativo')
                      .map((linha) => (
                        <tr
                          key={linha.codigo}
                          className={`${
                            linha.destaque
                              ? 'bg-slate-50 font-sans font-bold text-slate-900'
                              : linha.descricao.includes('Depreciação')
                              ? 'text-amber-700 bg-amber-50/30'
                              : ''
                          }`}
                        >
                          <td className="px-4 py-2 font-sans" style={{ paddingLeft: `${linha.nivel * 14}px` }}>
                            {linha.descricao}
                          </td>
                          <td className="px-3 py-2 text-right">{fmtMoeda(linha.saldo2025)}</td>
                          <td className="px-3 py-2 text-right font-semibold">{fmtMoeda(linha.saldo2026)}</td>
                          <td className="px-3 py-2 text-right font-sans text-blue-700 font-medium">
                            {fmtPct(linha.analiseVertical2026)}
                          </td>
                          <td className="px-3 py-2 text-right font-sans text-slate-600">
                            {linha.analiseHorizontal >= 0 ? `+${fmtPct(linha.analiseHorizontal)}` : fmtPct(linha.analiseHorizontal)}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* LADO DIREITO: PASSIVO & PATRIMÔNIO LÍQUIDO */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="bg-slate-50 px-5 py-3.5 border-b border-slate-200 flex items-center justify-between">
                <h3 className="font-bold text-slate-900 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
                  2. PASSIVO & PATRIMÔNIO LÍQUIDO
                </h3>
                <span className="text-sm font-bold text-emerald-900 font-mono">
                  {fmtMoeda(balanco.passivoTotalComPl)}
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-600">
                  <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-2.5">Obrigação / Capital</th>
                      <th className="px-3 py-2.5 text-right">Saldo 2025</th>
                      <th className="px-3 py-2.5 text-right">Saldo 2026</th>
                      <th className="px-3 py-2.5 text-right">AV %</th>
                      <th className="px-3 py-2.5 text-right">AH %</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono">
                    {balanco.linhas
                      .filter((l) => l.grupo === 'passivo_pl')
                      .map((linha) => (
                        <tr
                          key={linha.codigo}
                          className={`${
                            linha.destaque ? 'bg-slate-50 font-sans font-bold text-slate-900' : ''
                          }`}
                        >
                          <td className="px-4 py-2 font-sans" style={{ paddingLeft: `${linha.nivel * 14}px` }}>
                            {linha.descricao}
                          </td>
                          <td className="px-3 py-2 text-right">{fmtMoeda(linha.saldo2025)}</td>
                          <td className="px-3 py-2 text-right font-semibold">{fmtMoeda(linha.saldo2026)}</td>
                          <td className="px-3 py-2 text-right font-sans text-emerald-700 font-medium">
                            {fmtPct(linha.analiseVertical2026)}
                          </td>
                          <td className="px-3 py-2 text-right font-sans text-slate-600">
                            {linha.analiseHorizontal >= 0 ? `+${fmtPct(linha.analiseHorizontal)}` : fmtPct(linha.analiseHorizontal)}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* ABA 2: DRE & EBITDA COM ANÁLISE VERTICAL E HORIZONTAL */}
      {/* ===================================================================== */}
      {activeTab === 'dre' && (
        <div className="space-y-6">
          {/* Métricas Rápidas da DRE */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-slate-500 uppercase">Receita Líquida</span>
              <div className="text-2xl font-bold text-slate-900 mt-1 font-mono">
                {fmtMoeda(dre.receitaLiquida)}
              </div>
              <span className="text-xs text-emerald-600 font-semibold mt-1 inline-block">
                Base da Análise Vertical (100%)
              </span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-indigo-600 uppercase">EBITDA / LAIDA</span>
              <div className="text-2xl font-bold text-indigo-700 mt-1 font-mono">
                {fmtMoeda(dre.ebitda)}
              </div>
              <span className="text-xs text-indigo-600 font-semibold mt-1 inline-block">
                Margem EBITDA: {fmtPct(dre.margemEbitda)}
              </span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-amber-600 uppercase">Depreciação Patrimonial</span>
              <div className="text-2xl font-bold text-amber-700 mt-1 font-mono">
                {fmtMoeda(dre.despesaDepreciacao)}
              </div>
              <span className="text-xs text-slate-500 mt-1 inline-block">
                CPC 27 integrada aos ativos
              </span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs font-semibold text-emerald-600 uppercase">Lucro Líquido Final</span>
              <div className="text-2xl font-bold text-emerald-700 mt-1 font-mono">
                {fmtMoeda(dre.lucroLiquido)}
              </div>
              <span className="text-xs text-emerald-600 font-semibold mt-1 inline-block">
                Margem Líquida: {fmtPct(dre.margemLiquida)}
              </span>
            </div>
          </div>

          {/* Demonstração Detalhada em Tabela */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-900">Demonstração do Resultado do Exercício (DRE)</h3>
                <p className="text-xs text-slate-500">
                  Exercício social findo em 31/12/2026 comparativo com 2025.
                </p>
              </div>
              <div className="text-xs text-slate-600 bg-white px-3 py-1.5 rounded-lg border border-slate-300 font-medium">
                Análise Vertical calculada sobre a Receita Operacional Líquida (100%)
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-100 text-slate-700 text-xs font-semibold uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="px-6 py-3">Estrutura de Resultados</th>
                    <th className="px-4 py-3 text-right">Exercício 2025</th>
                    <th className="px-4 py-3 text-right">Exercício 2026</th>
                    <th className="px-4 py-3 text-right">Análise Vertical (AV%)</th>
                    <th className="px-4 py-3 text-right">Evolução (AH%)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono">
                  {dre.linhas.map((linha) => {
                    const isEbitda = linha.tipo === 'ebitda';
                    const isResultado = linha.tipo === 'resultado';
                    return (
                      <tr
                        key={linha.codigo}
                        className={`${
                          isEbitda
                            ? 'bg-indigo-50/80 font-sans font-bold text-indigo-950 border-y-2 border-indigo-200'
                            : isResultado
                            ? 'bg-emerald-100/70 font-sans font-bold text-emerald-950 text-base border-t-2 border-emerald-300'
                            : linha.destaque
                            ? 'bg-slate-50 font-sans font-bold text-slate-900'
                            : linha.descricao.includes('Depreciação')
                            ? 'text-amber-800 bg-amber-50/30'
                            : ''
                        }`}
                      >
                        <td className="px-6 py-2.5 font-sans">
                          {isEbitda && (
                            <span className="p-1 bg-indigo-600 text-white rounded text-[10px] mr-2">
                              DESTAQUE
                            </span>
                          )}
                          {linha.descricao}
                        </td>
                        <td className="px-4 py-2.5 text-right">{fmtMoeda(linha.valor2025)}</td>
                        <td className="px-4 py-2.5 text-right font-bold text-slate-900">{fmtMoeda(linha.valor2026)}</td>
                        <td className="px-4 py-2.5 text-right font-sans font-medium text-blue-700">
                          {fmtPct(linha.analiseVertical)}
                        </td>
                        <td className="px-4 py-2.5 text-right font-sans font-medium text-emerald-600">
                          {linha.analiseHorizontal >= 0 ? `+${fmtPct(linha.analiseHorizontal)}` : fmtPct(linha.analiseHorizontal)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* ABA 3: FLUXO DE CAIXA (DFC) */}
      {/* ===================================================================== */}
      {activeTab === 'dfc' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <div className="border-b border-slate-200 pb-4 mb-4 flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  Demonstração dos Fluxos de Caixa (DFC - Método Indireto)
                </h3>
                <p className="text-xs text-slate-500">
                  Conciliação do Lucro Líquido com o Caixa Gerado pelas Atividades Operacionais, Investimentos e Financiamento.
                </p>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-500 block">Variação Líquida de Caixa</span>
                <span className="text-xl font-bold font-mono text-emerald-700">
                  +{fmtMoeda(dfc.variacaoLiquidaCaixa)}
                </span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-2.5">Fluxos Financeiros / Atividade</th>
                    <th className="px-4 py-2.5 text-right">Exercício 2025</th>
                    <th className="px-4 py-2.5 text-right">Exercício 2026</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {dfc.linhas.map((l, idx) => (
                    <tr
                      key={idx}
                      className={`${
                        l.categoria === 'saldo'
                          ? 'bg-slate-50 font-bold font-sans text-slate-900'
                          : l.descricao.includes('Fluxo Líquido')
                          ? 'bg-blue-50/50 font-bold font-sans text-blue-900'
                          : ''
                      }`}
                    >
                      <td className="px-4 py-2.5 font-sans">{l.descricao}</td>
                      <td className="px-4 py-2.5 text-right">{fmtMoeda(l.valor2025)}</td>
                      <td className="px-4 py-2.5 text-right font-semibold text-slate-900">{fmtMoeda(l.valor2026)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* CONCILIAÇÃO FINAL */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-300 grid grid-cols-3 gap-4 text-center mt-6">
              <div>
                <span className="text-xs text-slate-500 block">Saldo de Caixa Inicial (01/01)</span>
                <span className="text-lg font-bold font-mono text-slate-800">{fmtMoeda(dfc.saldoInicialCaixa)}</span>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">Variação Líquida no Ano</span>
                <span className="text-lg font-bold font-mono text-emerald-700">+{fmtMoeda(dfc.variacaoLiquidaCaixa)}</span>
              </div>
              <div>
                <span className="text-xs text-slate-500 block">Saldo de Caixa Final (31/12)</span>
                <span className="text-lg font-bold font-mono text-blue-900">{fmtMoeda(dfc.saldoFinalCaixa)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* ABA 4: PAINEL DE ANÁLISES CONTÁBEIS & INDICADORES (EBITDA, ENDIVIDAMENTO) */}
      {/* ===================================================================== */}
      {activeTab === 'analises' && (
        <div className="space-y-6">
          {/* CARDS COM OS INDICADORES */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* GRUPO 1: RENTABILIDADE & EBITDA */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center gap-2 text-indigo-700 font-bold border-b border-slate-100 pb-2">
                <TrendingUp className="w-5 h-5" />
                <h4>Rentabilidade & Margens</h4>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Margem Bruta:</span>
                  <span className="font-bold text-slate-900">{fmtPct(indicadores.margemBruta)}</span>
                </div>
                <div className="flex justify-between items-center bg-indigo-50 p-1.5 rounded">
                  <span className="text-indigo-900 font-semibold">Margem EBITDA (LAIDA):</span>
                  <span className="font-bold text-indigo-700 text-sm">{fmtPct(indicadores.margemEbitda)}</span>
                </div>
                <div className="flex justify-between items-center bg-emerald-50 p-1.5 rounded">
                  <span className="text-emerald-900 font-semibold">Margem Líquida:</span>
                  <span className="font-bold text-emerald-700 text-sm">{fmtPct(indicadores.margemLiquida)}</span>
                </div>
                <div className="flex justify-between items-center pt-2 border-t border-slate-100">
                  <span className="text-slate-600">Retorno s/ Patrimônio (ROE):</span>
                  <span className="font-bold text-indigo-800">{fmtPct(indicadores.roe)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Retorno s/ Ativo Total (ROA):</span>
                  <span className="font-bold text-blue-800">{fmtPct(indicadores.roa)}</span>
                </div>
              </div>
            </div>

            {/* GRUPO 2: ENDIVIDAMENTO & ESTRUTURA */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center gap-2 text-amber-700 font-bold border-b border-slate-100 pb-2">
                <Percent className="w-5 h-5" />
                <h4>Endividamento & Estrutura</h4>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center bg-amber-50 p-1.5 rounded">
                  <span className="text-amber-900 font-semibold">Grau de Endividamento Geral:</span>
                  <span className="font-bold text-amber-800 text-sm">{fmtPct(indicadores.endividamentoGeral)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Composição do Endividamento (CP):</span>
                  <span className="font-bold text-slate-900">{fmtPct(indicadores.composicaoEndividamento)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Imobilização do Patrimônio Líquido:</span>
                  <span className="font-bold text-slate-900">{fmtPct(indicadores.imobilizacaoPatrimonioLiquido)}</span>
                </div>
                <div className="mt-3 p-2 bg-slate-50 rounded text-[11px] text-slate-500">
                  Índice de endividamento equilibrado (&lt;50%), com boa cobertura patrimonial do ativo imobilizado.
                </div>
              </div>
            </div>

            {/* GRUPO 3: LIQUIDEZ */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
              <div className="flex items-center gap-2 text-emerald-700 font-bold border-b border-slate-100 pb-2">
                <DollarSign className="w-5 h-5" />
                <h4>Índices de Liquidez</h4>
              </div>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center bg-emerald-50 p-1.5 rounded">
                  <span className="text-emerald-900 font-semibold">Liquidez Corrente:</span>
                  <span className="font-bold text-emerald-800 text-sm">{indicadores.liquidezCorrente.toFixed(2)}x</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Liquidez Seca (sem estoques):</span>
                  <span className="font-bold text-slate-900">{indicadores.liquidezSeca.toFixed(2)}x</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Liquidez Geral:</span>
                  <span className="font-bold text-slate-900">{indicadores.liquidezGeral.toFixed(2)}x</span>
                </div>
                <div className="mt-3 p-2 bg-slate-50 rounded text-[11px] text-slate-500">
                  A empresa possui R$ {indicadores.liquidezCorrente.toFixed(2)} em ativos circulantes para cada R$ 1,00 de dívida no curto prazo.
                </div>
              </div>
            </div>
          </div>

          {/* GRÁFICO COMPARATIVO 2025 vs 2026 */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
            <h3 className="font-bold text-slate-900 mb-1">
              Evolução dos Resultados: Receita Líquida vs EBITDA vs Depreciação vs Lucro Líquido
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Comparativo visual da geração de caixa operacional (EBITDA) e impacto contábil da depreciação dos bens.
            </p>

            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dadosGraficoDre} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="periodo" />
                  <YAxis tickFormatter={(v) => `R$ ${(v / 1000).toFixed(0)}k`} />
                  <Tooltip
                    formatter={(val: any) => [fmtMoeda(Number(val)), '']}
                    contentStyle={{ borderRadius: '8px', fontSize: '12px' }}
                  />
                  <Legend />
                  <Bar dataKey="ReceitaLiquida" name="Receita Líquida" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="EBITDA" name="EBITDA / LAIDA" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Depreciacao" name="Depreciação Patrimonial" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="LucroLiquido" name="Lucro Líquido" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Deseja analisar a evolução mensal contínua e a correlação com o caixa?
              </span>
              <button
                onClick={() => setActiveTab('visao_geral')}
                className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-lg hover:bg-indigo-100 transition-colors cursor-pointer"
              >
                <TrendingUp className="w-3.5 h-3.5" />
                Ver Evolução do EBITDA e Fluxo de Caixa nos Últimos 12 Meses →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* ABA 5: PLANO DE CONTAS CONTÁBIL */}
      {/* ===================================================================== */}
      {activeTab === 'plano_contas' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2.5 flex-1 w-full flex-wrap">
              <div className="relative flex-1 min-w-[220px]">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Buscar conta contábil por código ou descrição..."
                  value={searchPlano}
                  onChange={(e) => setSearchPlano(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <select
                value={filtroGrupoConta}
                onChange={(e) => setFiltroGrupoConta(e.target.value)}
                className="text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white text-slate-700"
              >
                <option value="all">Todos os Grupos</option>
                <option value="ativo">1. Ativo</option>
                <option value="passivo">2. Passivo</option>
                <option value="patrimonio_liquido">3. Patrimônio Líquido</option>
                <option value="receita">4. Receitas</option>
                <option value="custo">5. Custos</option>
                <option value="despesa">6. Despesas</option>
              </select>
            </div>

            <button
              onClick={() => setModalNovaConta(true)}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              Nova Conta Contábil
            </button>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-50 text-slate-700 text-xs font-semibold uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Código Contábil</th>
                    <th className="px-4 py-3">Nome da Conta</th>
                    <th className="px-4 py-3">Tipo</th>
                    <th className="px-4 py-3">Natureza</th>
                    <th className="px-4 py-3">Vínculo com Patrimônio</th>
                    <th className="px-4 py-3 text-right">Saldo Atual (R$)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {planoContas
                    .filter((c) => {
                      if (filtroGrupoConta !== 'all' && c.grupo !== filtroGrupoConta) return false;
                      if (searchPlano) {
                        const q = searchPlano.toLowerCase();
                        return c.codigo.toLowerCase().includes(q) || c.nome.toLowerCase().includes(q);
                      }
                      return true;
                    })
                    .map((conta) => (
                      <tr
                        key={conta.id}
                        className={`hover:bg-slate-50/70 transition-colors ${
                          conta.tipo === 'sintetica' ? 'bg-slate-50/40 font-bold text-slate-900' : ''
                        }`}
                      >
                        <td className="px-4 py-2.5 font-mono text-xs">
                          <span style={{ paddingLeft: `${(conta.grau - 1) * 12}px` }}>{conta.codigo}</span>
                        </td>
                        <td className="px-4 py-2.5">
                          <span className={conta.tipo === 'sintetica' ? 'font-bold' : ''}>
                            {conta.nome}
                          </span>
                        </td>
                        <td className="px-4 py-2.5">
                          <span
                            className={`text-xs px-2 py-0.5 rounded font-semibold ${
                              conta.tipo === 'sintetica'
                                ? 'bg-slate-200 text-slate-800'
                                : 'bg-blue-50 text-blue-700'
                            }`}
                          >
                            {conta.tipo.toUpperCase()}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-xs uppercase">
                          {conta.natureza === 'devedora' ? (
                            <span className="text-blue-700 font-semibold">Devedora (D)</span>
                          ) : (
                            <span className="text-emerald-700 font-semibold">Credora (C)</span>
                          )}
                        </td>
                        <td className="px-4 py-2.5">
                          {conta.vinculoPatrimonio !== 'nenhum' ? (
                            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
                              {conta.vinculoPatrimonio === 'imobilizado_custo'
                                ? 'Ativo Imobilizado'
                                : conta.vinculoPatrimonio === 'depreciacao_acumulada'
                                ? 'Deprec. Acumulada'
                                : 'Despesa Deprec.'}
                            </span>
                          ) : (
                            <span className="text-slate-400 text-xs">-</span>
                          )}
                        </td>
                        <td className="px-4 py-2.5 text-right font-mono font-medium text-slate-900">
                          {fmtMoeda(conta.saldoAtual)}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* ABA 6: CENTROS DE CUSTO */}
      {/* ===================================================================== */}
      {activeTab === 'centros_custo' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900">Centros de Custo & Alocação de Ativos</h3>
              <p className="text-xs text-slate-500">
                Segmentação para rateio de despesas, orçamentos mensais e controle de bens tombados por setor.
              </p>
            </div>

            <button
              onClick={() => setModalNovoCentroCusto(true)}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm"
            >
              <Plus className="w-4 h-4" />
              Novo Centro de Custo
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {centrosCusto.map((cc) => {
              // Bens pertencentes a esse centro de custo
              const bensDoCc = bens.filter((b) => b.centroCustoId === cc.id);
              const totalBens = bensDoCc.length;
              const valorPatrimonio = bensDoCc.reduce((acc, b) => acc + b.valorContabilLiquido, 0);

              return (
                <div key={cc.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                    <div>
                      <span className="font-mono text-xs text-indigo-600 font-bold bg-indigo-50 px-2 py-0.5 rounded">
                        {cc.codigo}
                      </span>
                      <h4 className="font-bold text-slate-900 mt-1">{cc.nome}</h4>
                    </div>
                    <Building2 className="w-5 h-5 text-slate-400" />
                  </div>

                  <div className="space-y-1.5 text-xs text-slate-600">
                    <div className="flex justify-between">
                      <span>Responsável:</span>
                      <span className="font-semibold text-slate-800">{cc.responsavel || 'Não definido'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Orçamento Mensal:</span>
                      <span className="font-semibold text-slate-800">{fmtMoeda(cc.orcamentoMensal)}</span>
                    </div>
                    <div className="flex justify-between pt-2 border-t border-slate-100">
                      <span>Bens Alocados:</span>
                      <span className="font-bold text-blue-700">{totalBens} equipamentos</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Valor do Patrimônio Alocado:</span>
                      <span className="font-bold text-emerald-700">{fmtMoeda(valorPatrimonio)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODAL: NOVA CONTA CONTÁBIL */}
      {/* ===================================================================== */}
      {modalNovaConta && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-bold text-slate-900">Cadastrar Nova Conta Contábil</h3>
              <button
                onClick={() => setModalNovaConta(false)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSalvarNovaConta} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Código Estruturado *</label>
                <input
                  type="text"
                  value={formContaCodigo}
                  onChange={(e) => setFormContaCodigo(e.target.value)}
                  placeholder="Ex: 1.2.3.01.0006"
                  required
                  className="w-full text-sm font-mono border border-slate-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nome / Descrição da Conta *</label>
                <input
                  type="text"
                  value={formContaNome}
                  onChange={(e) => setFormContaNome(e.target.value)}
                  placeholder="Ex: Equipamentos de Energia Solar"
                  required
                  className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Tipo da Conta *</label>
                  <select
                    value={formContaTipo}
                    onChange={(e) => setFormContaTipo(e.target.value as any)}
                    className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white"
                  >
                    <option value="analitica">Analítica (Recebe Lançamento)</option>
                    <option value="sintetica">Sintética (Totalizadora)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Natureza *</label>
                  <select
                    value={formContaNatureza}
                    onChange={(e) => setFormContaNatureza(e.target.value as any)}
                    className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white"
                  >
                    <option value="devedora">Devedora (D)</option>
                    <option value="credora">Credora (C)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Grupo *</label>
                  <select
                    value={formContaGrupo}
                    onChange={(e) => setFormContaGrupo(e.target.value as any)}
                    className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white"
                  >
                    <option value="ativo">1. Ativo</option>
                    <option value="passivo">2. Passivo</option>
                    <option value="patrimonio_liquido">3. Patrimônio Líquido</option>
                    <option value="receita">4. Receitas</option>
                    <option value="custo">5. Custos</option>
                    <option value="despesa">6. Despesas</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Vínculo com Patrimônio</label>
                  <select
                    value={formContaVinculo}
                    onChange={(e) => setFormContaVinculo(e.target.value)}
                    className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2 bg-white"
                  >
                    <option value="nenhum">Nenhum</option>
                    <option value="imobilizado_custo">Ativo Imobilizado (Custo)</option>
                    <option value="depreciacao_acumulada">Depreciação Acumulada</option>
                    <option value="despesa_depreciacao">Despesa de Depreciação</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setModalNovaConta(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
                >
                  Salvar Conta
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODAL: NOVO CENTRO DE CUSTO */}
      {/* ===================================================================== */}
      {modalNovoCentroCusto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <h3 className="font-bold text-slate-900">Novo Centro de Custo</h3>
              <button
                onClick={() => setModalNovoCentroCusto(false)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSalvarNovoCentroCusto} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Código *</label>
                <input
                  type="text"
                  value={formCcCodigo}
                  onChange={(e) => setFormCcCodigo(e.target.value)}
                  placeholder="Ex: CC-05"
                  required
                  className="w-full text-sm font-mono border border-slate-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nome do Centro de Custo *</label>
                <input
                  type="text"
                  value={formCcNome}
                  onChange={(e) => setFormCcNome(e.target.value)}
                  placeholder="Ex: Logística & Frota"
                  required
                  className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Gestor / Responsável</label>
                <input
                  type="text"
                  value={formCcResponsavel}
                  onChange={(e) => setFormCcResponsavel(e.target.value)}
                  placeholder="Ex: Roberto Silveira"
                  className="w-full text-sm border border-slate-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Orçamento Mensal Previsto (R$)</label>
                <input
                  type="number"
                  step="100"
                  value={formCcOrcamento}
                  onChange={(e) => setFormCcOrcamento(parseFloat(e.target.value) || 0)}
                  className="w-full text-sm font-semibold border border-slate-300 rounded-lg px-3 py-2"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setModalNovoCentroCusto(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100 rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
                >
                  Salvar Centro de Custo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
