import React, { useState, useEffect, useMemo } from 'react';
import {
  Receipt,
  Calculator,
  Building2,
  Calendar,
  CheckCircle2,
  AlertCircle,
  FileText,
  ShoppingBag,
  DollarSign,
  Download,
  Printer,
  QrCode,
  Send,
  RefreshCw,
  Plus,
  Search,
  Filter,
  ArrowRight,
  TrendingUp,
  Percent,
  Copy,
  Check,
  FileCheck,
  Clock,
  ShieldCheck,
  Sliders,
  Info,
} from 'lucide-react';
import {
  Empresa,
  NotaFiscal,
  ApuracaoSimplesNacional,
  ItemApuracaoAnexo,
  SegregacaoSimplesNacional,
  TipoAnexoSimples,
  User,
} from '../types';
import {
  apurarSimplesNacionalPeriodo,
} from '../utils/simplesNacionalCalculator';

interface SimplesNacionalViewProps {
  selectedEmpresa?: Empresa;
  empresas: Empresa[];
  notasFiscais: NotaFiscal[];
  currentUser?: User;
  onRefresh?: () => void;
}

export const SimplesNacionalView: React.FC<SimplesNacionalViewProps> = ({
  selectedEmpresa,
  empresas,
  notasFiscais,
  currentUser,
  onRefresh,
}) => {
  // Empresas enquadradas no Simples Nacional
  const empresasSimples = useMemo(() => {
    return empresas.filter(
      (e) => e.regimeTributario === 'Simples Nacional' || e.regimeTributario === 'MEI'
    );
  }, [empresas]);

  const [activeEmpresaId, setActiveEmpresaId] = useState<string>(
    selectedEmpresa && (selectedEmpresa.regimeTributario === 'Simples Nacional' || selectedEmpresa.regimeTributario === 'MEI')
      ? selectedEmpresa.id
      : empresasSimples[0]?.id || empresas[0]?.id || ''
  );

  const [competencia, setCompetencia] = useState<string>('09/2026');
  const [activeTab, setActiveTab] = useState<'apuracao' | 'documentos' | 'historico'>('apuracao');

  // RBT12 e Folha ajustáveis se o usuário quiser simular
  const [customRbt12, setCustomRbt12] = useState<string>('');
  const [customFolha12, setCustomFolha12] = useState<string>('');
  const [mostrarParametrosAvancados, setMostrarParametrosAvancados] = useState<boolean>(false);

  // Estado da apuração ativa
  const [apuracaoAtual, setApuracaoAtual] = useState<ApuracaoSimplesNacional | null>(null);
  const [historicoApuracoes, setHistoricoApuracoes] = useState<ApuracaoSimplesNacional[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isTransmitting, setIsTransmitting] = useState<boolean>(false);
  const [transmissaoSucesso, setTransmissaoSucesso] = useState<boolean>(false);
  const [pixCopiado, setPixCopiado] = useState<boolean>(false);
  const [linhaCopiada, setLinhaCopiada] = useState<boolean>(false);

  // Filtros da aba de documentos
  const [filtroTipoDoc, setFiltroTipoDoc] = useState<'todos' | 'NFe' | 'NFCe' | 'NFSe'>('todos');
  const [buscaDoc, setBuscaDoc] = useState<string>('');

  // Modal para lançamento rápido de Cupom Fiscal NFC-e ou NF-e
  const [showNovoDocModal, setShowNovoDocModal] = useState<boolean>(false);
  const [novoDocTipo, setNovoDocTipo] = useState<'NFCe' | 'NFe'>('NFCe');
  const [novoDocValor, setNovoDocValor] = useState<string>('1250.00');
  const [novoDocDescricao, setNovoDocDescricao] = useState<string>('Venda balcão de eletrônicos no PDV');
  const [novoDocSegregacao, setNovoDocSegregacao] = useState<SegregacaoSimplesNacional>('tributacao_integral');
  const [novoDocDestinatario, setNovoDocDestinatario] = useState<string>('Consumidor Final');

  const empresaAtual = useMemo(() => {
    return empresas.find((e) => e.id === activeEmpresaId) || empresas[0];
  }, [empresas, activeEmpresaId]);

  // Carregar histórico de apurações do backend
  const carregarHistorico = async () => {
    try {
      const res = await fetch(`/api/simples-nacional/apuracoes?empresaId=${activeEmpresaId}`);
      if (res.ok) {
        const data = await res.json();
        setHistoricoApuracoes(data);
        // Se houver apuração salva para a competência atual, carrega
        const salva = data.find((a: ApuracaoSimplesNacional) => a.competencia === competencia);
        if (salva) {
          setApuracaoAtual(salva);
        }
      }
    } catch (err) {
      console.warn('Usando motor local de apuração:', err);
    }
  };

  useEffect(() => {
    if (activeEmpresaId) {
      carregarHistorico();
      calcularApuracaoLocal();
    }
  }, [activeEmpresaId, competencia]);

  // Calcula a apuração com base nos dados
  const calcularApuracaoLocal = () => {
    if (!empresaAtual) return;
    setIsLoading(true);
    try {
      const notasEmpresa = notasFiscais.filter((nf) => nf.empresaId === empresaAtual.id);
      const rbt12Num = customRbt12
        ? parseFloat(customRbt12)
        : (empresaAtual.rbt12 || 1250000);
      const folha12Num = customFolha12
        ? parseFloat(customFolha12)
        : (empresaAtual.folhaPagamento12Meses || 340000);

      const resultado = apurarSimplesNacionalPeriodo({
        empresaId: empresaAtual.id,
        competencia,
        notasFiscais: notasEmpresa,
        rbt12: rbt12Num,
        folha12Meses: folha12Num,
      });
      setApuracaoAtual(resultado);
    } catch (err) {
      console.error('Erro ao calcular Simples Nacional:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Salvar Apuração no servidor
  const handleSalvarApuracao = async () => {
    if (!apuracaoAtual) return;
    try {
      setIsLoading(true);
      const res = await fetch('/api/simples-nacional/salvar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(apuracaoAtual),
      });
      if (res.ok) {
        const data = await res.json();
        setApuracaoAtual(data);
        carregarHistorico();
        alert('Apuração do Simples Nacional salva com sucesso!');
      }
    } catch (err) {
      console.error('Erro ao salvar apuração:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Transmitir Declaração PGDAS-D
  const handleTransmitirDeclaracao = async () => {
    if (!apuracaoAtual) return;
    const confirm = window.confirm(
      `Confirma a transmissão da declaração PGDAS-D da competência ${competencia} para a Receita Federal do Brasil?\nValor do DAS: R$ ${apuracaoAtual.valorTotalDas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`
    );
    if (!confirm) return;

    try {
      setIsTransmitting(true);
      // Primeiro garante que está salva
      await fetch('/api/simples-nacional/salvar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(apuracaoAtual),
      });

      // Transmite
      const res = await fetch(`/api/simples-nacional/transmitir/${apuracaoAtual.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          usuarioNome: currentUser?.nome || 'Carlos Eduardo Silveira',
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setApuracaoAtual(data.apuracao);
        setTransmissaoSucesso(true);
        carregarHistorico();
        if (onRefresh) onRefresh();
        setTimeout(() => setTransmissaoSucesso(false), 8000);
      } else {
        alert('Erro ao transmitir a declaração.');
      }
    } catch (err) {
      console.error('Erro na transmissão PGDAS-D:', err);
    } finally {
      setIsTransmitting(false);
    }
  };

  // Lançar novo cupom NFC-e ou NF-e
  const handleCriarNovoDocumento = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!empresaAtual) return;

    const valor = parseFloat(novoDocValor) || 0;
    if (valor <= 0) {
      alert('Informe um valor válido para a venda.');
      return;
    }

    const isNfce = novoDocTipo === 'NFCe';
    const cfop =
      novoDocSegregacao === 'substituicao_tributaria_icms' || novoDocSegregacao === 'icms_st_e_monofasico'
        ? '5.405'
        : '5.102';

    const novoDoc: Partial<NotaFiscal> = {
      empresaId: empresaAtual.id,
      numero: Math.floor(1000 + Math.random() * 8999),
      serie: isNfce ? '65' : '1',
      tipo: novoDocTipo,
      modeloDoc: isNfce ? '65' : '55',
      cfopPrincipal: cfop,
      anexoSimples: 'Anexo I',
      segregacaoTributaria: novoDocSegregacao,
      naturezaOperacao: `${cfop} - ${isNfce ? 'Venda no balcão a consumidor final (PDV)' : 'Venda de mercadoria adquirida de terceiros'}`,
      destinatarioNome: novoDocDestinatario || (isNfce ? 'Consumidor Final (Balcão)' : 'Cliente PJ'),
      destinatarioCpfCnpj: isNfce ? '000.000.000-00' : '12.345.678/0001-90',
      valorTotal: valor,
      valorServicosOuProdutos: valor,
      itens: [
        {
          descricao: novoDocDescricao || 'Mercadorias para revenda',
          quantidade: 1,
          valorUnitario: valor,
          valorTotal: valor,
          cfop,
        },
      ],
      dataEmissao: new Date().toISOString(),
      status: 'autorizada',
    };

    try {
      const res = await fetch('/api/notas-fiscais', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(novoDoc),
      });

      if (res.ok) {
        setShowNovoDocModal(false);
        if (onRefresh) onRefresh();
        // Recalcula apuração
        setTimeout(() => {
          calcularApuracaoLocal();
        }, 300);
      }
    } catch (err) {
      console.error('Erro ao emitir documento:', err);
    }
  };

  // Documentos da competência
  const documentosDoPeriodo = useMemo(() => {
    if (!empresaAtual) return [];
    const [mesComp, anoComp] = competencia.split('/');
    return notasFiscais.filter((nf) => {
      if (nf.empresaId !== empresaAtual.id) return false;
      const dataStr = nf.dataEmissao ? nf.dataEmissao.slice(0, 7) : '';
      const [anoDoc, mesDoc] = dataStr.split('-');
      if (mesDoc !== mesComp || anoDoc !== anoComp) return false;

      if (filtroTipoDoc !== 'todos' && nf.tipo !== filtroTipoDoc) return false;

      if (buscaDoc.trim()) {
        const busca = buscaDoc.toLowerCase();
        const numeroStr = String(nf.numero);
        const dest = nf.destinatarioNome?.toLowerCase() || '';
        const chave = nf.chaveAcesso?.toLowerCase() || '';
        return numeroStr.includes(busca) || dest.includes(busca) || chave.includes(busca);
      }

      return true;
    });
  }, [notasFiscais, empresaAtual, competencia, filtroTipoDoc, buscaDoc]);

  // Copiar Pix
  const handleCopiarPix = () => {
    if (apuracaoAtual?.pixQrCodePayload) {
      navigator.clipboard.writeText(apuracaoAtual.pixQrCodePayload);
      setPixCopiado(true);
      setTimeout(() => setPixCopiado(false), 3000);
    }
  };

  // Copiar Linha Digitável
  const handleCopiarLinha = () => {
    if (apuracaoAtual?.linhaDigitavel) {
      navigator.clipboard.writeText(apuracaoAtual.linhaDigitavel);
      setLinhaCopiada(true);
      setTimeout(() => setLinhaCopiada(false), 3000);
    }
  };

  // Impressão da Guia DAS
  const handleImprimirGuia = () => {
    window.print();
  };

  const isEmpresaSimples =
    empresaAtual?.regimeTributario === 'Simples Nacional' ||
    empresaAtual?.regimeTributario === 'MEI';

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12" id="modulo-simples-nacional">
      {/* HEADER PRINCIPAL */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
              <Receipt className="w-3.5 h-3.5" />
              Módulo Fiscal Automatizado
            </span>
            <span className="text-xs font-medium text-slate-500">LC 123/2006 & Res. CGSN 140/2018</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Fechamento do Simples Nacional & PGDAS-D
          </h1>
          <p className="text-sm text-slate-600">
            Apuração automática do imposto por faturamento de NF-e, NFC-e (balcão/PDV) e NFS-e com segregação de ST e monofásicos.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setShowNovoDocModal(true)}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl transition shadow-xs"
          >
            <Plus className="w-4 h-4" />
            Emitir NFC-e / NF-e Rápida
          </button>

          <button
            onClick={calcularApuracaoLocal}
            disabled={isLoading}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition shadow-sm disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            Recalcular Apuração
          </button>
        </div>
      </div>

      {/* SELETORES: EMPRESA E COMPETÊNCIA */}
      <div className="bg-slate-900 text-white p-5 rounded-2xl shadow-md grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
        <div className="md:col-span-5">
          <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
            <Building2 className="w-4 h-4 text-emerald-400" />
            Empresa Selecionada para Fechamento Fiscal:
          </label>
          <select
            value={activeEmpresaId}
            onChange={(e) => setActiveEmpresaId(e.target.value)}
            className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
          >
            {empresas.map((emp) => (
              <option key={emp.id} value={emp.id}>
                {emp.razaoSocial} ({emp.cnpj}) - {emp.regimeTributario}
              </option>
            ))}
          </select>
        </div>

        <div className="md:col-span-3">
          <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-emerald-400" />
            Competência de Apuração:
          </label>
          <select
            value={competencia}
            onChange={(e) => setCompetencia(e.target.value)}
            className="w-full bg-slate-800 border border-slate-700 text-white rounded-xl px-3 py-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
          >
            <option value="09/2026">09/2026 (Mês Atual em Aberto)</option>
            <option value="08/2026">08/2026 (Competência Anterior)</option>
            <option value="07/2026">07/2026 (Histórico)</option>
            <option value="06/2026">06/2026 (Histórico)</option>
          </select>
        </div>

        <div className="md:col-span-4 flex items-center justify-end gap-3 pt-2 md:pt-4">
          <button
            type="button"
            onClick={() => setMostrarParametrosAvancados(!mostrarParametrosAvancados)}
            className="text-xs text-slate-300 hover:text-emerald-400 flex items-center gap-1 underline transition"
          >
            <Sliders className="w-3.5 h-3.5" />
            {mostrarParametrosAvancados ? 'Ocultar Parâmetros RBT12/Folha' : 'Ajustar RBT12 / Folha'}
          </button>
        </div>

        {/* PARÂMETROS AVANÇADOS EXPANSÍVEIS */}
        {mostrarParametrosAvancados && (
          <div className="col-span-12 pt-3 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-slate-300 mb-1">
                RBT12 Customizado (R$):
                <span className="text-slate-400 text-[11px] block">
                  Deixe em branco para usar o RBT12 cadastrado na empresa (R${' '}
                  {(empresaAtual?.rbt12 || 1250000).toLocaleString('pt-BR')} )
                </span>
              </label>
              <input
                type="number"
                step="0.01"
                placeholder="Ex: 1250000.00"
                value={customRbt12}
                onChange={(e) => setCustomRbt12(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-sm text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-300 mb-1">
                Folha de Salários 12 Meses (Fator R):
                <span className="text-slate-400 text-[11px] block">
                  Utilizada para enquadramento do Fator R (Anexo III vs V)
                </span>
              </label>
              <input
                type="number"
                step="0.01"
                placeholder="Ex: 340000.00"
                value={customFolha12}
                onChange={(e) => setCustomFolha12(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-sm text-white"
              />
            </div>
          </div>
        )}
      </div>

      {/* AVISO SE A EMPRESA NÃO FOR SIMPLES NACIONAL */}
      {!isEmpresaSimples && (
        <div className="p-4 bg-amber-50 border border-amber-300 rounded-2xl flex items-start gap-3 text-amber-800">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="text-sm">
            <p className="font-semibold">
              Atenção: A empresa selecionada ({empresaAtual?.razaoSocial}) está enquadrada no{' '}
              {empresaAtual?.regimeTributario}.
            </p>
            <p className="text-amber-700 mt-1">
              O módulo do PGDAS-D destina-se a Microempresas (ME) e Empresas de Pequeno Porte (EPP)
              optantes pelo Simples Nacional. Para fins didáticos e de simulação, os cálculos
              podem ser executados com as regras do Simples Nacional ou você pode selecionar a empresa{' '}
              <strong>{empresasSimples[0]?.razaoSocial || 'Inovatech'}</strong>.
            </p>
          </div>
        </div>
      )}

      {/* FEEDBACK DE TRANSMISSÃO SUCESSO */}
      {transmissaoSucesso && (
        <div className="p-4 bg-emerald-50 border-2 border-emerald-500 rounded-2xl flex items-center justify-between text-emerald-900 shadow-sm animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold">
              <Check className="w-6 h-6" />
            </div>
            <div>
              <p className="font-bold text-base">Declaração PGDAS-D transmitida com sucesso à Receita Federal!</p>
              <p className="text-xs text-emerald-700">
                Protocolo: <strong>{apuracaoAtual?.protocoloTransmissao}</strong> | Recibo: {apuracaoAtual?.reciboDeclaracao}
              </p>
              <p className="text-xs text-emerald-700">
                A obrigação fiscal no controle do escritório foi automaticamente atualizada para <strong>ENTREGUE</strong>.
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('apuracao')}
            className="px-3 py-1.5 text-xs font-semibold bg-emerald-600 text-white rounded-lg hover:bg-emerald-700"
          >
            Ver Guia Emitida
          </button>
        </div>
      )}

      {/* CARDS COM MÉTRICAS CHAVE DA APURAÇÃO */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Receita Bruta Total */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Faturamento do Mês (RPA)</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900">
            R$ {(apuracaoAtual?.rpa || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-xs text-slate-500 mt-2 flex items-center gap-1.5">
            <span className="font-medium text-slate-700">{apuracaoAtual?.documentosResumo.totalDocumentos || 0}</span> documentos fiscais emitidos
          </div>
        </div>

        {/* Cupons Fiscais NFC-e (Balcão / Consumidor) */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Cupons NFC-e (Balcão)</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-purple-700">
            R$ {(apuracaoAtual?.documentosResumo.totalNfce.valor || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-xs text-slate-500 mt-2 flex items-center justify-between">
            <span>{apuracaoAtual?.documentosResumo.totalNfce.quantidade || 0} cupons modelo 65</span>
            <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800">PDV</span>
          </div>
        </div>

        {/* Faturamento NF-e Mercadorias */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Notas NF-e (Modelo 55)</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900">
            R$ {(apuracaoAtual?.documentosResumo.totalNfe.valor || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-xs text-slate-500 mt-2 flex items-center justify-between">
            <span>{apuracaoAtual?.documentosResumo.totalNfe.quantidade || 0} notas de saída</span>
            <span className="text-slate-400">Atacado / PJ</span>
          </div>
        </div>

        {/* Valor Total do Imposto DAS */}
        <div className="bg-gradient-to-br from-emerald-600 to-teal-700 p-5 rounded-2xl text-white shadow-md relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-emerald-100 uppercase tracking-wider">Total do DAS a Recolher</span>
            <Receipt className="w-5 h-5 text-emerald-200" />
          </div>
          <div className="text-2xl font-black tracking-tight">
            R$ {(apuracaoAtual?.valorTotalDas || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-xs text-emerald-100 mt-2 flex items-center justify-between">
            <span>Vencimento: 20/{competencia.split('/')[0] === '12' ? '01' : String(Number(competencia.split('/')[0]) + 1).padStart(2, '0')}/{competencia.split('/')[1]}</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white text-emerald-800">
              {apuracaoAtual?.status === 'transmitido_pgdas' ? 'Transmitido' : 'Calculado'}
            </span>
          </div>
        </div>
      </div>

      {/* NAVEGAÇÃO ENTRE ABAS */}
      <div className="border-b border-slate-200">
        <nav className="flex space-x-8" aria-label="Tabs">
          <button
            onClick={() => setActiveTab('apuracao')}
            className={`py-3 px-1 border-b-2 font-medium text-sm flex items-center gap-2 transition ${
              activeTab === 'apuracao'
                ? 'border-emerald-600 text-emerald-700 font-semibold'
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
            }`}
          >
            <Calculator className="w-4 h-4" />
            Apuração PGDAS-D & Guia DAS
          </button>

          <button
            onClick={() => setActiveTab('documentos')}
            className={`py-3 px-1 border-b-2 font-medium text-sm flex items-center gap-2 transition ${
              activeTab === 'documentos'
                ? 'border-emerald-600 text-emerald-700 font-semibold'
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
            }`}
          >
            <FileText className="w-4 h-4" />
            Notas & Cupons Fiscais ({documentosDoPeriodo.length})
          </button>

          <button
            onClick={() => setActiveTab('historico')}
            className={`py-3 px-1 border-b-2 font-medium text-sm flex items-center gap-2 transition ${
              activeTab === 'historico'
                ? 'border-emerald-600 text-emerald-700 font-semibold'
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
            }`}
          >
            <Clock className="w-4 h-4" />
            Histórico de Declarações ({historicoApuracoes.length})
          </button>
        </nav>
      </div>

      {/* ABA 1: APURAÇÃO PGDAS-D & GUIA DAS */}
      {activeTab === 'apuracao' && (
        <div className="space-y-6">
          {/* DETALHAMENTO DOS ANEXOS APURADOS */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4 pb-4 border-b border-slate-100">
              <div>
                <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Percent className="w-5 h-5 text-emerald-600" />
                  Memória de Cálculo e Segregação de Receitas
                </h2>
                <p className="text-xs text-slate-500">
                  Cálculo da alíquota efetiva por anexo com segregação de ICMS-ST e PIS/COFINS Monofásicos conforme Resolução CGSN nº 140/2018.
                </p>
              </div>

              <div className="text-right text-xs text-slate-500">
                <span>RBT12 Base: </span>
                <strong className="text-slate-800">
                  R$ {(apuracaoAtual?.rbt12 || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </strong>
                {apuracaoAtual?.fatorRCalculado !== undefined && apuracaoAtual.fatorRCalculado > 0 && (
                  <span className="ml-3 px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-medium">
                    Fator R: {(apuracaoAtual.fatorRCalculado * 100).toFixed(2)}% ({apuracaoAtual.fatorREnquadramento})
                  </span>
                )}
              </div>
            </div>

            {/* TABELA DE ITENS POR ANEXO */}
            <div className="space-y-4">
              {apuracaoAtual?.anexos && apuracaoAtual.anexos.length > 0 ? (
                apuracaoAtual.anexos.map((itemAnexo: ItemApuracaoAnexo, idx: number) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-slate-50 transition"
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-2.5 py-0.5 text-xs font-bold rounded-md bg-emerald-600 text-white">
                            {itemAnexo.anexo}
                          </span>
                          <span className="text-sm font-bold text-slate-800">{itemAnexo.descricao}</span>
                        </div>
                        <span className="text-xs text-slate-500 mt-1 block">
                          Enquadramento: <strong>{itemAnexo.faixaDescricao}</strong> | Alíquota Nominal:{' '}
                          {(itemAnexo.aliquotaNominal * 100).toFixed(2)}% | Parcela a Deduzir: R${' '}
                          {itemAnexo.parcelaDeduzir.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </span>
                      </div>

                      <div className="flex items-center gap-4 bg-white px-3.5 py-2 rounded-xl border border-slate-200 text-right">
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase block">Alíquota Efetiva Base</span>
                          <span className="text-sm font-bold text-emerald-700">
                            {(itemAnexo.aliquotaEfetivaBase * 100).toFixed(4)}%
                          </span>
                        </div>
                        <div className="h-6 w-px bg-slate-200" />
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase block">Total Devido Anexo</span>
                          <span className="text-base font-black text-slate-900">
                            R$ {itemAnexo.valorDevidoTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* SEGREGAÇÕES DA RECEITA */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-200 text-xs">
                      <div className="bg-white p-3 rounded-lg border border-slate-200">
                        <span className="text-slate-500 block mb-1">Tributação Integral (Venda Geral)</span>
                        <div className="flex justify-between items-baseline">
                          <span className="font-bold text-slate-800">
                            R$ {itemAnexo.receitaTributacaoIntegral.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                          </span>
                          <span className="text-emerald-700 font-medium">
                            {(itemAnexo.aliquotaEfetivaIntegral * 100).toFixed(2)}%
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 block mt-1">
                          Imposto: R$ {itemAnexo.valorTributacaoIntegral.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </span>
                      </div>

                      <div className="bg-white p-3 rounded-lg border border-slate-200">
                        <span className="text-slate-500 block mb-1 flex items-center justify-between">
                          <span>Substituição Tributária (ICMS-ST)</span>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 font-semibold">
                            ICMS Zerado no DAS
                          </span>
                        </span>
                        <div className="flex justify-between items-baseline">
                          <span className="font-bold text-slate-800">
                            R$ {itemAnexo.receitaSubstituicaoTributariaIcms.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                          </span>
                          <span className="text-amber-700 font-medium">
                            {(itemAnexo.aliquotaEfetivaSemIcms * 100).toFixed(2)}%
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 block mt-1">
                          Imposto: R$ {itemAnexo.valorSubstituicaoTributariaIcms.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </span>
                      </div>

                      <div className="bg-white p-3 rounded-lg border border-slate-200">
                        <span className="text-slate-500 block mb-1 flex items-center justify-between">
                          <span>PIS/COFINS Monofásicos</span>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-100 text-indigo-800 font-semibold">
                            Deduzido no PGDAS
                          </span>
                        </span>
                        <div className="flex justify-between items-baseline">
                          <span className="font-bold text-slate-800">
                            R$ {itemAnexo.receitaPisCofinsMonofasico.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                          </span>
                          <span className="text-indigo-700 font-medium">
                            {(itemAnexo.aliquotaEfetivaSemPisCofins * 100).toFixed(2)}%
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 block mt-1">
                          Benefício fiscal aplicado por NCM
                        </span>
                      </div>
                    </div>

                    {/* REPARTIÇÃO DOS TRIBUTOS FEDERAIS, ESTADUAIS E MUNICIPAIS */}
                    <div className="mt-3 pt-3 border-t border-slate-200">
                      <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-2">
                        Repartição Tributária Oficial do Anexo (Destinação):
                      </span>
                      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 text-center text-xs">
                        <div className="bg-white p-2 rounded border border-slate-200">
                          <span className="text-[10px] text-slate-400 block">IRPJ</span>
                          <span className="font-bold text-slate-800">
                            R$ {itemAnexo.reparticaoTributos.irpj.toFixed(2)}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded border border-slate-200">
                          <span className="text-[10px] text-slate-400 block">CSLL</span>
                          <span className="font-bold text-slate-800">
                            R$ {itemAnexo.reparticaoTributos.csll.toFixed(2)}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded border border-slate-200">
                          <span className="text-[10px] text-slate-400 block">COFINS</span>
                          <span className="font-bold text-slate-800">
                            R$ {itemAnexo.reparticaoTributos.cofins.toFixed(2)}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded border border-slate-200">
                          <span className="text-[10px] text-slate-400 block">PIS/PASEP</span>
                          <span className="font-bold text-slate-800">
                            R$ {itemAnexo.reparticaoTributos.pis.toFixed(2)}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded border border-slate-200">
                          <span className="text-[10px] text-slate-400 block">CPP (INSS)</span>
                          <span className="font-bold text-slate-800">
                            R$ {itemAnexo.reparticaoTributos.cpp.toFixed(2)}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded border border-slate-200">
                          <span className="text-[10px] text-slate-400 block">ICMS</span>
                          <span className="font-bold text-slate-800">
                            R$ {itemAnexo.reparticaoTributos.icms.toFixed(2)}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded border border-slate-200">
                          <span className="text-[10px] text-slate-400 block">IPI</span>
                          <span className="font-bold text-slate-800">
                            R$ {itemAnexo.reparticaoTributos.ipi.toFixed(2)}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded border border-slate-200">
                          <span className="text-[10px] text-slate-400 block">ISS</span>
                          <span className="font-bold text-slate-800">
                            R$ {itemAnexo.reparticaoTributos.iss.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-slate-500">
                  Nenhum faturamento registrado na competência {competencia}.
                </div>
              )}
            </div>

            {/* AÇÕES DE TRANSMISSÃO E GRAVAÇÃO */}
            <div className="mt-6 pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div className="text-xs text-slate-500 flex items-center gap-1.5">
                <Info className="w-4 h-4 text-slate-400" />
                <span>
                  O valor apurado integrará o DAS gerado com código de barras, Pix e recibo de transmissão no SERPRO.
                </span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={handleSalvarApuracao}
                  disabled={isLoading}
                  className="px-4 py-2 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
                >
                  Salvar Rascunho
                </button>

                <button
                  onClick={handleTransmitirDeclaracao}
                  disabled={isTransmitting || apuracaoAtual?.status === 'transmitido_pgdas'}
                  className={`inline-flex items-center gap-2 px-5 py-2 text-sm font-bold text-white rounded-xl transition shadow-sm ${
                    apuracaoAtual?.status === 'transmitido_pgdas'
                      ? 'bg-slate-400 cursor-not-allowed'
                      : 'bg-emerald-600 hover:bg-emerald-700'
                  }`}
                >
                  <Send className={`w-4 h-4 ${isTransmitting ? 'animate-pulse' : ''}`} />
                  {apuracaoAtual?.status === 'transmitido_pgdas'
                    ? 'PGDAS-D Já Transmitido'
                    : isTransmitting
                    ? 'Transmitindo à Receita...'
                    : 'Transmitir PGDAS-D Oficial'}
                </button>
              </div>
            </div>
          </div>

          {/* SIMULAÇÃO DA GUIA DAS OFICIAL (DOCUMENTO DE ARRECADAÇÃO DO SIMPLES NACIONAL) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 print:m-0 print:border-none">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 mb-4 border-b border-slate-200">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-black">
                  DAS
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">Documento de Arrecadação do Simples Nacional (DAS)</h3>
                  <p className="text-xs text-slate-500">
                    Guia única para recolhimento com código de barras e Pix QR Code
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleImprimirGuia}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
                >
                  <Printer className="w-4 h-4" />
                  Imprimir / PDF
                </button>
              </div>
            </div>

            {/* GUIA EM ESTILO OFICIAL */}
            <div className="border-2 border-slate-900 rounded-xl p-5 bg-white space-y-4">
              {/* CABEÇALHO DO DAS */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 pb-4 border-b-2 border-slate-900">
                <div className="md:col-span-8 flex items-center gap-3">
                  <div className="w-12 h-12 bg-slate-900 text-white rounded-lg flex items-center justify-center font-bold text-lg">
                    RFB
                  </div>
                  <div>
                    <h4 className="font-extrabold text-sm text-slate-900 uppercase">
                      Ministério da Fazenda - Secretaria Especial da Receita Federal do Brasil
                    </h4>
                    <p className="text-xs text-slate-700">Comitê Gestor do Simples Nacional - PGDAS-D</p>
                    <p className="text-xs font-semibold text-emerald-800 mt-0.5">
                      DOCUMENTO DE ARRECADAÇÃO DO SIMPLES NACIONAL (DAS)
                    </p>
                  </div>
                </div>

                <div className="md:col-span-4 bg-slate-100 p-3 rounded-lg border border-slate-300 text-right">
                  <span className="text-[10px] text-slate-500 uppercase block font-semibold">Número da Guia</span>
                  <span className="text-sm font-mono font-bold text-slate-900">{apuracaoAtual?.numeroGuiaDas}</span>
                  <div className="mt-1 flex justify-end gap-2 text-xs">
                    <span className="text-slate-500">Status:</span>
                    <span className="font-bold text-emerald-700 uppercase">{apuracaoAtual?.status}</span>
                  </div>
                </div>
              </div>

              {/* DADOS DA EMPRESA E VENCIMENTO */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <span className="text-[10px] text-slate-500 block uppercase font-semibold">Razão Social</span>
                  <span className="font-bold text-slate-900 block truncate">{empresaAtual?.razaoSocial}</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <span className="text-[10px] text-slate-500 block uppercase font-semibold">CNPJ</span>
                  <span className="font-mono font-bold text-slate-900 block">{empresaAtual?.cnpj}</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <span className="text-[10px] text-slate-500 block uppercase font-semibold">Período de Apuração</span>
                  <span className="font-bold text-slate-900 block">{competencia}</span>
                </div>
                <div className="p-2.5 bg-emerald-50 rounded border border-emerald-300">
                  <span className="text-[10px] text-emerald-700 block uppercase font-bold">Data de Vencimento</span>
                  <span className="font-bold text-emerald-900 text-sm block">
                    {apuracaoAtual?.dataVencimentoDas?.split('-').reverse().join('/') || '20/10/2026'}
                  </span>
                </div>
              </div>

              {/* VALOR TOTAL A RECOLHER */}
              <div className="p-4 bg-emerald-700 text-white rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-xs text-emerald-100 uppercase font-semibold block">
                    Valor Total do Documento a Pagar
                  </span>
                  <span className="text-2xl font-black">
                    R$ {(apuracaoAtual?.valorTotalDas || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </span>
                </div>

                <div className="text-right text-xs text-emerald-100">
                  <span>Autenticação Mecânica / Protocolo:</span>
                  <span className="font-mono block font-bold mt-0.5">
                    {apuracaoAtual?.protocoloTransmissao || 'AGUARDANDO TRANSMISSÃO'}
                  </span>
                </div>
              </div>

              {/* PIX E CÓDIGO DE BARRAS */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 pt-2">
                {/* QR CODE PIX */}
                <div className="md:col-span-4 p-4 border border-slate-200 rounded-xl bg-slate-50 flex flex-col items-center justify-center text-center">
                  <div className="w-32 h-32 bg-white p-2 rounded-lg border border-slate-300 shadow-xs flex items-center justify-center mb-3">
                    <QrCode className="w-24 h-24 text-slate-900" />
                  </div>
                  <span className="text-xs font-bold text-slate-800">Pague com Pix (Baixa Imediata)</span>
                  <span className="text-[11px] text-slate-500 mt-1">Aponte a câmera do aplicativo do seu banco</span>
                  <button
                    type="button"
                    onClick={handleCopiarPix}
                    className="mt-2.5 inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold text-emerald-700 bg-emerald-100 hover:bg-emerald-200 rounded-lg transition"
                  >
                    {pixCopiado ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Copy className="w-3.5 h-3.5" />}
                    {pixCopiado ? 'Código Pix Copiado!' : 'Copiar Código Pix'}
                  </button>
                </div>

                {/* CÓDIGO DE BARRAS & LINHA DIGITÁVEL */}
                <div className="md:col-span-8 p-4 border border-slate-200 rounded-xl bg-slate-50 flex flex-col justify-between">
                  <div>
                    <span className="text-xs font-bold text-slate-800 block mb-1">
                      Linha Digitável para Pagamento Bancário
                    </span>
                    <div className="flex items-center justify-between gap-2 p-2.5 bg-white rounded-lg border border-slate-300 font-mono text-xs font-semibold text-slate-900">
                      <span>{apuracaoAtual?.linhaDigitavel || '85880000000-0 00000000000-0 00000000000-0 00000000000-0'}</span>
                      <button
                        type="button"
                        onClick={handleCopiarLinha}
                        className="p-1 hover:bg-slate-100 rounded text-slate-600 hover:text-slate-900"
                        title="Copiar linha digitável"
                      >
                        {linhaCopiada ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* REPRESENTAÇÃO VISUAL DAS BARRAS */}
                  <div className="mt-4 p-3 bg-white rounded-lg border border-slate-300 flex flex-col items-center">
                    <div className="h-10 w-full flex items-center justify-center space-x-1 overflow-hidden opacity-80">
                      {Array.from({ length: 55 }).map((_, i) => (
                        <div
                          key={i}
                          className="h-full bg-slate-900"
                          style={{ width: `${(i % 3) + 1}px` }}
                        />
                      ))}
                    </div>
                    <span className="font-mono text-[10px] text-slate-500 mt-1">
                      {apuracaoAtual?.codigoBarras}
                    </span>
                  </div>

                  <p className="text-[10px] text-slate-500 mt-2 text-center">
                    Documento emitido eletronicamente pelo ContabGest em conformidade com o sistema PGDAS-D da Receita Federal do Brasil.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ABA 2: NOTAS FISCAIS & CUPONS FISCAIS DA COMPETÊNCIA */}
      {activeTab === 'documentos' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Documentos Fiscais de Saída ({competencia})
              </h3>
              <p className="text-xs text-slate-500">
                Lista de todas as Notas Fiscais Eletrônicas (NF-e mod 55), Cupons Fiscais (NFC-e mod 65) e Notas de Serviço (NFS-e) que compõem a receita do período.
              </p>
            </div>

            <button
              onClick={() => setShowNovoDocModal(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition shadow-xs self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              Lançar Venda Balcão (NFC-e)
            </button>
          </div>

          {/* BARRA DE FILTROS E BUSCA */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-xs font-semibold text-slate-500 flex items-center gap-1">
                <Filter className="w-3.5 h-3.5" /> Tipo:
              </span>
              <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setFiltroTipoDoc('todos')}
                  className={`px-2.5 py-1 rounded-lg transition ${
                    filtroTipoDoc === 'todos' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Todos ({notasFiscais.filter((n) => n.empresaId === empresaAtual?.id).length})
                </button>
                <button
                  type="button"
                  onClick={() => setFiltroTipoDoc('NFCe')}
                  className={`px-2.5 py-1 rounded-lg transition ${
                    filtroTipoDoc === 'NFCe' ? 'bg-purple-600 text-white shadow-xs' : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  NFC-e Balcão
                </button>
                <button
                  type="button"
                  onClick={() => setFiltroTipoDoc('NFe')}
                  className={`px-2.5 py-1 rounded-lg transition ${
                    filtroTipoDoc === 'NFe' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  NF-e Saída
                </button>
                <button
                  type="button"
                  onClick={() => setFiltroTipoDoc('NFSe')}
                  className={`px-2.5 py-1 rounded-lg transition ${
                    filtroTipoDoc === 'NFSe' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  NFS-e Serviços
                </button>
              </div>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Buscar por número, cliente..."
                value={buscaDoc}
                onChange={(e) => setBuscaDoc(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* TABELA DE DOCUMENTOS FISCAIS */}
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-700 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-3">Modelo / Tipo</th>
                  <th className="py-3 px-3">Número / Série</th>
                  <th className="py-3 px-3">Emissão</th>
                  <th className="py-3 px-3">Destinatário</th>
                  <th className="py-3 px-3">CFOP / Natureza</th>
                  <th className="py-3 px-3">Segregação Tributária</th>
                  <th className="py-3 px-3 text-right">Valor Total</th>
                  <th className="py-3 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {documentosDoPeriodo.length > 0 ? (
                  documentosDoPeriodo.map((doc) => (
                    <tr key={doc.id} className="hover:bg-slate-50/80 transition">
                      {/* Modelo / Tipo */}
                      <td className="py-3 px-3">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            doc.tipo === 'NFCe'
                              ? 'bg-purple-100 text-purple-800'
                              : doc.tipo === 'NFSe'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {doc.tipo === 'NFCe' && <ShoppingBag className="w-3 h-3" />}
                          {doc.tipo === 'NFe' && <FileText className="w-3 h-3" />}
                          {doc.tipo === 'NFSe' && <Receipt className="w-3 h-3" />}
                          {doc.tipo} {doc.modeloDoc ? `(Mod ${doc.modeloDoc})` : ''}
                        </span>
                      </td>

                      {/* Número / Série */}
                      <td className="py-3 px-3 font-mono font-bold text-slate-800">
                        Nº {doc.numero} <span className="text-slate-400 font-normal">Série {doc.serie}</span>
                      </td>

                      {/* Data Emissão */}
                      <td className="py-3 px-3">
                        {new Date(doc.dataEmissao).toLocaleDateString('pt-BR', {
                          day: '2-digit',
                          month: '2-digit',
                          year: 'numeric',
                        })}
                      </td>

                      {/* Destinatário */}
                      <td className="py-3 px-3">
                        <div className="font-semibold text-slate-800 truncate max-w-[200px]">
                          {doc.destinatarioNome || 'Consumidor Final'}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {doc.destinatarioCpfCnpj || '000.000.000-00'}
                        </div>
                      </td>

                      {/* CFOP */}
                      <td className="py-3 px-3">
                        <span className="font-mono font-bold text-slate-700 block">
                          {doc.cfopPrincipal || (doc.tipo === 'NFCe' ? '5.102' : doc.tipo === 'NFSe' ? '1.101' : '5.102')}
                        </span>
                        <span className="text-[10px] text-slate-400 truncate max-w-[180px] block">
                          {doc.naturezaOperacao || 'Venda de mercadorias'}
                        </span>
                      </td>

                      {/* Segregação */}
                      <td className="py-3 px-3">
                        {doc.segregacaoTributaria === 'substituicao_tributaria_icms' ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-800">
                            ICMS Retido por ST
                          </span>
                        ) : doc.segregacaoTributaria === 'icms_st_e_monofasico' ? (
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-100 text-indigo-800">
                            ST + PIS/COFINS Monofásico
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                            Tributação Integral
                          </span>
                        )}
                        <span className="text-[10px] text-slate-400 block mt-0.5">
                          {doc.anexoSimples || 'Anexo I'}
                        </span>
                      </td>

                      {/* Valor Total */}
                      <td className="py-3 px-3 text-right font-bold text-slate-900 font-mono text-sm">
                        R$ {doc.valorTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            doc.status === 'autorizada'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}
                        >
                          <CheckCircle2 className="w-3 h-3" />
                          {doc.status}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-400">
                      Nenhum documento fiscal encontrado para os filtros selecionados.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ABA 3: HISTÓRICO DE DECLARAÇÕES PGDAS-D TRANSMITIDAS */}
      {activeTab === 'historico' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
          <div className="pb-4 border-b border-slate-200">
            <h3 className="text-lg font-bold text-slate-900">Histórico de Apurações do Simples Nacional</h3>
            <p className="text-xs text-slate-500">
              Declarações PGDAS-D processadas e transmitidas à Receita Federal para a empresa {empresaAtual?.razaoSocial}.
            </p>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 border-b border-slate-200 text-[11px] font-semibold text-slate-700 uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-3">Competência</th>
                  <th className="py-3 px-3">Receita Bruta (RPA)</th>
                  <th className="py-3 px-3">RBT12 Acumulado</th>
                  <th className="py-3 px-3">Total do DAS</th>
                  <th className="py-3 px-3">Protocolo SERPRO</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3 text-center">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {historicoApuracoes.length > 0 ? (
                  historicoApuracoes.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50 transition">
                      <td className="py-3 px-3 font-bold text-slate-900">
                        {item.competencia}
                      </td>
                      <td className="py-3 px-3 font-mono">
                        R$ {item.rpa.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-3 px-3 font-mono">
                        R$ {item.rbt12.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-3 px-3 font-mono font-bold text-emerald-700 text-sm">
                        R$ {item.valorTotalDas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-3 px-3 font-mono text-[11px] text-slate-500">
                        {item.protocoloTransmissao || 'Não transmitido'}
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            item.status === 'transmitido_pgdas'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {item.status === 'transmitido_pgdas' ? 'Transmitido' : 'Rascunho'}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => {
                            setCompetencia(item.competencia);
                            setApuracaoAtual(item);
                            setActiveTab('apuracao');
                          }}
                          className="px-2.5 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition"
                        >
                          Ver Guia / Detalhes
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      Nenhuma apuração histórica encontrada.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL PARA LANÇAR NOVO CUPOM NFC-E OU NF-E */}
      {showNovoDocModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
                  <ShoppingBag className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900">
                    Lançar Venda / Cupom Fiscal Eletrônico
                  </h3>
                  <p className="text-xs text-slate-500">
                    Alimenta instantaneamente a receita da competência no PGDAS-D
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowNovoDocModal(false)}
                className="text-slate-400 hover:text-slate-600 text-xl font-bold"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCriarNovoDocumento} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Tipo de Documento Fiscal:
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setNovoDocTipo('NFCe')}
                    className={`py-2 px-3 rounded-xl border text-center font-bold transition flex items-center justify-center gap-1.5 ${
                      novoDocTipo === 'NFCe'
                        ? 'border-purple-500 bg-purple-50 text-purple-800'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <ShoppingBag className="w-4 h-4" />
                    NFC-e (Cupom Balcão PDV)
                  </button>
                  <button
                    type="button"
                    onClick={() => setNovoDocTipo('NFe')}
                    className={`py-2 px-3 rounded-xl border text-center font-bold transition flex items-center justify-center gap-1.5 ${
                      novoDocTipo === 'NFe'
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-800'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <FileText className="w-4 h-4" />
                    NF-e (Venda Mercantil 55)
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Valor Total da Venda (R$):
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={novoDocValor}
                  onChange={(e) => setNovoDocValor(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-sm text-slate-900 font-bold focus:bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Segregação Tributária do Simples Nacional:
                </label>
                <select
                  value={novoDocSegregacao}
                  onChange={(e) => setNovoDocSegregacao(e.target.value as SegregacaoSimplesNacional)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="tributacao_integral">
                    Tributação Integral (Venda Geral no Anexo I) - CFOP 5.102
                  </option>
                  <option value="substituicao_tributaria_icms">
                    Substituição Tributária (ICMS ST) - CFOP 5.405 (Dedução de ICMS no DAS)
                  </option>
                  <option value="icms_st_e_monofasico">
                    ICMS-ST + PIS/COFINS Monofásico (Eletrônicos/Autopeças) - CFOP 5.405
                  </option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Destinatário / Cliente:
                </label>
                <input
                  type="text"
                  value={novoDocDestinatario}
                  onChange={(e) => setNovoDocDestinatario(e.target.value)}
                  placeholder="Ex: Consumidor Final ou Razão Social"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Descrição dos Itens / Produto:
                </label>
                <input
                  type="text"
                  value={novoDocDescricao}
                  onChange={(e) => setNovoDocDescricao(e.target.value)}
                  placeholder="Ex: Teclado gamer, cabos, fones de ouvido"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowNovoDocModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  Confirmar Emissão
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
