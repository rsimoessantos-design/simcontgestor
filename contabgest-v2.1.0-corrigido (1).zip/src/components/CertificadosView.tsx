import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  ShieldX,
  Upload,
  Key,
  CheckCircle2,
  AlertTriangle,
  Clock,
  RefreshCw,
  Plus,
  Lock,
  Calendar,
  Building2,
  FileCode,
  HardDrive,
  X,
  Sparkles,
} from 'lucide-react';
import { CertificadoDigital, Empresa } from '../types';
import { api } from '../services/api';

interface CertificadosViewProps {
  selectedEmpresa?: Empresa;
  empresas: Empresa[];
  certificados: CertificadoDigital[];
  onRefresh: () => void;
}

export const CertificadosView: React.FC<CertificadosViewProps> = ({
  selectedEmpresa,
  empresas,
  certificados,
  onRefresh,
}) => {
  const [isInstaladorModalOpen, setIsInstaladorModalOpen] = useState(false);
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('todos');
  const [testingId, setTestingId] = useState<string | null>(null);
  const [testSuccessMessage, setTestSuccessMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Form State for certificate installation
  const [uploadStep, setUploadStep] = useState<1 | 2 | 3>(1);
  const [certFile, setCertFile] = useState<File | null>(null);
  const [certPassword, setCertPassword] = useState('');
  const [installData, setInstallData] = useState({
    empresaId: selectedEmpresa?.id || (empresas[0]?.id || ''),
    tipo: 'A1' as 'A1' | 'A3',
    titular: '',
    cnpjCpf: '',
    emissor: 'Certisign Autoridade Certificadora ICP-Brasil',
    validadeInicio: new Date().toISOString().split('T')[0],
    validadeFim: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  });

  const filteredCerts = certificados.filter((c) => {
    if (selectedStatusFilter === 'todos') return true;
    return c.status === selectedStatusFilter;
  });

  // Calculate alert counts
  const validos = certificados.filter((c) => c.status === 'valido').length;
  const alerta = certificados.filter((c) => c.status === 'alerta').length;
  const expirando = certificados.filter((c) => c.status === 'expirando').length;
  const expirados = certificados.filter((c) => c.status === 'expirado').length;

  const certificadosPrecisandoAtencao = certificados.filter(
    (c) => c.status === 'alerta' || c.status === 'expirando' || c.status === 'expirado'
  );

  const handleSimularTesteComunicacao = (cert: CertificadoDigital) => {
    setTestingId(cert.id);
    setTestSuccessMessage(null);

    setTimeout(() => {
      setTestingId(null);
      setTestSuccessMessage(
        `Comunicação bem-sucedida! Certificado de ${cert.titular} respondeu perfeitamente aos servidores da SEFAZ e e-CAC com TLS 1.2 ativo.`
      );
      setTimeout(() => setTestSuccessMessage(null), 5000);
    }, 1200);
  };

  const handleInstalarCertificadoServidor = async (certId: string) => {
    try {
      await api.instalarCertificado(certId, true);
      onRefresh();
      alert('Certificado instalado e ativado no cofre seguro do servidor com sucesso!');
    } catch (err: any) {
      alert(err.message || 'Erro ao instalar certificado.');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setCertFile(file);

      // Pre-fill extracted titular and CNPJ based on selected empresa
      const emp = empresas.find((e) => e.id === installData.empresaId);
      if (emp) {
        setInstallData((prev) => ({
          ...prev,
          titular: `${emp.razaoSocial} : ${emp.cnpj.replace(/\\D/g, '')}`,
          cnpjCpf: emp.cnpj,
        }));
      }
    }
  };

  const handleProximoPasso = () => {
    if (uploadStep === 1) {
      if (!certFile) {
        setErrorMsg('Por favor, selecione o arquivo do certificado digital (.pfx ou .p12).');
        return;
      }
      setErrorMsg('');
      setUploadStep(2);
    } else if (uploadStep === 2) {
      if (!certPassword) {
        setErrorMsg('Informe a senha do arquivo para descriptografar o par de chaves.');
        return;
      }
      setErrorMsg('');
      setUploadStep(3);
    }
  };

  const handleFinalizarInstalacao = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMsg('');

    try {
      const diasRestantes = Math.ceil(
        (new Date(installData.validadeFim).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
      );

      let status: 'valido' | 'alerta' | 'expirando' | 'expirado' = 'valido';
      if (diasRestantes <= 0) status = 'expirado';
      else if (diasRestantes <= 15) status = 'expirando';
      else if (diasRestantes <= 30) status = 'alerta';

      await api.createCertificado({
        empresaId: installData.empresaId,
        tipo: installData.tipo,
        categoria: (installData.cnpjCpf.length > 14 ? 'e-CNPJ' : 'e-CPF') as 'e-CNPJ' | 'e-CPF' | 'NF-e',
        titular: installData.titular || 'Certificado Digital ICP-Brasil',
        cnpjCpf: installData.cnpjCpf,
        emissor: installData.emissor,
        dataEmissao: installData.validadeInicio,
        dataValidade: installData.validadeFim,
        diasParaVencer: diasRestantes,
        status,
        instaladoNoServidor: true,
        senhaSalva: true,
      });

      setIsInstaladorModalOpen(false);
      setUploadStep(1);
      setCertFile(null);
      setCertPassword('');
      onRefresh();
    } catch (err: any) {
      setErrorMsg(err.message || 'Erro ao finalizar a instalação do certificado.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <ShieldCheck className="w-7 h-7 text-indigo-600" />
            Controle de Certificados Digitais & Instalador
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Monitoramento de vencimento de certificados A1/A3 e cofre centralizado para emissão e e-CAC
          </p>
        </div>

        <button
          id="btn-abrir-instalador-cert"
          onClick={() => {
            setIsInstaladorModalOpen(true);
            setUploadStep(1);
            setCertFile(null);
            setCertPassword('');
          }}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors"
        >
          <Upload className="w-4 h-4" />
          Instalar Novo Certificado Digital
        </button>
      </div>

      {/* Success Notification */}
      {testSuccessMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-3 animate-fade-in shadow-sm">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="font-medium">{testSuccessMessage}</span>
        </div>
      )}

      {/* Attention Warning Card if any expiring soon */}
      {certificadosPrecisandoAtencao.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3.5">
          <div className="p-2 bg-amber-100 text-amber-800 rounded-lg shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-bold text-amber-900">
              Atenção: {certificadosPrecisandoAtencao.length} certificado(s) requerem renovação imediata
            </h4>
            <p className="text-xs text-amber-700 mt-0.5">
              Certificados com prazo menor que 30 dias ou expirados impedem a emissão de notas fiscais e consultas ao
              e-CAC da Receita Federal.
            </p>
          </div>
        </div>
      )}

      {/* KPI Counters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div
          onClick={() => setSelectedStatusFilter(selectedStatusFilter === 'valido' ? 'todos' : 'valido')}
          className={`cursor-pointer rounded-xl border p-4 transition-all ${
            selectedStatusFilter === 'valido'
              ? 'border-emerald-500 ring-2 ring-emerald-500/20 bg-emerald-50/30'
              : 'border-slate-200 bg-white hover:border-emerald-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase">Válidos</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-bold text-slate-900 mt-2">{validos}</p>
          <p className="text-xs text-slate-500 mt-0.5">&gt; 30 dias de validade</p>
        </div>

        <div
          onClick={() => setSelectedStatusFilter(selectedStatusFilter === 'alerta' ? 'todos' : 'alerta')}
          className={`cursor-pointer rounded-xl border p-4 transition-all ${
            selectedStatusFilter === 'alerta'
              ? 'border-amber-500 ring-2 ring-amber-500/20 bg-amber-50/30'
              : 'border-slate-200 bg-white hover:border-amber-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase">Em Alerta</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-bold text-amber-600 mt-2">{alerta}</p>
          <p className="text-xs text-slate-500 mt-0.5">16 a 30 dias para vencer</p>
        </div>

        <div
          onClick={() => setSelectedStatusFilter(selectedStatusFilter === 'expirando' ? 'todos' : 'expirando')}
          className={`cursor-pointer rounded-xl border p-4 transition-all ${
            selectedStatusFilter === 'expirando'
              ? 'border-rose-500 ring-2 ring-rose-500/20 bg-rose-50/30'
              : 'border-slate-200 bg-white hover:border-rose-300'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase">Expirando</span>
            <ShieldAlert className="w-4 h-4 text-rose-600" />
          </div>
          <p className="text-2xl font-bold text-rose-600 mt-2">{expirando}</p>
          <p className="text-xs text-slate-500 mt-0.5">Menos de 15 dias restantes</p>
        </div>

        <div
          onClick={() => setSelectedStatusFilter(selectedStatusFilter === 'expirado' ? 'todos' : 'expirado')}
          className={`cursor-pointer rounded-xl border p-4 transition-all ${
            selectedStatusFilter === 'expirado'
              ? 'border-slate-700 ring-2 ring-slate-500/20 bg-slate-100'
              : 'border-slate-200 bg-white hover:border-slate-400'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase">Expirados</span>
            <ShieldX className="w-4 h-4 text-slate-600" />
          </div>
          <p className="text-2xl font-bold text-slate-700 mt-2">{expirados}</p>
          <p className="text-xs text-slate-500 mt-0.5">Vencidos (Renovação necessária)</p>
        </div>
      </div>

      {/* Certificates List */}
      <div className="space-y-3">
        {filteredCerts.length === 0 ? (
          <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500 text-sm">
            Nenhum certificado cadastrado para o filtro selecionado.
          </div>
        ) : (
          filteredCerts.map((cert) => {
            const emp = empresas.find((e) => e.id === cert.empresaId);
            return (
              <div
                key={cert.id}
                className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm hover:shadow transition-shadow flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-3.5">
                  <div
                    className={`p-3 rounded-xl shrink-0 ${
                      cert.status === 'valido'
                        ? 'bg-emerald-50 text-emerald-600'
                        : cert.status === 'alerta'
                        ? 'bg-amber-50 text-amber-600'
                        : cert.status === 'expirando'
                        ? 'bg-rose-50 text-rose-600'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {cert.status === 'valido' ? (
                      <ShieldCheck className="w-6 h-6" />
                    ) : cert.status === 'alerta' ? (
                      <Clock className="w-6 h-6" />
                    ) : cert.status === 'expirando' ? (
                      <ShieldAlert className="w-6 h-6" />
                    ) : (
                      <ShieldX className="w-6 h-6" />
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800 uppercase tracking-wide">
                        {cert.tipo}
                      </span>
                      <h4 className="text-sm font-bold text-slate-900">{cert.titular}</h4>
                      {cert.instaladoNoServidor ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                          <CheckCircle2 className="w-3 h-3" /> Instalado no Cofre
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full">
                          <Lock className="w-3 h-3" /> Aguardando Instalação
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-500 mt-1 flex items-center gap-3 flex-wrap">
                      <span className="font-mono">CNPJ: {cert.cnpjCpf}</span>
                      <span>•</span>
                      <span>{emp?.razaoSocial || 'Empresa do Grupo'}</span>
                      <span>•</span>
                      <span>Emissor: {cert.emissor}</span>
                    </p>

                    <div className="flex items-center gap-4 mt-2 text-xs">
                      <span className="text-slate-500">
                        Vencimento:{' '}
                        <strong className="text-slate-800">
                          {new Date(cert.validadeFim).toLocaleDateString('pt-BR')}
                        </strong>
                      </span>
                      <span
                        className={`font-semibold ${
                          cert.diasParaVencer <= 0
                            ? 'text-slate-600'
                            : cert.diasParaVencer <= 15
                            ? 'text-rose-600'
                            : cert.diasParaVencer <= 30
                            ? 'text-amber-600'
                            : 'text-emerald-600'
                        }`}
                      >
                        {cert.diasParaVencer <= 0
                          ? 'EXPIRADO'
                          : `${cert.diasParaVencer} dias restantes`}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 self-end md:self-center">
                  {!cert.instaladoNoServidor && (
                    <button
                      onClick={() => handleInstalarCertificadoServidor(cert.id)}
                      className="px-3 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors flex items-center gap-1.5"
                    >
                      <HardDrive className="w-3.5 h-3.5" />
                      Instalar no Servidor
                    </button>
                  )}

                  <button
                    disabled={testingId === cert.id}
                    onClick={() => handleSimularTesteComunicacao(cert)}
                    className="px-3 py-1.5 text-xs font-semibold border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg transition-colors flex items-center gap-1.5 disabled:opacity-50"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${testingId === cert.id ? 'animate-spin text-indigo-600' : ''}`}
                    />
                    {testingId === cert.id ? 'Testando...' : 'Testar SEFAZ/RFB'}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal Instalador de Certificados Digitais */}
      {isInstaladorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">Instalador de Certificado Digital</h3>
                  <p className="text-xs text-slate-500">Passo {uploadStep} de 3 - Instalação segura ICP-Brasil</p>
                </div>
              </div>
              <button
                onClick={() => setIsInstaladorModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {errorMsg && (
              <div className="mt-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                {errorMsg}
              </div>
            )}

            {/* Stepper Wizard */}
            <div className="mt-5">
              {uploadStep === 1 && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Selecione a Empresa Associada *
                    </label>
                    <select
                      value={installData.empresaId}
                      onChange={(e) => setInstallData({ ...installData, empresaId: e.target.value })}
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      {empresas.map((emp) => (
                        <option key={emp.id} value={emp.id}>
                          {emp.razaoSocial} ({emp.cnpj})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Modelo do Certificado *
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => setInstallData({ ...installData, tipo: 'A1' })}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          installData.tipo === 'A1'
                            ? 'border-indigo-600 bg-indigo-50/40 ring-1 ring-indigo-500'
                            : 'border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <span className="font-bold text-xs text-slate-900 block">Tipo A1 (Arquivo .PFX)</span>
                        <span className="text-[11px] text-slate-500 block mt-0.5">
                          Recomendado para servidores em nuvem e automação total
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setInstallData({ ...installData, tipo: 'A3' })}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          installData.tipo === 'A3'
                            ? 'border-indigo-600 bg-indigo-50/40 ring-1 ring-indigo-500'
                            : 'border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <span className="font-bold text-xs text-slate-900 block">Tipo A3 (Token / SmartCard)</span>
                        <span className="text-[11px] text-slate-500 block mt-0.5">
                          Conexão por dispositivo físico e driver PKCS#11
                        </span>
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Arquivo do Certificado (.pfx / .p12) *
                    </label>
                    <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-indigo-400 transition-colors bg-slate-50/50">
                      <FileCode className="w-8 h-8 text-indigo-500 mx-auto mb-2" />
                      <label
                        htmlFor="file-upload"
                        className="cursor-pointer text-xs font-semibold text-indigo-600 hover:text-indigo-700 underline block"
                      >
                        {certFile ? certFile.name : 'Clique para selecionar o arquivo .PFX ou .P12'}
                      </label>
                      <input
                        id="file-upload"
                        type="file"
                        accept=".pfx,.p12"
                        className="hidden"
                        onChange={handleFileChange}
                      />
                      <span className="text-[10px] text-slate-400 block mt-1">
                        Criptografia de 2048 bits com certificado de Raiz ICP-Brasil
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {uploadStep === 2 && (
                <div className="space-y-4">
                  <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl text-xs text-indigo-900 flex items-center gap-2.5">
                    <Lock className="w-4 h-4 text-indigo-600 shrink-0" />
                    <span>
                      Arquivo <strong>{certFile?.name}</strong> carregado com sucesso.
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Senha do Certificado Digital *
                    </label>
                    <input
                      type="password"
                      value={certPassword}
                      onChange={(e) => setCertPassword(e.target.value)}
                      placeholder="Digite a senha de emissão do PFX"
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      autoFocus
                    />
                    <span className="text-[11px] text-slate-500 block mt-1">
                      A senha será criptografada e armazenada de forma segura para permitir a assinatura eletrônica de
                      lotes fiscais.
                    </span>
                  </div>
                </div>
              )}

              {uploadStep === 3 && (
                <form onSubmit={handleFinalizarInstalacao} className="space-y-4">
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Chave pública validada e dados extraídos com sucesso!</span>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Nome do Titular / Razão Social
                    </label>
                    <input
                      type="text"
                      value={installData.titular}
                      onChange={(e) => setInstallData({ ...installData, titular: e.target.value })}
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-none"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">CNPJ do Titular</label>
                      <input
                        type="text"
                        value={installData.cnpjCpf}
                        onChange={(e) => setInstallData({ ...installData, cnpjCpf: e.target.value })}
                        className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Data de Vencimento
                      </label>
                      <input
                        type="date"
                        value={installData.validadeFim}
                        onChange={(e) => setInstallData({ ...installData, validadeFim: e.target.value })}
                        className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-none"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Autoridade Certificadora (Emissor)
                    </label>
                    <input
                      type="text"
                      value={installData.emissor}
                      onChange={(e) => setInstallData({ ...installData, emissor: e.target.value })}
                      className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-none"
                      required
                    />
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setUploadStep(2)}
                      className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                    >
                      Voltar
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="inline-flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors disabled:opacity-50"
                    >
                      <HardDrive className="w-3.5 h-3.5" />
                      {isSubmitting ? 'Instalando...' : 'Concluir e Instalar no Servidor'}
                    </button>
                  </div>
                </form>
              )}

              {uploadStep < 3 && (
                <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => {
                      if (uploadStep === 1) setIsInstaladorModalOpen(false);
                      else setUploadStep(1);
                    }}
                    className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={handleProximoPasso}
                    className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm transition-colors"
                  >
                    Avançar
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
