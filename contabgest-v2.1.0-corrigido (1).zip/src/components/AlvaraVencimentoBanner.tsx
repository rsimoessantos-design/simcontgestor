import React, { useState } from 'react';
import {
  AlertTriangle,
  FileBadge,
  Clock,
  ExternalLink,
  X,
  ChevronRight,
  ShieldAlert,
  Building2,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { AlvaraLicenca, Empresa } from '../types';

interface AlvaraVencimentoBannerProps {
  alvaras: AlvaraLicenca[];
  empresas?: Empresa[];
  onNavigateToAlvaras?: () => void;
  onOpenRenovacaoModal?: (alvara: AlvaraLicenca) => void;
  compact?: boolean;
}

export const AlvaraVencimentoBanner: React.FC<AlvaraVencimentoBannerProps> = ({
  alvaras,
  empresas = [],
  onNavigateToAlvaras,
  onOpenRenovacaoModal,
  compact = false,
}) => {
  const [dismissed, setDismissed] = useState(false);

  // Calcula os alvarás que vencem nos próximos 30 dias ou que já estão vencidos/vencendo
  const alvarasCriticos = alvaras
    .map((alv) => {
      const dataVal = new Date(alv.dataValidade);
      const hoje = new Date();
      const diffTime = dataVal.getTime() - hoje.getTime();
      const diasRestantes = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return {
        ...alv,
        diasCalculados: diasRestantes,
      };
    })
    .filter((alv) => {
      // Regra: até 30 dias para vencer (ou já vencidos se menor que 0)
      return alv.diasCalculados <= 30 && alv.status !== 'renovado';
    })
    .sort((a, b) => a.diasCalculados - b.diasCalculados);

  if (dismissed || alvarasCriticos.length === 0) {
    return null;
  }

  const maisUrgente = alvarasCriticos[0];
  const getEmpresaNome = (empresaId: string) => {
    const emp = empresas.find((e) => e.id === empresaId);
    return emp?.nomeFantasia || emp?.razaoSocial || 'Empresa';
  };

  if (compact) {
    return (
      <div className="bg-amber-500/10 border border-amber-300/80 rounded-xl p-3 text-amber-900 flex items-center justify-between gap-3 shadow-xs animate-in fade-in">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center shrink-0 text-amber-700">
            <Clock className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-amber-950">
                Lembrete de Vencimento (Janela de 30 Dias)
              </span>
              <span className="bg-amber-200 text-amber-900 font-bold px-1.5 py-0.2 rounded text-[10px]">
                {alvarasCriticos.length}{' '}
                {alvarasCriticos.length === 1 ? 'alvará crítico' : 'alvarás críticos'}
              </span>
            </div>
            <p className="text-[11px] text-amber-800">
              <span className="font-semibold">{maisUrgente.tipo}</span> ({getEmpresaNome(maisUrgente.empresaId)}) -{' '}
              {maisUrgente.diasCalculados <= 0 ? (
                <span className="text-rose-700 font-bold">VENCEU há {Math.abs(maisUrgente.diasCalculados)} dias</span>
              ) : (
                <span className="font-bold text-amber-900">vence em {maisUrgente.diasCalculados} dias</span>
              )}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {onNavigateToAlvaras && (
            <button
              onClick={onNavigateToAlvaras}
              className="px-2.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-xs transition-colors"
            >
              <span>Ver Licenças</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          )}
          <button
            onClick={() => setDismissed(true)}
            className="p-1 text-amber-700 hover:text-amber-900 rounded-md"
            title="Dispensar lembrete"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      id="alvara-vencimento-alert-banner"
      className="bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-amber-500/10 border-2 border-amber-400/80 rounded-2xl p-4 sm:p-5 text-slate-800 shadow-sm relative overflow-hidden animate-in fade-in slide-in-from-top-2"
    >
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-amber-200/20 rounded-full blur-2xl pointer-events-none -mr-20 -mt-20"></div>

      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-md">
            <Clock className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500 text-white shadow-xs">
                <ShieldAlert className="w-3.5 h-3.5" />
                Lembrete Automático: Vencimento de Alvarás e Licenças
              </span>
              <span className="text-xs font-bold text-amber-900 bg-amber-100 border border-amber-300 px-2 py-0.5 rounded-full">
                Janela de Alerta: 30 Dias Antes da Expiração
              </span>
            </div>

            <h3 className="text-base font-bold text-slate-900 mt-1">
              {alvarasCriticos.length === 1 ? (
                <>Atenção: 1 licença/alvará expira em menos de 30 dias</>
              ) : (
                <>Atenção: {alvarasCriticos.length} licenças e alvarás requerem renovação imediata</>
              )}
            </h3>

            <p className="text-xs text-slate-600 mt-0.5 max-w-3xl leading-relaxed">
              O sistema detectou documentos com vigência próxima ao término. Iniciar a solicitação de renovação junto aos órgãos competentes (Prefeitura, Corpo de Bombeiros, Vigilância Sanitária) com 30 dias de antecedência evita multas fiscais, interdições e bloqueios na emissão de notas fiscais.
            </p>

            {/* Lista dos alvarás críticos */}
            <div className="mt-3 flex flex-wrap gap-2">
              {alvarasCriticos.slice(0, 3).map((alv) => {
                const vencido = alv.diasCalculados <= 0;
                return (
                  <div
                    key={alv.id}
                    className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs ${
                      vencido
                        ? 'bg-rose-50 border-rose-300 text-rose-900'
                        : 'bg-white border-amber-300 text-amber-950 shadow-2xs'
                    }`}
                  >
                    <FileBadge className={`w-4 h-4 ${vencido ? 'text-rose-600' : 'text-amber-600'}`} />
                    <span className="font-semibold">{alv.tipo}</span>
                    <span className="text-slate-500">({getEmpresaNome(alv.empresaId)})</span>
                    <span
                      className={`font-mono font-bold px-1.5 py-0.2 rounded text-[11px] ${
                        vencido
                          ? 'bg-rose-600 text-white'
                          : 'bg-amber-200 text-amber-900'
                      }`}
                    >
                      {vencido
                        ? `Expirou há ${Math.abs(alv.diasCalculados)} dias`
                        : `Vence em ${alv.diasCalculados} dias`}
                    </span>
                  </div>
                );
              })}
              {alvarasCriticos.length > 3 && (
                <span className="inline-flex items-center px-2.5 py-1 text-xs text-slate-600 font-medium">
                  + {alvarasCriticos.length - 3} outros alvarás
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-row md:flex-col items-center md:items-end justify-between md:justify-center gap-2 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-amber-200">
          <div className="flex items-center gap-2">
            {onNavigateToAlvaras && (
              <button
                id="btn-ver-todos-alvaras-alerta"
                onClick={onNavigateToAlvaras}
                className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs rounded-xl shadow-sm flex items-center gap-1.5 transition-colors"
              >
                <FileBadge className="w-3.5 h-3.5" />
                <span>Gerenciar Licenças</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            )}
            <button
              onClick={() => setDismissed(true)}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-black/5 transition-colors"
              title="Dispensar este aviso por agora"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <span className="text-[10px] text-slate-500 font-medium">
            Monitoramento 24h SEFAZ & Prefeituras
          </span>
        </div>
      </div>
    </div>
  );
};
