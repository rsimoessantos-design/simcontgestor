import React from 'react';
import {
  Calendar as CalendarIcon,
  BarChart3,
  Settings,
  Database,
  FileSpreadsheet,
  Download,
  Shield,
  Server,
  UserCheck,
  CheckCircle2,
} from 'lucide-react';
import { Empresa, NavSection } from '../types';

interface SectionProps {
  selectedEmpresa?: Empresa;
}

export const AgendaView: React.FC<SectionProps> = ({ selectedEmpresa }) => {
  const events = [
    {
      data: '15/09/2026',
      titulo: 'Vencimento DCTFWeb e EFD-Contribuições [DEMO]',
      tipo: 'Fiscal',
      hora: '17:00',
      status: 'urgente',
    },
    {
      data: '18/09/2026',
      titulo: 'Renovação CND FGTS (CRF) Caixa Econômica [DEMO]',
      tipo: 'Certidão',
      hora: '14:00',
      status: 'alerta',
    },
    {
      data: '20/09/2026',
      titulo: 'Transmissão PGDAS-D Simples Nacional [DEMO]',
      tipo: 'Tributário',
      hora: '18:00',
      status: 'normal',
    },
    {
      data: '25/09/2026',
      titulo: 'Reunião Mensal de Alinhamento Tributário com Sócios [DEMO]',
      tipo: 'Atendimento',
      hora: '10:30',
      status: 'normal',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-bold text-slate-900">Agenda e Prazos Fiscais</h1>
          <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
            DEMO
          </span>
        </div>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          {selectedEmpresa
            ? `Cronograma de compromissos para: ${selectedEmpresa.nomeFantasia}`
            : 'Cronograma consolidado de prazos tributários e atendimentos do escritório'}
        </p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 divide-y divide-slate-100">
        {events.map((ev, i) => (
          <div key={i} className="py-4 first:pt-0 last:pb-0 flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 flex flex-col items-center justify-center font-bold text-xs shrink-0">
                <span>{ev.data.split('/')[0]}</span>
                <span className="text-[9px] uppercase text-emerald-600 font-normal">Set</span>
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-sm">{ev.titulo}</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Horário limite: <strong className="text-slate-700">{ev.hora}</strong> • Categoria:{' '}
                  {ev.tipo}
                </p>
              </div>
            </div>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                ev.status === 'urgente'
                  ? 'bg-rose-100 text-rose-800'
                  : ev.status === 'alerta'
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-slate-100 text-slate-700'
              }`}
            >
              {ev.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export const RelatoriosView: React.FC<SectionProps> = ({ selectedEmpresa }) => {
  const relatorios = [
    {
      titulo: 'Demonstração do Resultado do Exercício (DRE Sintética)',
      periodo: 'Competência Anual 2026 [DEMO]',
      formato: 'PDF / XLS',
    },
    {
      titulo: 'Balancete de Verificação de 4 Colunas',
      periodo: 'Acumulado até Agosto/2026 [DEMO]',
      formato: 'PDF',
    },
    {
      titulo: 'Relatório Gerencial de Conformidade Tributária',
      periodo: '3º Trimestre 2026 [DEMO]',
      formato: 'PDF',
    },
    {
      titulo: 'Extrato de Faturamento e Comprovante de Simples Nacional',
      periodo: 'Últimos 12 Meses [DEMO]',
      formato: 'PDF',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-bold text-slate-900">Relatórios Contábeis & Gerenciais</h1>
          <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
            DEMO
          </span>
        </div>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          {selectedEmpresa
            ? `Demonstrativos e peças contábeis da empresa: ${selectedEmpresa.nomeFantasia}`
            : 'Emissão e exportação de relatórios para os clientes'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {relatorios.map((rel, idx) => (
          <div
            key={idx}
            className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between gap-4 hover:border-slate-300 transition-all"
          >
            <div>
              <h3 className="font-bold text-slate-900 text-sm">{rel.titulo}</h3>
              <p className="text-xs text-slate-500 mt-1">{rel.periodo}</p>
              <span className="inline-block mt-2 text-[10px] font-mono bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                Formato: {rel.formato}
              </span>
            </div>
            <button
              onClick={() => alert(`Gerando relatório de demonstração: ${rel.titulo}`)}
              className="p-2.5 rounded-lg bg-slate-50 hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 border border-slate-200 hover:border-emerald-200 transition-colors"
              title="Exportar arquivo"
            >
              <Download className="w-5 h-5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

interface ConfiguracoesProps {
  onNavigate?: (section: NavSection) => void;
}

export const ConfiguracoesView: React.FC<ConfiguracoesProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-6">
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900">Configurações da Plataforma SaaS</h1>
            <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full border border-emerald-300">
              PRODUÇÃO v2.0.0
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Parâmetros do escritório de contabilidade, isolamento de dados e infraestrutura
          </p>
        </div>

        {onNavigate && (
          <button
            onClick={() => onNavigate('banco_dados')}
            className="inline-flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
          >
            <Database className="w-4 h-4 text-emerald-400" />
            <span>Abrir Gerenciador do Banco</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Persistence Status */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
              <Database className="w-4 h-4 text-emerald-600" />
              <span>Camada de Banco de Dados & Persistência</span>
            </div>
            {onNavigate && (
              <button
                onClick={() => onNavigate('banco_dados')}
                className="text-[11px] font-bold text-emerald-600 hover:text-emerald-700 underline cursor-pointer"
              >
                Gerenciar Tabelas →
              </button>
            )}
          </div>

          <div className="space-y-2.5 text-xs text-slate-600">
            <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <span className="font-medium">Arquitetura de Dados:</span>
              <span className="font-semibold text-emerald-700">
                Multi-Tenant Isolado por Empresa (empresaId)
              </span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <span className="font-medium">Repositório Backend:</span>
              <span className="font-mono text-slate-800">Node.js Express + Data Repository</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <span className="font-medium">Compatibilidade Persistente:</span>
              <span className="text-slate-800 font-semibold">PostgreSQL / Cloud SQL / JSON Store</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <span className="font-medium">Estado dos Registros:</span>
              <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Produção Ativo (Deploy Ready)
              </span>
            </div>
          </div>
        </div>

        {/* Security & Access */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-slate-900 font-bold text-sm border-b border-slate-100 pb-3">
            <Shield className="w-4 h-4 text-blue-600" />
            <span>Segurança & Controle de Acesso</span>
          </div>

          <div className="space-y-2.5 text-xs text-slate-600">
            <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <span className="font-medium">Níveis de Permissão:</span>
              <span className="font-semibold text-slate-800">Contador Admin, Analista Fiscal</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <span className="font-medium">Autenticação:</span>
              <span className="font-semibold text-emerald-700">Sessão JWT / API Tokens</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <span className="font-medium">Escritório Titular:</span>
              <span className="text-slate-800 font-medium">Silveira & Associados Contabilidade</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
