import React, { useState, useMemo } from 'react';
import {
  FileBadge,
  ShieldCheck,
  ShieldAlert,
  Flame,
  Trees,
  Building,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Search,
  Plus,
  Filter,
  FileText,
  Printer,
  Download,
  Trash2,
  Edit,
  ExternalLink,
  Info,
  MapPin,
  Maximize2,
  RefreshCw,
  Sparkles,
  ChevronRight,
  FileCheck,
  AlertCircle,
  FileWarning,
} from 'lucide-react';
import { AlvaraLicenca, Empresa, TipoAlvaraLicenca, StatusAlvaraLicenca } from '../types';
import { api } from '../services/api';
import { AlvaraVencimentoBanner } from './AlvaraVencimentoBanner';

interface AlvarasViewProps {
  selectedEmpresa?: Empresa | null;
  empresas: Empresa[];
  alvaras: AlvaraLicenca[];
  onRefresh: () => void;
}

const TIPOS_LICENCA: { label: TipoAlvaraLicenca; icon: React.ElementType; color: string; desc: string }[] = [
  {
    label: 'Alvará de Funcionamento',
    icon: Building,
    color: 'text-indigo-600 bg-indigo-50 border-indigo-200',
    desc: 'Localização e Funcionamento Municipal / Zoneamento',
  },
  {
    label: 'Alvará Sanitário',
    icon: ShieldCheck,
    color: 'text-emerald-600 bg-emerald-50 border-emerald-200',
    desc: 'Vigilância Sanitária (VISA / ANVISA / COVISA)',
  },
  {
    label: 'Alvará do Corpo de Bombeiros (AVCB/CLCB)',
    icon: Flame,
    color: 'text-rose-600 bg-rose-50 border-rose-200',
    desc: 'Auto de Vistoria (AVCB) ou Certificado de Licença (CLCB)',
  },
  {
    label: 'Licença Ambiental (LP/LI/LO)',
    icon: Trees,
    color: 'text-teal-600 bg-teal-50 border-teal-200',
    desc: 'Licença Prévia, de Instalação e Operação (CETESB/IAT/INEA)',
  },
  {
    label: 'Licença da Polícia Civil',
    icon: FileBadge,
    color: 'text-amber-600 bg-amber-50 border-amber-200',
    desc: 'Controle de Produtos Químicos e Blindagens',
  },
  {
    label: 'Licença da Polícia Federal',
    icon: ShieldAlert,
    color: 'text-blue-600 bg-blue-50 border-blue-200',
    desc: 'Certificado de Registro Cadastral / Químicos Controlados',
  },
  {
    label: 'Certificado de Registro Exército',
    icon: FileCheck,
    color: 'text-slate-700 bg-slate-100 border-slate-300',
    desc: 'Armamentos, Pirotecnia e Explosivos Industriais',
  },
  {
    label: 'Outras Licenças',
    icon: FileText,
    color: 'text-purple-600 bg-purple-50 border-purple-200',
    desc: 'Licenças de Publicidade, Concessionárias e Especiais',
  },
];

export const AlvarasView: React.FC<AlvarasViewProps> = ({
  selectedEmpresa,
  empresas,
  alvaras,
  onRefresh,
}) => {
  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTipo, setFilterTipo] = useState<string>('todos');
  const [filterStatus, setFilterStatus] = useState<string>('todos');
  const [filterEmpresaId, setFilterEmpresaId] = useState<string>(selectedEmpresa?.id || 'todas');

  // Modals state
  const [modalNovoOpen, setModalNovoOpen] = useState(false);
  const [modalDetalhes, setModalDetalhes] = useState<AlvaraLicenca | null>(null);
  const [modalRenovacao, setModalRenovacao] = useState<AlvaraLicenca | null>(null);
  const [editingAlvara, setEditingAlvara] = useState<AlvaraLicenca | null>(null);

  // Form state
  const [formEmpresaId, setFormEmpresaId] = useState('');
  const [formTipo, setFormTipo] = useState<TipoAlvaraLicenca>('Alvará de Funcionamento');
  const [formOrgaoEmissor, setFormOrgaoEmissor] = useState('');
  const [formNumeroAlvara, setFormNumeroAlvara] = useState('');
  const [formNumeroClcbAvcb, setFormNumeroClcbAvcb] = useState('');
  const [formNumeroIptuPredio, setFormNumeroIptuPredio] = useState('');
  const [formAreaImovel, setFormAreaImovel] = useState('');
  const [formAreaConstruida, setFormAreaConstruida] = useState('');
  const [formAreaUtilizada, setFormAreaUtilizada] = useState('');
  const [formNumeroCadastroImobiliario, setFormNumeroCadastroImobiliario] = useState('');
  const [formNumeroInscricaoMunicipal, setFormNumeroInscricaoMunicipal] = useState('');
  const [formDataEmissao, setFormDataEmissao] = useState('');
  const [formDataValidade, setFormDataValidade] = useState('');
  const [formProtocoloRenovacao, setFormProtocoloRenovacao] = useState('');
  const [formResponsavelTecnico, setFormResponsavelTecnico] = useState('');
  const [formArtRrtNumero, setFormArtRrtNumero] = useState('');
  const [formObservacoes, setFormObservacoes] = useState('');
  const [formDocumentoAnexo, setFormDocumentoAnexo] = useState('');
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Renewal quick modal state
  const [renovacaoProtocolo, setRenovacaoProtocolo] = useState('');
  const [renovacaoData, setRenovacaoData] = useState(new Date().toISOString().split('T')[0]);
  const [renovacaoSubmitting, setRenovacaoSubmitting] = useState(false);

  // Helpers for company lookup
  const getEmpresaNome = (empresaId: string) => {
    const emp = empresas.find((e) => e.id === empresaId);
    return emp ? emp.nomeFantasia || emp.razaoSocial : 'Empresa não encontrada';
  };

  const getEmpresaCnpj = (empresaId: string) => {
    const emp = empresas.find((e) => e.id === empresaId);
    return emp ? emp.cnpj : '';
  };

  // Sync filter with selectedEmpresa prop
  React.useEffect(() => {
    if (selectedEmpresa) {
      setFilterEmpresaId(selectedEmpresa.id);
    } else {
      setFilterEmpresaId('todas');
    }
  }, [selectedEmpresa]);

  // Open modal for creation
  const handleOpenNovo = (empresaIdDefault?: string) => {
    const defaultEmpId = empresaIdDefault || (filterEmpresaId !== 'todas' ? filterEmpresaId : (empresas[0]?.id || ''));
    setEditingAlvara(null);
    setFormEmpresaId(defaultEmpId);
    setFormTipo('Alvará de Funcionamento');
    setFormOrgaoEmissor('Prefeitura Municipal');
    setFormNumeroAlvara('');
    setFormNumeroClcbAvcb('');
    setFormNumeroIptuPredio('');
    setFormAreaImovel('');
    setFormAreaConstruida('');
    setFormAreaUtilizada('');
    setFormNumeroCadastroImobiliario('');
    setFormNumeroInscricaoMunicipal('');
    setFormDataEmissao(new Date().toISOString().split('T')[0]);
    
    // Default 1 year validity
    const nextYear = new Date();
    nextYear.setFullYear(nextYear.getFullYear() + 1);
    setFormDataValidade(nextYear.toISOString().split('T')[0]);

    setFormProtocoloRenovacao('');
    setFormResponsavelTecnico('');
    setFormArtRrtNumero('');
    setFormObservacoes('');
    setFormDocumentoAnexo('');
    setFormError(null);
    setModalNovoOpen(true);
  };

  // Open modal for editing
  const handleOpenEdit = (alvara: AlvaraLicenca) => {
    setEditingAlvara(alvara);
    setFormEmpresaId(alvara.empresaId);
    setFormTipo(alvara.tipo);
    setFormOrgaoEmissor(alvara.orgaoEmissor);
    setFormNumeroAlvara(alvara.numeroAlvara);
    setFormNumeroClcbAvcb(alvara.numeroClcbAvcb || '');
    setFormNumeroIptuPredio(alvara.numeroIptuPredio || '');
    setFormAreaImovel(alvara.areaImovel ? String(alvara.areaImovel) : '');
    setFormAreaConstruida(alvara.areaConstruida ? String(alvara.areaConstruida) : '');
    setFormAreaUtilizada(alvara.areaUtilizada ? String(alvara.areaUtilizada) : '');
    setFormNumeroCadastroImobiliario(alvara.numeroCadastroImobiliario || '');
    setFormNumeroInscricaoMunicipal(alvara.numeroInscricaoMunicipal || '');
    setFormDataEmissao(alvara.dataEmissao || '');
    setFormDataValidade(alvara.dataValidade || '');
    setFormProtocoloRenovacao(alvara.protocoloRenovacao || '');
    setFormResponsavelTecnico(alvara.responsavelTecnico || '');
    setFormArtRrtNumero(alvara.artRrtNumero || '');
    setFormObservacoes(alvara.observacoes || '');
    setFormDocumentoAnexo(alvara.documentoAnexo || '');
    setFormError(null);
    setModalNovoOpen(true);
  };

  // Quick fill demo data for testing
  const handlePreencherExemplo = (tipoExemplo: 'sanitario' | 'bombeiro' | 'funcionamento' | 'ambiental') => {
    const empTarget = (filterEmpresaId !== 'todas' ? filterEmpresaId : (empresas[0]?.id || ''));
    setFormEmpresaId(empTarget);

    if (tipoExemplo === 'sanitario') {
      setFormTipo('Alvará Sanitário');
      setFormOrgaoEmissor('Vigilância Sanitária Municipal (VISA)');
      setFormNumeroAlvara(`VISA-CAD-${Math.floor(100000 + Math.random() * 900000)}/2026`);
      setFormNumeroClcbAvcb('AVCB-SP-2025-44912');
      setFormNumeroIptuPredio('014.288.0192-3');
      setFormAreaImovel('750.00');
      setFormAreaConstruida('580.00');
      setFormAreaUtilizada('210.00');
      setFormNumeroCadastroImobiliario('SQL-0142880192');
      setFormNumeroInscricaoMunicipal('5.291.802-9');
      setFormDataEmissao('2026-01-10');
      setFormDataValidade('2027-01-10');
      setFormResponsavelTecnico('Nutricionista Renata Salles (CRN-3 48102)');
      setFormArtRrtNumero('CRN-RT-2026-09');
      setFormObservacoes('Alvará sanitário deferido para manipulação de alimentos, cozinha industrial e câmara fria.');
      setFormDocumentoAnexo('alvara_sanitario_vigilancia_2026.pdf');
    } else if (tipoExemplo === 'bombeiro') {
      setFormTipo('Alvará do Corpo de Bombeiros (AVCB/CLCB)');
      setFormOrgaoEmissor('Corpo de Bombeiros Militar (CBMSP)');
      setFormNumeroAlvara(`AVCB-SP-${Math.floor(10000 + Math.random() * 90000)}/2026`);
      setFormNumeroClcbAvcb(`AVCB-REG-${Math.floor(10000 + Math.random() * 90000)}`);
      setFormNumeroIptuPredio('014.288.0192-3');
      setFormAreaImovel('1200.00');
      setFormAreaConstruida('950.00');
      setFormAreaUtilizada('950.00');
      setFormNumeroCadastroImobiliario('SQL-0142880192');
      setFormNumeroInscricaoMunicipal('5.291.802-9');
      setFormDataEmissao('2025-11-15');
      setFormDataValidade('2026-11-15');
      setFormResponsavelTecnico('Eng. Segurança do Trabalho Carlos F. Lima (CREA 509124)');
      setFormArtRrtNumero('ART-BOMB-2025-7712');
      setFormObservacoes('Sistema de hidrantes pressurizados, alarme contra incêndio e rota de fuga sinalizada.');
      setFormDocumentoAnexo('avcb_bombeiros_vistoria_regular.pdf');
    } else if (tipoExemplo === 'ambiental') {
      setFormTipo('Licença Ambiental (LP/LI/LO)');
      setFormOrgaoEmissor('CETESB - Companhia Ambiental do Estado de SP');
      setFormNumeroAlvara(`LO-CETESB-2024/${Math.floor(1000 + Math.random() * 9000)}`);
      setFormNumeroClcbAvcb('AVCB-SP-2025-44912');
      setFormNumeroIptuPredio('033.409.1102-8');
      setFormAreaImovel('8500.00');
      setFormAreaConstruida('4200.00');
      setFormAreaUtilizada('3900.00');
      setFormNumeroCadastroImobiliario('CAD-AMB-SP-033409');
      setFormNumeroInscricaoMunicipal('6.104.992-1');
      setFormDataEmissao('2024-06-01');
      setFormDataValidade('2027-06-01');
      setFormResponsavelTecnico('Eng. Ambiental Juliana Furtado (CREA 49102)');
      setFormArtRrtNumero('ART-AMB-2024-004');
      setFormObservacoes('Licença de Operação com condicionantes para tratamento de efluentes industriais e emissões gasosas.');
      setFormDocumentoAnexo('licenca_ambiental_cetesb_lo.pdf');
    } else {
      setFormTipo('Alvará de Funcionamento');
      setFormOrgaoEmissor('Secretaria Municipal da Fazenda e Urbanismo');
      setFormNumeroAlvara(`ALV-MUN-2025/${Math.floor(10000 + Math.random() * 90000)}`);
      setFormNumeroClcbAvcb('CLCB-2025-9912');
      setFormNumeroIptuPredio('014.288.0192-3');
      setFormAreaImovel('750.00');
      setFormAreaConstruida('580.00');
      setFormAreaUtilizada('450.00');
      setFormNumeroCadastroImobiliario('SQL-0142880192');
      setFormNumeroInscricaoMunicipal('5.291.802-9');
      setFormDataEmissao('2025-05-10');
      setFormDataValidade('2027-05-10');
      setFormResponsavelTecnico('Arquiteto Paulo Mendonça (CAU A-8812)');
      setFormArtRrtNumero('RRT-2025-44102');
      setFormObservacoes('Uso comercial e administrativo conforme certidão de diretrizes urbanísticas.');
      setFormDocumentoAnexo('alvara_localizacao_funcionamento.pdf');
    }
  };

  // Submit form (create or edit)
  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formEmpresaId) {
      setFormError('Selecione uma empresa');
      return;
    }
    if (!formNumeroAlvara.trim()) {
      setFormError('Informe o número do alvará ou licença');
      return;
    }
    if (!formDataValidade) {
      setFormError('Informe a data de validade');
      return;
    }

    setFormSubmitting(true);
    setFormError(null);

    try {
      const payload = {
        empresaId: formEmpresaId,
        tipo: formTipo,
        orgaoEmissor: formOrgaoEmissor.trim() || 'Órgão Competente',
        numeroAlvara: formNumeroAlvara.trim(),
        numeroClcbAvcb: formNumeroClcbAvcb.trim() || undefined,
        numeroIptuPredio: formNumeroIptuPredio.trim() || 'N/A',
        areaImovel: parseFloat(formAreaImovel) || 0,
        areaConstruida: parseFloat(formAreaConstruida) || 0,
        areaUtilizada: parseFloat(formAreaUtilizada) || 0,
        numeroCadastroImobiliario: formNumeroCadastroImobiliario.trim() || 'N/A',
        numeroInscricaoMunicipal: formNumeroInscricaoMunicipal.trim() || 'N/A',
        dataEmissao: formDataEmissao || new Date().toISOString().split('T')[0],
        dataValidade: formDataValidade,
        protocoloRenovacao: formProtocoloRenovacao.trim() || undefined,
        responsavelTecnico: formResponsavelTecnico.trim() || undefined,
        artRrtNumero: formArtRrtNumero.trim() || undefined,
        observacoes: formObservacoes.trim() || undefined,
        documentoAnexo: formDocumentoAnexo.trim() || undefined,
      };

      if (editingAlvara) {
        await api.updateAlvara(editingAlvara.id, payload);
      } else {
        await api.createAlvara(payload as any);
      }

      setModalNovoOpen(false);
      onRefresh();
    } catch (err: any) {
      setFormError(err.message || 'Erro ao salvar alvará');
    } finally {
      setFormSubmitting(false);
    }
  };

  // Submit quick renewal
  const handleSubmitRenovacao = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!modalRenovacao) return;
    if (!renovacaoProtocolo.trim()) {
      alert('Informe o número do protocolo do processo de renovação.');
      return;
    }

    setRenovacaoSubmitting(true);
    try {
      await api.renovarAlvara(modalRenovacao.id, renovacaoProtocolo.trim(), renovacaoData);
      setModalRenovacao(null);
      setRenovacaoProtocolo('');
      onRefresh();
    } catch (err: any) {
      alert(err.message || 'Erro ao registrar renovação');
    } finally {
      setRenovacaoSubmitting(false);
    }
  };

  // Delete license
  const handleDelete = async (id: string, numero: string) => {
    if (confirm(`Tem certeza que deseja excluir o alvará "${numero}"?`)) {
      try {
        await api.deleteAlvara(id);
        if (modalDetalhes?.id === id) setModalDetalhes(null);
        onRefresh();
      } catch (err: any) {
        alert(err.message || 'Erro ao excluir');
      }
    }
  };

  // Export to CSV
  const handleExportCsv = () => {
    if (filteredAlvaras.length === 0) {
      alert('Nenhum registro para exportar.');
      return;
    }

    const headers = [
      'Empresa',
      'CNPJ',
      'Tipo de Licença',
      'Órgão Emissor',
      'Número do Alvará',
      'AVCB/CLCB',
      'IPTU do Prédio',
      'Inscrição Municipal',
      'Cadastro Imobiliário',
      'Área Imóvel (m²)',
      'Área Construída (m²)',
      'Área Utilizada (m²)',
      'Data Emissão',
      'Data Validade',
      'Dias Restantes',
      'Status',
      'Protocolo Renovação',
      'Responsável Técnico',
    ];

    const rows = filteredAlvaras.map((a) => [
      `"${getEmpresaNome(a.empresaId)}"`,
      `"${getEmpresaCnpj(a.empresaId)}"`,
      `"${a.tipo}"`,
      `"${a.orgaoEmissor}"`,
      `"${a.numeroAlvara}"`,
      `"${a.numeroClcbAvcb || ''}"`,
      `"${a.numeroIptuPredio}"`,
      `"${a.numeroInscricaoMunicipal}"`,
      `"${a.numeroCadastroImobiliario}"`,
      a.areaImovel,
      a.areaConstruida,
      a.areaUtilizada,
      a.dataEmissao,
      a.dataValidade,
      a.diasParaVencer,
      `"${a.status}"`,
      `"${a.protocoloRenovacao || ''}"`,
      `"${a.responsavelTecnico || ''}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(';'), ...rows.map((r) => r.join(';'))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `alvaras_licencas_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filtered alvarás
  const filteredAlvaras = useMemo(() => {
    return alvaras.filter((alv) => {
      // Filter company
      if (filterEmpresaId !== 'todas' && alv.empresaId !== filterEmpresaId) {
        return false;
      }

      // Filter license type
      if (filterTipo !== 'todos' && alv.tipo !== filterTipo) {
        return false;
      }

      // Filter status
      if (filterStatus !== 'todos' && alv.status !== filterStatus) {
        return false;
      }

      // Search term
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const empresaNome = getEmpresaNome(alv.empresaId).toLowerCase();
        const empresaCnpj = getEmpresaCnpj(alv.empresaId).toLowerCase();
        const numAlvara = (alv.numeroAlvara || '').toLowerCase();
        const numAvcb = (alv.numeroClcbAvcb || '').toLowerCase();
        const iptu = (alv.numeroIptuPredio || '').toLowerCase();
        const cadImob = (alv.numeroCadastroImobiliario || '').toLowerCase();
        const inscMun = (alv.numeroInscricaoMunicipal || '').toLowerCase();
        const orgao = (alv.orgaoEmissor || '').toLowerCase();
        const resp = (alv.responsavelTecnico || '').toLowerCase();

        return (
          empresaNome.includes(query) ||
          empresaCnpj.includes(query) ||
          numAlvara.includes(query) ||
          numAvcb.includes(query) ||
          iptu.includes(query) ||
          cadImob.includes(query) ||
          inscMun.includes(query) ||
          orgao.includes(query) ||
          resp.includes(query)
        );
      }

      return true;
    });
  }, [alvaras, filterEmpresaId, filterTipo, filterStatus, searchTerm, empresas]);

  // KPIs Calculations
  const kpis = useMemo(() => {
    const list = filterEmpresaId === 'todas' ? alvaras : alvaras.filter((a) => a.empresaId === filterEmpresaId);
    const total = list.length;
    const vigentes = list.filter((a) => a.status === 'vigente').length;
    const vencendo = list.filter((a) => a.status === 'vencendo').length;
    const vencidos = list.filter((a) => a.status === 'vencido').length;
    const emRenovacao = list.filter((a) => a.status === 'em_renovacao').length;

    // Metragens monitoradas
    const areaConstruidaTotal = list.reduce((acc, curr) => acc + (curr.areaConstruida || 0), 0);
    const areaUtilizadaTotal = list.reduce((acc, curr) => acc + (curr.areaUtilizada || 0), 0);

    return {
      total,
      vigentes,
      vencendo,
      vencidos,
      emRenovacao,
      areaConstruidaTotal,
      areaUtilizadaTotal,
    };
  }, [alvaras, filterEmpresaId]);

  // Render badge helper
  const renderStatusBadge = (alvara: AlvaraLicenca) => {
    if (alvara.status === 'vigente') {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          <span>Vigente ({alvara.diasParaVencer} dias)</span>
        </span>
      );
    }
    if (alvara.status === 'vencendo') {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-300 animate-pulse">
          <Clock className="w-3.5 h-3.5 text-amber-600" />
          <span>Vence em {alvara.diasParaVencer} dias</span>
        </span>
      );
    }
    if (alvara.status === 'vencido') {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
          <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
          <span>Vencido há {Math.abs(alvara.diasParaVencer)} dias</span>
        </span>
      );
    }
    if (alvara.status === 'em_renovacao') {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
          <RefreshCw className="w-3.5 h-3.5 text-blue-600 animate-spin" />
          <span>Em Renovação</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
        Dispensado
      </span>
    );
  };

  const getTipoIcon = (tipo: TipoAlvaraLicenca) => {
    const item = TIPOS_LICENCA.find((t) => t.label === tipo);
    const IconComp = item ? item.icon : FileBadge;
    const colorClass = item ? item.color : 'text-slate-600 bg-slate-100 border-slate-200';
    return (
      <div className={`p-2 rounded-lg border ${colorClass}`}>
        <IconComp className="w-4 h-4" />
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Alerta Automático: Lembretes de Vencimento de Alvarás (30 dias) */}
      <AlvaraVencimentoBanner alvaras={alvaras} empresas={empresas} />

      {/* Header View */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-600 text-white rounded-xl shadow-xs">
              <FileBadge className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <span>Gestão de Alvarás, Licenças & Imobiliário</span>
                <span className="text-xs bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-md">
                  Vigilância Sanitária, Bombeiros & Ambiental
                </span>
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Controle preventivo de vigência, dados cadastrais de IPTU, áreas (m²), inscrição municipal e números de AVCB/CLCB
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => handleOpenNovo()}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Cadastrar Alvará / Licença</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium border border-slate-200 transition-colors"
            title="Exportar dados em formato CSV"
          >
            <Download className="w-3.5 h-3.5 text-slate-600" />
            <span>Exportar CSV</span>
          </button>

          <button
            onClick={onRefresh}
            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-200 transition-colors"
            title="Recarregar registros"
          >
            <RefreshCw className="w-4 h-4 text-slate-600" />
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-slate-500 text-xs font-medium">Total de Licenças</p>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-bold text-slate-900">{kpis.total}</span>
            <FileText className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Todas cadastradas</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-emerald-200 shadow-xs bg-emerald-50/20">
          <p className="text-emerald-700 text-xs font-semibold">Vigentes e Regulares</p>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-bold text-emerald-700">{kpis.vigentes}</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-[11px] text-emerald-600 mt-1">Dentro da validade legal</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-amber-300 shadow-xs bg-amber-50/30">
          <p className="text-amber-800 text-xs font-semibold">Vencendo em até 60 dias</p>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-bold text-amber-700">{kpis.vencendo}</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-[11px] text-amber-700 mt-1">Ação preventiva requerida</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-rose-200 shadow-xs bg-rose-50/20">
          <p className="text-rose-700 text-xs font-semibold">Vencidos / Irregulares</p>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-bold text-rose-700">{kpis.vencidos}</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <p className="text-[11px] text-rose-600 mt-1">Risco fiscal e interdição</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-blue-200 shadow-xs bg-blue-50/20">
          <p className="text-blue-700 text-xs font-semibold">Em Renovação</p>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-2xl font-bold text-blue-700">{kpis.emRenovacao}</span>
            <RefreshCw className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-[11px] text-blue-600 mt-1">Protocolos em análise</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <p className="text-slate-500 text-xs font-medium">Área Ocupada Monitorada</p>
          <div className="flex items-baseline justify-between mt-1">
            <span className="text-xl font-bold text-slate-900">
              {kpis.areaUtilizadaTotal.toLocaleString('pt-BR')} <span className="text-xs font-normal text-slate-500">m²</span>
            </span>
            <Maximize2 className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Construída: {kpis.areaConstruidaTotal.toLocaleString('pt-BR')} m²</p>
        </div>
      </div>

      {/* Banner de Alerta Crítico se houver alvarás vencidos */}
      {kpis.vencidos > 0 && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-start justify-between gap-3 text-xs text-rose-900 shadow-xs">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-rose-800 text-sm">
                Atenção: Existem {kpis.vencidos} alvarás ou licenças vencidas necessitando de protocolo imediato!
              </p>
              <p className="text-rose-700 mt-0.5">
                Operar com Alvará de Funcionamento, Sanitário ou AVCB de Bombeiros vencido expõe o cliente a multas municipais, cassação de inscrição estadual e bloqueio de emissão de NF-e.
              </p>
            </div>
          </div>
          <button
            onClick={() => setFilterStatus('vencido')}
            className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-semibold text-xs transition-colors shrink-0 shadow-xs"
          >
            Filtrar Vencidos
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar por Razão Social, CNPJ, Nº do Alvará, AVCB/CLCB, IPTU, Inscrição Municipal ou Órgão..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
            {/* Empresa Filter */}
            <select
              value={filterEmpresaId}
              onChange={(e) => setFilterEmpresaId(e.target.value)}
              className="px-2.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg font-medium text-slate-700 focus:outline-hidden focus:border-emerald-500"
            >
              <option value="todas">Todas as Empresas ({empresas.length})</option>
              {empresas.map((emp) => (
                <option key={emp.id} value={emp.id}>
                  {emp.nomeFantasia || emp.razaoSocial}
                </option>
              ))}
            </select>

            {/* Tipo Filter */}
            <select
              value={filterTipo}
              onChange={(e) => setFilterTipo(e.target.value)}
              className="px-2.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg font-medium text-slate-700 focus:outline-hidden focus:border-emerald-500"
            >
              <option value="todos">Todos os Tipos de Alvará</option>
              {TIPOS_LICENCA.map((t) => (
                <option key={t.label} value={t.label}>
                  {t.label}
                </option>
              ))}
            </select>

            {/* Status Filter */}
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-2.5 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg font-medium text-slate-700 focus:outline-hidden focus:border-emerald-500"
            >
              <option value="todos">Todos os Status</option>
              <option value="vigente">Vigentes (Regulares)</option>
              <option value="vencendo">Vencendo em 60 dias</option>
              <option value="vencido">Vencidos (Críticos)</option>
              <option value="em_renovacao">Em Renovação</option>
              <option value="dispensado">Dispensados</option>
            </select>

            {(searchTerm || filterTipo !== 'todos' || filterStatus !== 'todos' || filterEmpresaId !== 'todas') && (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setFilterTipo('todos');
                  setFilterStatus('todos');
                  setFilterEmpresaId('todas');
                }}
                className="text-xs text-slate-500 hover:text-slate-800 underline px-1"
              >
                Limpar
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Listagem em Tabela Principal */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">
              Registros de Licenciamento & Alvarás ({filteredAlvaras.length})
            </h2>
            <p className="text-xs text-slate-500">
              Controle imobiliário, sanitário, bombeiros e licenças ambientais das empresas
            </p>
          </div>
          <div className="text-xs text-slate-400">
            Atualizado automaticamente pelo sistema de conformidade fiscal
          </div>
        </div>

        {filteredAlvaras.length === 0 ? (
          <div className="text-center py-12 px-4">
            <FileBadge className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-700 font-semibold text-sm">Nenhum alvará ou licença encontrado</p>
            <p className="text-slate-400 text-xs mt-1 max-w-md mx-auto">
              Tente alterar os filtros ou cadastre o primeiro alvará de funcionamento, vigilância sanitária ou bombeiros para a empresa selecionada.
            </p>
            <button
              onClick={() => handleOpenNovo()}
              className="mt-4 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs"
            >
              Cadastrar Agora
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                  <th className="py-3 px-4">Empresa / Titular</th>
                  <th className="py-3 px-4">Tipo & Órgão Emissor</th>
                  <th className="py-3 px-4">Nº do Alvará / AVCB</th>
                  <th className="py-3 px-4">Dados do Imóvel & IPTU</th>
                  <th className="py-3 px-4">Metragens (m²)</th>
                  <th className="py-3 px-4">Vigência & Validade</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAlvaras.map((alvara) => {
                  const empNome = getEmpresaNome(alvara.empresaId);
                  const empCnpj = getEmpresaCnpj(alvara.empresaId);

                  return (
                    <tr key={alvara.id} className="hover:bg-slate-50/75 transition-colors">
                      {/* Empresa */}
                      <td className="py-3.5 px-4">
                        <div>
                          <p className="font-semibold text-slate-900 text-xs">{empNome}</p>
                          <p className="text-[11px] text-slate-500 font-mono mt-0.5">CNPJ: {empCnpj}</p>
                          <p className="text-[10px] text-slate-400">
                            Inscr. Mun: <span className="font-medium text-slate-600">{alvara.numeroInscricaoMunicipal || 'N/A'}</span>
                          </p>
                        </div>
                      </td>

                      {/* Tipo & Órgão */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-start gap-2.5">
                          {getTipoIcon(alvara.tipo)}
                          <div>
                            <p className="font-semibold text-slate-900 text-xs leading-snug">{alvara.tipo}</p>
                            <p className="text-[11px] text-slate-500 mt-0.5">{alvara.orgaoEmissor}</p>
                            {alvara.responsavelTecnico && (
                              <p className="text-[10px] text-emerald-700 font-medium mt-0.5 truncate max-w-[200px]" title={alvara.responsavelTecnico}>
                                RT: {alvara.responsavelTecnico}
                              </p>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Número do Alvará e AVCB */}
                      <td className="py-3.5 px-4">
                        <div>
                          <p className="font-mono font-semibold text-slate-800 text-xs bg-slate-100 px-2 py-0.5 rounded-md inline-block">
                            {alvara.numeroAlvara}
                          </p>
                          {alvara.numeroClcbAvcb && (
                            <div className="mt-1 flex items-center gap-1 text-[11px] text-rose-700 font-medium">
                              <Flame className="w-3 h-3 text-rose-500 shrink-0" />
                              <span>{alvara.numeroClcbAvcb}</span>
                            </div>
                          )}
                          {alvara.protocoloRenovacao && (
                            <p className="text-[10px] text-blue-700 font-mono mt-1">
                              Prot: {alvara.protocoloRenovacao}
                            </p>
                          )}
                        </div>
                      </td>

                      {/* Dados Imobiliários & IPTU */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-0.5">
                          <p className="text-[11px] text-slate-700">
                            <span className="text-slate-400">IPTU:</span> <span className="font-mono font-medium">{alvara.numeroIptuPredio || 'N/A'}</span>
                          </p>
                          <p className="text-[10px] text-slate-500">
                            <span className="text-slate-400">Cad. Imob:</span> <span className="font-mono">{alvara.numeroCadastroImobiliario || 'N/A'}</span>
                          </p>
                        </div>
                      </td>

                      {/* Metragens m² */}
                      <td className="py-3.5 px-4">
                        <div className="text-[11px] space-y-0.5">
                          <p className="text-slate-800 font-medium">
                            {alvara.areaUtilizada ? `${alvara.areaUtilizada.toLocaleString('pt-BR')} m²` : '-'}
                            <span className="text-[10px] text-slate-400 font-normal ml-1">(empresa)</span>
                          </p>
                          <p className="text-[10px] text-slate-500">
                            Construída: {alvara.areaConstruida ? `${alvara.areaConstruida.toLocaleString('pt-BR')} m²` : '-'}
                          </p>
                          <p className="text-[10px] text-slate-400">
                            Terreno: {alvara.areaImovel ? `${alvara.areaImovel.toLocaleString('pt-BR')} m²` : '-'}
                          </p>
                        </div>
                      </td>

                      {/* Vigência & Validade */}
                      <td className="py-3.5 px-4">
                        <div>
                          <p className="text-xs font-semibold text-slate-800">
                            {new Date(alvara.dataValidade + 'T00:00:00').toLocaleDateString('pt-BR')}
                          </p>
                          <p className="text-[10px] text-slate-400">
                            Emissão: {new Date(alvara.dataEmissao + 'T00:00:00').toLocaleDateString('pt-BR')}
                          </p>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4 text-center">
                        {renderStatusBadge(alvara)}
                      </td>

                      {/* Ações */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setModalDetalhes(alvara)}
                            className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-md transition-colors"
                            title="Ver Prontuário Completo"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </button>

                          {alvara.status !== 'em_renovacao' && (
                            <button
                              onClick={() => {
                                setModalRenovacao(alvara);
                                setRenovacaoProtocolo('');
                                setRenovacaoData(new Date().toISOString().split('T')[0]);
                              }}
                              className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded-md transition-colors"
                              title="Registrar Protocolo de Renovação"
                            >
                              <RefreshCw className="w-4 h-4" />
                            </button>
                          )}

                          <button
                            onClick={() => handleOpenEdit(alvara)}
                            className="p-1.5 text-slate-500 hover:text-amber-700 hover:bg-amber-50 rounded-md transition-colors"
                            title="Editar Dados"
                          >
                            <Edit className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => handleDelete(alvara.id, alvara.numeroAlvara)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                            title="Excluir Registro"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* MODAL: Cadastrar ou Editar Alvará */}
      {modalNovoOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-6 shadow-2xl border border-slate-200 my-8">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg">
                  <FileBadge className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">
                    {editingAlvara ? 'Editar Alvará / Licença' : 'Cadastrar Novo Alvará ou Licença'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Preencha os dados do alvará, órgão emissor, IPTU, AVCB e metragens da edificação
                  </p>
                </div>
              </div>
              <button
                onClick={() => setModalNovoOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            {/* Preenchimento Rápido Demo (se for novo) */}
            {!editingAlvara && (
              <div className="mt-3 p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between flex-wrap gap-2 text-xs">
                <div className="flex items-center gap-1.5 text-slate-600 font-medium">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>Preenchimento rápido para demonstração:</span>
                </div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <button
                    type="button"
                    onClick={() => handlePreencherExemplo('sanitario')}
                    className="px-2.5 py-1 bg-emerald-100 text-emerald-800 rounded-md font-semibold hover:bg-emerald-200 transition-colors"
                  >
                    + Sanitário (VISA)
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePreencherExemplo('bombeiro')}
                    className="px-2.5 py-1 bg-rose-100 text-rose-800 rounded-md font-semibold hover:bg-rose-200 transition-colors"
                  >
                    + Bombeiro (AVCB)
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePreencherExemplo('ambiental')}
                    className="px-2.5 py-1 bg-teal-100 text-teal-800 rounded-md font-semibold hover:bg-teal-200 transition-colors"
                  >
                    + Ambiental (LO)
                  </button>
                  <button
                    type="button"
                    onClick={() => handlePreencherExemplo('funcionamento')}
                    className="px-2.5 py-1 bg-indigo-100 text-indigo-800 rounded-md font-semibold hover:bg-indigo-200 transition-colors"
                  >
                    + Funcionamento
                  </button>
                </div>
              </div>
            )}

            {formError && (
              <div className="mt-3 p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmitForm} className="mt-4 space-y-4 text-xs">
              {/* Seção 1: Empresa e Tipo */}
              <div className="bg-slate-50/70 p-3.5 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                  <Building className="w-4 h-4 text-slate-600" />
                  <span>1. Identificação da Empresa e Tipo de Alvará</span>
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Empresa Titular *
                    </label>
                    <select
                      value={formEmpresaId}
                      onChange={(e) => setFormEmpresaId(e.target.value)}
                      required
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option value="">Selecione a empresa...</option>
                      {empresas.map((emp) => (
                        <option key={emp.id} value={emp.id}>
                          {emp.nomeFantasia || emp.razaoSocial} ({emp.cnpj})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Tipo de Licença / Alvará *
                    </label>
                    <select
                      value={formTipo}
                      onChange={(e) => setFormTipo(e.target.value as TipoAlvaraLicenca)}
                      required
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden"
                    >
                      {TIPOS_LICENCA.map((t) => (
                        <option key={t.label} value={t.label}>
                          {t.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Órgão Emissor / Autoridade *
                    </label>
                    <input
                      type="text"
                      value={formOrgaoEmissor}
                      onChange={(e) => setFormOrgaoEmissor(e.target.value)}
                      placeholder="Ex: Prefeitura Municipal de SP, Vigilância Sanitária (VISA), CBMSP, CETESB"
                      required
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Inscrição Municipal da Empresa (IM / CCM)
                    </label>
                    <input
                      type="text"
                      value={formNumeroInscricaoMunicipal}
                      onChange={(e) => setFormNumeroInscricaoMunicipal(e.target.value)}
                      placeholder="Ex: 4.891.204-8"
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>
                </div>
              </div>

              {/* Seção 2: Identificadores & Datas */}
              <div className="bg-slate-50/70 p-3.5 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                  <FileBadge className="w-4 h-4 text-emerald-600" />
                  <span>2. Números do Alvará, Bombeiros (AVCB/CLCB) & Vigência</span>
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Número do Alvará / Registro *
                    </label>
                    <input
                      type="text"
                      value={formNumeroAlvara}
                      onChange={(e) => setFormNumeroAlvara(e.target.value)}
                      placeholder="Ex: ALV-2026/09812 ou VISA-SP-7712"
                      required
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Número do CLCB ou AVCB (Bombeiros)
                    </label>
                    <input
                      type="text"
                      value={formNumeroClcbAvcb}
                      onChange={(e) => setFormNumeroClcbAvcb(e.target.value)}
                      placeholder="Ex: AVCB-SP-2025-44912 ou CLCB-RJ-9914"
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Data de Emissão
                    </label>
                    <input
                      type="date"
                      value={formDataEmissao}
                      onChange={(e) => setFormDataEmissao(e.target.value)}
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Data de Validade *
                    </label>
                    <input
                      type="date"
                      value={formDataValidade}
                      onChange={(e) => setFormDataValidade(e.target.value)}
                      required
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden font-semibold text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Protocolo de Renovação (se houver)
                    </label>
                    <input
                      type="text"
                      value={formProtocoloRenovacao}
                      onChange={(e) => setFormProtocoloRenovacao(e.target.value)}
                      placeholder="Ex: PROC-2026-049182"
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Seção 3: Dados Imobiliários do Prédio & Metragens */}
              <div className="bg-slate-50/70 p-3.5 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <span>3. Dados do Imóvel, Cadastro Imobiliário, IPTU & Áreas (m²)</span>
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Número do IPTU do Prédio
                    </label>
                    <input
                      type="text"
                      value={formNumeroIptuPredio}
                      onChange={(e) => setFormNumeroIptuPredio(e.target.value)}
                      placeholder="Ex: 012.345.0089-1"
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Número do Cadastro Imobiliário (SQL / Inscrição Cadastral)
                    </label>
                    <input
                      type="text"
                      value={formNumeroCadastroImobiliario}
                      onChange={(e) => setFormNumeroCadastroImobiliario(e.target.value)}
                      placeholder="Ex: SQL-0123450089 ou CAD-IMO-98210"
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Área do Imóvel / Terreno (m²)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={formAreaImovel}
                      onChange={(e) => setFormAreaImovel(e.target.value)}
                      placeholder="Ex: 650.00"
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Área Construída Total (m²)
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={formAreaConstruida}
                      onChange={(e) => setFormAreaConstruida(e.target.value)}
                      placeholder="Ex: 520.00"
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-semibold mb-1 text-emerald-800">
                      Área Utilizada para a Empresa (m²) *
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      value={formAreaUtilizada}
                      onChange={(e) => setFormAreaUtilizada(e.target.value)}
                      placeholder="Ex: 380.00"
                      className="w-full p-2 bg-white border border-emerald-300 rounded-lg focus:border-emerald-500 focus:outline-hidden font-semibold"
                    />
                  </div>
                </div>
              </div>

              {/* Seção 4: Responsável Técnico & Observações */}
              <div className="bg-slate-50/70 p-3.5 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-purple-600" />
                  <span>4. Responsável Técnico, ART/RRT & Condicionantes</span>
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Responsável Técnico / Engenheiro / Arquiteto
                    </label>
                    <input
                      type="text"
                      value={formResponsavelTecnico}
                      onChange={(e) => setFormResponsavelTecnico(e.target.value)}
                      placeholder="Ex: Eng. Marcelo Albuquerque (CREA-SP 506129)"
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Número da ART / RRT
                    </label>
                    <input
                      type="text"
                      value={formArtRrtNumero}
                      onChange={(e) => setFormArtRrtNumero(e.target.value)}
                      placeholder="Ex: ART-2024-9912048"
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Arquivo / Anexo em PDF
                    </label>
                    <input
                      type="text"
                      value={formDocumentoAnexo}
                      onChange={(e) => setFormDocumentoAnexo(e.target.value)}
                      placeholder="Ex: alvara_funcionamento_2026.pdf"
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Observações / Condicionantes
                    </label>
                    <input
                      type="text"
                      value={formObservacoes}
                      onChange={(e) => setFormObservacoes(e.target.value)}
                      placeholder="Ex: Válido mediante manutenção dos extintores e laudo de ruído."
                      className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-emerald-500 focus:outline-hidden"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setModalNovoOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-medium transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={formSubmitting}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold shadow-xs disabled:opacity-50 transition-colors flex items-center gap-1.5"
                >
                  {formSubmitting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Salvando...</span>
                    </>
                  ) : (
                    <span>{editingAlvara ? 'Salvar Alterações' : 'Cadastrar Alvará'}</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Visualizar Prontuário Completo do Alvará / Imóvel */}
      {modalDetalhes && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 my-8">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                  Prontuário Imobiliário & Licença Legal
                </span>
                <h3 className="font-bold text-slate-900 text-lg mt-1">
                  {modalDetalhes.tipo}
                </h3>
                <p className="text-xs text-slate-500">
                  {getEmpresaNome(modalDetalhes.empresaId)} • CNPJ: {getEmpresaCnpj(modalDetalhes.empresaId)}
                </p>
              </div>
              <button
                onClick={() => setModalDetalhes(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs">
              {/* Status Header */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                <div>
                  <p className="text-slate-500 text-[11px]">Condição do Licenciamento:</p>
                  <div className="mt-1">{renderStatusBadge(modalDetalhes)}</div>
                </div>
                <div className="text-right">
                  <p className="text-slate-500 text-[11px]">Vencimento:</p>
                  <p className="text-sm font-bold text-slate-900">
                    {new Date(modalDetalhes.dataValidade + 'T00:00:00').toLocaleDateString('pt-BR')}
                  </p>
                </div>
              </div>

              {/* Bloco 1: Identificação do Alvará & Órgão */}
              <div className="border border-slate-200 rounded-xl p-3.5 space-y-2">
                <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5 border-b border-slate-100 pb-1.5">
                  <FileBadge className="w-4 h-4 text-emerald-600" />
                  <span>Dados do Registro e Órgão Emissor</span>
                </h4>
                <div className="grid grid-cols-2 gap-3 text-slate-700">
                  <div>
                    <span className="text-slate-400 block text-[11px]">Número do Alvará:</span>
                    <span className="font-mono font-bold text-slate-900">{modalDetalhes.numeroAlvara}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Órgão Competente:</span>
                    <span className="font-semibold">{modalDetalhes.orgaoEmissor}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Data de Emissão:</span>
                    <span>{new Date(modalDetalhes.dataEmissao + 'T00:00:00').toLocaleDateString('pt-BR')}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Auto de Vistoria (AVCB / CLCB):</span>
                    <span className="font-mono text-rose-700 font-bold">{modalDetalhes.numeroClcbAvcb || 'Não aplicável / Isento'}</span>
                  </div>
                </div>
              </div>

              {/* Bloco 2: Dados Prediais & IPTU */}
              <div className="border border-slate-200 rounded-xl p-3.5 space-y-2">
                <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5 border-b border-slate-100 pb-1.5">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <span>Dados Imobiliários & IPTU do Prédio</span>
                </h4>
                <div className="grid grid-cols-2 gap-3 text-slate-700">
                  <div>
                    <span className="text-slate-400 block text-[11px]">Número do IPTU:</span>
                    <span className="font-mono font-semibold">{modalDetalhes.numeroIptuPredio || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Inscrição Municipal (IM/CCM):</span>
                    <span className="font-mono font-semibold">{modalDetalhes.numeroInscricaoMunicipal || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Cadastro Imobiliário (SQL):</span>
                    <span className="font-mono">{modalDetalhes.numeroCadastroImobiliario || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Protocolo de Renovação:</span>
                    <span className="font-mono text-blue-700">{modalDetalhes.protocoloRenovacao || 'Nenhum protocolo ativo'}</span>
                  </div>
                </div>
              </div>

              {/* Bloco 3: Metragens */}
              <div className="border border-slate-200 rounded-xl p-3.5 space-y-2">
                <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5 border-b border-slate-100 pb-1.5">
                  <Maximize2 className="w-4 h-4 text-indigo-600" />
                  <span>Metragens Auditadas da Edificação</span>
                </h4>
                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="p-2.5 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[10px]">Área do Imóvel</span>
                    <span className="text-sm font-bold text-slate-800">
                      {modalDetalhes.areaImovel ? `${modalDetalhes.areaImovel.toLocaleString('pt-BR')} m²` : '-'}
                    </span>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[10px]">Área Construída Total</span>
                    <span className="text-sm font-bold text-slate-800">
                      {modalDetalhes.areaConstruida ? `${modalDetalhes.areaConstruida.toLocaleString('pt-BR')} m²` : '-'}
                    </span>
                  </div>
                  <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg">
                    <span className="text-emerald-700 block text-[10px] font-semibold">Área Utilizada (Empresa)</span>
                    <span className="text-sm font-bold text-emerald-800">
                      {modalDetalhes.areaUtilizada ? `${modalDetalhes.areaUtilizada.toLocaleString('pt-BR')} m²` : '-'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Bloco 4: Responsável Técnico & Observações */}
              {(modalDetalhes.responsavelTecnico || modalDetalhes.observacoes || modalDetalhes.documentoAnexo) && (
                <div className="border border-slate-200 rounded-xl p-3.5 space-y-2">
                  <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5 border-b border-slate-100 pb-1.5">
                    <Info className="w-4 h-4 text-slate-600" />
                    <span>Detalhes Técnicos & Condicionantes</span>
                  </h4>
                  {modalDetalhes.responsavelTecnico && (
                    <p className="text-slate-700">
                      <strong>Responsável Técnico:</strong> {modalDetalhes.responsavelTecnico}{' '}
                      {modalDetalhes.artRrtNumero && `(ART/RRT: ${modalDetalhes.artRrtNumero})`}
                    </p>
                  )}
                  {modalDetalhes.observacoes && (
                    <p className="text-slate-600 bg-slate-50 p-2 rounded-lg italic">
                      "{modalDetalhes.observacoes}"
                    </p>
                  )}
                  {modalDetalhes.documentoAnexo && (
                    <div className="flex items-center gap-2 text-emerald-700 font-medium">
                      <FileText className="w-4 h-4" />
                      <span>Anexo: {modalDetalhes.documentoAnexo}</span>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="mt-6 pt-3 border-t border-slate-100 flex items-center justify-between">
              <button
                onClick={() => window.print()}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Imprimir Ficha</span>
              </button>

              <button
                onClick={() => setModalDetalhes(null)}
                className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition-colors"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Registrar Protocolo de Renovação Rápida */}
      {modalRenovacao && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
                  <RefreshCw className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">Registrar Protocolo de Renovação</h3>
                  <p className="text-xs text-slate-500">
                    Alvará: <span className="font-mono font-semibold">{modalRenovacao.numeroAlvara}</span>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setModalRenovacao(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitRenovacao} className="mt-4 space-y-3.5 text-xs">
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-blue-900">
                <p className="font-semibold">Proteção contra multas municipais:</p>
                <p className="text-[11px] text-blue-700 mt-0.5">
                  Protocolar o pedido tempestivamente dentro do prazo legal garante a prorrogação tácita da atividade até a vistoria do órgão competente.
                </p>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Número do Protocolo / Processo Administrativo *
                </label>
                <input
                  type="text"
                  value={renovacaoProtocolo}
                  onChange={(e) => setRenovacaoProtocolo(e.target.value)}
                  placeholder="Ex: PROC-VISA-2026/0912 ou CBMSP-VIST-4412"
                  required
                  className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-blue-500 focus:outline-hidden font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Data de Protocolização
                </label>
                <input
                  type="date"
                  value={renovacaoData}
                  onChange={(e) => setRenovacaoData(e.target.value)}
                  required
                  className="w-full p-2 bg-white border border-slate-200 rounded-lg focus:border-blue-500 focus:outline-hidden"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalRenovacao(null)}
                  className="px-3 py-1.5 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={renovacaoSubmitting}
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors disabled:opacity-50"
                >
                  {renovacaoSubmitting ? 'Salvando...' : 'Confirmar Renovação'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
