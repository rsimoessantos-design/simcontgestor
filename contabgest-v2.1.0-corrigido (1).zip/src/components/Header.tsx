import React, { useState } from 'react';
import {
  Menu,
  Building2,
  Bell,
  Search,
  LogOut,
  ChevronDown,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  Clock,
  ShieldCheck,
  BookOpen,
} from 'lucide-react';
import { Empresa, User } from '../types';

interface HeaderProps {
  user: User;
  empresas: Empresa[];
  selectedEmpresaId: string;
  onSelectEmpresa: (id: string) => void;
  onOpenMobileMenu: () => void;
  onLogout: () => void;
  onOpenManual?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  empresas,
  selectedEmpresaId,
  onSelectEmpresa,
  onOpenMobileMenu,
  onLogout,
  onOpenManual,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const selectedEmpresa = empresas.find((e) => e.id === selectedEmpresaId);

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-xs">
      {/* Top Production Indicator Bar */}
      <div className="bg-slate-900 text-slate-200 px-4 py-1.5 flex items-center justify-between text-xs border-b border-slate-800">
        <div className="flex items-center gap-2 font-medium">
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-[10px] tracking-wide border border-emerald-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            PRODUÇÃO v2.0.0
          </span>
          <span className="text-slate-300 hidden sm:inline">
            Ambiente de Produção Ativo • Certificação Digital & Isolamento Multi-Empresas Operando
          </span>
          <span className="sm:hidden text-slate-300">Produção v2.0.0</span>
        </div>
        <div className="text-slate-400 text-[11px] flex items-center gap-2 font-mono">
          <span className="hidden md:inline">Deploy:</span>
          <span className="inline-flex items-center gap-1 text-emerald-400 font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            Pronto para Publicação
          </span>
        </div>
      </div>

      <div className="px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        {/* Left Side: Mobile Menu Button & Company Selector */}
        <div className="flex items-center gap-3">
          <button
            id="btn-mobile-menu"
            onClick={onOpenMobileMenu}
            className="p-2 -ml-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 lg:hidden"
            aria-label="Abrir menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Company Multi-Tenant Selector */}
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center justify-center w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200">
              <Building2 className="w-4 h-4" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                Empresa Ativa
              </span>
              <div className="relative">
                <select
                  id="header-company-selector"
                  value={selectedEmpresaId}
                  onChange={(e) => onSelectEmpresa(e.target.value)}
                  className="appearance-none bg-slate-50 hover:bg-slate-100 border border-slate-300 text-slate-800 text-xs sm:text-sm font-semibold rounded-lg pl-2.5 pr-8 py-1.5 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 cursor-pointer max-w-[220px] sm:max-w-[320px] truncate"
                >
                  <option value="todas">🏢 Todas as Empresas (Visão Consolidada)</option>
                  {empresas.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.nomeFantasia} ({emp.regimeTributario})
                    </option>
                  ))}
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none text-slate-500">
                  <ChevronDown className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Quick Search, Notifications, User Menu */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Search */}
          <div className="relative hidden md:block">
            <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              placeholder="Buscar obrigação, cliente, CNPJ..."
              className="w-52 lg:w-60 pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white text-slate-700 placeholder-slate-400 transition-all"
            />
          </div>

          {/* Botão Manual do Usuário */}
          {onOpenManual && (
            <button
              id="btn-abrir-manual-header"
              onClick={onOpenManual}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 transition-colors shadow-2xs"
              title="Abrir Manual do Usuário ContabGest"
            >
              <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
              <span className="hidden sm:inline">Manual do Usuário</span>
            </button>
          )}

          {/* Notifications */}
          <div className="relative">
            <button
              id="btn-notifications-dropdown"
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
              aria-label="Notificações"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full ring-2 ring-white"></span>
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 sm:w-88 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                  <span className="font-semibold text-xs text-slate-800">
                    Notificações do Escritório
                  </span>
                  <span className="text-[10px] text-rose-600 font-bold bg-rose-50 px-1.5 py-0.5 rounded">4 alertas</span>
                </div>
                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 text-xs">
                  {/* Alerta de Alvará 30 dias */}
                  <div className="p-3 bg-amber-50/60 hover:bg-amber-50 flex items-start gap-2.5 border-l-2 border-amber-500">
                    <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5 animate-pulse" />
                    <div>
                      <p className="font-bold text-amber-950">
                        Lembrete: Alvará do Corpo de Bombeiros (AVCB)
                      </p>
                      <p className="text-[11px] text-amber-900 font-medium">
                        Vence em 33 dias • Inicie a renovação no painel de Alvarás
                      </p>
                    </div>
                  </div>
                  <div className="p-3 hover:bg-slate-50 flex items-start gap-2.5">
                    <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-slate-800">
                        DCTFWeb vence em breve (15/09)
                      </p>
                      <p className="text-[11px] text-slate-500">Inovatech Comércio Ltda</p>
                    </div>
                  </div>
                  <div className="p-3 hover:bg-slate-50 flex items-start gap-2.5">
                    <Clock className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-slate-800">Certidão FGTS vence em 6 dias</p>
                      <p className="text-[11px] text-slate-500">Renovação solicitada à CEF</p>
                    </div>
                  </div>
                  <div className="p-3 hover:bg-slate-50 flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-slate-800">eSocial Folha Mensal Concluída</p>
                      <p className="text-[11px] text-slate-500">Protocolo transmitido com sucesso</p>
                    </div>
                  </div>
                </div>
                <div className="p-2 border-t border-slate-100 text-center">
                  <button
                    onClick={() => setShowNotifications(false)}
                    className="text-[11px] font-semibold text-emerald-600 hover:text-emerald-700"
                  >
                    Marcar todas como lidas
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* User Profile dropdown */}
          <div className="relative">
            <button
              id="btn-user-profile-menu"
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center text-xs font-bold ring-2 ring-emerald-500/30">
                {user.nome.substring(0, 2).toUpperCase()}
              </div>
              <div className="hidden lg:flex flex-col text-left">
                <span className="text-xs font-semibold text-slate-800 leading-tight">
                  {user.nome}
                </span>
                <span className="text-[10px] text-slate-500 leading-tight">
                  {user.role === 'contador_admin' ? 'Contador Responsável' : 'Analista Fiscal'}
                </span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden lg:block" />
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-50">
                <div className="px-3.5 py-2 border-b border-slate-100">
                  <p className="text-xs font-semibold text-slate-800">{user.nome}</p>
                  <p className="text-[11px] text-slate-500 truncate">{user.email}</p>
                  <span className="inline-block mt-1 px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 text-[10px] font-medium">
                    {user.escritorioNome}
                  </span>
                </div>
                <button
                  id="btn-logout"
                  onClick={() => {
                    setShowUserMenu(false);
                    onLogout();
                  }}
                  className="w-full px-3.5 py-2 text-left text-xs font-medium text-rose-600 hover:bg-rose-50 flex items-center gap-2 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sair do sistema</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
