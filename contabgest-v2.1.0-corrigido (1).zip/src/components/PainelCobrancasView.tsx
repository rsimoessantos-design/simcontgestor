import React, { useState, useEffect, useMemo } from 'react';
import {
  FileText,
  Plus,
  Search,
  Filter,
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Send,
  Download,
  Printer,
  Copy,
  Check,
  Building2,
  DollarSign,
  TrendingUp,
  FileCheck,
  ShieldCheck,
  Receipt,
  X,
  Share2,
  ExternalLink,
  MessageCircle,
  Mail,
  RefreshCw,
  Eye,
  FilePlus,
  Briefcase,
  AlertCircle,
  FolderOpen,
  ArrowUpDown,
  Layers,
  Sparkles,
  QrCode,
  Tag,
  FileSpreadsheet,
  Bell,
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ModalExportacaoCobrancas } from './ModalExportacaoCobrancas';
import { AbaLembretesAutomaticos } from './AbaLembretesAutomaticos';
import {
  Empresa,
  ContratoHonorario,
  MensalidadeHonorario,
  ReciboHonorario,
  ServicoContabil,
  CategoriaServicoContabil,
  StatusMensalidade,
} from '../types';
import { api } from '../services/api';
import {
  SERVICOS_CONTABEIS_PADRAO,
  CONTRATOS_HONORARIOS_PADRAO,
  MENSALIDADES_HONORARIOS_PADRAO,
  RECIBOS_HONORARIOS_PADRAO,
  valorPorExtenso,
} from '../data/demoCobrancas';
import { avaliarFilaLembretes, carregarRegrasStorage } from '../utils/lembretesCobrancaUtils';

interface PainelCobrancasViewProps {
  empresas: Empresa[];
  selectedEmpresa?: Empresa;
  onRefresh?: () => void;
}

type TabType = 'mensalidades' | 'contratos' | 'servicos' | 'recibos' | 'lembretes';

export const PainelCobrancasView: React.FC<PainelCobrancasViewProps> = ({
  empresas,
  selectedEmpresa,
  onRefresh,
}) => {
  // Estado das Abas
  const [activeTab, setActiveTab] = useState<TabType>('mensalidades');

  // Dados do Módulo
  const [contratos, setContratos] = useState<ContratoHonorario[]>(CONTRATOS_HONORARIOS_PADRAO);
  const [mensalidades, setMensalidades] = useState<MensalidadeHonorario[]>(MENSALIDADES_HONORARIOS_PADRAO);
  const [servicos, setServicos] = useState<ServicoContabil[]>(SERVICOS_CONTABEIS_PADRAO);
  const [recibos, setRecibos] = useState<ReciboHonorario[]>(RECIBOS_HONORARIOS_PADRAO);
  const [loading, setLoading] = useState(false);

  // Filtros
  const [filtroEmpresaId, setFiltroEmpresaId] = useState<string>(selectedEmpresa ? selectedEmpresa.id : 'todas');
  const [filtroCompetencia, setFiltroCompetencia] = useState<string>('todas');
  const [filtroStatus, setFiltroStatus] = useState<string>('todos');
  const [buscaTexto, setBuscaTexto] = useState<string>('');

  // Modais
  const [modalNovoContratoOpen, setModalNovoContratoOpen] = useState(false);
  const [modalBaixaOpen, setModalBaixaOpen] = useState(false);
  const [modalReciboOpen, setModalReciboOpen] = useState(false);
  const [modalWhatsAppOpen, setModalWhatsAppOpen] = useState(false);
  const [modalEmailOpen, setModalEmailOpen] = useState(false);
  const [modalPixOpen, setModalPixOpen] = useState(false);
  const [modalNovoServicoOpen, setModalNovoServicoOpen] = useState(false);
  const [modalLoteOpen, setModalLoteOpen] = useState(false);
  const [modalDocContratoOpen, setModalDocContratoOpen] = useState(false);
  const [modalExportarOpen, setModalExportarOpen] = useState(false);

  // Seleção Múltipla para Ações em Lote (Exportação OFX / CSV)
  const [mensalidadesSelecionadasIds, setMensalidadesSelecionadasIds] = useState<string[]>([]);

  // Itens Selecionados para Ações
  const [mensalidadeSelecionada, setMensalidadeSelecionada] = useState<MensalidadeHonorario | null>(null);
  const [reciboSelecionado, setReciboSelecionado] = useState<ReciboHonorario | null>(null);
  const [contratoSelecionado, setContratoSelecionado] = useState<ContratoHonorario | null>(null);

  // Estados de Formulário
  const [copiadoPix, setCopiadoPix] = useState(false);
  const [copiadoCodigo, setCopiadoCodigo] = useState(false);
  const [feedbackAcao, setFeedbackAcao] = useState<string | null>(null);

  // Form Baixa
  const [baixaForm, setBaixaForm] = useState({
    dataPagamento: new Date().toISOString().split('T')[0],
    formaPagamento: 'pix',
    valorPago: 0,
    emitirReciboAuto: true,
    observacao: '',
  });

  // Form WhatsApp
  const [whatsAppForm, setWhatsAppForm] = useState({
    telefone: '',
    mensagem: '',
  });

  // Form Email
  const [emailForm, setEmailForm] = useState({
    destinatario: '',
    assunto: '',
    mensagem: '',
  });

  // Form Novo Contrato
  const [novoContratoForm, setNovoContratoForm] = useState({
    empresaId: selectedEmpresa ? selectedEmpresa.id : (empresas[0]?.id || 'emp-1'),
    numeroContrato: `CONT-${new Date().getFullYear()}/${String(Math.floor(Math.random() * 899 + 100))}`,
    dataAssinatura: new Date().toISOString().split('T')[0],
    dataInicioVigencia: new Date().toISOString().split('T')[0],
    dataTerminoVigencia: '',
    diaVencimento: 10,
    valorMensalidade: 1200,
    reajusteAnualIndice: 'IPCA' as 'IPCA' | 'IGP-M' | 'INPC' | 'Fixo',
    servicosSelecionados: ['srv-1', 'srv-2', 'srv-4'] as string[],
    documentoContratoNome: '',
    observacoes: 'Contrato padrão de honorários contábeis e fiscais com emissão de recibo digital.',
  });

  // Form Novo Serviço
  const [novoServicoForm, setNovoServicoForm] = useState({
    codigo: '',
    nome: '',
    categoria: 'Fiscal' as CategoriaServicoContabil,
    descricao: '',
    valorSugerido: 350,
    recorrente: true,
  });

  // Form Lote
  const [loteCompetencia, setLoteCompetencia] = useState('10/2026');

  // Atualiza filtro se a empresa selecionada mudar no topo do app
  useEffect(() => {
    if (selectedEmpresa) {
      setFiltroEmpresaId(selectedEmpresa.id);
    }
  }, [selectedEmpresa]);

  // Carregar dados da API
  const carregarDados = async () => {
    setLoading(true);
    try {
      const [resContratos, resMensalidades, resServicos, resRecibos] = await Promise.allSettled([
        api.getContratosHonorarios(),
        api.getMensalidadesHonorarios(),
        api.getServicosContabeis(),
        api.getRecibosHonorarios(),
      ]);

      if (resContratos.status === 'fulfilled' && resContratos.value.length > 0) {
        setContratos(resContratos.value);
      }
      if (resMensalidades.status === 'fulfilled' && resMensalidades.value.length > 0) {
        setMensalidades(resMensalidades.value);
      }
      if (resServicos.status === 'fulfilled' && resServicos.value.length > 0) {
        setServicos(resServicos.value);
      }
      if (resRecibos.status === 'fulfilled' && resRecibos.value.length > 0) {
        setRecibos(resRecibos.value);
      }
    } catch (e) {
      console.warn('Usando dados de demonstração em memória para cobranças:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregarDados();
  }, []);

  // Notificação temporária
  const exibirFeedback = (msg: string) => {
    setFeedbackAcao(msg);
    setTimeout(() => setFeedbackAcao(null), 4000);
  };

  // Helper para buscar nome da empresa
  const getNomeEmpresa = (empresaId: string) => {
    const emp = empresas.find((e) => e.id === empresaId);
    return emp?.razaoSocial || emp?.nomeFantasia || 'Empresa Cliente';
  };

  const getCnpjEmpresa = (empresaId: string) => {
    const emp = empresas.find((e) => e.id === empresaId);
    return emp?.cnpj || '00.000.000/0001-00';
  };

  const getEmailEmpresa = (empresaId: string) => {
    const emp = empresas.find((e) => e.id === empresaId);
    return emp?.email || 'contato@cliente.com.br';
  };

  const getTelefoneEmpresa = (empresaId: string) => {
    const emp = empresas.find((e) => e.id === empresaId);
    return emp?.telefone || '(11) 98765-4321';
  };

  // Lista de competências disponíveis
  const competenciasDisponiveis = useMemo(() => {
    const setComp = new Set<string>();
    mensalidades.forEach((m) => setComp.add(m.competencia));
    return Array.from(setComp).sort().reverse();
  }, [mensalidades]);

  // Quantidade de lembretes pendentes na régua de cobrança automática
  const lembretesPendentesQtd = useMemo(() => {
    try {
      const regras = carregarRegrasStorage();
      const fila = avaliarFilaLembretes(mensalidades, empresas, contratos, regras, '2026-09-17');
      return fila.filter((f) => !f.jaEnviadoHoje).length;
    } catch {
      return 0;
    }
  }, [mensalidades, empresas, contratos]);

  // Mensalidades Filtradas
  const mensalidadesFiltradas = useMemo(() => {
    return mensalidades.filter((m) => {
      if (filtroEmpresaId !== 'todas' && m.empresaId !== filtroEmpresaId) return false;
      if (filtroCompetencia !== 'todas' && m.competencia !== filtroCompetencia) return false;
      if (filtroStatus !== 'todos' && m.status !== filtroStatus) return false;
      if (buscaTexto.trim()) {
        const query = buscaTexto.toLowerCase();
        const nomeEmpresa = getNomeEmpresa(m.empresaId).toLowerCase();
        const cnpj = getCnpjEmpresa(m.empresaId).toLowerCase();
        const contrato = contratos.find((c) => c.id === m.contratoId);
        const numContrato = contrato?.numeroContrato?.toLowerCase() || '';
        const recNum = m.reciboNumero?.toLowerCase() || '';
        return (
          nomeEmpresa.includes(query) ||
          cnpj.includes(query) ||
          numContrato.includes(query) ||
          recNum.includes(query) ||
          m.competencia.includes(query)
        );
      }
      return true;
    });
  }, [mensalidades, filtroEmpresaId, filtroCompetencia, filtroStatus, buscaTexto, contratos, empresas]);

  // Contratos Filtrados
  const contratosFiltrados = useMemo(() => {
    return contratos.filter((c) => {
      if (filtroEmpresaId !== 'todas' && c.empresaId !== filtroEmpresaId) return false;
      if (buscaTexto.trim()) {
        const query = buscaTexto.toLowerCase();
        const nomeEmpresa = getNomeEmpresa(c.empresaId).toLowerCase();
        const numContrato = c.numeroContrato.toLowerCase();
        return nomeEmpresa.includes(query) || numContrato.includes(query);
      }
      return true;
    });
  }, [contratos, filtroEmpresaId, buscaTexto, empresas]);

  // Métricas do Painel
  const metricas = useMemo(() => {
    const contratosAtivos = contratos.filter((c) => c.status === 'ativo');
    const totalMrr = contratosAtivos.reduce((acc, c) => acc + c.valorMensalidade, 0);

    // Mensalidades do mês 09/2026 (ou competência filtrada)
    const compRef = filtroCompetencia !== 'todas' ? filtroCompetencia : '09/2026';
    const doPeriodo = mensalidades.filter((m) => m.competencia === compRef);

    const totalPeriodo = doPeriodo.reduce((acc, m) => acc + m.valor, 0);
    const pagasPeriodo = doPeriodo.filter((m) => m.status === 'pago');
    const valorPagoPeriodo = pagasPeriodo.reduce((acc, m) => acc + (m.valorPago || m.valor), 0);

    const atrasadas = mensalidades.filter((m) => m.status === 'atrasado');
    const valorAtrasado = atrasadas.reduce((acc, m) => acc + m.valor, 0);

    const pendentes = mensalidades.filter((m) => m.status === 'pendente');
    const valorPendente = pendentes.reduce((acc, m) => acc + m.valor, 0);

    const taxaInadimplencia = totalPeriodo > 0 ? (valorAtrasado / totalPeriodo) * 100 : 0;

    return {
      totalMrr,
      totalContratos: contratos.length,
      contratosAtivos: contratosAtivos.length,
      valorPagoPeriodo,
      qtdPagoPeriodo: pagasPeriodo.length,
      valorPendente,
      qtdPendente: pendentes.length,
      valorAtrasado,
      qtdAtrasadas: atrasadas.length,
      taxaInadimplencia,
      compRef,
    };
  }, [contratos, mensalidades, filtroCompetencia]);

  // --- Handlers de Ações ---

  // Abrir Modal de Baixa
  const handleAbrirBaixa = (mens: MensalidadeHonorario) => {
    setMensalidadeSelecionada(mens);
    setBaixaForm({
      dataPagamento: new Date().toISOString().split('T')[0],
      formaPagamento: mens.formaPagamento || 'pix',
      valorPago: mens.valor,
      emitirReciboAuto: true,
      observacao: 'Pagamento confirmado e compensado com sucesso.',
    });
    setModalBaixaOpen(true);
  };

  // Confirmar Baixa de Pagamento
  const handleConfirmarBaixa = async () => {
    if (!mensalidadeSelecionada) return;
    try {
      const atualizada = await api.baixarMensalidade(mensalidadeSelecionada.id, {
        dataPagamento: baixaForm.dataPagamento,
        formaPagamento: baixaForm.formaPagamento,
        valorPago: baixaForm.valorPago,
        observacao: baixaForm.observacao,
      });

      // Atualiza lista local
      setMensalidades((prev) =>
        prev.map((m) => (m.id === atualizada.id ? { ...m, ...atualizada } : m))
      );

      // Se optou por emitir recibo automaticamente
      if (baixaForm.emitirReciboAuto) {
        const novoRecibo = await api.emitirReciboHonorario(atualizada.id);
        setRecibos((prev) => [novoRecibo, ...prev]);
        setMensalidades((prev) =>
          prev.map((m) =>
            m.id === atualizada.id
              ? { ...m, reciboEmitido: true, reciboId: novoRecibo.id, reciboNumero: novoRecibo.numero }
              : m
          )
        );
        exibirFeedback(`Mensalidade baixada e Recibo nº ${novoRecibo.numero} gerado com sucesso!`);
      } else {
        exibirFeedback(`Mensalidade de R$ ${atualizada.valor.toFixed(2)} baixada com sucesso!`);
      }

      setModalBaixaOpen(false);
    } catch (err: any) {
      exibirFeedback(`Erro ao registrar baixa: ${err.message}`);
    }
  };

  // Abrir Modal de Visualização de Recibo
  const handleAbrirRecibo = async (mens: MensalidadeHonorario) => {
    setMensalidadeSelecionada(mens);
    let r = recibos.find((item) => item.mensalidadeId === mens.id);

    if (!r) {
      // Tenta emitir se já está pago
      if (mens.status === 'pago') {
        try {
          r = await api.emitirReciboHonorario(mens.id);
          setRecibos((prev) => [r!, ...prev]);
          setMensalidades((prev) =>
            prev.map((m) =>
              m.id === mens.id
                ? { ...m, reciboEmitido: true, reciboId: r!.id, reciboNumero: r!.numero }
                : m
            )
          );
        } catch (err) {
          console.error(err);
        }
      }
    }

    if (r) {
      setReciboSelecionado(r);
      setModalReciboOpen(true);
    } else {
      // Cria recibo temporário para visualização / rascunho
      const contrato = contratos.find((c) => c.id === mens.contratoId);
      const emp = empresas.find((e) => e.id === mens.empresaId);
      const tempRecibo: ReciboHonorario = {
        id: `rec-temp-${mens.id}`,
        numero: mens.reciboNumero || `REC-${new Date().getFullYear()}/${String(recibos.length + 90).padStart(3, '0')}`,
        mensalidadeId: mens.id,
        contratoId: mens.contratoId,
        empresaId: mens.empresaId,
        razaoSocialCliente: emp?.razaoSocial || 'Cliente Contábil',
        nomeFantasiaCliente: emp?.nomeFantasia || emp?.razaoSocial,
        cnpjCpfCliente: emp?.cnpj || '00.000.000/0001-00',
        enderecoCliente: emp?.cidade && emp?.uf
          ? `${emp.cidade}/${emp.uf}`
          : 'São Paulo/SP',
        valor: mens.valorPago || mens.valor,
        valorPorExtenso: valorPorExtenso(mens.valorPago || mens.valor),
        competencia: mens.competencia,
        dataEmissao: new Date().toISOString().split('T')[0],
        dataPagamento: mens.dataPagamento || new Date().toISOString().split('T')[0],
        formaPagamento: (mens.formaPagamento || 'PIX').toUpperCase(),
        discriminacaoServicos: contrato?.servicosContratadosNomes || [
          'Escrituração Contábil, Fechamento Fiscal e Apuração Simples Nacional',
          'Processamento de Folha de Pagamento & eSocial',
        ],
        nomeEscritorio: 'ContabGest Assessoria e Auditoria Contábil S/S',
        cnpjEscritorio: '45.879.123/0001-44',
        enderecoEscritorio: 'Rua Funchal, 418 - Vila Olímpia, São Paulo/SP - CEP: 04551-060',
        contadorResponsavel: 'Roberto Simões Santos',
        crcContador: 'CRC-SP 1SP234567/O-8',
      };
      setReciboSelecionado(tempRecibo);
      setModalReciboOpen(true);
    }
  };

  // Abrir Modal de Envio WhatsApp
  const handleAbrirWhatsApp = (mens: MensalidadeHonorario) => {
    setMensalidadeSelecionada(mens);
    const emp = empresas.find((e) => e.id === mens.empresaId);
    const contrato = contratos.find((c) => c.id === mens.contratoId);
    const tel = emp?.telefone || '(11) 98765-4321';

    const texto = `Olá! 📄 Segue a cobrança de honorários contábeis da *${emp?.razaoSocial || 'Sua Empresa'}*:

📌 *Contrato:* ${contrato?.numeroContrato || 'Padrão'}
🗓 *Competência:* ${mens.competencia}
⏰ *Vencimento:* ${formatarData(mens.dataVencimento)}
💰 *Valor:* R$ ${mens.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}

🔑 *Chave PIX (Copia e Cola):*
${mens.pixCopiaECola || 'contabgest.financeiro@contabgest.com.br'}

📊 *Código de Barras Boleto:*
${mens.codigoBarras || '34191.79001 01043.510047 91020.150008 7 98350000185000'}

${mens.status === 'pago' ? '✅ *Status:* Pago. O Recibo Oficial de Honorários está quitado e disponível.' : 'Agradecemos a parceria! Qualquer dúvida, estamos à disposição.'}`;

    setWhatsAppForm({
      telefone: tel,
      mensagem: texto,
    });
    setModalWhatsAppOpen(true);
  };

  // Disparar Envio WhatsApp
  const handleDispararWhatsApp = async () => {
    if (!mensalidadeSelecionada) return;
    try {
      await api.enviarCobranca(mensalidadeSelecionada.id, 'whatsapp', whatsAppForm.telefone);

      // Abre link do WhatsApp Web
      const telNumeros = whatsAppForm.telefone.replace(/\D/g, '');
      const urlWa = `https://wa.me/55${telNumeros}?text=${encodeURIComponent(whatsAppForm.mensagem)}`;
      window.open(urlWa, '_blank');

      exibirFeedback(`Cobrança registrada e enviada via WhatsApp para ${whatsAppForm.telefone}!`);
      setModalWhatsAppOpen(false);
      carregarDados();
    } catch (err: any) {
      exibirFeedback(`Erro ao registrar envio: ${err.message}`);
    }
  };

  // Abrir Modal de Envio E-mail
  const handleAbrirEmail = (mens: MensalidadeHonorario) => {
    setMensalidadeSelecionada(mens);
    const emp = empresas.find((e) => e.id === mens.empresaId);
    const contrato = contratos.find((c) => c.id === mens.contratoId);
    const mail = emp?.email || 'contato@cliente.com.br';

    const assunto = `[ContabGest] Fatura & Honorários Contábeis - ${mens.competencia} - ${emp?.razaoSocial || 'Cliente'}`;
    const corpo = `Prezado(a) cliente ${emp?.razaoSocial},

Informamos que a cobrança referente aos serviços contábeis, fiscais e de departamento pessoal da competência ${mens.competencia} está disponível para liquidação:

• Número do Contrato: ${contrato?.numeroContrato || 'CONT-PADRAO'}
• Data de Vencimento: ${formatarData(mens.dataVencimento)}
• Valor da Mensalidade: R$ ${mens.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}

Serviços inclusos no contrato:
${(contrato?.servicosContratadosNomes || ['Assessoria Contábil e Fiscal Integral']).map((s) => `  - ${s}`).join('\n')}

DADOS PARA PAGAMENTO:
Chave PIX: contabgest.financeiro@contabgest.com.br
PIX Copia e Cola:
${mens.pixCopiaECola || '00020126580014br.gov.bcb.pix...'}

Linha Digitável do Boleto:
${mens.codigoBarras || '34191.79001 01043.510047 91020.150008 7 98350000185000'}

O Recibo de Honorários e o comprovante com assinatura do contador responsável serão liberados após a conciliação bancária.

Atenciosamente,
Departamento Financeiro
ContabGest Assessoria Contábil`;

    setEmailForm({
      destinatario: mail,
      assunto,
      mensagem: corpo,
    });
    setModalEmailOpen(true);
  };

  // Disparar Envio E-mail
  const handleDispararEmail = async () => {
    if (!mensalidadeSelecionada) return;
    try {
      await api.enviarCobranca(mensalidadeSelecionada.id, 'email', emailForm.destinatario);
      exibirFeedback(`E-mail com fatura e recibo enviado com sucesso para ${emailForm.destinatario}!`);
      setModalEmailOpen(false);
      carregarDados();
    } catch (err: any) {
      exibirFeedback(`Erro ao enviar e-mail: ${err.message}`);
    }
  };

  // Abrir Modal de QR Code / PIX
  const handleAbrirPix = (mens: MensalidadeHonorario) => {
    setMensalidadeSelecionada(mens);
    setCopiadoPix(false);
    setCopiadoCodigo(false);
    setModalPixOpen(true);
  };

  // Copiar PIX
  const handleCopiarPix = (texto: string) => {
    navigator.clipboard.writeText(texto);
    setCopiadoPix(true);
    setTimeout(() => setCopiadoPix(false), 2500);
  };

  // Copiar Código de Barras
  const handleCopiarCodigo = (texto: string) => {
    navigator.clipboard.writeText(texto);
    setCopiadoCodigo(true);
    setTimeout(() => setCopiadoCodigo(false), 2500);
  };

  // Salvar Novo Contrato
  const handleSalvarNovoContrato = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const resp = await api.createContratoHonorario({
        empresaId: novoContratoForm.empresaId,
        numeroContrato: novoContratoForm.numeroContrato,
        dataAssinatura: novoContratoForm.dataAssinatura,
        dataInicioVigencia: novoContratoForm.dataInicioVigencia,
        dataTerminoVigencia: novoContratoForm.dataTerminoVigencia || undefined,
        diaVencimento: Number(novoContratoForm.diaVencimento),
        valorMensalidade: Number(novoContratoForm.valorMensalidade),
        reajusteAnualIndice: novoContratoForm.reajusteAnualIndice,
        servicosIds: novoContratoForm.servicosSelecionados,
        documentoContratoNome: novoContratoForm.documentoContratoNome || `Contrato_${novoContratoForm.numeroContrato.replace('/', '_')}.pdf`,
        observacoes: novoContratoForm.observacoes,
      });

      setContratos((prev) => [resp.contrato, ...prev]);
      if (resp.mensalidade) {
        setMensalidades((prev) => [resp.mensalidade, ...prev]);
      }

      exibirFeedback(`Contrato ${resp.contrato.numeroContrato} cadastrado e 1ª mensalidade gerada!`);
      setModalNovoContratoOpen(false);
    } catch (err: any) {
      exibirFeedback(`Erro ao salvar contrato: ${err.message}`);
    }
  };

  // Salvar Novo Serviço
  const handleSalvarNovoServico = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const resp = await api.createServicoContabil(novoServicoForm);
      setServicos((prev) => [...prev, resp]);
      exibirFeedback(`Serviço "${resp.nome}" cadastrado com sucesso no catálogo!`);
      setModalNovoServicoOpen(false);
      setNovoServicoForm({
        codigo: '',
        nome: '',
        categoria: 'Fiscal',
        descricao: '',
        valorSugerido: 350,
        recorrente: true,
      });
    } catch (err: any) {
      exibirFeedback(`Erro ao cadastrar serviço: ${err.message}`);
    }
  };

  // Executar Geração em Lote
  const handleGerarLote = async () => {
    try {
      const resp = await api.gerarMensalidadesEmLote(loteCompetencia);
      setMensalidades((prev) => [...resp.mensalidades, ...prev]);
      exibirFeedback(`Lote gerado com sucesso! ${resp.totalGeradas} mensalidades criadas para a competência ${loteCompetencia}.`);
      setModalLoteOpen(false);
    } catch (err: any) {
      exibirFeedback(`Erro ao gerar lote: ${err.message}`);
    }
  };

  // Funções de Seleção em Lote
  const handleToggleSelectAll = () => {
    if (
      mensalidadesSelecionadasIds.length === mensalidadesFiltradas.length &&
      mensalidadesFiltradas.length > 0
    ) {
      setMensalidadesSelecionadasIds([]);
    } else {
      setMensalidadesSelecionadasIds(mensalidadesFiltradas.map((m) => m.id));
    }
  };

  const handleToggleSelectRow = (id: string) => {
    setMensalidadesSelecionadasIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleClearSelection = () => {
    setMensalidadesSelecionadasIds([]);
  };

  // Visualizar / Baixar Documento de Contrato Assinado
  const handleVisualizarDocumentoContrato = (contrato: ContratoHonorario) => {
    setContratoSelecionado(contrato);
    setModalDocContratoOpen(true);
  };

  // Exportar Recibo em PDF Real com jsPDF
  const handleGerarReciboPdf = (rec: ReciboHonorario) => {
    try {
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      // Borda Superior Decorativa
      doc.setFillColor(5, 150, 105); // emerald-600
      doc.rect(0, 0, 210, 8, 'F');

      // Cabeçalho Escritório
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(16);
      doc.setTextColor(15, 23, 42);
      doc.text(rec.nomeEscritorio.toUpperCase(), 14, 22);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(100, 116, 139);
      doc.text(`CNPJ: ${rec.cnpjEscritorio} | Endereço: ${rec.enderecoEscritorio}`, 14, 28);
      doc.text(`Responsável Técnico: ${rec.contadorResponsavel} | ${rec.crcContador}`, 14, 33);

      // Linha Divisória
      doc.setDrawColor(226, 232, 240);
      doc.line(14, 38, 196, 38);

      // Título do Recibo
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(18);
      doc.setTextColor(5, 150, 105);
      doc.text('RECIBO DE HONORÁRIOS PROFISSIONAIS', 105, 50, { align: 'center' });

      // Caixa de Destaque com Número e Valor
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(203, 213, 225);
      doc.roundedRect(14, 56, 182, 24, 2, 2, 'FD');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.setTextColor(71, 85, 105);
      doc.text(`RECIBO Nº: ${rec.numero}`, 20, 66);
      doc.text(`COMPETÊNCIA: ${rec.competencia}`, 20, 74);

      doc.setFontSize(16);
      doc.setTextColor(5, 150, 105);
      doc.text(`VALOR: R$ ${rec.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 190, 71, {
        align: 'right',
      });

      // Texto Formal de Quitação
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(30, 41, 59);

      const textoDeclaracao = `Recebemos de ${rec.razaoSocialCliente}, pessoa jurídica de direito privado inscrita no CNPJ/MF sob o nº ${rec.cnpjCpfCliente}, estabelecida em ${rec.enderecoCliente || 'São Paulo/SP'}, a quantia líquida de R$ ${rec.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} (${rec.valorPorExtenso}), mediante liquidação via ${rec.formaPagamento}, referente à prestação dos serviços técnicos contábeis e fiscais especificados a seguir:`;

      const splitDeclaracao = doc.splitTextToSize(textoDeclaracao, 182);
      doc.text(splitDeclaracao, 14, 90);

      // Tabela de Serviços
      const tableData = rec.discriminacaoServicos.map((serv, i) => [
        String(i + 1).padStart(2, '0'),
        serv,
        rec.competencia,
        'Executado / Conforme Contrato',
      ]);

      autoTable(doc, {
        startY: 112,
        head: [['Item', 'Descrição do Serviço Contábil Contratado', 'Competência', 'Situação Operacional']],
        body: tableData,
        theme: 'striped',
        headStyles: {
          fillColor: [16, 185, 129],
          textColor: [255, 255, 255],
          fontSize: 9,
          fontStyle: 'bold',
        },
        styles: {
          fontSize: 8.5,
          cellPadding: 3.5,
          textColor: [51, 65, 85],
        },
        columnStyles: {
          0: { cellWidth: 14, halign: 'center' },
          1: { cellWidth: 95 },
          2: { cellWidth: 30, halign: 'center' },
          3: { cellWidth: 43 },
        },
      });

      // @ts-ignore
      const finalY = doc.lastAutoTable.finalY || 180;

      // Declaração de Quitação Plena
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(9);
      doc.setTextColor(100, 116, 139);
      doc.text(
        'Por ser verdade e para que produza os devidos efeitos jurídicos e fiscais, firmamos o presente recibo dando plena, geral e irrevogável quitação da competência supracitada.',
        14,
        finalY + 14,
        { maxWidth: 182 }
      );

      // Data e Assinatura
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(30, 41, 59);
      doc.text(`São Paulo - SP, ${formatarData(rec.dataPagamento || rec.dataEmissao)}.`, 14, finalY + 34);

      // Campo de Assinatura
      doc.setDrawColor(148, 163, 184);
      doc.line(105, finalY + 54, 190, finalY + 54);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9.5);
      doc.text(rec.contadorResponsavel, 147.5, finalY + 60, { align: 'center' });
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(100, 116, 139);
      doc.text(`${rec.crcContador} - Contador Responsável`, 147.5, finalY + 65, { align: 'center' });

      // Rodapé
      doc.setFontSize(7.5);
      doc.text(
        `Documento assinado digitalmente no padrão ICP-Brasil pelo sistema ContabGest SaaS. Autenticidade verificável via e-CAC / CRC.`,
        105,
        285,
        { align: 'center' }
      );

      // Salva o PDF no browser
      doc.save(`Recibo_Honorarios_${rec.numero.replace('/', '_')}.pdf`);
      exibirFeedback(`Recibo ${rec.numero} gerado em PDF com sucesso!`);
    } catch (e: any) {
      console.error('Erro ao gerar PDF do recibo:', e);
      exibirFeedback('Erro ao gerar PDF do recibo. Tente novamente.');
    }
  };

  // Formatação de data
  function formatarData(dataIso?: string) {
    if (!dataIso) return '-';
    const partes = dataIso.split('-');
    if (partes.length === 3) {
      return `${partes[2]}/${partes[1]}/${partes[0]}`;
    }
    return dataIso;
  }

  return (
    <div id="painel-cobrancas-view" className="space-y-6">
      {/* Toast de Feedback */}
      {feedbackAcao && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-5 py-3 rounded-xl shadow-2xl border border-emerald-500/40 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <Sparkles className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-sm font-medium">{feedbackAcao}</span>
          <button
            onClick={() => setFeedbackAcao(null)}
            className="text-slate-400 hover:text-white ml-2 p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header com Ações Rápidas */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                <Briefcase className="w-3.5 h-3.5" />
                Gestão Financeira do Escritório
              </span>
              <span className="text-xs text-slate-500 font-medium">Contratos & Recibos</span>
            </div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
              Gestão de Honorários & Cobranças Recorrentes
            </h1>
            <p className="text-sm text-slate-600 mt-1 max-w-3xl">
              Controle centralizado de contratos de prestação de serviços, vencimentos mensais,
              envio de cobranças por WhatsApp e E-mail, emissão de recibos de honorários (CRC) e
              guarda de contratos assinados.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              id="btn-lembretes-automaticos-header"
              onClick={() => setActiveTab('lembretes')}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold text-indigo-900 bg-indigo-50 hover:bg-indigo-100 transition-colors cursor-pointer border border-indigo-200 shadow-xs"
            >
              <Bell className="w-4 h-4 text-indigo-600" />
              Lembretes Automáticos
              {lembretesPendentesQtd > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-bold">
                  {lembretesPendentesQtd}
                </span>
              )}
            </button>

            <button
              id="btn-exportar-lote-cobrancas"
              onClick={() => setModalExportarOpen(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 transition-colors cursor-pointer border border-emerald-200 shadow-xs"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
              Exportar em Lote (OFX / CSV)
            </button>

            <button
              id="btn-lote-mensalidades"
              onClick={() => setModalLoteOpen(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer border border-slate-200"
            >
              <RefreshCw className="w-4 h-4 text-slate-600" />
              Gerar Lote de Mensalidades
            </button>

            <button
              id="btn-novo-contrato"
              onClick={() => setModalNovoContratoOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 shadow-sm transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Novo Contrato de Honorários
            </button>
          </div>
        </div>

        {/* Cards de Métricas */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 mt-6 pt-6 border-t border-slate-100">
          <div className="bg-slate-50 border border-slate-200/60 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                MRR (Receita Recorrente)
              </span>
              <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-700">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-xl font-bold text-slate-900">
                R$ {metricas.totalMrr.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div className="mt-1 text-xs text-slate-500">
              {metricas.contratosAtivos} contratos ativos vigentes
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-200/60 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Recebido no Mês ({metricas.compRef})
              </span>
              <div className="w-8 h-8 rounded-lg bg-teal-100 flex items-center justify-center text-teal-700">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-xl font-bold text-emerald-700">
                R$ {metricas.valorPagoPeriodo.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div className="mt-1 text-xs text-slate-500">
              {metricas.qtdPagoPeriodo} mensalidades liquidadas
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-200/60 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                A Vencer (Pendentes)
              </span>
              <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center text-amber-700">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-xl font-bold text-amber-700">
                R$ {metricas.valorPendente.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div className="mt-1 text-xs text-slate-500">
              {metricas.qtdPendente} faturas aguardando vencimento
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-200/60 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Inadimplência (Atrasadas)
              </span>
              <div className="w-8 h-8 rounded-lg bg-rose-100 flex items-center justify-center text-rose-700">
                <AlertTriangle className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-xl font-bold text-rose-700">
                R$ {metricas.valorAtrasado.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div className="mt-1 text-xs text-rose-600 font-medium">
              {metricas.qtdAtrasadas} cobranças em aberto
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-200/60 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Recibos Emitidos
              </span>
              <div className="w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-700">
                <Receipt className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-xl font-bold text-slate-900">{recibos.length}</span>
              <span className="text-xs text-slate-500">oficiais</span>
            </div>
            <div className="mt-1 text-xs text-slate-500">com assinatura e CRC</div>
          </div>
        </div>
      </div>

      {/* Abas de Navegação */}
      <div className="border-b border-slate-200 flex items-center justify-between">
        <div className="flex gap-2">
          <button
            id="tab-mensalidades"
            onClick={() => setActiveTab('mensalidades')}
            className={`px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'mensalidades'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            Mensalidades & Cobranças
            <span className="ml-1 px-2 py-0.5 text-xs rounded-full bg-slate-100 text-slate-700 font-medium">
              {mensalidades.length}
            </span>
          </button>

          <button
            id="tab-contratos"
            onClick={() => setActiveTab('contratos')}
            className={`px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'contratos'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
            }`}
          >
            <FileText className="w-4 h-4" />
            Contratos de Honorários
            <span className="ml-1 px-2 py-0.5 text-xs rounded-full bg-slate-100 text-slate-700 font-medium">
              {contratos.length}
            </span>
          </button>

          <button
            id="tab-servicos"
            onClick={() => setActiveTab('servicos')}
            className={`px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'servicos'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
            }`}
          >
            <Layers className="w-4 h-4" />
            Catálogo de Serviços Contábeis
            <span className="ml-1 px-2 py-0.5 text-xs rounded-full bg-slate-100 text-slate-700 font-medium">
              {servicos.length}
            </span>
          </button>

          <button
            id="tab-recibos"
            onClick={() => setActiveTab('recibos')}
            className={`px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'recibos'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
            }`}
          >
            <Receipt className="w-4 h-4" />
            Recibos Emitidos
            <span className="ml-1 px-2 py-0.5 text-xs rounded-full bg-slate-100 text-slate-700 font-medium">
              {recibos.length}
            </span>
          </button>

          <button
            id="tab-lembretes"
            onClick={() => setActiveTab('lembretes')}
            className={`px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'lembretes'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
            }`}
          >
            <Bell className="w-4 h-4 text-indigo-600" />
            Lembretes Automáticos (WhatsApp & E-mail)
            {lembretesPendentesQtd > 0 ? (
              <span className="ml-1 px-2 py-0.5 text-xs rounded-full bg-indigo-100 text-indigo-800 font-bold animate-pulse">
                {lembretesPendentesQtd} pendentes
              </span>
            ) : (
              <span className="ml-1 px-2 py-0.5 text-xs rounded-full bg-emerald-100 text-emerald-800 font-medium">
                Em dia
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Barra de Filtros */}
      <div className="bg-white border border-slate-200/80 rounded-xl p-4 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="flex flex-1 flex-wrap gap-2.5 items-center w-full">
          {/* Busca Texto */}
          <div className="relative min-w-[220px] flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar cliente, CNPJ, contrato ou recibo..."
              value={buscaTexto}
              onChange={(e) => setBuscaTexto(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          {/* Filtro Empresa */}
          <div className="w-full sm:w-auto">
            <select
              value={filtroEmpresaId}
              onChange={(e) => setFiltroEmpresaId(e.target.value)}
              className="w-full sm:w-auto px-3 py-1.5 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-700 font-medium"
            >
              <option value="todas">🏢 Todas as Empresas</option>
              {empresas.map((emp) => (
                <option key={emp.id} value={emp.id}>
                  {emp.razaoSocial || emp.nomeFantasia}
                </option>
              ))}
            </select>
          </div>

          {/* Filtro Competência */}
          {activeTab === 'mensalidades' && (
            <div>
              <select
                value={filtroCompetencia}
                onChange={(e) => setFiltroCompetencia(e.target.value)}
                className="px-3 py-1.5 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-700 font-medium"
              >
                <option value="todas">📅 Todas Competências</option>
                {competenciasDisponiveis.map((comp) => (
                  <option key={comp} value={comp}>
                    Competência {comp}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Filtro Status */}
          {activeTab === 'mensalidades' && (
            <div>
              <select
                value={filtroStatus}
                onChange={(e) => setFiltroStatus(e.target.value)}
                className="px-3 py-1.5 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-700 font-medium"
              >
                <option value="todos">⚡ Todos Status</option>
                <option value="pendente">⏳ Pendente</option>
                <option value="pago">✅ Pago</option>
                <option value="atrasado">🚨 Atrasado</option>
              </select>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2 self-end md:self-auto">
          {activeTab === 'servicos' && (
            <button
              onClick={() => setModalNovoServicoOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              Novo Serviço
            </button>
          )}

          <button
            onClick={() => carregarDados()}
            title="Atualizar dados"
            className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* ABA 1: GESTÃO DE MENSALIDADES & COBRANÇAS                                 */}
      {/* ========================================================================= */}
      {activeTab === 'mensalidades' && (
        <div className="space-y-3">
          {/* Barra de Ações em Lote quando há seleção */}
          {mensalidadesSelecionadasIds.length > 0 && (
            <div className="bg-emerald-900 text-white px-4 py-2.5 rounded-xl flex flex-wrap items-center justify-between gap-3 shadow-md animate-in fade-in">
              <div className="flex items-center gap-2 text-xs">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="font-bold">
                  {mensalidadesSelecionadasIds.length} mensalidade(s) selecionada(s)
                </span>
                <span className="text-emerald-200 hidden sm:inline">
                  (Total:{' '}
                  R${' '}
                  {mensalidades
                    .filter((m) => mensalidadesSelecionadasIds.includes(m.id))
                    .reduce((a, b) => a + b.valor, 0)
                    .toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  )
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  id="btn-exportar-selecionadas-cobrancas"
                  onClick={() => setModalExportarOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-xs font-bold text-white transition-colors cursor-pointer shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  Exportar Selecionadas (OFX / CSV)
                </button>
                <button
                  onClick={handleClearSelection}
                  className="text-xs text-emerald-200 hover:text-white underline ml-2 cursor-pointer"
                >
                  Limpar seleção
                </button>
              </div>
            </div>
          )}

          <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
                  <tr>
                    <th className="py-3.5 px-3 w-10 text-center">
                      <input
                        type="checkbox"
                        checked={
                          mensalidadesFiltradas.length > 0 &&
                          mensalidadesSelecionadasIds.length === mensalidadesFiltradas.length
                        }
                        onChange={handleToggleSelectAll}
                        aria-label="Selecionar todas as cobranças da página"
                        className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      />
                    </th>
                    <th className="py-3.5 px-4">Cliente / Empresa</th>
                    <th className="py-3.5 px-4">Contrato</th>
                    <th className="py-3.5 px-4">Competência</th>
                    <th className="py-3.5 px-4">Vencimento</th>
                    <th className="py-3.5 px-4">Valor (R$)</th>
                    <th className="py-3.5 px-4">Status</th>
                    <th className="py-3.5 px-4">Recibo CRC</th>
                    <th className="py-3.5 px-4">Envios</th>
                    <th className="py-3.5 px-4 text-right">Ações de Cobrança</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {mensalidadesFiltradas.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="py-12 text-center text-slate-500">
                        <FileText className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                        Nenhuma mensalidade encontrada para os filtros selecionados.
                      </td>
                    </tr>
                  ) : (
                    mensalidadesFiltradas.map((mens) => {
                      const contrato = contratos.find((c) => c.id === mens.contratoId);
                      const nomeEmpresa = getNomeEmpresa(mens.empresaId);
                      const cnpj = getCnpjEmpresa(mens.empresaId);

                      return (
                        <tr
                          key={mens.id}
                          className={`hover:bg-slate-50/70 transition-colors ${
                            mensalidadesSelecionadasIds.includes(mens.id) ? 'bg-emerald-50/40' : ''
                          }`}
                        >
                          <td className="py-3.5 px-3 text-center">
                            <input
                              type="checkbox"
                              checked={mensalidadesSelecionadasIds.includes(mens.id)}
                              onChange={() => handleToggleSelectRow(mens.id)}
                              aria-label={`Selecionar mensalidade ${mens.id}`}
                              className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                            />
                          </td>
                          <td className="py-3.5 px-4">
                          <div className="font-semibold text-slate-900">{nomeEmpresa}</div>
                          <div className="text-[11px] text-slate-500">{cnpj}</div>
                        </td>

                        <td className="py-3.5 px-4">
                          <div className="font-medium text-slate-700">
                            {contrato?.numeroContrato || 'CONT-PADRAO'}
                          </div>
                          <div className="text-[10px] text-slate-500">
                            Dia {contrato?.diaVencimento || 10} / {contrato?.reajusteAnualIndice || 'IPCA'}
                          </div>
                        </td>

                        <td className="py-3.5 px-4">
                          <span className="inline-flex items-center px-2 py-0.5 rounded-md text-xs font-semibold bg-slate-100 text-slate-800">
                            {mens.competencia}
                          </span>
                        </td>

                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-slate-900">
                            {formatarData(mens.dataVencimento)}
                          </div>
                          {mens.status === 'pago' ? (
                            <div className="text-[10px] text-emerald-600 font-medium">
                              Pago em {formatarData(mens.dataPagamento)}
                            </div>
                          ) : mens.status === 'atrasado' ? (
                            <div className="text-[10px] text-rose-600 font-semibold">Em atraso</div>
                          ) : (
                            <div className="text-[10px] text-amber-600 font-medium">A vencer</div>
                          )}
                        </td>

                        <td className="py-3.5 px-4">
                          <div className="font-bold text-slate-900 text-sm">
                            R$ {mens.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                          </div>
                          {mens.valorPago && mens.status === 'pago' && (
                            <div className="text-[10px] text-slate-500">
                              Liq.: R$ {mens.valorPago.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                            </div>
                          )}
                        </td>

                        <td className="py-3.5 px-4">
                          {mens.status === 'pago' && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              Pago
                            </span>
                          )}
                          {mens.status === 'pendente' && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">
                              <Clock className="w-3 h-3 text-amber-600" />
                              Pendente
                            </span>
                          )}
                          {mens.status === 'atrasado' && (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-100 text-rose-800 border border-rose-200">
                              <AlertTriangle className="w-3 h-3 text-rose-600" />
                              Atrasado
                            </span>
                          )}
                        </td>

                        <td className="py-3.5 px-4">
                          {mens.reciboEmitido ? (
                            <button
                              onClick={() => handleAbrirRecibo(mens)}
                              className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 transition-colors border border-indigo-200"
                            >
                              <Receipt className="w-3 h-3" />
                              {mens.reciboNumero || 'Ver Recibo'}
                            </button>
                          ) : (
                            <button
                              onClick={() => handleAbrirRecibo(mens)}
                              className="text-[11px] text-slate-400 hover:text-slate-600 underline"
                            >
                              Gerar Recibo
                            </button>
                          )}
                        </td>

                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-1.5">
                            {mens.historicoEnvios && mens.historicoEnvios.length > 0 ? (
                              mens.historicoEnvios.map((env, i) => (
                                <span
                                  key={i}
                                  title={`Enviado via ${env.canal} em ${new Date(env.dataEnvio).toLocaleDateString()} para ${env.destinatario}`}
                                  className={`p-1 rounded-md text-[10px] ${
                                    env.canal === 'whatsapp'
                                      ? 'bg-emerald-100 text-emerald-700'
                                      : 'bg-blue-100 text-blue-700'
                                  }`}
                                >
                                  {env.canal === 'whatsapp' ? (
                                    <MessageCircle className="w-3 h-3" />
                                  ) : (
                                    <Mail className="w-3 h-3" />
                                  )}
                                </span>
                              ))
                            ) : (
                              <span className="text-[10px] text-slate-400 italic">Não enviado</span>
                            )}
                          </div>
                        </td>

                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Ver PIX / Código de Barras */}
                            <button
                              onClick={() => handleAbrirPix(mens)}
                              title="Ver Chave PIX e Código de Barras"
                              className="p-1.5 text-slate-600 hover:text-emerald-700 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200"
                            >
                              <QrCode className="w-3.5 h-3.5" />
                            </button>

                            {/* Lembrete Automático / Régua */}
                            {mens.status !== 'pago' && (
                              <button
                                onClick={() => setActiveTab('lembretes')}
                                title="Ver Régua de Cobrança e Lembretes Automáticos"
                                className="p-1.5 text-indigo-700 hover:bg-indigo-50 rounded-lg transition-colors border border-indigo-200"
                              >
                                <Bell className="w-3.5 h-3.5" />
                              </button>
                            )}

                            {/* Enviar WhatsApp */}
                            <button
                              onClick={() => handleAbrirWhatsApp(mens)}
                              title="Enviar Cobrança por WhatsApp"
                              className="p-1.5 text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors border border-emerald-200"
                            >
                              <MessageCircle className="w-3.5 h-3.5" />
                            </button>

                            {/* Enviar E-mail */}
                            <button
                              onClick={() => handleAbrirEmail(mens)}
                              title="Enviar Cobrança por E-mail"
                              className="p-1.5 text-blue-700 hover:bg-blue-50 rounded-lg transition-colors border border-blue-200"
                            >
                              <Mail className="w-3.5 h-3.5" />
                            </button>

                            {/* Ação Baixar Pagamento */}
                            {mens.status !== 'pago' ? (
                              <button
                                onClick={() => handleAbrirBaixa(mens)}
                                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-sm"
                              >
                                <Check className="w-3.5 h-3.5" />
                                Baixar
                              </button>
                            ) : (
                              <button
                                onClick={() => handleAbrirRecibo(mens)}
                                title="Visualizar Recibo"
                                className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                Recibo
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      )}

      {/* ========================================================================= */}
      {/* ABA 2: CONTRATOS DE HONORÁRIOS & GUARDA DE DOCUMENTOS                     */}
      {/* ========================================================================= */}
      {activeTab === 'contratos' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {contratosFiltrados.map((contrato) => {
              const nomeEmpresa = getNomeEmpresa(contrato.empresaId);
              const cnpj = getCnpjEmpresa(contrato.empresaId);
              const qtdMensalidades = mensalidades.filter((m) => m.contratoId === contrato.id).length;
              const qtdPagas = mensalidades.filter(
                (m) => m.contratoId === contrato.id && m.status === 'pago'
              ).length;

              return (
                <div
                  key={contrato.id}
                  className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="font-bold text-slate-900 text-sm">{contrato.numeroContrato}</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          contrato.status === 'ativo'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {contrato.status.toUpperCase()}
                      </span>
                    </div>

                    <div className="font-semibold text-slate-900 text-base mb-0.5">{nomeEmpresa}</div>
                    <div className="text-xs text-slate-500 mb-3">{cnpj}</div>

                    <div className="bg-slate-50 rounded-xl p-3 space-y-2 text-xs border border-slate-100 mb-4">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Valor Mensal:</span>
                        <span className="font-bold text-slate-900">
                          R$ {contrato.valorMensalidade.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Dia de Vencimento:</span>
                        <span className="font-semibold text-slate-800">Todo dia {contrato.diaVencimento}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Data de Assinatura:</span>
                        <span className="text-slate-700">{formatarData(contrato.dataAssinatura)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Reajuste Anual:</span>
                        <span className="text-slate-700 font-medium">{contrato.reajusteAnualIndice}</span>
                      </div>
                    </div>

                    {/* Serviços Inclusos */}
                    <div className="mb-4">
                      <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                        Serviços Contratados ({contrato.servicosContratadosNomes?.length || 0})
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {(contrato.servicosContratadosNomes || []).slice(0, 3).map((serv, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-[10px] font-medium"
                          >
                            {serv}
                          </span>
                        ))}
                        {(contrato.servicosContratadosNomes?.length || 0) > 3 && (
                          <span className="px-1.5 py-0.5 bg-emerald-50 text-emerald-700 rounded-md text-[10px] font-semibold">
                            +{contrato.servicosContratadosNomes!.length - 3} mais
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Guarda de Documento e Ações */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <button
                      onClick={() => handleVisualizarDocumentoContrato(contrato)}
                      className="inline-flex items-center gap-1.5 text-emerald-700 hover:text-emerald-800 font-semibold cursor-pointer"
                    >
                      <FolderOpen className="w-3.5 h-3.5" />
                      Contrato Assinado
                    </button>

                    <span className="text-[11px] text-slate-500 font-medium">
                      {qtdPagas}/{qtdMensalidades} pagas
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ABA 3: CATÁLOGO DE SERVIÇOS CONTÁBEIS                                     */}
      {/* ========================================================================= */}
      {activeTab === 'servicos' && (
        <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                Catálogo Geral de Serviços do Escritório
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Tabela de serviços e honorários profissionais prestados aos clientes do escritório.
                Utilizados para composição de contratos e discriminação formal em recibos de quitação.
              </p>
            </div>
            <button
              onClick={() => setModalNovoServicoOpen(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              Cadastrar Novo Serviço
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Código</th>
                  <th className="py-3 px-4">Serviço Contábil</th>
                  <th className="py-3 px-4">Categoria</th>
                  <th className="py-3 px-4">Descrição Operacional</th>
                  <th className="py-3 px-4">Valor Sugerido</th>
                  <th className="py-3 px-4">Tipo</th>
                  <th className="py-3 px-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {servicos.map((srv) => (
                  <tr key={srv.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono font-semibold text-slate-700">{srv.codigo}</td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{srv.nome}</td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-800">
                        {srv.categoria}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600 max-w-md">{srv.descricao}</td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      R$ {srv.valorSugerido.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-3 px-4">
                      {srv.recorrente ? (
                        <span className="text-[11px] text-emerald-700 font-semibold">Mensal Recorrente</span>
                      ) : (
                        <span className="text-[11px] text-amber-700 font-semibold">Eventual / Avulso</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                        Ativo
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ABA 4: RECIBOS EMITIDOS (HISTÓRICO CRC)                                   */}
      {/* ========================================================================= */}
      {activeTab === 'recibos' && (
        <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
                <tr>
                  <th className="py-3.5 px-4">Nº Recibo</th>
                  <th className="py-3.5 px-4">Cliente / Sacado</th>
                  <th className="py-3.5 px-4">Competência</th>
                  <th className="py-3.5 px-4">Data Pagamento</th>
                  <th className="py-3.5 px-4">Valor Liquidado</th>
                  <th className="py-3.5 px-4">Forma</th>
                  <th className="py-3.5 px-4">Responsável Técnico</th>
                  <th className="py-3.5 px-4 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {recibos.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-500">
                      Nenhum recibo de honorários emitido até o momento.
                    </td>
                  </tr>
                ) : (
                  recibos.map((rec) => (
                    <tr key={rec.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-emerald-700">
                        {rec.numero}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900">{rec.razaoSocialCliente}</div>
                        <div className="text-[11px] text-slate-500">{rec.cnpjCpfCliente}</div>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-800 font-semibold">
                          {rec.competencia}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 font-medium">
                        {formatarData(rec.dataPagamento)}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        R$ {rec.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                          {rec.formaPagamento}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-medium text-slate-800">{rec.contadorResponsavel}</div>
                        <div className="text-[10px] text-slate-500">{rec.crcContador}</div>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => {
                              setReciboSelecionado(rec);
                              setModalReciboOpen(true);
                            }}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            Visualizar
                          </button>
                          <button
                            onClick={() => handleGerarReciboPdf(rec)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-sm"
                          >
                            <Download className="w-3.5 h-3.5" />
                            PDF
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: NOVO CONTRATO DE HONORÁRIOS                                      */}
      {/* ========================================================================= */}
      {modalNovoContratoOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-base">Novo Contrato de Prestação de Serviços</h3>
              </div>
              <button
                onClick={() => setModalNovoContratoOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSalvarNovoContrato} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Empresa / Cliente Contratante *
                  </label>
                  <select
                    required
                    value={novoContratoForm.empresaId}
                    onChange={(e) => setNovoContratoForm({ ...novoContratoForm, empresaId: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    {empresas.map((emp) => (
                      <option key={emp.id} value={emp.id}>
                        {emp.razaoSocial} ({emp.cnpj})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Número do Contrato
                  </label>
                  <input
                    type="text"
                    required
                    value={novoContratoForm.numeroContrato}
                    onChange={(e) => setNovoContratoForm({ ...novoContratoForm, numeroContrato: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Data de Assinatura *
                  </label>
                  <input
                    type="date"
                    required
                    value={novoContratoForm.dataAssinatura}
                    onChange={(e) => setNovoContratoForm({ ...novoContratoForm, dataAssinatura: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Início de Vigência *
                  </label>
                  <input
                    type="date"
                    required
                    value={novoContratoForm.dataInicioVigencia}
                    onChange={(e) => setNovoContratoForm({ ...novoContratoForm, dataInicioVigencia: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Dia de Vencimento da Mensalidade *
                  </label>
                  <select
                    value={novoContratoForm.diaVencimento}
                    onChange={(e) => setNovoContratoForm({ ...novoContratoForm, diaVencimento: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value={5}>Todo dia 05</option>
                    <option value={10}>Todo dia 10</option>
                    <option value={15}>Todo dia 15</option>
                    <option value={20}>Todo dia 20</option>
                    <option value={25}>Todo dia 25</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Valor Mensal dos Honorários (R$) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={novoContratoForm.valorMensalidade}
                    onChange={(e) => setNovoContratoForm({ ...novoContratoForm, valorMensalidade: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bold text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Índice de Reajuste Anual
                  </label>
                  <select
                    value={novoContratoForm.reajusteAnualIndice}
                    onChange={(e) => setNovoContratoForm({ ...novoContratoForm, reajusteAnualIndice: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="IPCA">IPCA (IBGE)</option>
                    <option value="IGP-M">IGP-M (FGV)</option>
                    <option value="INPC">INPC (IBGE)</option>
                    <option value="Fixo">Fixo / Reajuste sob Acordo</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Arquivo do Contrato Assinado (PDF)
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: Contrato_Assinado_AlphaTech.pdf"
                    value={novoContratoForm.documentoContratoNome}
                    onChange={(e) => setNovoContratoForm({ ...novoContratoForm, documentoContratoNome: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none text-slate-600"
                  />
                </div>
              </div>

              {/* Checklist de Serviços Contábeis Vinculados */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="font-semibold text-slate-800">
                    Serviços Contábeis Vinculados ao Contrato *
                  </label>
                  <button
                    type="button"
                    onClick={() =>
                      setNovoContratoForm({
                        ...novoContratoForm,
                        servicosSelecionados: servicos.filter((s) => s.recorrente).map((s) => s.id),
                      })
                    }
                    className="text-emerald-700 hover:text-emerald-800 font-semibold"
                  >
                    Selecionar Padrão Recorrente
                  </button>
                </div>

                <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-xl p-3 grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-50/50">
                  {servicos.map((serv) => {
                    const isChecked = novoContratoForm.servicosSelecionados.includes(serv.id);
                    return (
                      <label
                        key={serv.id}
                        className={`flex items-start gap-2 p-2 rounded-lg border cursor-pointer transition-colors ${
                          isChecked
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                            : 'bg-white border-slate-200 text-slate-700'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setNovoContratoForm({
                                ...novoContratoForm,
                                servicosSelecionados: [...novoContratoForm.servicosSelecionados, serv.id],
                              });
                            } else {
                              setNovoContratoForm({
                                ...novoContratoForm,
                                servicosSelecionados: novoContratoForm.servicosSelecionados.filter(
                                  (id) => id !== serv.id
                                ),
                              });
                            }
                          }}
                          className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500"
                        />
                        <div className="min-w-0">
                          <div className="font-semibold leading-tight">{serv.nome}</div>
                          <div className="text-[10px] text-slate-500 mt-0.5">
                            {serv.categoria} • Sugerido: R$ {serv.valorSugerido.toFixed(2)}
                          </div>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Observações e Cláusulas Específicas
                </label>
                <textarea
                  rows={2}
                  value={novoContratoForm.observacoes}
                  onChange={(e) => setNovoContratoForm({ ...novoContratoForm, observacoes: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalNovoContratoOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-50 font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold shadow-sm"
                >
                  Salvar Contrato & Gerar Mensalidade
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: REGISTRO DE BAIXA (PAGAMENTO)                                    */}
      {/* ========================================================================= */}
      {modalBaixaOpen && mensalidadeSelecionada && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-emerald-50">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-base">Registrar Baixa de Mensalidade</h3>
              </div>
              <button
                onClick={() => setModalBaixaOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-100">
                <div className="font-bold text-slate-900 text-sm">
                  {getNomeEmpresa(mensalidadeSelecionada.empresaId)}
                </div>
                <div className="text-slate-500 mt-0.5">
                  Competência: {mensalidadeSelecionada.competencia} | Vencimento:{' '}
                  {formatarData(mensalidadeSelecionada.dataVencimento)}
                </div>
                <div className="text-base font-bold text-emerald-700 mt-2">
                  Valor: R${' '}
                  {mensalidadeSelecionada.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Data do Pagamento *</label>
                <input
                  type="date"
                  value={baixaForm.dataPagamento}
                  onChange={(e) => setBaixaForm({ ...baixaForm, dataPagamento: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Forma de Liquidação *</label>
                <select
                  value={baixaForm.formaPagamento}
                  onChange={(e) => setBaixaForm({ ...baixaForm, formaPagamento: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                >
                  <option value="pix">PIX Instantâneo</option>
                  <option value="boleto">Boleto Bancário Liquidado</option>
                  <option value="transferencia">Transferência Bancária (TED/DOC)</option>
                  <option value="dinheiro">Espécie / Caixa Físico</option>
                  <option value="cartao">Cartão de Crédito / Débito</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Valor Pago (R$) *</label>
                <input
                  type="number"
                  step="0.01"
                  value={baixaForm.valorPago}
                  onChange={(e) => setBaixaForm({ ...baixaForm, valorPago: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bold text-slate-900"
                />
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 font-semibold text-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={baixaForm.emitirReciboAuto}
                    onChange={(e) => setBaixaForm({ ...baixaForm, emitirReciboAuto: e.target.checked })}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  Gerar Recibo Oficial de Honorários com numeração CRC
                </label>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalBaixaOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-50 font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmarBaixa}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold shadow-sm"
                >
                  Confirmar Baixa
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: VISUALIZADOR DE RECIBO DE HONORÁRIOS (PADRÃO CRC)               */}
      {/* ========================================================================= */}
      {modalReciboOpen && reciboSelecionado && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-150">
            {/* Barra de Ações do Recibo */}
            <div className="px-6 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  Recibo Oficial de Honorários Contábeis
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleGerarReciboPdf(reciboSelecionado)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  Salvar PDF
                </button>
                <button
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors border border-slate-200"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Imprimir
                </button>
                <button
                  onClick={() => setModalReciboOpen(false)}
                  className="text-slate-400 hover:text-slate-600 p-1 ml-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Documento Timbrado do Recibo */}
            <div className="p-8 space-y-6 text-slate-800 bg-white" id="documento-recibo-impressao">
              {/* Cabeçalho Timbrado */}
              <div className="border-b-2 border-emerald-600 pb-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-xl font-black text-slate-900 tracking-tight">
                      {reciboSelecionado.nomeEscritorio}
                    </h2>
                    <p className="text-xs text-slate-600 mt-0.5">
                      CNPJ: {reciboSelecionado.cnpjEscritorio} | {reciboSelecionado.enderecoEscritorio}
                    </p>
                    <p className="text-xs text-slate-600">
                      Contador Responsável: {reciboSelecionado.contadorResponsavel} • CRC:{' '}
                      {reciboSelecionado.crcContador}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="inline-block px-3 py-1 rounded-md text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                      {reciboSelecionado.numero}
                    </span>
                    <div className="text-xs text-slate-500 mt-1">
                      Competência: <strong className="text-slate-800">{reciboSelecionado.competencia}</strong>
                    </div>
                  </div>
                </div>
              </div>

              {/* Caixa Destaque de Valor */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <span className="text-xs uppercase font-bold text-slate-500 tracking-wider">
                    Valor Quitado
                  </span>
                  <div className="text-2xl font-black text-emerald-700">
                    R$ {reciboSelecionado.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </div>
                  <div className="text-xs text-slate-600 font-medium italic mt-0.5">
                    ({reciboSelecionado.valorPorExtenso})
                  </div>
                </div>
                <div className="text-right text-xs">
                  <div className="text-slate-500">Liquidação:</div>
                  <div className="font-semibold text-slate-900">{reciboSelecionado.formaPagamento}</div>
                  <div className="text-slate-500 mt-1">Data de Pagamento:</div>
                  <div className="font-semibold text-slate-900">
                    {formatarData(reciboSelecionado.dataPagamento)}
                  </div>
                </div>
              </div>

              {/* Texto de Quitação Formal */}
              <div className="text-xs leading-relaxed text-justify space-y-3">
                <p>
                  Recebemos de <strong>{reciboSelecionado.razaoSocialCliente}</strong>, pessoa jurídica
                  inscrita no CNPJ sob o nº <strong>{reciboSelecionado.cnpjCpfCliente}</strong>,
                  estabelecida em {reciboSelecionado.enderecoCliente || 'São Paulo/SP'}, a importância de{' '}
                  <strong>
                    R$ {reciboSelecionado.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}{' '}
                    ({reciboSelecionado.valorPorExtenso})
                  </strong>
                  , correspondente à prestação dos serviços técnicos de contabilidade, apuração tributária
                  e departamento pessoal discriminados abaixo:
                </p>
              </div>

              {/* Discriminação dos Serviços */}
              <div>
                <div className="text-xs font-bold uppercase text-slate-700 tracking-wider mb-2">
                  Discriminação dos Serviços Prestados:
                </div>
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 text-slate-700 font-semibold">
                      <tr>
                        <th className="py-2 px-3 w-12 text-center">Item</th>
                        <th className="py-2 px-3">Serviço Técnico Realizado</th>
                        <th className="py-2 px-3 text-right">Competência</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {reciboSelecionado.discriminacaoServicos.map((serv, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/60">
                          <td className="py-2 px-3 text-center text-slate-400 font-mono">
                            {String(idx + 1).padStart(2, '0')}
                          </td>
                          <td className="py-2 px-3 font-medium text-slate-800">{serv}</td>
                          <td className="py-2 px-3 text-right text-slate-500">
                            {reciboSelecionado.competencia}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Termo Final de Quitação */}
              <p className="text-[11px] text-slate-500 italic text-justify">
                E por ser a mais lídima expressão da verdade, firmamos o presente recibo dando plena,
                geral e irrevogável quitação dos honorários correspondentes à referida competência.
              </p>

              {/* Assinatura */}
              <div className="pt-6 border-t border-slate-200 flex justify-between items-end">
                <div className="text-xs text-slate-500">
                  São Paulo - SP, {formatarData(reciboSelecionado.dataPagamento || reciboSelecionado.dataEmissao)}.
                </div>
                <div className="text-center">
                  <div className="w-64 border-b border-slate-400 mb-1.5 mx-auto"></div>
                  <div className="font-bold text-slate-900 text-xs">
                    {reciboSelecionado.contadorResponsavel}
                  </div>
                  <div className="text-[11px] text-slate-500">{reciboSelecionado.crcContador}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ABA 5: SISTEMA DE LEMBRETES AUTOMÁTICOS (WHATSAPP & E-MAIL)               */}
      {/* ========================================================================= */}
      {activeTab === 'lembretes' && (
        <AbaLembretesAutomaticos
          mensalidades={mensalidades}
          empresas={empresas}
          contratos={contratos}
          onAtualizarMensalidade={(atualizada) => {
            setMensalidades((prev) =>
              prev.map((m) => (m.id === atualizada.id ? atualizada : m))
            );
          }}
          onFeedback={(msg) => exibirFeedback(msg)}
        />
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: ENVIO POR WHATSAPP COM DADOS DE PAGAMENTO E RECIBO              */}
      {/* ========================================================================= */}
      {modalWhatsAppOpen && mensalidadeSelecionada && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-emerald-50">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-base">Enviar Cobrança via WhatsApp</h3>
              </div>
              <button
                onClick={() => setModalWhatsAppOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Número de WhatsApp do Cliente *
                </label>
                <input
                  type="text"
                  value={whatsAppForm.telefone}
                  onChange={(e) => setWhatsAppForm({ ...whatsAppForm, telefone: e.target.value })}
                  placeholder="(11) 98765-4321"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none font-semibold text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Mensagem Formatada Pronta para Envio
                </label>
                <textarea
                  rows={8}
                  value={whatsAppForm.mensagem}
                  onChange={(e) => setWhatsAppForm({ ...whatsAppForm, mensagem: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono text-[11px] bg-slate-50"
                />
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-amber-800 text-[11px]">
                💡 Ao clicar em <strong>"Abrir no WhatsApp"</strong>, a janela do WhatsApp Web será aberta com a mensagem pronta e o envio será registrado no histórico da fatura.
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalWhatsAppOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-50 font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleDispararWhatsApp}
                  className="inline-flex items-center gap-2 px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold shadow-sm"
                >
                  <Send className="w-3.5 h-3.5" />
                  Abrir no WhatsApp & Registrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: ENVIO POR E-MAIL COM FATURA E RECIBO                             */}
      {/* ========================================================================= */}
      {modalEmailOpen && mensalidadeSelecionada && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-blue-50">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-blue-600" />
                <h3 className="font-bold text-slate-900 text-base">Enviar Cobrança por E-mail</h3>
              </div>
              <button
                onClick={() => setModalEmailOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">E-mail do Destinatário *</label>
                <input
                  type="email"
                  value={emailForm.destinatario}
                  onChange={(e) => setEmailForm({ ...emailForm, destinatario: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none font-semibold text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Assunto do E-mail</label>
                <input
                  type="text"
                  value={emailForm.assunto}
                  onChange={(e) => setEmailForm({ ...emailForm, assunto: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Corpo da Mensagem</label>
                <textarea
                  rows={8}
                  value={emailForm.mensagem}
                  onChange={(e) => setEmailForm({ ...emailForm, mensagem: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono text-[11px] bg-slate-50"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalEmailOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-50 font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleDispararEmail}
                  className="inline-flex items-center gap-2 px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold shadow-sm"
                >
                  <Send className="w-3.5 h-3.5" />
                  Enviar E-mail
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 6: QR CODE PIX E LINHA DIGITÁVEL DO BOLETO                          */}
      {/* ========================================================================= */}
      {modalPixOpen && mensalidadeSelecionada && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-emerald-50">
              <div className="flex items-center gap-2">
                <QrCode className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-base">Pagamento PIX & Boleto</h3>
              </div>
              <button
                onClick={() => setModalPixOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs text-center">
              {/* Ilustração QR Code */}
              <div className="w-44 h-44 mx-auto bg-slate-50 border-2 border-dashed border-emerald-500 rounded-2xl flex flex-col items-center justify-center p-3">
                <QrCode className="w-32 h-32 text-slate-800" />
                <span className="text-[10px] text-emerald-700 font-bold uppercase tracking-wider mt-1">
                  PIX Instantâneo
                </span>
              </div>

              <div className="text-center">
                <div className="text-xl font-black text-slate-900">
                  R$ {mensalidadeSelecionada.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </div>
                <div className="text-xs text-slate-500">
                  Vencimento: {formatarData(mensalidadeSelecionada.dataVencimento)}
                </div>
              </div>

              {/* PIX Copia e Cola */}
              <div className="text-left bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-semibold text-slate-700">Chave PIX (Copia e Cola):</span>
                  <button
                    onClick={() =>
                      handleCopiarPix(
                        mensalidadeSelecionada.pixCopiaECola ||
                          '00020126580014br.gov.bcb.pix0136contabgest.financeiro@contabgest.com.br...'
                      )
                    }
                    className="inline-flex items-center gap-1 text-emerald-700 font-bold hover:underline cursor-pointer"
                  >
                    {copiadoPix ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiadoPix ? 'Copiado!' : 'Copiar'}
                  </button>
                </div>
                <div className="font-mono text-[10px] text-slate-600 truncate">
                  {mensalidadeSelecionada.pixCopiaECola ||
                    '00020126580014br.gov.bcb.pix0136contabgest.financeiro@contabgest.com.br52040000...'}
                </div>
              </div>

              {/* Código de Barras */}
              <div className="text-left bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-semibold text-slate-700">Linha Digitável do Boleto:</span>
                  <button
                    onClick={() =>
                      handleCopiarCodigo(
                        mensalidadeSelecionada.codigoBarras ||
                          '34191.79001 01043.510047 91020.150008 7 98350000185000'
                      )
                    }
                    className="inline-flex items-center gap-1 text-emerald-700 font-bold hover:underline cursor-pointer"
                  >
                    {copiadoCodigo ? (
                      <Check className="w-3.5 h-3.5" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    {copiadoCodigo ? 'Copiado!' : 'Copiar'}
                  </button>
                </div>
                <div className="font-mono text-[11px] font-bold text-slate-800">
                  {mensalidadeSelecionada.codigoBarras ||
                    '34191.79001 01043.510047 91020.150008 7 98350000185000'}
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => setModalPixOpen(false)}
                  className="w-full py-2 bg-slate-900 text-white rounded-xl font-semibold hover:bg-slate-800 transition-colors"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 7: CADASTRAR NOVO SERVIÇO CONTÁBIL                                  */}
      {/* ========================================================================= */}
      {modalNovoServicoOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Tag className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-base">Novo Serviço Contábil</h3>
              </div>
              <button
                onClick={() => setModalNovoServicoOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSalvarNovoServico} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nome do Serviço *</label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Consultoria de Blindagem Patrimonial"
                  value={novoServicoForm.nome}
                  onChange={(e) => setNovoServicoForm({ ...novoServicoForm, nome: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Categoria *</label>
                  <select
                    value={novoServicoForm.categoria}
                    onChange={(e) => setNovoServicoForm({ ...novoServicoForm, categoria: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="Fiscal">Fiscal</option>
                    <option value="Contábil">Contábil</option>
                    <option value="Folha/DP">Folha/DP</option>
                    <option value="Societário">Societário</option>
                    <option value="BPO Financeiro">BPO Financeiro</option>
                    <option value="Consultoria">Consultoria</option>
                    <option value="Certidões">Certidões</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Valor Sugerido (R$)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={novoServicoForm.valorSugerido}
                    onChange={(e) => setNovoServicoForm({ ...novoServicoForm, valorSugerido: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bold text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Descrição Detalhada</label>
                <textarea
                  rows={3}
                  placeholder="Descreva o escopo e as rotinas contempladas no serviço..."
                  value={novoServicoForm.descricao}
                  onChange={(e) => setNovoServicoForm({ ...novoServicoForm, descricao: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 font-semibold text-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={novoServicoForm.recorrente}
                    onChange={(e) => setNovoServicoForm({ ...novoServicoForm, recorrente: e.target.checked })}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  Serviço Recorrente Mensal (Honorário Contínuo)
                </label>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalNovoServicoOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-50 font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold shadow-sm"
                >
                  Salvar Serviço
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 8: GERAR LOTE DE MENSALIDADES                                       */}
      {/* ========================================================================= */}
      {modalLoteOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <RefreshCw className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-base">Gerar Mensalidades em Lote</h3>
              </div>
              <button
                onClick={() => setModalLoteOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <p className="text-slate-600 leading-relaxed">
                Esta rotina varrerá todos os <strong>{metricas.contratosAtivos} contratos ativos</strong> e
                gerará automaticamente as faturas e cobranças para a competência indicada, calculando a
                data de vencimento conforme o dia contratado e gerando a linha digitável e QR Code PIX.
              </p>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Competência Alvo (Formato MM/AAAA) *
                </label>
                <input
                  type="text"
                  value={loteCompetencia}
                  onChange={(e) => setLoteCompetencia(e.target.value)}
                  placeholder="Ex: 10/2026"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none font-bold text-base text-slate-900"
                />
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalLoteOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-50 font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleGerarLote}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold shadow-sm"
                >
                  Processar e Gerar Lote
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 9: GUARDA DE DOCUMENTO / CONTRATO ASSINADO                          */}
      {/* ========================================================================= */}
      {modalDocContratoOpen && contratoSelecionado && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <FolderOpen className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 text-base">Guarda de Contrato Assinado</h3>
              </div>
              <button
                onClick={() => setModalDocContratoOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center gap-3">
                <FileText className="w-8 h-8 text-emerald-600 shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="font-bold text-slate-900 text-sm truncate">
                    {contratoSelecionado.documentoContratoNome ||
                      `Contrato_${contratoSelecionado.numeroContrato}.pdf`}
                  </div>
                  <div className="text-slate-500 text-[11px] mt-0.5">
                    Contrato nº {contratoSelecionado.numeroContrato} • Assinado em{' '}
                    {formatarData(contratoSelecionado.dataAssinatura)}
                  </div>
                </div>
              </div>

              <div className="space-y-2 border border-slate-100 rounded-xl p-3 text-slate-600">
                <div className="flex justify-between">
                  <span>Status do Contrato:</span>
                  <span className="font-semibold text-emerald-700 uppercase">
                    {contratoSelecionado.status}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Assinado com Certificado Digital:</span>
                  <span className="font-semibold text-slate-800">Sim (Padrão ICP-Brasil)</span>
                </div>
                <div className="flex justify-between">
                  <span>Vigência:</span>
                  <span className="text-slate-800">
                    A partir de {formatarData(contratoSelecionado.dataInicioVigencia)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Cláusula de Reajuste:</span>
                  <span className="text-slate-800 font-medium">
                    Índice {contratoSelecionado.reajusteAnualIndice}
                  </span>
                </div>
              </div>

              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-emerald-900 text-[11px] flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                Documento mantido em custódia digital segura com integridade verificável.
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalDocContratoOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-50 font-medium"
                >
                  Fechar
                </button>
                <button
                  type="button"
                  onClick={() => {
                    exibirFeedback('Download do contrato assinado iniciado!');
                    setModalDocContratoOpen(false);
                  }}
                  className="inline-flex items-center gap-2 px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  Baixar Arquivo PDF
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Exportação em Lote (OFX / CSV) */}
      <ModalExportacaoCobrancas
        isOpen={modalExportarOpen}
        onClose={() => setModalExportarOpen(false)}
        mensalidadesTotais={mensalidades}
        mensalidadesFiltradas={mensalidadesFiltradas}
        mensalidadesSelecionadasIds={mensalidadesSelecionadasIds}
        contratos={contratos}
        empresas={empresas}
        onFeedback={exibirFeedback}
      />
    </div>
  );
};
