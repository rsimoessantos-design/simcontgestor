import React, { useState } from 'react';
import { Users, Plus, Search, Mail, Phone, MapPin, Building, UserCheck } from 'lucide-react';
import { Cliente, Empresa } from '../types';

interface ClientesViewProps {
  clientes: Cliente[];
  empresas: Empresa[];
  selectedEmpresa?: Empresa;
}

export const ClientesView: React.FC<ClientesViewProps> = ({
  clientes,
  empresas,
  selectedEmpresa,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredClientes = clientes.filter(
    (c) =>
      c.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.cpfCnpj.includes(searchTerm) ||
      c.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getEmpresaName = (empresaId: string) => {
    const emp = empresas.find((e) => e.id === empresaId);
    return emp ? emp.nomeFantasia : 'Não vinculada';
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900">Carteira de Clientes</h1>
            <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
              DEMO
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {selectedEmpresa
              ? `Clientes e compradores diretos vinculados à empresa: ${selectedEmpresa.nomeFantasia}`
              : 'Clientes cadastrados em todas as empresas geridas'}
          </p>
        </div>

        <button
          onClick={() =>
            alert('Cadastro de cliente pronto para expansão no próximo módulo.')
          }
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Novo Cliente</span>
        </button>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
        <div className="relative mb-4">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar por nome do cliente, CPF, CNPJ ou e-mail..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Cliente</th>
                <th className="py-3 px-4">Tipo & Documento</th>
                <th className="py-3 px-4">Empresa Titular</th>
                <th className="py-3 px-4">Contato</th>
                <th className="py-3 px-4">Cidade / UF</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredClientes.map((cli) => (
                <tr key={cli.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4 font-semibold text-slate-900">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-md bg-slate-100 text-slate-600 flex items-center justify-center font-bold text-[11px]">
                        {cli.tipo}
                      </div>
                      <span>{cli.nome}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono">{cli.cpfCnpj}</td>
                  <td className="py-3 px-4">
                    <span className="inline-block px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
                      {getEmpresaName(cli.empresaId)}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div>{cli.email}</div>
                    <div className="text-[11px] text-slate-400">{cli.telefone}</div>
                  </td>
                  <td className="py-3 px-4">
                    {cli.cidade} / {cli.uf}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                      ATIVO
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
