import React, { useState } from 'react';
import {
  CalendarCheck2,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileText,
  Search,
  Check,
  Building,
  Plus,
} from 'lucide-react';
import { Obrigacao, Empresa } from '../types';

interface ObrigacoesViewProps {
  obrigacoes: Obrigacao[];
  empresas: Empresa[];
  selectedEmpresa?: Empresa;
  onUpdateStatus: (id: string, newStatus: Obrigacao['status']) => void;
}

export const ObrigacoesView: React.FC<ObrigacoesViewProps> = ({
  obrigacoes,
  empresas,
  selectedEmpresa,
  onUpdateStatus,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTipo, setFilterTipo] = useState('todos');
  const [filterStatus, setFilterStatus] = useState('todos');

  const filtered = obrigacoes.filter((ob) => {
    const matchesSearch =
      ob.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ob.competencia.includes(searchTerm) ||
      ob.responsavel.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTipo = filterTipo === 'todos' || ob.tipo === filterTipo;
    const matchesStatus = filterStatus === 'todos' || ob.status === filterStatus;
    return matchesSearch && matchesTipo && matchesStatus;
  });

  const formatCurrency = (val?: number) => {
    if (!val) return '—';
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
  };

  const getEmpresaName = (empresaId: string) => {
    const emp = empresas.find((e) => e.id === empresaId);
    return emp ? emp.nomeFantasia : 'Todas';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900">
              Calendário e Obrigações Fiscais
            </h1>
            <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
              DEMO
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {selectedEmpresa
              ? `Obrigações e guias fiscais da empresa: ${selectedEmpresa.nomeFantasia}`
              : 'Gestão de declarações federais, estaduais, municipais e trabalhistas'}
          </p>
        </div>

        <button
          onClick={() =>
            alert('Cadastro de nova obrigação fiscal preparado para o módulo fiscal.')
          }
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Nova Obrigação</span>
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar por declaração, imposto, competência ou responsável..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
          />
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span>Âmbito:</span>
            <select
              value={filterTipo}
              onChange={(e) => setFilterTipo(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg py-1.5 px-2 bg-slate-50"
            >
              <option value="todos">Todos</option>
              <option value="Federal">Federal</option>
              <option value="Estadual">Estadual</option>
              <option value="Municipal">Municipal</option>
              <option value="Trabalhista">Trabalhista</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <span>Status:</span>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg py-1.5 px-2 bg-slate-50"
            >
              <option value="todos">Todos os status</option>
              <option value="pendente">Pendente</option>
              <option value="vencendo">Vencendo</option>
              <option value="concluida">Concluída</option>
              <option value="atrasada">Atrasada</option>
            </select>
          </div>
        </div>
      </div>

      {/* Obligations Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Obrigação / Tributo</th>
                <th className="py-3 px-4">Empresa</th>
                <th className="py-3 px-4">Competência</th>
                <th className="py-3 px-4">Vencimento</th>
                <th className="py-3 px-4">Valor Estimado</th>
                <th className="py-3 px-4">Responsável</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((ob) => (
                <tr key={ob.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-900">{ob.titulo}</div>
                    <div className="text-[11px] text-slate-400">Âmbito: {ob.tipo}</div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-medium text-slate-700">
                      {getEmpresaName(ob.empresaId)}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono font-medium text-slate-700">
                    {ob.competencia}
                  </td>
                  <td className="py-3 px-4 font-mono font-medium text-slate-800">
                    {ob.dataVencimento}
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-900">
                    {formatCurrency(ob.valorTributo)}
                  </td>
                  <td className="py-3 px-4 text-slate-600">{ob.responsavel}</td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        ob.status === 'concluida'
                          ? 'bg-emerald-100 text-emerald-800'
                          : ob.status === 'atrasada'
                          ? 'bg-rose-100 text-rose-800'
                          : ob.status === 'vencendo'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {ob.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    {ob.status !== 'concluida' ? (
                      <button
                        onClick={() => onUpdateStatus(ob.id, 'concluida')}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold border border-emerald-200 transition-colors"
                        title="Marcar como transmitida"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Transmitir</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => onUpdateStatus(ob.id, 'pendente')}
                        className="text-[11px] text-slate-400 hover:text-slate-600 underline"
                      >
                        Reabrir
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
