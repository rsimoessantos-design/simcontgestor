import React, { useState, useEffect } from 'react';
import {
  X,
  Send,
  MessageCircle,
  Mail,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ExternalLink,
  Copy,
  QrCode,
  DollarSign,
  Building2,
  Calendar,
} from 'lucide-react';
import { LembreteFilaItem } from '../types';
import { gerarUrlWhatsApp, gerarMailto } from '../utils/lembretesCobrancaUtils';

interface ModalDisparoLembreteProps {
  isOpen: boolean;
  onClose: () => void;
  item: LembreteFilaItem | null;
  onConfirmarEnvio: (
    mensalidadeId: string,
    canal: 'whatsapp' | 'email',
    destinatario: string,
    mensagemEnviada: string
  ) => Promise<void>;
}

export const ModalDisparoLembrete: React.FC<ModalDisparoLembreteProps> = ({
  isOpen,
  onClose,
  item,
  onConfirmarEnvio,
}) => {
  if (!isOpen || !item) return null;

  const [canalSelecionado, setCanalSelecionado] = useState<'whatsapp' | 'email'>(
    item.canalSugerido === 'email' ? 'email' : 'whatsapp'
  );
  const [destinatario, setDestinatario] = useState(
    item.canalSugerido === 'email' ? item.destinatarioEmail : item.destinatarioWhatsApp
  );
  const [mensagemEditavel, setMensagemEditavel] = useState(item.mensagemFormatada);
  const [assuntoEditavel, setAssuntoEditavel] = useState(item.assuntoFormatado);
  const [enviando, setEnviando] = useState(false);
  const [copiadoPix, setCopiadoPix] = useState(false);

  useEffect(() => {
    if (canalSelecionado === 'whatsapp') {
      setDestinatario(item.destinatarioWhatsApp);
    } else {
      setDestinatario(item.destinatarioEmail);
    }
  }, [canalSelecionado, item]);

  const handleCopiarPix = () => {
    if (item.mensalidade.pixCopiaECola) {
      navigator.clipboard.writeText(item.mensalidade.pixCopiaECola);
      setCopiadoPix(true);
      setTimeout(() => setCopiadoPix(false), 2500);
    }
  };

  const handleExecutarDisparo = async () => {
    try {
      setEnviando(true);
      if (canalSelecionado === 'whatsapp') {
        const urlWa = gerarUrlWhatsApp(destinatario, mensagemEditavel);
        window.open(urlWa, '_blank');
      } else {
        const urlMail = gerarMailto(destinatario, assuntoEditavel, mensagemEditavel);
        window.location.href = urlMail;
      }

      await onConfirmarEnvio(
        item.mensalidade.id,
        canalSelecionado,
        destinatario,
        mensagemEditavel
      );
      onClose();
    } catch (err) {
      console.error('Erro ao registrar envio', err);
    } finally {
      setEnviando(false);
    }
  };

  const formatarMoeda = (val: number) =>
    val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 max-h-[92vh] flex flex-col">
        {/* Topo do Modal */}
        <div
          className={`px-6 py-4 border-b flex items-center justify-between ${
            item.tipo === 'atraso'
              ? 'bg-rose-50 border-rose-200'
              : item.tipo === 'vencimento'
              ? 'bg-amber-50 border-amber-200'
              : 'bg-emerald-50 border-emerald-200'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div
              className={`p-2 rounded-xl text-white ${
                item.tipo === 'atraso'
                  ? 'bg-rose-600'
                  : item.tipo === 'vencimento'
                  ? 'bg-amber-600'
                  : 'bg-emerald-600'
              }`}
            >
              {canalSelecionado === 'whatsapp' ? (
                <MessageCircle className="w-5 h-5" />
              ) : (
                <Mail className="w-5 h-5" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-slate-900 text-base">
                  Disparar Lembrete de Cobrança
                </h3>
                <span
                  className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                    item.tipo === 'atraso'
                      ? 'bg-rose-100 text-rose-800'
                      : item.tipo === 'vencimento'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {item.regraAplicada.nome}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Cliente: <strong>{item.empresa.razaoSocial}</strong> • Vencimento:{' '}
                <strong>{item.mensalidade.dataVencimento}</strong> ({formatarMoeda(item.mensalidade.valor)})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-white/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Conteúdo com rolagem suave */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs">
          {/* Seletor de Canal */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1.5">
              Selecione o Canal de Notificação
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setCanalSelecionado('whatsapp')}
                className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-semibold border transition-all cursor-pointer ${
                  canalSelecionado === 'whatsapp'
                    ? 'border-emerald-600 bg-emerald-50/80 text-emerald-800 shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                WhatsApp ({item.empresa.telefone || 'Sem tel'})
              </button>

              <button
                type="button"
                onClick={() => setCanalSelecionado('email')}
                className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-semibold border transition-all cursor-pointer ${
                  canalSelecionado === 'email'
                    ? 'border-blue-600 bg-blue-50/80 text-blue-800 shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <Mail className="w-4 h-4 text-blue-600" />
                E-mail ({item.empresa.email || 'Sem email'})
              </button>
            </div>
          </div>

          {/* Campo Destinatário */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Destinatário ({canalSelecionado === 'whatsapp' ? 'Número WhatsApp com DDD' : 'Endereço de E-mail'}) *
            </label>
            <input
              type={canalSelecionado === 'whatsapp' ? 'tel' : 'email'}
              value={destinatario}
              onChange={(e) => setDestinatario(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none font-semibold text-slate-900 bg-slate-50"
            />
          </div>

          {/* Se E-mail, exibe campo Assunto */}
          {canalSelecionado === 'email' && (
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Assunto do E-mail *
              </label>
              <input
                type="text"
                value={assuntoEditavel}
                onChange={(e) => setAssuntoEditavel(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none font-medium text-slate-800"
              />
            </div>
          )}

          {/* Pré-visualização da Mensagem */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-semibold text-slate-700">
                Mensagem Formatada (Pronta para Envio com Variáveis Preenchidas)
              </label>
              <span className="text-[11px] text-slate-400">Você pode ajustar o texto antes de disparar</span>
            </div>

            <div className="relative">
              <textarea
                rows={9}
                value={mensagemEditavel}
                onChange={(e) => setMensagemEditavel(e.target.value)}
                className={`w-full p-3.5 border rounded-xl font-mono text-[11px] focus:outline-none leading-relaxed ${
                  canalSelecionado === 'whatsapp'
                    ? 'bg-emerald-50/30 border-emerald-300 focus:ring-2 focus:ring-emerald-500'
                    : 'bg-slate-50 border-slate-300 focus:ring-2 focus:ring-blue-500'
                }`}
              />
            </div>
          </div>

          {/* Resumo da Fatura com Pix Rápido */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-100 text-emerald-800 rounded-lg">
                <QrCode className="w-5 h-5" />
              </div>
              <div>
                <span className="font-semibold text-slate-800 block text-xs">
                  Chave Pix & Código de Barras Inclusos na Mensagem
                </span>
                <span className="text-[11px] text-slate-500 font-mono">
                  {item.mensalidade.pixCopiaECola
                    ? `${item.mensalidade.pixCopiaECola.slice(0, 32)}...`
                    : 'Chave do Escritório'}
                </span>
              </div>
            </div>

            {item.mensalidade.pixCopiaECola && (
              <button
                type="button"
                onClick={handleCopiarPix}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-100 transition-colors shrink-0"
              >
                {copiadoPix ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    Copiado!
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-500" />
                    Copiar Pix
                  </>
                )}
              </button>
            )}
          </div>

          {/* Alerta caso já tenha sido enviado hoje */}
          {item.jaEnviadoHoje && (
            <div className="bg-amber-50 border border-amber-300 rounded-xl p-3 text-amber-900 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                <strong>Atenção:</strong> Um lembrete já foi enviado para este cliente hoje às{' '}
                {item.ultimoEnvio?.dataEnvio
                  ? new Date(item.ultimoEnvio.dataEnvio).toLocaleTimeString('pt-BR', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })
                  : 'horário registrado'}
                . Enviar novamente gerará uma segunda notificação.
              </span>
            </div>
          )}
        </div>

        {/* Rodapé de Ações */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="text-[11px] text-slate-500">
            Status: <span className="font-semibold text-slate-700">Pronto para Envio</span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-100 font-medium text-xs transition-colors cursor-pointer"
            >
              Cancelar
            </button>

            <button
              type="button"
              onClick={handleExecutarDisparo}
              disabled={enviando || !destinatario}
              className={`inline-flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-bold text-white shadow-sm transition-all cursor-pointer ${
                canalSelecionado === 'whatsapp'
                  ? 'bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-300'
                  : 'bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300'
              }`}
            >
              <Send className="w-3.5 h-3.5" />
              {canalSelecionado === 'whatsapp'
                ? 'Abrir no WhatsApp & Confirmar'
                : 'Enviar por E-mail & Confirmar'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
