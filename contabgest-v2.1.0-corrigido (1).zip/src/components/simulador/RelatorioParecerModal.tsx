import React, { useState, useRef } from 'react';
import {
  X,
  Printer,
  Copy,
  Check,
  Building2,
  TrendingDown,
  Award,
  Calendar,
  UserCheck,
  FileCheck,
  Share2,
} from 'lucide-react';
import {
  ParametrosSimulacaoTributaria,
  ResultadoCenarioSimulacao,
  User,
} from '../../types';

interface RelatorioParecerModalProps {
  isOpen: boolean;
  onClose: () => void;
  parametros: ParametrosSimulacaoTributaria;
  cenarios: ResultadoCenarioSimulacao[];
  melhorOpcao: ResultadoCenarioSimulacao;
  fatorRCalculado: number;
  fatorREnquadrado: boolean;
  resumoParecer: string;
  currentUser: User;
}

export const RelatorioParecerModal: React.FC<RelatorioParecerModalProps> = ({
  isOpen,
  onClose,
  parametros,
  cenarios,
  melhorOpcao,
  fatorRCalculado,
  fatorREnquadrado,
  resumoParecer,
  currentUser,
}) => {
  const [copiado, setCopiado] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const dataAtual = new Date().toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });

  const formatarMoeda = (val: number) =>
    val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  // Calcular economia frente ao mais caro ou frente ao Simples Tradicional
  const piorOpcao = cenarios
    .filter((c) => c.elegivel)
    .reduce((max, c) =>
      c.tributos.custoLiquidoTributario > max.tributos.custoLiquidoTributario ? c : max
    , melhorOpcao);

  const economiaAnualMaxima = Math.max(
    0,
    piorOpcao.tributos.custoLiquidoTributario - melhorOpcao.tributos.custoLiquidoTributario
  );
  const economiaMensalMedia = economiaAnualMaxima / 12;

  const handleImprimir = () => {
    window.print();
  };

  const handleCopiarWhatsApp = () => {
    const textoWhatsApp = `📊 *DIAGNÓSTICO TRIBUTÁRIO & REFORMA TRIBUTÁRIA*
🏢 *Empresa:* ${parametros.nomeEmpresa || 'Cliente'} ${parametros.cnpj ? `(${parametros.cnpj})` : ''}
📅 *Ano de Análise:* ${parametros.anoAnalise}
💰 *Faturamento Anual Projetado:* ${formatarMoeda(parametros.faturamentoAnual)}

🏆 *REGIME RECOMENDADO: ${melhorOpcao.titulo.toUpperCase()}*
• Carga Tributária Anual: ${formatarMoeda(melhorOpcao.tributos.totalTributosAnual)}
• Alíquota Efetiva: ${melhorOpcao.tributos.aliquotaEfetivaTotal.toFixed(2)}%
• Estimativa de Economia Anual: *${formatarMoeda(economiaAnualMaxima)}* (~${formatarMoeda(economiaMensalMedia)}/mês)
• Crédito Tributário Gerado para Clientes B2B: ${formatarMoeda(melhorOpcao.tributos.creditoGeradoClientesB2B)}

📋 *COMPARATIVO GERAL:*
${cenarios
  .filter((c) => c.elegivel)
  .map(
    (c) =>
      `- ${c.titulo}: ${formatarMoeda(c.tributos.totalTributosAnual)} (${c.tributos.aliquotaEfetivaTotal.toFixed(2)}%) ${c.isMelhorOpcao ? '⭐ [Mais Econômico]' : ''}`
  )
  .join('\n')}

📌 *Parecer Consultivo:*
${resumoParecer.replace(/\*\*/g, '')}

Elaborado por:
*${currentUser.escritorioNome || 'ContabGest Contabilidade'}*
Responsável: ${currentUser.nome} (${currentUser.cargo})`;

    navigator.clipboard.writeText(textoWhatsApp);
    setCopiado(true);
    setTimeout(() => setCopiado(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Top Actions */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between no-print">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white">
              <FileCheck className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-800">
                Parecer de Planejamento Tributário & Diagnóstico
              </h2>
              <p className="text-xs text-slate-500">
                Relatório executivo para tomada de decisão e apresentação ao cliente
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopiarWhatsApp}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 transition-colors shadow-xs"
            >
              {copiado ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiado ? 'Copiado p/ WhatsApp!' : 'Copiar p/ WhatsApp'}</span>
            </button>

            <button
              onClick={handleImprimir}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 text-white hover:bg-slate-900 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Imprimir / PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div ref={printRef} className="p-8 overflow-y-auto space-y-6 text-slate-800 print:p-0">
          {/* Header do Escritório */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-6 border-b-2 border-slate-900 gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-700 flex items-center justify-center text-white font-bold text-xl shadow-sm">
                <Building2 className="w-7 h-7" />
              </div>
              <div>
                <h1 className="text-xl font-black text-slate-900 tracking-tight">
                  {currentUser.escritorioNome || 'ContabGest Consultoria Tributária'}
                </h1>
                <p className="text-xs text-slate-600 font-medium">
                  Assessoria Contábil, Fiscal & Planejamento Tributário Estratégico
                </p>
                <p className="text-[11px] text-slate-500">
                  Responsável: {currentUser.nome} • {currentUser.cargo} • CRC Ativo
                </p>
              </div>
            </div>

            <div className="text-right sm:border-l sm:border-slate-200 sm:pl-6 text-xs text-slate-500">
              <p className="font-semibold text-slate-700">Relatório de Enquadramento Tributário</p>
              <p>Emissão: {dataAtual}</p>
              <p>Exercício Base: <strong className="text-slate-800">{parametros.anoAnalise}</strong></p>
            </div>
          </div>

          {/* Dados do Cliente e Premissas */}
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 text-xs grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <span className="text-slate-500 block">Empresa / Cliente:</span>
              <strong className="text-slate-800 text-sm block truncate">
                {parametros.nomeEmpresa || 'Não informado'}
              </strong>
            </div>
            <div>
              <span className="text-slate-500 block">CNPJ:</span>
              <strong className="text-slate-800 font-mono">
                {parametros.cnpj || 'Sob consulta'}
              </strong>
            </div>
            <div>
              <span className="text-slate-500 block">Atividade Econômica:</span>
              <strong className="text-slate-800 capitalize">
                {parametros.atividade.replace('_', ' ')}
              </strong>
            </div>
            <div>
              <span className="text-slate-500 block">Receita Bruta Anual:</span>
              <strong className="text-emerald-700 font-semibold text-sm">
                {formatarMoeda(parametros.faturamentoAnual)}
              </strong>
            </div>
          </div>

          {/* Card Destaque: Recomendação Técnica */}
          <div className="bg-emerald-50/80 border-2 border-emerald-500 rounded-2xl p-5 text-emerald-950">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-600 text-white">
                  <Award className="w-3.5 h-3.5" />
                  Regime Mais Vantajoso Recomendado
                </span>
                <h3 className="text-xl font-extrabold text-emerald-900">
                  {melhorOpcao.titulo}
                </h3>
                <p className="text-xs text-emerald-800">
                  {melhorOpcao.subtitulo} • {melhorOpcao.descricao}
                </p>
              </div>

              <div className="bg-white p-3.5 rounded-xl border border-emerald-300 text-right min-w-[200px] shadow-xs">
                <span className="text-[11px] text-slate-500 block font-semibold">
                  Economia Projetada
                </span>
                <span className="text-xl font-black text-emerald-600 block">
                  {formatarMoeda(economiaAnualMaxima)}
                </span>
                <span className="text-[10px] text-slate-500 font-medium">
                  equivale a ~{formatarMoeda(economiaMensalMedia)} / mês
                </span>
              </div>
            </div>
          </div>

          {/* Parecer Técnico Escrito */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Parecer Técnico & Diagnóstico do Especialista
            </h4>
            <div className="p-4 bg-slate-50/80 rounded-xl border border-slate-200 text-xs sm:text-sm leading-relaxed text-slate-700 whitespace-pre-line">
              {resumoParecer}
            </div>
          </div>

          {/* Tabela Comparativa Analítica */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Quadro Comparativo Lado a Lado dos Regimes
            </h4>
            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <th className="py-3 px-3">Cenário Tributário</th>
                    <th className="py-3 px-3 text-right">Tributos Federais</th>
                    <th className="py-3 px-3 text-right">ICMS / ISS / IBS</th>
                    <th className="py-3 px-3 text-right">Encargos Folha</th>
                    <th className="py-3 px-3 text-right">Total Anual (R$)</th>
                    <th className="py-3 px-3 text-right">Alíq. Efetiva</th>
                    <th className="py-3 px-3 text-right">Crédito B2B</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {cenarios.map((c) => {
                    const tributosFederais =
                      c.tributos.irpj + c.tributos.csll + c.tributos.pisCofinsOuCbs;
                    const encargosFolha =
                      c.tributos.inssPatronalFolha + c.tributos.inssProLabore;

                    return (
                      <tr
                        key={c.id}
                        className={`${
                          c.isMelhorOpcao
                            ? 'bg-emerald-50/70 font-semibold text-emerald-950'
                            : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <td className="py-2.5 px-3">
                          <div className="flex items-center gap-1.5">
                            {c.isMelhorOpcao && (
                              <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
                            )}
                            <span className={c.isMelhorOpcao ? 'text-emerald-900 font-bold' : ''}>
                              {c.titulo}
                            </span>
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono">
                          {formatarMoeda(tributosFederais)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono">
                          {formatarMoeda(c.tributos.icmsIssOuIbs)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono">
                          {formatarMoeda(encargosFolha)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold">
                          {formatarMoeda(c.tributos.totalTributosAnual)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold">
                          {c.tributos.aliquotaEfetivaTotal.toFixed(2)}%
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-emerald-700 font-medium">
                          {formatarMoeda(c.tributos.creditoGeradoClientesB2B)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Análise de Fator R e Impacto B2B */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
              <span className="font-bold text-slate-800 block mb-1">
                Fator R (Folha de Salários / Receita):
              </span>
              <div className="flex items-center justify-between">
                <span>Relação apurada no exercício:</span>
                <strong className={`font-bold ${fatorREnquadrado ? 'text-emerald-700' : 'text-amber-700'}`}>
                  {(fatorRCalculado * 100).toFixed(1)}% {fatorREnquadrado ? '(Anexo III - Beneficiado)' : '(Anexo V)'}
                </strong>
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Quando a folha de salários e pró-labore supera 28%, atividades regulamentadas pagam alíquotas reduzidas a partir de 6%.
              </p>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
              <span className="font-bold text-slate-800 block mb-1">
                Impacto Comercial & Transição da Reforma:
              </span>
              <p className="text-[11px] text-slate-600">
                A empresa possui <strong>{parametros.percentualVendasB2B}%</strong> de suas vendas destinadas a pessoas jurídicas. A capacidade de transferir créditos integrais de CBS/IBS impacta diretamente a competitividade com clientes corporativos.
              </p>
            </div>
          </div>

          {/* Assinatura do Responsável Técnico */}
          <div className="pt-8 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-6 text-xs text-slate-500">
            <div>
              <p className="font-bold text-slate-800">
                {currentUser.escritorioNome || 'ContabGest Contabilidade'}
              </p>
              <p>Departamento de Consultoria Tributária & Planejamento Fiscal</p>
            </div>

            <div className="text-center sm:text-right border-t sm:border-t-0 pt-3 sm:pt-0">
              <div className="w-48 h-0.5 bg-slate-400 mx-auto sm:ml-auto mb-1"></div>
              <p className="font-semibold text-slate-800">{currentUser.nome}</p>
              <p className="text-[11px] text-slate-500">{currentUser.cargo} • CRC/SP</p>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between no-print">
          <span className="text-xs text-slate-500">
            Documento gerado eletronicamente pelo módulo de Planejamento Tributário ContabGest.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-200 text-slate-800 hover:bg-slate-300 transition-colors"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
