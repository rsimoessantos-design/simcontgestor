import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from 'recharts';
import { ResultadoCenarioSimulacao } from '../../types';

interface GraficoComparativoTributarioProps {
  cenarios: ResultadoCenarioSimulacao[];
}

export const GraficoComparativoTributario: React.FC<GraficoComparativoTributarioProps> = ({
  cenarios,
}) => {
  const dadosGrafico = cenarios
    .filter((c) => c.elegivel)
    .map((c) => {
      let nomeCurto = 'Simples Trad.';
      if (c.id === 'simples_hibrido') nomeCurto = 'Simples Híbrido';
      if (c.id === 'lucro_presumido') nomeCurto = 'Lucro Presumido';
      if (c.id === 'lucro_real') nomeCurto = 'Lucro Real';

      const tributosFederais =
        c.tributos.irpj + c.tributos.csll + c.tributos.pisCofinsOuCbs;
      const tributosLocais = c.tributos.icmsIssOuIbs;
      const encargosFolha =
        c.tributos.inssPatronalFolha + c.tributos.inssProLabore;

      return {
        name: nomeCurto,
        fullName: c.titulo,
        'Tributos Federais': Math.round(tributosFederais),
        'Tributos Estaduais/Municipais': Math.round(tributosLocais),
        'Encargos Folha & Pró-Labore': Math.round(encargosFolha),
        'Total Anual': Math.round(c.tributos.totalTributosAnual),
        'Crédito B2B Gerado': Math.round(c.tributos.creditoGeradoClientesB2B),
        isMelhor: c.isMelhorOpcao,
      };
    });

  const formatarReal = (valor: number) =>
    valor.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
      maximumFractionDigits: 0,
    });

  return (
    <div className="w-full bg-white rounded-xl p-5 border border-slate-200">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <div>
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
            <span>Composição da Carga Tributária por Regime (Anual)</span>
          </h3>
          <p className="text-xs text-slate-500">
            Comparativo discriminando tributos federais, impostos sobre consumo e encargos sobre folha
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            Menor Custo Identificado
          </span>
        </div>
      </div>

      <div className="h-72 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={dadosGrafico}
            margin={{ top: 15, right: 15, left: 10, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
            <XAxis
              dataKey="name"
              tick={{ fill: '#475569', fontSize: 12, fontWeight: 600 }}
              axisLine={{ stroke: '#CBD5E1' }}
              tickLine={false}
            />
            <YAxis
              tickFormatter={(val) => `R$ ${(val / 1000).toFixed(0)}k`}
              tick={{ fill: '#64748B', fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              width={65}
            />
            <Tooltip
              formatter={(value: any, name: any) => [formatarReal(Number(value)), name]}
              contentStyle={{
                backgroundColor: '#0F172A',
                borderColor: '#1E293B',
                borderRadius: '8px',
                color: '#F8FAFC',
                fontSize: '12px',
                boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.2)',
              }}
              labelStyle={{ fontWeight: 'bold', color: '#38BDF8', marginBottom: '4px' }}
            />
            <Legend
              wrapperStyle={{ paddingTop: '10px', fontSize: '11px' }}
              iconType="circle"
            />
            <Bar
              dataKey="Tributos Federais"
              stackId="a"
              fill="#3B82F6"
              radius={[0, 0, 0, 0]}
            />
            <Bar
              dataKey="Tributos Estaduais/Municipais"
              stackId="a"
              fill="#8B5CF6"
              radius={[0, 0, 0, 0]}
            />
            <Bar
              dataKey="Encargos Folha & Pró-Labore"
              stackId="a"
              fill="#F59E0B"
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
