import React, { useState, useMemo } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  BarChart,
  AreaChart,
  Bar,
  Line,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine,
} from 'recharts';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Activity,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  Calendar,
  Layers,
  CheckCircle2,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Info,
  HelpCircle,
  FileSpreadsheet,
  Target,
  ShieldCheck,
} from 'lucide-react';
import { DreData, BemPatrimonial, Empresa } from '../types';
import {
  gerarEvolucaoEbitdaFluxoCaixa12Meses,
  MesEvolucaoFinanceira,
} from '../utils/ebitdaFluxoCaixa12Meses';

interface GraficoEvolucaoEbitdaFluxoCaixaProps {
  dre: DreData;
  bens: BemPatrimonial[];
  empresaId: string;
  empresaSelecionada?: Empresa;
  onNavigateToDre?: () => void;
  onNavigateToDfc?: () => void;
}

type TipoVisualizacao = 'combinado' | 'barras' | 'area';
type FiltroPeriodo = '12M' | '6M' | 'trimestres';

export const GraficoEvolucaoEbitdaFluxoCaixa: React.FC<GraficoEvolucaoEbitdaFluxoCaixaProps> = ({
  dre,
  bens,
  empresaId,
  empresaSelecionada,
  onNavigateToDre,
  onNavigateToDfc,
}) => {
  const [tipoVisualizacao, setTipoVisualizacao] = useState<TipoVisualizacao>('combinado');
  const [filtroPeriodo, setFiltroPeriodo] = useState<FiltroPeriodo>('12M');
  const [exibirSaldoAcumulado, setExibirSaldoAcumulado] = useState<boolean>(true);
  const [mostrarTabelaDetalhada, setMostrarTabelaDetalhada] = useState<boolean>(false);
  const [mesHover, setMesHover] = useState<MesEvolucaoFinanceira | null>(null);

  // Gera a base analítica de 12 meses integrada
  const { dadosMensais, resumo } = useMemo(() => {
    return gerarEvolucaoEbitdaFluxoCaixa12Meses(dre, bens, empresaId);
  }, [dre, bens, empresaId]);

  // Aplica filtro de período
  const dadosFiltrados = useMemo(() => {
    if (filtroPeriodo === '6M') {
      return dadosMensais.slice(6); // últimos 6 meses (Abr a Set/26)
    }
    if (filtroPeriodo === 'trimestres') {
      // Agrupa em 4 trimestres: Q4/25, Q1/26, Q2/26, Q3/26
      const trimestres = [
        { rotulo: 'Q4/2025', itens: dadosMensais.slice(0, 3) },
        { rotulo: 'Q1/2026', itens: dadosMensais.slice(3, 6) },
        { rotulo: 'Q2/2026', itens: dadosMensais.slice(6, 9) },
        { rotulo: 'Q3/2026', itens: dadosMensais.slice(9, 12) },
      ];
      return trimestres.map((t, idx) => {
        const ebitda = t.itens.reduce((acc, m) => acc + m.ebitda, 0);
        const rec = t.itens.reduce((acc, m) => acc + m.receitaLiquida, 0);
        const fluxoLiquido = t.itens.reduce((acc, m) => acc + m.fluxoCaixaLiquido, 0);
        const fluxoOp = t.itens.reduce((acc, m) => acc + m.fluxoCaixaOperacional, 0);
        const ultimoItem = t.itens[t.itens.length - 1];
        return {
          id: `trimestre-${idx}`,
          mesAno: t.rotulo,
          mesAnoCompleto: `Trimestre ${t.rotulo}`,
          ano: 2026,
          mes: idx + 1,
          receitaLiquida: rec,
          ebitda,
          margemEbitda: Number(((ebitda / rec) * 100).toFixed(1)),
          depreciacao: t.itens.reduce((acc, m) => acc + m.depreciacao, 0),
          lucroLiquido: t.itens.reduce((acc, m) => acc + m.lucroLiquido, 0),
          fluxoCaixaOperacional: fluxoOp,
          fluxoCaixaLiquido: fluxoLiquido,
          saldoCaixaFinal: ultimoItem.saldoCaixaFinal,
          conversaoCaixaEbitda: Number(((fluxoOp / (ebitda || 1)) * 100).toFixed(1)),
          tendencia: (idx === 3 || idx === 1 ? 'alta' : 'estavel') as 'alta' | 'estavel' | 'queda',
          destaque: `Total consolidado do trimestre ${t.rotulo}`,
        };
      });
    }
    return dadosMensais;
  }, [dadosMensais, filtroPeriodo]);

  const fmtMoeda = (val: number) =>
    new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(
      val || 0
    );

  const fmtMoedaCompacta = (val: number) => {
    const absVal = Math.abs(val);
    if (absVal >= 1000000) {
      return `R$ ${(val / 1000000).toFixed(1)}M`;
    }
    if (absVal >= 1000) {
      return `R$ ${(val / 1000).toFixed(0)}k`;
    }
    return `R$ ${val}`;
  };

  const fmtPct = (val: number) => `${(val || 0).toFixed(1)}%`;

  // Custom Tooltip do Recharts
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const dataItem: MesEvolucaoFinanceira = payload[0]?.payload;
      if (!dataItem) return null;

      return (
        <div className="bg-slate-900/95 backdrop-blur-sm text-white p-4 rounded-xl border border-slate-700 shadow-xl text-xs max-w-xs space-y-2.5 z-50">
          <div className="border-b border-slate-700 pb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-300 block">
              {dataItem.mesAnoCompleto || label}
            </span>
            <p className="text-[11px] text-slate-300 italic mt-0.5">{dataItem.destaque}</p>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <span className="flex items-center gap-1.5 text-indigo-300 font-medium">
                <span className="w-2.5 h-2.5 rounded-xs bg-indigo-500 inline-block" />
                EBITDA (LAIDA):
              </span>
              <span className="font-bold text-white font-mono">{fmtMoeda(dataItem.ebitda)}</span>
            </div>
            <div className="flex justify-between items-center text-[11px] text-slate-400 pl-4">
              <span>Margem EBITDA:</span>
              <span className="font-semibold text-indigo-200">{fmtPct(dataItem.margemEbitda)}</span>
            </div>

            <div className="flex justify-between items-center pt-1 border-t border-slate-800">
              <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" />
                Fluxo Líquido Caixa:
              </span>
              <span
                className={`font-bold font-mono ${
                  dataItem.fluxoCaixaLiquido >= 0 ? 'text-emerald-300' : 'text-rose-400'
                }`}
              >
                {dataItem.fluxoCaixaLiquido >= 0 ? '+' : ''}
                {fmtMoeda(dataItem.fluxoCaixaLiquido)}
              </span>
            </div>
            <div className="flex justify-between items-center text-[11px] text-slate-400 pl-4">
              <span>Fluxo Operacional:</span>
              <span className="font-medium text-slate-200">{fmtMoeda(dataItem.fluxoCaixaOperacional)}</span>
            </div>

            {exibirSaldoAcumulado && (
              <div className="flex justify-between items-center pt-1 border-t border-slate-800">
                <span className="flex items-center gap-1.5 text-sky-300 font-medium">
                  <span className="w-2.5 h-2.5 rounded-xs bg-sky-400 inline-block" />
                  Saldo Disponível:
                </span>
                <span className="font-bold text-sky-200 font-mono">
                  {fmtMoeda(dataItem.saldoCaixaFinal)}
                </span>
              </div>
            )}

            <div className="flex justify-between items-center pt-1.5 border-t border-slate-700/80">
              <span className="text-amber-300 font-medium">Conversão Caixa / EBITDA:</span>
              <span className="font-bold text-amber-300">{fmtPct(dataItem.conversaoCaixaEbitda)}</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div
      id="componente-evolucao-ebitda-fluxo-caixa"
      className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-6 p-6"
    >
      {/* 1. CABEÇALHO DO COMPONENTE COM AÇÕES */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-gradient-to-tr from-indigo-600 to-violet-600 text-white rounded-xl shadow-xs">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                  Evolução do EBITDA & Fluxo de Caixa
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold">
                  Últimos 12 Meses
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
                  {empresaSelecionada?.nomeFantasia || 'Empresa Ativa'}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Visão integrada entre o resultado operacional contábil (EBITDA / LAIDA) e a liquidez real gerada em caixa (DFC).
              </p>
            </div>
          </div>
        </div>

        {/* CONTROLES DE VISUALIZAÇÃO E FILTROS */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Seletor de Período */}
          <div className="inline-flex rounded-xl bg-slate-100 p-1 border border-slate-200">
            <button
              id="filtro-periodo-12m"
              onClick={() => setFiltroPeriodo('12M')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                filtroPeriodo === '12M'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              12 Meses
            </button>
            <button
              id="filtro-periodo-6m"
              onClick={() => setFiltroPeriodo('6M')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                filtroPeriodo === '6M'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Últimos 6M
            </button>
            <button
              id="filtro-periodo-trimestres"
              onClick={() => setFiltroPeriodo('trimestres')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                filtroPeriodo === 'trimestres'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Trimestres
            </button>
          </div>

          {/* Seletor de Tipo de Gráfico */}
          <div className="inline-flex rounded-xl bg-slate-100 p-1 border border-slate-200">
            <button
              id="tipo-grafico-combinado"
              onClick={() => setTipoVisualizacao('combinado')}
              title="Gráfico Combinado (Barras EBITDA + Linha Caixa)"
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                tipoVisualizacao === 'combinado'
                  ? 'bg-white text-indigo-700 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Combinado
            </button>
            <button
              id="tipo-grafico-barras"
              onClick={() => setTipoVisualizacao('barras')}
              title="Barras Comparativas Lado a Lado"
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                tipoVisualizacao === 'barras'
                  ? 'bg-white text-indigo-700 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Barras
            </button>
            <button
              id="tipo-grafico-area"
              onClick={() => setTipoVisualizacao('area')}
              title="Visão em Área e Volume"
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                tipoVisualizacao === 'area'
                  ? 'bg-white text-indigo-700 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Área
            </button>
          </div>

          {/* Toggle Linha de Saldo */}
          <button
            id="toggle-saldo-acumulado"
            onClick={() => setExibirSaldoAcumulado(!exibirSaldoAcumulado)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium border transition-colors cursor-pointer ${
              exibirSaldoAcumulado
                ? 'bg-sky-50 text-sky-800 border-sky-300'
                : 'bg-white text-slate-500 border-slate-300 hover:bg-slate-50'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                exibirSaldoAcumulado ? 'bg-sky-500' : 'bg-slate-300'
              }`}
            />
            Linha de Saldo Disponível
          </button>
        </div>
      </div>

      {/* 2. CARDS DE INDICADORES EXECUTIVOS (LTM) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* CARD 1: EBITDA TOTAL LTM */}
        <div className="bg-slate-50/80 p-4 rounded-xl border border-slate-200 hover:border-indigo-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              EBITDA Acumulado (12M)
            </span>
            <div className="p-1.5 bg-indigo-100 text-indigo-700 rounded-lg">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono mt-2">
            {fmtMoeda(resumo.ebitdaTotal)}
          </div>
          <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-200/60 text-xs">
            <span className="text-slate-500">
              Média: <strong className="text-slate-700">{fmtMoeda(resumo.ebitdaMedioMensal)}/mês</strong>
            </span>
            <span className="font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
              Margem: {fmtPct(resumo.margemEbitdaMedia)}
            </span>
          </div>
        </div>

        {/* CARD 2: FLUXO DE CAIXA LÍQUIDO LTM */}
        <div className="bg-slate-50/80 p-4 rounded-xl border border-slate-200 hover:border-emerald-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Geração Líquida de Caixa
            </span>
            <div className="p-1.5 bg-emerald-100 text-emerald-700 rounded-lg">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-700 font-mono mt-2">
            +{fmtMoeda(resumo.fluxoCaixaLiquidoTotal)}
          </div>
          <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-200/60 text-xs">
            <span className="text-slate-500">
              Operacional: <strong className="text-slate-700">{fmtMoeda(resumo.fluxoCaixaOperacionalTotal)}</strong>
            </span>
            <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
              Saldo: {fmtMoeda(resumo.saldoCaixaAtual)}
            </span>
          </div>
        </div>

        {/* CARD 3: CONVERSÃO DE EBITDA EM CAIXA */}
        <div className="bg-slate-50/80 p-4 rounded-xl border border-slate-200 hover:border-amber-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Conversão Caixa / EBITDA
            </span>
            <div className="p-1.5 bg-amber-100 text-amber-700 rounded-lg">
              <Target className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-800 font-mono mt-2">
            {fmtPct(resumo.conversaoCaixaEbitdaMedia)}
          </div>
          <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-200/60 text-xs">
            <span className="text-slate-500">Qualidade dos Lucros:</span>
            <span className="inline-flex items-center gap-1 font-bold text-emerald-700">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Alta Eficiência (&gt;80%)
            </span>
          </div>
        </div>

        {/* CARD 4: DIAGNÓSTICO DE TENDÊNCIA */}
        <div className="bg-slate-50/80 p-4 rounded-xl border border-slate-200 hover:border-indigo-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Tendência Financeira
            </span>
            <div className="p-1.5 bg-indigo-100 text-indigo-700 rounded-lg">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-center gap-2 mt-2">
            <span className="text-lg font-black text-slate-900">
              {resumo.tendenciaGeral === 'crescimento_forte'
                ? 'Expansão Acelerada'
                : 'Crescimento Firme'}
            </span>
            <span className="inline-flex items-center text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
              <ArrowUpRight className="w-3.5 h-3.5" />
              +{resumo.crescimentoEbitdaMoM}% MoM
            </span>
          </div>
          <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-200/60 text-xs">
            <span className="text-slate-500">
              Melhor Mês: <strong className="text-slate-700">{resumo.melhorMesEbitda.mesAno}</strong>
            </span>
            <span className="text-indigo-600 font-medium">Solvência Confortável</span>
          </div>
        </div>
      </div>

      {/* 3. GRÁFICO RECHARTS INTERATIVO */}
      <div className="bg-slate-50/50 p-5 rounded-2xl border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
          <div className="flex items-center gap-3">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-600" />
              Evolução Temporal: EBITDA vs Fluxo de Caixa Líquido
            </h3>
            <span className="text-xs text-slate-400">
              (Valores em Reais - R$)
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold">
            <span className="flex items-center gap-1.5 text-indigo-700">
              <span className="w-3 h-3 rounded-xs bg-indigo-600 inline-block" />
              EBITDA (Operacional)
            </span>
            <span className="flex items-center gap-1.5 text-emerald-700">
              <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block" />
              Fluxo de Caixa Líquido
            </span>
            {exibirSaldoAcumulado && (
              <span className="flex items-center gap-1.5 text-sky-700">
                <span className="w-3 h-0.5 bg-sky-500 inline-block" />
                Saldo Disponível
              </span>
            )}
          </div>
        </div>

        {/* CONTAINER RECHARTS */}
        <div className="h-80 w-full" id="container-recharts-ebitda-fluxo">
          <ResponsiveContainer width="100%" height="100%">
            {tipoVisualizacao === 'combinado' ? (
              <ComposedChart
                data={dadosFiltrados}
                margin={{ top: 15, right: 25, left: 10, bottom: 5 }}
              >
                <defs>
                  <linearGradient id="corEbitdaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#4f46e5" stopOpacity={0.9} />
                    <stop offset="100%" stopColor="#6366f1" stopOpacity={0.65} />
                  </linearGradient>
                  <linearGradient id="corCaixaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.9} />
                    <stop offset="100%" stopColor="#059669" stopOpacity={0.7} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis
                  dataKey="mesAno"
                  tick={{ fontSize: 12, fill: '#475569', fontWeight: 600 }}
                  axisLine={{ stroke: '#cbd5e1' }}
                  tickLine={{ stroke: '#cbd5e1' }}
                />
                <YAxis
                  yAxisId="valores"
                  tickFormatter={fmtMoedaCompacta}
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  axisLine={{ stroke: '#cbd5e1' }}
                  tickLine={false}
                />
                {exibirSaldoAcumulado && (
                  <YAxis
                    yAxisId="saldo"
                    orientation="right"
                    tickFormatter={fmtMoedaCompacta}
                    tick={{ fontSize: 11, fill: '#0284c7' }}
                    axisLine={{ stroke: '#bae6fd' }}
                    tickLine={false}
                  />
                )}
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine
                  yAxisId="valores"
                  y={0}
                  stroke="#94a3b8"
                  strokeWidth={1.5}
                  strokeDasharray="4 4"
                  label={{
                    value: 'Ponto Zero (Equilíbrio)',
                    position: 'insideTopLeft',
                    fill: '#94a3b8',
                    fontSize: 10,
                  }}
                />
                <Bar
                  yAxisId="valores"
                  dataKey="ebitda"
                  name="EBITDA"
                  fill="url(#corEbitdaGrad)"
                  radius={[5, 5, 0, 0]}
                  barSize={30}
                />
                <Line
                  yAxisId="valores"
                  type="monotone"
                  dataKey="fluxoCaixaLiquido"
                  name="Fluxo de Caixa Líquido"
                  stroke="#10b981"
                  strokeWidth={3}
                  dot={{ r: 4, fill: '#10b981', stroke: '#ffffff', strokeWidth: 2 }}
                  activeDot={{ r: 6, fill: '#059669', stroke: '#ffffff', strokeWidth: 2 }}
                />
                {exibirSaldoAcumulado && (
                  <Line
                    yAxisId="saldo"
                    type="monotone"
                    dataKey="saldoCaixaFinal"
                    name="Saldo Acumulado"
                    stroke="#0284c7"
                    strokeWidth={2}
                    strokeDasharray="4 4"
                    dot={{ r: 3, fill: '#0284c7' }}
                  />
                )}
              </ComposedChart>
            ) : tipoVisualizacao === 'barras' ? (
              <BarChart
                data={dadosFiltrados}
                margin={{ top: 15, right: 25, left: 10, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis
                  dataKey="mesAno"
                  tick={{ fontSize: 12, fill: '#475569', fontWeight: 600 }}
                />
                <YAxis tickFormatter={fmtMoedaCompacta} tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine y={0} stroke="#94a3b8" strokeDasharray="3 3" />
                <Legend />
                <Bar
                  dataKey="ebitda"
                  name="EBITDA (LAIDA)"
                  fill="#4f46e5"
                  radius={[4, 4, 0, 0]}
                  barSize={20}
                />
                <Bar
                  dataKey="fluxoCaixaLiquido"
                  name="Fluxo de Caixa Líquido"
                  fill="#10b981"
                  radius={[4, 4, 0, 0]}
                  barSize={20}
                />
              </BarChart>
            ) : (
              <AreaChart
                data={dadosFiltrados}
                margin={{ top: 15, right: 25, left: 10, bottom: 5 }}
              >
                <defs>
                  <linearGradient id="areaEbitda" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.6} />
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0.05} />
                  </linearGradient>
                  <linearGradient id="areaCaixa" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.6} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis
                  dataKey="mesAno"
                  tick={{ fontSize: 12, fill: '#475569', fontWeight: 600 }}
                />
                <YAxis tickFormatter={fmtMoedaCompacta} tick={{ fontSize: 11, fill: '#64748b' }} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="ebitda"
                  name="EBITDA"
                  stroke="#4f46e5"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#areaEbitda)"
                />
                <Area
                  type="monotone"
                  dataKey="fluxoCaixaLiquido"
                  name="Fluxo de Caixa Líquido"
                  stroke="#10b981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#areaCaixa)"
                />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>

        {/* NOTA DE RODAPÉ DO GRÁFICO */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between text-[11px] text-slate-500 pt-3 border-t border-slate-200 mt-2 gap-2">
          <div className="flex items-center gap-1.5">
            <Info className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
            <span>
              O <strong>EBITDA</strong> mede a eficiência operacional bruta, enquanto o{' '}
              <strong>Fluxo de Caixa Líquido</strong> reflete as entradas e saídas reais de dinheiro após capital de giro e investimentos.
            </span>
          </div>
          <div className="flex items-center gap-2 font-medium">
            <span className="text-slate-600">Período de Análise:</span>
            <span className="text-slate-900 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
              Out/2025 até Set/2026
            </span>
          </div>
        </div>
      </div>

      {/* 4. PAINEL DE INSIGHTS E TENDÊNCIAS FINANCEIRAS PARA O GESTOR */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* INSIGHT 1: RESILIÊNCIA E CONVERSÃO DE CAIXA */}
        <div className="bg-gradient-to-br from-indigo-50/60 to-white p-4 rounded-xl border border-indigo-100 space-y-2">
          <div className="flex items-center gap-2 text-indigo-900 font-bold text-xs">
            <ShieldCheck className="w-4 h-4 text-indigo-600" />
            <span>Excelente Conversão Operacional</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            A empresa converteu <strong>{fmtPct(resumo.conversaoCaixaEbitdaMedia)}</strong> de cada real de EBITDA em fluxo de caixa operacional líquido. Essa relação superior a 80% indica baixíssima inadimplência de clientes e equilíbrio saudável do capital de giro.
          </p>
          <div className="text-[11px] font-semibold text-indigo-700 flex items-center gap-1 pt-1">
            <CheckCircle2 className="w-3.5 h-3.5" /> Lucro contábil alinhado à entrada real de caixa
          </div>
        </div>

        {/* INSIGHT 2: SAZONALIDADE E PONTOS DE ATENÇÃO */}
        <div className="bg-gradient-to-br from-amber-50/60 to-white p-4 rounded-xl border border-amber-100 space-y-2">
          <div className="flex items-center gap-2 text-amber-900 font-bold text-xs">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            <span>Sazonalidade e Pressão no Início do Ano</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            O menor fluxo de caixa ocorreu em <strong>{resumo.menorMesCaixa.mesAnoCompleto}</strong> ({fmtMoeda(resumo.menorMesCaixa.fluxoCaixaLiquido)}), período típico de recolhimento de tributos anuais (IPTU/IPVA) e renovação de contratos. O colchão de caixa acumulado absorveu a oscilação com segurança.
          </p>
          <div className="text-[11px] font-semibold text-amber-800 flex items-center gap-1 pt-1">
            <Info className="w-3.5 h-3.5" /> Provisão antecipada recomendada para nov/dez
          </div>
        </div>

        {/* INSIGHT 3: TENDÊNCIA DE EXPANSÃO RECENTE */}
        <div className="bg-gradient-to-br from-emerald-50/60 to-white p-4 rounded-xl border border-emerald-100 space-y-2">
          <div className="flex items-center gap-2 text-emerald-900 font-bold text-xs">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <span>Aceleração no Q3/2026</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            O trimestre recente registrou o maior EBITDA da série em <strong>{resumo.melhorMesEbitda.mesAnoCompleto}</strong> ({fmtMoeda(resumo.melhorMesEbitda.ebitda)}), impulsionado pelo ganho de escala e absorção de novos clientes após os investimentos patrimoniais em TI e energia fotovoltaica.
          </p>
          <div className="text-[11px] font-semibold text-emerald-800 flex items-center gap-1 pt-1">
            <ArrowUpRight className="w-3.5 h-3.5" /> Crescimento sustentável sem endividamento
          </div>
        </div>
      </div>

      {/* 5. TABELA ANALÍTICA MÊS A MÊS (EXPANSÍVEL) */}
      <div className="border border-slate-200 rounded-xl overflow-hidden">
        <button
          id="btn-toggle-tabela-detalhada"
          onClick={() => setMostrarTabelaDetalhada(!mostrarTabelaDetalhada)}
          className="w-full bg-slate-50 hover:bg-slate-100 p-3.5 flex items-center justify-between text-xs font-bold text-slate-700 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-indigo-600" />
            <span>Detalhamento Numérico Mês a Mês (EBITDA, Fluxos e Saldos)</span>
            <span className="text-[11px] font-normal text-slate-500">
              ({dadosFiltrados.length} períodos consolidados)
            </span>
          </div>
          <div className="flex items-center gap-1 text-indigo-600">
            <span>{mostrarTabelaDetalhada ? 'Recolher Tabela' : 'Visualizar Tabela Completa'}</span>
            {mostrarTabelaDetalhada ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </button>

        {mostrarTabelaDetalhada && (
          <div className="overflow-x-auto bg-white">
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-100/90 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Mês / Exercício</th>
                  <th className="px-3 py-3 text-right">Receita Líquida</th>
                  <th className="px-3 py-3 text-right text-indigo-700">EBITDA</th>
                  <th className="px-3 py-3 text-right">Margem %</th>
                  <th className="px-3 py-3 text-right">Fluxo Operacional</th>
                  <th className="px-3 py-3 text-right text-emerald-700">Fluxo Líquido Caixa</th>
                  <th className="px-3 py-3 text-right text-sky-700">Saldo Disponível</th>
                  <th className="px-3 py-3 text-right text-amber-700">Conversão %</th>
                  <th className="px-4 py-3 text-center">Tendência</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {dadosFiltrados.map((item) => (
                  <tr
                    key={item.id}
                    className="hover:bg-indigo-50/30 transition-colors font-sans"
                  >
                    <td className="px-4 py-2.5 font-bold text-slate-900 font-sans">
                      {item.mesAnoCompleto}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-slate-700">
                      {fmtMoeda(item.receitaLiquida)}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono font-bold text-indigo-700">
                      {fmtMoeda(item.ebitda)}
                    </td>
                    <td className="px-3 py-2.5 text-right font-sans font-semibold text-slate-700">
                      {fmtPct(item.margemEbitda)}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-slate-700">
                      {fmtMoeda(item.fluxoCaixaOperacional)}
                    </td>
                    <td
                      className={`px-3 py-2.5 text-right font-mono font-bold ${
                        item.fluxoCaixaLiquido >= 0 ? 'text-emerald-700' : 'text-rose-600'
                      }`}
                    >
                      {item.fluxoCaixaLiquido >= 0 ? '+' : ''}
                      {fmtMoeda(item.fluxoCaixaLiquido)}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-sky-800 font-medium">
                      {fmtMoeda(item.saldoCaixaFinal)}
                    </td>
                    <td className="px-3 py-2.5 text-right font-sans font-bold text-amber-700">
                      {fmtPct(item.conversaoCaixaEbitda)}
                    </td>
                    <td className="px-4 py-2.5 text-center font-sans">
                      {item.tendencia === 'alta' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          <TrendingUp className="w-3 h-3" /> Alta
                        </span>
                      ) : item.tendencia === 'queda' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                          <TrendingDown className="w-3 h-3" /> Atenção
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                          <Activity className="w-3 h-3" /> Estável
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-slate-50 font-bold border-t-2 border-slate-300 font-mono text-xs">
                <tr>
                  <td className="px-4 py-3 font-sans text-slate-900">Total Acumulado</td>
                  <td className="px-3 py-3 text-right text-slate-800">
                    {fmtMoeda(dadosFiltrados.reduce((a, b) => a + b.receitaLiquida, 0))}
                  </td>
                  <td className="px-3 py-3 text-right text-indigo-900">
                    {fmtMoeda(dadosFiltrados.reduce((a, b) => a + b.ebitda, 0))}
                  </td>
                  <td className="px-3 py-3 text-right font-sans text-slate-800">
                    {fmtPct(resumo.margemEbitdaMedia)}
                  </td>
                  <td className="px-3 py-3 text-right text-slate-800">
                    {fmtMoeda(dadosFiltrados.reduce((a, b) => a + b.fluxoCaixaOperacional, 0))}
                  </td>
                  <td className="px-3 py-3 text-right text-emerald-800">
                    +{fmtMoeda(dadosFiltrados.reduce((a, b) => a + b.fluxoCaixaLiquido, 0))}
                  </td>
                  <td className="px-3 py-3 text-right text-sky-900">
                    {fmtMoeda(resumo.saldoCaixaAtual)}
                  </td>
                  <td className="px-3 py-3 text-right font-sans text-amber-800">
                    {fmtPct(resumo.conversaoCaixaEbitdaMedia)}
                  </td>
                  <td className="px-4 py-3 text-center font-sans text-emerald-800 text-[11px]">
                    Superavitário
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>

      {/* 6. ATALHOS RÁPIDOS PARA O GESTOR */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <span className="text-xs text-slate-500">
          Precisa auditar a conciliação linha por linha?
        </span>
        <div className="flex items-center gap-2">
          {onNavigateToDre && (
            <button
              onClick={onNavigateToDre}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-lg hover:bg-indigo-100 transition-colors cursor-pointer"
            >
              <TrendingUp className="w-3.5 h-3.5" />
              Ver Demonstração Completa da DRE
            </button>
          )}
          {onNavigateToDfc && (
            <button
              onClick={onNavigateToDfc}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 transition-colors cursor-pointer"
            >
              <DollarSign className="w-3.5 h-3.5" />
              Ver Fluxo de Caixa Detalhado (DFC)
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
