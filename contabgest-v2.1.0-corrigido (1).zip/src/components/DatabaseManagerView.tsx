import React, { useState, useEffect, useRef } from 'react';
import {
  Database,
  Download,
  Upload,
  RotateCcw,
  Plus,
  Trash2,
  Edit,
  Search,
  CheckCircle2,
  AlertTriangle,
  FileCode,
  Layers,
  Save,
  X,
  RefreshCw,
  Eye,
  ShieldAlert,
  Server,
  HardDrive,
  Info,
} from 'lucide-react';
import { DatabaseTableKey, DatabaseStats, User } from '../types';
import { api } from '../services/api';

interface DatabaseManagerViewProps {
  currentUser: User;
  onDatabaseAltered?: () => void;
}

const TABLE_DEFINITIONS: Array<{
  key: DatabaseTableKey;
  label: string;
  description: string;
  defaultTemplate: any;
}> = [
  {
    key: 'empresas',
    label: 'Empresas',
    description: 'Empresas clientes e cadastros societários do escritório',
    defaultTemplate: {
      cnpj: '00.000.000/0001-00',
      razaoSocial: 'Nova Empresa Ltda',
      nomeFantasia: 'Nova Empresa',
      regimeTributario: 'Simples Nacional',
      status: 'ativa',
      telefone: '(11) 99999-9999',
      email: 'contato@novaempresa.com.br',
      cidade: 'São Paulo',
      uf: 'SP',
      faturamentoMensal: 85000,
      qtdeFuncionarios: 5,
      responsavelContabil: 'Carlos Eduardo Silveira',
      isDemo: false,
    },
  },
  {
    key: 'clientes',
    label: 'Clientes',
    description: 'Clientes finais e contratos vinculados às empresas',
    defaultTemplate: {
      empresaId: 'emp_1',
      nome: 'Novo Cliente Corporativo',
      tipo: 'PJ',
      cpfCnpj: '98.765.432/0001-10',
      email: 'financeiro@cliente.com.br',
      telefone: '(11) 3333-4444',
      status: 'ativo',
      isDemo: false,
    },
  },
  {
    key: 'socios',
    label: 'Sócios',
    description: 'Quadro Societário e Administradores (QSA)',
    defaultTemplate: {
      empresaId: 'emp_1',
      nome: 'Novo Sócio Diretor',
      cpf: '123.456.789-00',
      participacaoPercentual: 50,
      cargo: 'Sócio-Administrador',
      isAdministrador: true,
      email: 'socio@empresa.com.br',
      isDemo: false,
    },
  },
  {
    key: 'obrigacoes',
    label: 'Obrigações Fiscais',
    description: 'Declarações e tributos municipais, estaduais e federais',
    defaultTemplate: {
      empresaId: 'emp_1',
      titulo: 'Nova Obrigação Fiscal',
      tipo: 'Federal',
      dataVencimento: new Date().toISOString().split('T')[0],
      status: 'pendente',
      competencia: '09/2026',
      descricao: 'Entrega de declaração fiscal mensal',
      isDemo: false,
    },
  },
  {
    key: 'documentos',
    label: 'Documentos',
    description: 'Arquivos, extratos bancários, XMLs e relatórios contábeis',
    defaultTemplate: {
      empresaId: 'emp_1',
      nome: 'Extrato_Bancario_Novo.pdf',
      categoria: 'Contábil',
      tamanho: '1.2 MB',
      dataEnvio: new Date().toISOString().split('T')[0],
      status: 'aprovado',
      enviadoPor: 'Contador Administrador',
      extensao: 'PDF',
      isDemo: false,
    },
  },
  {
    key: 'certidoes',
    label: 'Certidões CNDs',
    description: 'Certidões Negativas de Débitos com Receita, Caixa e Tribunais',
    defaultTemplate: {
      empresaId: 'emp_1',
      orgao: 'Receita Federal e PGFN',
      tipo: 'Débitos Relativos a Créditos Tributários',
      codigo: 'CND-NOVA-2026',
      dataEmissao: new Date().toISOString().split('T')[0],
      dataValidade: '2026-12-31',
      status: 'valida',
      isDemo: false,
    },
  },
  {
    key: 'tarefas',
    label: 'Tarefas Operacionais',
    description: 'Demandas da equipe contábil, fiscal e folha de pagamento',
    defaultTemplate: {
      empresaId: 'emp_1',
      titulo: 'Conciliação Contábil Periódica',
      descricao: 'Verificar lançamentos contábeis e divergências de extratos',
      responsavel: 'Carlos Eduardo Silveira',
      prioridade: 'alta',
      status: 'a_fazer',
      dataVencimento: new Date().toISOString().split('T')[0],
      isDemo: false,
    },
  },
  {
    key: 'contasPagar',
    label: 'Contas a Pagar',
    description: 'Títulos provisionados e despesas das empresas',
    defaultTemplate: {
      empresaId: 'emp_1',
      descricao: 'Nova Despesa Administrativa',
      categoriaId: 'cat_2',
      beneficiario: 'Fornecedor de Serviços Ltda',
      valor: 1500.0,
      dataVencimento: new Date().toISOString().split('T')[0],
      status: 'pendente',
      isDemo: false,
    },
  },
  {
    key: 'contasReceber',
    label: 'Contas a Receber',
    description: 'Títulos a receber, faturas e honorários contábeis',
    defaultTemplate: {
      empresaId: 'emp_1',
      descricao: 'Honorários de Consultoria Contábil',
      categoriaId: 'cat_1',
      pagador: 'Cliente Contratante',
      valor: 3200.0,
      dataVencimento: new Date().toISOString().split('T')[0],
      status: 'pendente',
      isDemo: false,
    },
  },
  {
    key: 'categoriasFinanceiras',
    label: 'Categorias Financeiras',
    description: 'Plano de contas de despesas e receitas',
    defaultTemplate: {
      nome: 'Nova Categoria Financeira',
      tipo: 'despesa',
      cor: '#3b82f6',
      isDemo: false,
    },
  },
  {
    key: 'users',
    label: 'Usuários do Sistema',
    description: 'Contadores, analistas e permissões de acesso ao sistema',
    defaultTemplate: {
      nome: 'Novo Analista Contábil',
      email: 'novo.analista@contabgest.com.br',
      cargo: 'Assistente Contábil',
      role: 'analista_fiscal',
      escritorioNome: 'Silveira & Associados Contabilidade',
    },
  },
];

export const DatabaseManagerView: React.FC<DatabaseManagerViewProps> = ({
  currentUser,
  onDatabaseAltered,
}) => {
  const [activeTable, setActiveTable] = useState<DatabaseTableKey>('empresas');
  const [stats, setStats] = useState<DatabaseStats | null>(null);
  const [records, setRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [notification, setNotification] = useState<{
    type: 'success' | 'error' | 'info';
    message: string;
  } | null>(null);

  // Modal States
  const [showModal, setShowModal] = useState(false);
  const [editingRecord, setEditingRecord] = useState<any | null>(null);
  const [editorMode, setEditorMode] = useState<'form' | 'json'>('form');
  const [formData, setFormData] = useState<any>({});
  const [rawJsonText, setRawJsonText] = useState('');
  const [jsonError, setJsonError] = useState<string | null>(null);

  // Inspector Modal
  const [inspectRecord, setInspectRecord] = useState<any | null>(null);

  // Delete Confirmation
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Reset Confirmation
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  // File Upload Ref
  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentTableDef =
    TABLE_DEFINITIONS.find((t) => t.key === activeTable) || TABLE_DEFINITIONS[0];

  const showFeedback = (type: 'success' | 'error' | 'info', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 4000);
  };

  // Load Database Stats
  const loadStats = async () => {
    try {
      const data = await api.getDatabaseStats();
      setStats(data);
    } catch (err) {
      console.error('Erro ao carregar estatísticas do banco:', err);
    }
  };

  // Load Active Table Records
  const loadTableRecords = async (tableKey: DatabaseTableKey) => {
    setLoading(true);
    try {
      const data = await api.getDatabaseTable(tableKey);
      setRecords(data);
    } catch (err: any) {
      showFeedback('error', err.message || 'Falha ao carregar registros da tabela');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
    loadTableRecords(activeTable);
  }, [activeTable]);

  const handleTableChange = (key: DatabaseTableKey) => {
    setActiveTable(key);
    setSearchTerm('');
  };

  // Filtered records
  const filteredRecords = records.filter((r) => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    return Object.entries(r).some(([_, val]) =>
      String(val).toLowerCase().includes(term)
    );
  });

  // Open Create Modal
  const handleOpenCreate = () => {
    setEditingRecord(null);
    const initial = { ...currentTableDef.defaultTemplate };
    setFormData(initial);
    setRawJsonText(JSON.stringify(initial, null, 2));
    setJsonError(null);
    setEditorMode('form');
    setShowModal(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (record: any) => {
    setEditingRecord(record);
    setFormData({ ...record });
    setRawJsonText(JSON.stringify(record, null, 2));
    setJsonError(null);
    setEditorMode('form');
    setShowModal(true);
  };

  // Save Record (Create or Update)
  const handleSaveRecord = async () => {
    let payloadToSave = formData;

    if (editorMode === 'json') {
      try {
        payloadToSave = JSON.parse(rawJsonText);
      } catch (err: any) {
        setJsonError('JSON inválido: verifique chaves, vírgulas e aspas.');
        return;
      }
    }

    try {
      if (editingRecord) {
        await api.updateDatabaseRecord(activeTable, editingRecord.id, payloadToSave);
        showFeedback('success', `Registro "${editingRecord.id}" atualizado com sucesso no banco.`);
      } else {
        await api.createDatabaseRecord(activeTable, payloadToSave);
        showFeedback('success', `Novo registro inserido com sucesso na tabela "${currentTableDef.label}".`);
      }

      setShowModal(false);
      loadTableRecords(activeTable);
      loadStats();
      onDatabaseAltered?.();
    } catch (err: any) {
      showFeedback('error', err.message || 'Erro ao persistir registro.');
    }
  };

  // Delete Record
  const handleDeleteRecord = async (id: string) => {
    try {
      await api.deleteDatabaseRecord(activeTable, id);
      showFeedback('success', `Registro "${id}" excluído com sucesso do banco.`);
      setDeletingId(null);
      loadTableRecords(activeTable);
      loadStats();
      onDatabaseAltered?.();
    } catch (err: any) {
      showFeedback('error', err.message || 'Erro ao excluir registro.');
    }
  };

  // Download Backup JSON
  const handleDownloadDump = async () => {
    try {
      const dump = await api.getDatabaseDump();
      const blob = new Blob([JSON.stringify(dump, null, 2)], {
        type: 'application/json',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `contabgest_backup_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showFeedback('success', 'Backup exportado com sucesso.');
    } catch (err: any) {
      showFeedback('error', err.message || 'Erro ao gerar backup');
    }
  };

  // Upload Backup JSON
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        await api.restoreDatabase(parsed);
        showFeedback('success', 'Backup restaurado com sucesso! Dados sincronizados.');
        loadStats();
        loadTableRecords(activeTable);
        onDatabaseAltered?.();
      } catch (err: any) {
        showFeedback('error', 'Falha ao restaurar: Arquivo JSON de backup inválido.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Reset to Seed
  const handleResetToDemo = async () => {
    try {
      await api.resetDatabase();
      setShowResetConfirm(false);
      showFeedback('success', 'Banco de dados restaurado com sucesso.');
      loadStats();
      loadTableRecords(activeTable);
      onDatabaseAltered?.();
    } catch (err: any) {
      showFeedback('error', err.message || 'Erro ao restaurar banco');
    }
  };

  // Enable Production Mode and Clean Tags
  const handleEnableProductionMode = async () => {
    try {
      const res = await api.setProductionMode(true, true);
      showFeedback('success', res.message || 'Modo Produção v2.0.0 ativado com sucesso!');
      loadStats();
      loadTableRecords(activeTable);
      onDatabaseAltered?.();
    } catch (err: any) {
      showFeedback('error', err.message || 'Erro ao ativar Modo de Produção');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-slate-900 text-white p-6 rounded-2xl border border-slate-800 shadow-md">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl font-bold tracking-tight text-white">
                    Gerenciador do Banco de Dados Contábil
                  </h1>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                    Administrador
                  </span>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    PRODUÇÃO v2.0.0
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Painel de alta disponibilidade para inspecionar, criar, editar e manter registros com integridade referencial.
                </p>
              </div>
            </div>
          </div>

          {/* Quick Action Tools */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              id="btn-production-mode"
              onClick={handleEnableProductionMode}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
              title="Ativar Modo de Produção e higienizar tags DEMO dos registros"
            >
              <CheckCircle2 className="w-4 h-4 text-white" />
              <span>Modo Produção v2.0.0</span>
            </button>

            <button
              id="btn-export-db-dump"
              onClick={handleDownloadDump}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
              title="Baixar backup completo em JSON"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>Exportar Backup (JSON)</span>
            </button>

            <button
              id="btn-import-db-backup"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
              title="Importar arquivo JSON de backup"
            >
              <Upload className="w-4 h-4 text-blue-400" />
              <span>Importar Backup</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileChange}
              className="hidden"
            />

            <button
              id="btn-reset-db-demo"
              onClick={() => setShowResetConfirm(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
              title="Restaurar base de dados inicial"
            >
              <RotateCcw className="w-4 h-4 text-slate-400" />
              <span>Restaurar Base Padrão</span>
            </button>
          </div>
        </div>

        {/* System Stats Bar */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-800/50 p-2.5 rounded-lg border border-slate-700/50">
            <span className="text-[10px] uppercase text-slate-400 font-semibold block">
              Mecanismo de Armazenamento
            </span>
            <span className="font-medium text-slate-200 truncate block mt-0.5">
              JSON Repository (Multi-Tenant)
            </span>
          </div>

          <div className="bg-slate-800/50 p-2.5 rounded-lg border border-slate-700/50">
            <span className="text-[10px] uppercase text-slate-400 font-semibold block">
              Total de Registros
            </span>
            <span className="font-bold text-emerald-400 text-sm block mt-0.5">
              {stats ? `${stats.totalRecords} registros` : 'Carregando...'}
            </span>
          </div>

          <div className="bg-slate-800/50 p-2.5 rounded-lg border border-slate-700/50">
            <span className="text-[10px] uppercase text-slate-400 font-semibold block">
              Versão do Esquema
            </span>
            <span className="font-mono text-slate-200 block mt-0.5">
              v{stats?.version || '2.0.0'}
            </span>
          </div>

          <div className="bg-slate-800/50 p-2.5 rounded-lg border border-slate-700/50">
            <span className="text-[10px] uppercase text-slate-400 font-semibold block">
              Última Gravação
            </span>
            <span className="font-mono text-slate-300 truncate block mt-0.5 text-[11px]">
              {stats?.lastSaved
                ? new Date(stats.lastSaved).toLocaleTimeString('pt-BR')
                : 'Sincronizado'}
            </span>
          </div>
        </div>
      </div>

      {/* Notification Banner */}
      {notification && (
        <div
          className={`p-3.5 rounded-xl border text-xs font-semibold flex items-center justify-between transition-all ${
            notification.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
              : notification.type === 'error'
              ? 'bg-rose-50 text-rose-800 border-rose-200'
              : 'bg-blue-50 text-blue-800 border-blue-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {notification.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            ) : notification.type === 'error' ? (
              <AlertTriangle className="w-4 h-4 text-rose-600" />
            ) : (
              <Info className="w-4 h-4 text-blue-600" />
            )}
            <span>{notification.message}</span>
          </div>
          <button
            onClick={() => setNotification(null)}
            className="p-1 hover:bg-black/5 rounded"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Table Selector Pills */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
        <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 px-1">
          Selecione a Tabela do Banco de Dados para Gerenciar:
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {TABLE_DEFINITIONS.map((tab) => {
            const count = stats?.tableCounts?.[tab.key] ?? 0;
            const isActive = activeTable === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => handleTableChange(tab.key)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    isActive ? 'bg-emerald-500 text-slate-900' : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Table Actions & Records Area */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Table Action Bar */}
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-50/50">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-slate-900">
                Tabela: <span className="text-emerald-700 font-mono">[{activeTable}]</span> - {currentTableDef.label}
              </h2>
              <span className="text-[11px] text-slate-500">
                ({filteredRecords.length} de {records.length} registros)
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">{currentTableDef.description}</p>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative flex-1 sm:w-64">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder={`Filtrar em ${currentTableDef.label}...`}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
              />
            </div>

            <button
              onClick={() => loadTableRecords(activeTable)}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
              title="Recarregar tabela"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            </button>

            <button
              id="btn-add-record"
              onClick={handleOpenCreate}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Inserir Registro</span>
            </button>
          </div>
        </div>

        {/* Data Table */}
        <div className="overflow-x-auto">
          {loading ? (
            <div className="py-12 text-center text-slate-500 text-xs flex flex-col items-center gap-2">
              <div className="w-6 h-6 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin"></div>
              <span>Lendo registros do banco de dados...</span>
            </div>
          ) : filteredRecords.length === 0 ? (
            <div className="py-12 text-center">
              <p className="text-xs font-semibold text-slate-700">
                Nenhum registro encontrado nesta tabela.
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                Clique em "Inserir Registro" para adicionar novos dados.
              </p>
            </div>
          ) : (
            <table className="w-full text-left text-xs text-slate-600">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4 w-28">ID</th>
                  <th className="py-3 px-4">Dados Principais</th>
                  <th className="py-3 px-4">Empresa / Vínculo</th>
                  <th className="py-3 px-4">Status / Tags</th>
                  <th className="py-3 px-4 text-center w-36">Ações de Admin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-sans">
                {filteredRecords.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                    {/* ID */}
                    <td className="py-3 px-4 font-mono font-semibold text-[11px] text-slate-700">
                      {item.id}
                    </td>

                    {/* Main columns dynamic preview */}
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">
                        {item.nomeFantasia ||
                          item.razaoSocial ||
                          item.nome ||
                          item.titulo ||
                          item.descricao ||
                          item.codigo ||
                          'Item sem nome'}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5 truncate max-w-xs">
                        {item.cnpj ||
                          item.cpfCnpj ||
                          item.cpf ||
                          item.email ||
                          item.competencia ||
                          item.categoria ||
                          item.orgao ||
                          item.beneficiario ||
                          item.pagador ||
                          ''}
                      </div>
                    </td>

                    {/* Company Link */}
                    <td className="py-3 px-4">
                      {item.empresaId ? (
                        <span className="font-mono text-[11px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-medium">
                          {item.empresaId}
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[11px] italic">Global</span>
                      )}
                    </td>

                    {/* Status Badge */}
                    <td className="py-3 px-4">
                      {item.status ? (
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            item.status === 'ativa' ||
                            item.status === 'ativo' ||
                            item.status === 'concluida' ||
                            item.status === 'aprovado' ||
                            item.status === 'valida' ||
                            item.status === 'pago' ||
                            item.status === 'recebido'
                              ? 'bg-emerald-100 text-emerald-800'
                              : item.status === 'pendente' || item.status === 'a_fazer'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {String(item.status).toUpperCase()}
                        </span>
                      ) : item.valor !== undefined ? (
                        <span className="font-bold text-slate-800 font-mono">
                          {new Intl.NumberFormat('pt-BR', {
                            style: 'currency',
                            currency: 'BRL',
                          }).format(item.valor)}
                        </span>
                      ) : (
                        <span className="text-slate-400 text-[11px]">-</span>
                      )}
                    </td>

                    {/* Action buttons */}
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setInspectRecord(item)}
                          className="p-1.5 text-slate-500 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                          title="Inspecionar JSON completo"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => handleOpenEdit(item)}
                          className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                          title="Editar registro"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => setDeletingId(item.id)}
                          className="p-1.5 text-slate-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                          title="Excluir registro do banco"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* CREATE / EDIT RECORD MODAL */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <span>
                    {editingRecord
                      ? `Editar Registro: ${editingRecord.id}`
                      : `Inserir Novo Registro em [${activeTable}]`}
                  </span>
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
                    Admin
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  Faça alterações nos campos estruturados ou edite o documento JSON diretamente.
                </p>
              </div>

              {/* Mode Toggle */}
              <div className="flex items-center bg-slate-100 p-1 rounded-lg text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => {
                    setEditorMode('form');
                    setJsonError(null);
                  }}
                  className={`px-3 py-1 rounded-md transition-colors ${
                    editorMode === 'form'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  Campos
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setRawJsonText(JSON.stringify(formData, null, 2));
                    setEditorMode('json');
                    setJsonError(null);
                  }}
                  className={`px-3 py-1 rounded-md transition-colors ${
                    editorMode === 'json'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  JSON Direto
                </button>
              </div>
            </div>

            {/* Form Mode */}
            {editorMode === 'form' ? (
              <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-slate-200">
                {Object.keys(formData).map((key) => {
                  if (key === 'id') return null; // ID is read-only or auto
                  const val = formData[key];
                  const isBoolean = typeof val === 'boolean';
                  const isNumber = typeof val === 'number';

                  return (
                    <div key={key} className="space-y-1">
                      <label className="block text-xs font-bold text-slate-700 capitalize">
                        {key.replace(/([A-Z])/g, ' $1')}
                      </label>
                      {isBoolean ? (
                        <select
                          value={formData[key] ? 'true' : 'false'}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              [key]: e.target.value === 'true',
                            })
                          }
                          className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg bg-slate-50"
                        >
                          <option value="true">Sim (true)</option>
                          <option value="false">Não (false)</option>
                        </select>
                      ) : isNumber ? (
                        <input
                          type="number"
                          value={formData[key] || 0}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              [key]: parseFloat(e.target.value) || 0,
                            })
                          }
                          className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                        />
                      ) : (
                        <input
                          type="text"
                          value={formData[key] || ''}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              [key]: e.target.value,
                            })
                          }
                          className="w-full text-xs px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                        />
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              /* JSON Raw Editor Mode */
              <div className="space-y-2">
                <textarea
                  rows={14}
                  value={rawJsonText}
                  onChange={(e) => {
                    setRawJsonText(e.target.value);
                    setJsonError(null);
                  }}
                  className="w-full font-mono text-xs p-3 bg-slate-900 text-emerald-300 border border-slate-800 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none"
                />
                {jsonError && (
                  <p className="text-xs text-rose-600 font-semibold">{jsonError}</p>
                )}
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2 pt-4 mt-4 border-t border-slate-100 text-xs">
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg font-medium"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveRecord}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg shadow-xs cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{editingRecord ? 'Salvar Alterações' : 'Gravar no Banco'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* JSON INSPECTOR MODAL */}
      {inspectRecord && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <FileCode className="w-5 h-5 text-blue-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  Documento JSON: {inspectRecord.id}
                </h3>
              </div>
              <button
                onClick={() => setInspectRecord(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <pre className="bg-slate-900 text-emerald-400 font-mono text-xs p-4 rounded-xl max-h-[60vh] overflow-auto">
              {JSON.stringify(inspectRecord, null, 2)}
            </pre>

            <div className="flex justify-end mt-4 pt-3 border-t border-slate-100">
              <button
                onClick={() => setInspectRecord(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deletingId && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 text-center">
              Confirmar Exclusão Definitiva
            </h3>
            <p className="text-xs text-slate-500 text-center mt-1">
              Tem certeza que deseja remover o registro <strong className="font-mono text-slate-900">{deletingId}</strong> da tabela <strong className="text-slate-900">[{activeTable}]</strong>? Esta alteração será gravada permanentemente no banco de dados.
            </p>

            <div className="flex items-center justify-center gap-2 mt-5">
              <button
                onClick={() => setDeletingId(null)}
                className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold rounded-lg"
              >
                Cancelar
              </button>
              <button
                onClick={() => handleDeleteRecord(deletingId)}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-lg shadow-xs"
              >
                Sim, Excluir do Banco
              </button>
            </div>
          </div>
        </div>
      )}

      {/* RESET TO SEED CONFIRMATION */}
      {showResetConfirm && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto mb-3">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 text-center">
              Restaurar Base de Dados Padrão?
            </h3>
            <p className="text-xs text-slate-500 text-center mt-1">
              Esta ação reinicializa os registros do banco de dados para a estrutura operacional limpa. Certifique-se de exportar um backup antes caso deseje preservar alterações.
            </p>

            <div className="flex items-center justify-center gap-2 mt-5">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold rounded-lg"
              >
                Cancelar
              </button>
              <button
                onClick={handleResetToDemo}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-lg shadow-xs"
              >
                Confirmar e Restaurar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
