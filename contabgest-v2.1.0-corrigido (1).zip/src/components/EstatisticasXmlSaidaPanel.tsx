import React, { useState, useMemo } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  FileText,
  TrendingUp,
  DollarSign,
  Users,
  Building2,
  Calendar,
  Layers,
  ArrowUpRight,
  Filter,
  CheckCircle2,
  Download,
} from 'lucide-react';
import { NotaFiscal, Empresa } from '../types';

interface EstatisticasXmlSaidaPanelProps {
  notasFiscais: NotaFiscal[];
  empresas: Empresa[];
  selectedEmpresa?: Empresa;
  onOpenImportModal: () => void;
}

const COLORS = ['#10b981', '#0ea5e9', '#6366f1', '#f59e0b', '#ec4899', '#8b5cf6', '#14b8a6', '#f97316'];

export const EstatisticasXmlSaidaPanel: React.FC<EstatisticasXmlSaidaPanelProps> = ({
  notasFiscais,
  empresas,
  selectedEmpresa,
  onOpenImportModal,
}) => {
  const [empresaFiltro, setEmpresaFiltro] = useState<string>(selectedEmpresa?.id || 'todas');
  const [origemFiltro, setOrigemFiltro] = useState<'todos' | 'importado_erp' | 'sistema'>('todos');
  const [anoFiltro, setAnoFiltro] = useState<string>('2026');

  // Filtrar notas de saída (apenas autorizadas ou todas exceto canceladas)
  const notasFiltradas = useMemo(() => {
    return notasFiscais.filter((nf) => {
      if (nf.status === 'cancelada') return false;
      if (empresaFiltro !== 'todas' && nf.empresaId !== empresaFiltro) return false;
      if (origemFiltro === 'importado_erp' && nf.origem !== 'importado_erp') return false;
      if (origemFiltro === 'sistema' && nf.origem === 'importado_erp') return false;

      const anoNota = nf.dataEmissao ? nf.dataEmissao.slice(0, 4) : '2026';
      if (anoFiltro !== 'todos' && anoNota !== anoFiltro) return false;

      return true;
    });
  }, [notasFiscais, empresaFiltro, origemFiltro, anoFiltro]);

  // Cálculos de KPI
  const kpis = useMemo(() => {
    const totalNotas = notasFiltradas.length;
    const faturamentoTotal = notasFiltradas.reduce((acc, nf) => acc + (nf.valorTotal || 0), 0);
    const ticketMedio = totalNotas > 0 ? faturamentoTotal / totalNotas : 0;
    const notasImportadasErp = notasFiltradas.filter((nf) => nf.origem === 'importado_erp').length;

    // Achar maior cliente
    const clientesMap: Record<string, number> = {};
    notasFiltradas.forEach((nf) => {
      const nome = nf.destinatarioNome || 'Cliente Não Identificado';
      clientesMap[nome] = (clientesMap[nome] || 0) + (nf.valorTotal || 0);
    });

    let maiorClienteNome = 'N/A';
    let maiorClienteValor = 0;
    Object.entries(clientesMap).forEach(([nome, valor]) => {
      if (valor > maiorClienteValor) {
        maiorClienteValor = valor;
        maiorClienteNome = nome;
      }
    });

    return {
      totalNotas,
      faturamentoTotal,
      ticketMedio,
      notasImportadasErp,
      maiorClienteNome,
      maiorClienteValor,
    };
  }, [notasFiltradas]);

  // 1. Total de notas e faturamento por mês
  const dadosPorMes = useMemo(() => {
    const mesesNomes = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    const mapa = mesesNomes.map((mes, idx) => ({
      mes,
      mesNum: idx + 1,
      quantidade: 0,
      valor: 0,
      acumulado: 0,
    }));

    notasFiltradas.forEach((nf) => {
      if (nf.dataEmissao) {
        const d = new Date(nf.dataEmissao);
        const m = d.getMonth();
        if (m >= 0 && m < 12) {
          mapa[m].quantidade += 1;
          mapa[m].valor += nf.valorTotal || 0;
        }
      }
    });

    // Calcular valores acumulados mês a mês para apuração do Simples
    let somaAcumulada = 0;
    mapa.forEach((m) => {
      somaAcumulada += m.valor;
      m.acumulado = somaAcumulada;
    });

    return mapa;
  }, [notasFiltradas]);

  // 2. Top 10 Clientes por Volume de Faturamento
  const top10Clientes = useMemo(() => {
    const clientesMap: Record<
      string,
      { nome: string; cnpjCpf: string; valorTotal: number; quantidadeNotas: number }
    > = {};

    notasFiltradas.forEach((nf) => {
      const chave = nf.destinatarioCpfCnpj || nf.destinatarioNome || 'Desconhecido';
      if (!clientesMap[chave]) {
        clientesMap[chave] = {
          nome: nf.destinatarioNome || 'Cliente Sem Razão Social',
          cnpjCpf: nf.destinatarioCpfCnpj || '-',
          valorTotal: 0,
          quantidadeNotas: 0,
        };
      }
      clientesMap[chave].valorTotal += nf.valorTotal || 0;
      clientesMap[chave].quantidadeNotas += 1;
    });

    return Object.values(clientesMap)
      .sort((a, b) => b.valorTotal - a.valorTotal)
      .slice(0, 10);
  }, [notasFiltradas]);

  // 3. Distribuição por Anexo do Simples Nacional / CFOP
  const dadosAnexos = useMemo(() => {
    const anexos: Record<string, number> = {
      'Anexo I (Comércio)': 0,
      'Anexo II (Indústria)': 0,
      'Anexo III (Serviços)': 0,
      'Anexo IV (Obras/Vig.)': 0,
      'Anexo V (Tecnologia)': 0,
    };

    notasFiltradas.forEach((nf) => {
      const anexo = nf.anexoSimples || (nf.tipo === 'NFSe' ? 'Anexo III' : 'Anexo I');
      if (anexo.includes('I') && !anexo.includes('II') && !anexo.includes('III') && !anexo.includes('IV') && !anexo.includes('V')) {
        anexos['Anexo I (Comércio)'] += nf.valorTotal || 0;
      } else if (anexo.includes('II') && !anexo.includes('III')) {
        anexos['Anexo II (Indústria)'] += nf.valorTotal || 0;
      } else if (anexo.includes('III')) {
        anexos['Anexo III (Serviços)'] += nf.valorTotal || 0;
      } else if (anexo.includes('IV')) {
        anexos['Anexo IV (Obras/Vig.)'] += nf.valorTotal || 0;
      } else {
        anexos['Anexo V (Tecnologia)'] += nf.valorTotal || 0;
      }
    });

    return Object.entries(anexos)
      .filter(([_, valor]) => valor > 0)
      .map(([name, value]) => ({ name, value }));
  }, [notasFiltradas]);

  const formatCurrency = (val: number) => {
    return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const formatShortCurrency = (val: number) => {
    if (val >= 1000000) return `R$ ${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `R$ ${(val / 1000).toFixed(0)}k`;
    return `R$ ${val.toFixed(0)}`;
  };

  return (
    <div className="space-y-6">
      {/* Barra Superior de Filtros e Ações */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          {/* Filtro de Empresa */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Empresa
            </label>
            <div className="relative">
              <Building2 className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <select
                value={empresaFiltro}
                onChange={(e) => setEmpresaFiltro(e.target.value)}
                className="pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              >
                <option value="todas">Todas as Empresas</option>
                {empresas.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.razaoSocial}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Filtro de Origem */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Origem dos Documentos
            </label>
            <select
              value={origemFiltro}
              onChange={(e) => setOrigemFiltro(e.target.value as any)}
              className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            >
              <option value="todos">Todos (ERP Externo + Sistema)</option>
              <option value="importado_erp">Apenas XMLs Importados (Outro ERP - Mod. 55)</option>
              <option value="sistema">Apenas Emitidas no ContabGest</option>
            </select>
          </div>

          {/* Filtro de Ano */}
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Exercício / Ano
            </label>
            <select
              value={anoFiltro}
              onChange={(e) => setAnoFiltro(e.target.value)}
              className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            >
              <option value="2026">2026 (Ano Corrente)</option>
              <option value="2025">2025</option>
              <option value="todos">Todos os Anos</option>
            </select>
          </div>
        </div>

        <button
          onClick={onOpenImportModal}
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors"
        >
          <ArrowUpRight className="w-4 h-4" />
          Importar Novos XMLs Modelo 55
        </button>
      </div>

      {/* Cards de Métricas e KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1 */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total Faturado (Saídas)
            </span>
            <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2">
            <h3 className="text-2xl font-bold text-slate-800">{formatCurrency(kpis.faturamentoTotal)}</h3>
            <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
              <span className="text-emerald-600 font-semibold">{kpis.totalNotas} notas</span> computadas no período
            </p>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              XMLs Importados (ERP)
            </span>
            <div className="w-9 h-9 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2">
            <h3 className="text-2xl font-bold text-slate-800">{kpis.notasImportadasErp}</h3>
            <p className="text-xs text-slate-500 mt-1">
              Notas Mod. 55 capturadas para o Simples Nacional
            </p>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Ticket Médio por Nota
            </span>
            <div className="w-9 h-9 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2">
            <h3 className="text-2xl font-bold text-slate-800">{formatCurrency(kpis.ticketMedio)}</h3>
            <p className="text-xs text-slate-500 mt-1">
              Média por documento fiscal emitido/capturado
            </p>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Maior Cliente (Volume)
            </span>
            <div className="w-9 h-9 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-2">
            <h3 className="text-sm font-bold text-slate-800 truncate" title={kpis.maiorClienteNome}>
              {kpis.maiorClienteNome}
            </h3>
            <p className="text-xs text-emerald-600 font-semibold mt-1">
              {formatCurrency(kpis.maiorClienteValor)} faturados
            </p>
          </div>
        </div>
      </div>

      {/* Grid de Gráficos Principais */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gráfico 1: Total de Notas por Mês (Barras) */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">Total de Notas Fiscais por Mês</h3>
              <p className="text-xs text-slate-500">Volume de emissões/importações mensais no exercício</p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 bg-slate-100 text-slate-600 rounded-md">
              Unidades de NF-e
            </span>
          </div>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dadosPorMes} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="mes" stroke="#64748b" fontSize={12} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any) => [`${val} notas fiscais`, 'Quantidade']}
                />
                <Bar dataKey="quantidade" fill="#10b981" radius={[4, 4, 0, 0]} name="Notas Emitidas" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Gráfico 2: Valores Acumulados (Área - Evolução do Faturamento) */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800">Faturamento Mensal & Valores Acumulados</h3>
              <p className="text-xs text-slate-500">Base para apuração do Simples Nacional e RBT12</p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 bg-emerald-50 text-emerald-700 rounded-md">
              R$ (Reais)
            </span>
          </div>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dadosPorMes} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorAcumulado" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="mes" stroke="#64748b" fontSize={12} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} tickFormatter={formatShortCurrency} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '8px', fontSize: '12px' }}
                  formatter={(val: any, name: any) => [
                    formatCurrency(Number(val)),
                    name === 'acumulado' ? 'Receita Acumulada' : 'Faturamento Mês',
                  ]}
                />
                <Area
                  type="monotone"
                  dataKey="acumulado"
                  stroke="#0ea5e9"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorAcumulado)"
                  name="acumulado"
                />
                <Bar dataKey="valor" fill="#10b981" radius={[4, 4, 0, 0]} name="valor" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Seção Inferior: Top 10 Clientes por Volume & Distribuição por Anexo */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top 10 Clientes (2 Colunas) */}
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                Top 10 Clientes por Volume de Faturamento
                <span className="text-[11px] bg-slate-100 text-slate-600 font-semibold px-2 py-0.5 rounded-full">
                  Receita Bruta
                </span>
              </h3>
              <p className="text-xs text-slate-500">Destinatários com maior concentração de faturamento</p>
            </div>
          </div>

          {top10Clientes.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-xs">
              Nenhuma nota fiscal encontrada com os filtros selecionados.
            </div>
          ) : (
            <div className="space-y-3">
              {top10Clientes.map((cliente, idx) => {
                const percentual = kpis.faturamentoTotal > 0 ? (cliente.valorTotal / kpis.faturamentoTotal) * 100 : 0;
                return (
                  <div key={idx} className="p-3 bg-slate-50 rounded-lg border border-slate-100 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5 overflow-hidden">
                        <span
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                            idx === 0
                              ? 'bg-amber-100 text-amber-700'
                              : idx === 1
                              ? 'bg-slate-200 text-slate-700'
                              : idx === 2
                              ? 'bg-amber-50 text-amber-800'
                              : 'bg-slate-100 text-slate-500'
                          }`}
                        >
                          {idx + 1}
                        </span>
                        <div>
                          <h4 className="text-xs font-bold text-slate-800 truncate max-w-xs md:max-w-md">
                            {cliente.nome}
                          </h4>
                          <span className="text-[11px] text-slate-400">
                            {cliente.cnpjCpf} • {cliente.quantidadeNotas} {cliente.quantidadeNotas === 1 ? 'nota' : 'notas'}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-bold text-slate-800">{formatCurrency(cliente.valorTotal)}</span>
                        <div className="text-[10px] text-slate-500">{percentual.toFixed(1)}% do faturamento</div>
                      </div>
                    </div>
                    {/* Barra de Progresso Relativa */}
                    <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                        style={{ width: `${percentual}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Distribuição por Anexo do Simples Nacional */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-800">Distribuição por Anexo do Simples</h3>
            <p className="text-xs text-slate-500 mb-4">Classificação automática pelo CFOP das notas de saída</p>

            {dadosAnexos.length > 0 ? (
              <div className="h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={dadosAnexos}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={75}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {dadosAnexos.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value: any) => [formatCurrency(Number(value)), 'Faturamento']}
                      contentStyle={{ backgroundColor: '#ffffff', borderColor: '#e2e8f0', borderRadius: '8px', fontSize: '12px' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="text-center py-16 text-slate-400 text-xs">
                Dados insuficientes para composição dos Anexos.
              </div>
            )}

            <div className="space-y-2 mt-2">
              {dadosAnexos.map((anexo, idx) => (
                <div key={idx} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: COLORS[idx % COLORS.length] }}
                    />
                    <span className="text-slate-600 font-medium">{anexo.name}</span>
                  </div>
                  <span className="font-bold text-slate-800">{formatCurrency(anexo.value)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 text-[11px] text-slate-500 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Dados sincronizados em tempo real com o módulo PGDAS-D e apuração mensal do DAS.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
