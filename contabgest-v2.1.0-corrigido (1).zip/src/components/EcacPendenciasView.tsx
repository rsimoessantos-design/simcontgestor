import React, { useState } from 'react';
import {
  Activity,
  RefreshCw,
  CheckCircle2,
  AlertOctagon,
  AlertTriangle,
  Clock,
  ExternalLink,
  ShieldCheck,
  Building2,
  DollarSign,
  FileCheck,
  Search,
  Filter,
  Check,
  X,
  Radio,
  ArrowUpRight,
  Info,
} from 'lucide-react';
import { PendenciaEcac, Empresa } from '../types';
import { api } from '../services/api';

interface EcacPendenciasViewProps {
  selectedEmpresa?: Empresa;
  empresas: Empresa[];
  pendencias: PendenciaEcac[];
  onRefresh: () => void;
}

export const EcacPendenciasView: React.FC<EcacPendenciasViewProps> = ({
  selectedEmpresa,
  empresas,
  pendencias,
  onRefresh,
}) => {
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);
  const [selectedPendenciaForResolve, setSelectedPendenciaForResolve] = useState<PendenciaEcac | null>(null);
  const [protocoloRegularizacao, setProtocoloRegularizacao] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [filterGravidade, setFilterGravidade] = useState<string>('todos');
  const [filterStatus, setFilterStatus] = useState<string>('todos');
  const [searchTerm, setSearchTerm] = useState('');

  // Sincronização e-CAC
  const handleSincronizarReceita = async () => {
    setIsSyncing(true);
    setSyncFeedback(null);
    try {
      await api.sincronizarReceitaFederal(selectedEmpresa?.id);
      setTimeout(() => {
        setIsSyncing(false);
        setSyncFeedback(
          'Varredura concluída com sucesso! Conexão autenticada via mTLS com o e-CAC da Receita Federal e PGFN.'
        );
        onRefresh();
        setTimeout(() => setSyncFeedback(null), 6000);
      }, 1500);
    } catch (err: any) {
      setIsSyncing(false);
      alert('Erro na conexão com os servidores da Receita Federal: ' + err.message);
    }
  };

  // Resolver pendência
  const handleResolverPendencia = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPendenciaForResolve) return;

    setIsSubmitting(true);
    try {
      await api.resolverPendenciaEcac(
        selectedPendenciaForResolve.id,
        protocoloRegularizacao || `REC-RFB-${Date.now()}`
      );
      setSelectedPendenciaForResolve(null);
      setProtocoloRegularizacao('');
      onRefresh();
    } catch (err: any) {
      alert(err.message || 'Erro ao regularizar pendência.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Cálculos do Velocímetro e Indicadores
  const total = pendencias.length;
  const resolvidas = pendencias.filter((p) => p.status === 'resolvida').length;
  const pendentes = pendencias.filter((p) => p.status === 'pendente').length;
  const emAnalise = pendencias.filter((p) => p.status === 'em_analise').length;

  // Percentual de regularidade de 0 a 100%
  const percentualResolvido = total > 0 ? Math.round((resolvidas / total) * 100) : 100;

  // Ângulo do ponteiro do velocímetro (-90 graus em 0% até +90 graus em 100%)
  const anguloPonteiro = -90 + (percentualResolvido / 100) * 180;

  // Valor total de débitos em aberto
  const totalValorDebitosAbertos = pendencias
    .filter((p) => p.status !== 'resolvida' && p.valor)
    .reduce((acc, curr) => acc + (curr.valor || 0), 0);

  // Filtragem
  const filteredPendencias = pendencias.filter((p) => {
    const matchesSearch =
      p.descricao.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.tipo.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.codigoReceita?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.protocoloRegularizacao?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesGravidade = filterGravidade === 'todos' || p.gravidade === filterGravidade;
    const matchesStatus = filterStatus === 'todos' || p.status === filterStatus;

    return matchesSearch && matchesGravidade && matchesStatus;
  });

  // Cor do velocímetro com base no percentual
  const getCorVelocimetro = (percent: number) => {
    if (percent < 40) return '#ef4444'; // Vermelho
    if (percent < 75) return '#f59e0b'; // Âmbar
    if (percent < 95) return '#3b82f6'; // Azul
    return '#10b981'; // Verde Esmeralda (100% regular)
  };

  return (
    <div className="space-y-6">
      {/* Header & Status Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2.5">
            <Activity className="w-7 h-7 text-blue-600" />
            Painel e-CAC: Pendências Fiscais & Velocímetro da Receita Federal
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            {selectedEmpresa
              ? `Monitoramento de Regularidade Fiscal da ${selectedEmpresa.razaoSocial} junto à RFB e PGFN`
              : 'Varredura automática e sincronização contínua com os sistemas da Receita Federal'}
          </p>
        </div>

        <button
          id="btn-sincronizar-ecac"
          disabled={isSyncing}
          onClick={handleSincronizarReceita}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
          {isSyncing ? 'Varrendo e-CAC / RFB...' : 'Sincronizar com Receita Federal'}
        </button>
      </div>

      {/* Sync Banner Status */}
      <div className="bg-slate-900 text-slate-100 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm border border-slate-800">
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center">
            <span className="w-3 h-3 bg-emerald-500 rounded-full animate-ping absolute"></span>
            <span className="w-3 h-3 bg-emerald-500 rounded-full"></span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                Canal Oficial e-CAC Ativo
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                mTLS 2048-bit
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Conexão com os módulos: Situação Fiscal Integrada, Caixa Postal DTE, Malha Fiscal DCTF e Dívida Ativa PGFN
            </p>
          </div>
        </div>

        <div className="text-xs text-slate-400 font-mono self-start sm:self-auto">
          Última consulta:{' '}
          <strong className="text-slate-200">{new Date().toLocaleTimeString('pt-BR')} (Hoje)</strong>
        </div>
      </div>

      {syncFeedback && (
        <div className="p-4 bg-blue-50 border border-blue-200 text-blue-900 text-xs rounded-xl flex items-center gap-2.5 shadow-sm">
          <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0" />
          <span className="font-medium">{syncFeedback}</span>
        </div>
      )}

      {/* VELOCÍMETRO GAUGE + METRICS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Velocímetro de 0 a 100% */}
        <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-sm flex flex-col items-center justify-between text-center relative overflow-hidden">
          <div className="w-full flex items-center justify-between mb-2">
            <div className="text-left">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
                Velocímetro de Resolução
              </span>
              <h3 className="text-base font-bold text-slate-900">Índice de Regularidade Fiscal</h3>
            </div>
            <span
              className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                percentualResolvido === 100
                  ? 'bg-emerald-100 text-emerald-800'
                  : percentualResolvido >= 75
                  ? 'bg-blue-100 text-blue-800'
                  : percentualResolvido >= 40
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-rose-100 text-rose-800'
              }`}
            >
              {percentualResolvido === 100
                ? '100% Regularizada'
                : percentualResolvido >= 75
                ? 'Alta Regularidade'
                : percentualResolvido >= 40
                ? 'Atenção Necessária'
                : 'Risco Fiscal Elevado'}
            </span>
          </div>

          {/* SVG Gauge Graphic */}
          <div className="relative my-4 w-72 h-44 flex items-center justify-center">
            <svg viewBox="0 0 240 140" className="w-full h-full overflow-visible">
              {/* Definitions */}
              <defs>
                <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#ef4444" />
                  <stop offset="35%" stopColor="#f59e0b" />
                  <stop offset="70%" stopColor="#3b82f6" />
                  <stop offset="100%" stopColor="#10b981" />
                </linearGradient>
              </defs>

              {/* Background Arc Track (semi-circle) */}
              <path
                d="M 20 120 A 100 100 0 0 1 220 120"
                fill="none"
                stroke="#e2e8f0"
                strokeWidth="20"
                strokeLinecap="round"
              />

              {/* Colored Gauge Arc */}
              <path
                d="M 20 120 A 100 100 0 0 1 220 120"
                fill="none"
                stroke="url(#gaugeGradient)"
                strokeWidth="20"
                strokeLinecap="round"
                strokeDasharray="314.159"
                strokeDashoffset={314.159 - (percentualResolvido / 100) * 314.159}
                style={{ transition: 'stroke-dashoffset 0.8s ease-in-out' }}
              />

              {/* Ticks and values */}
              <text x="18" y="138" fontSize="10" fontWeight="bold" fill="#64748b">
                0%
              </text>
              <text x="65" y="55" fontSize="10" fontWeight="bold" fill="#64748b">
                25%
              </text>
              <text x="110" y="32" fontSize="10" fontWeight="bold" fill="#64748b">
                50%
              </text>
              <text x="160" y="55" fontSize="10" fontWeight="bold" fill="#64748b">
                75%
              </text>
              <text x="206" y="138" fontSize="10" fontWeight="bold" fill="#64748b">
                100%
              </text>

              {/* Center Pivot Point */}
              <circle cx="120" cy="120" r="10" fill="#1e293b" />
              <circle cx="120" cy="120" r="4" fill="#ffffff" />

              {/* Needle Pointer */}
              <g
                transform={`rotate(${anguloPonteiro} 120 120)`}
                style={{ transition: 'transform 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)' }}
              >
                <polygon points="116,120 124,120 121,35 119,35" fill="#0f172a" />
                <circle cx="120" cy="35" r="3" fill={getCorVelocimetro(percentualResolvido)} />
              </g>
            </svg>

            {/* Big percentage display overlay */}
            <div className="absolute bottom-0 left-0 right-0 flex flex-col items-center">
              <span
                className="text-4xl font-black tracking-tight"
                style={{ color: getCorVelocimetro(percentualResolvido) }}
              >
                {percentualResolvido}%
              </span>
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                Pendências Resolvidas
              </span>
            </div>
          </div>

          {/* Gauge Summary Footer */}
          <div className="w-full bg-slate-50 border border-slate-100 rounded-xl p-3 grid grid-cols-3 gap-2 text-xs">
            <div>
              <span className="text-slate-500 block text-[11px]">Total Detectadas</span>
              <strong className="text-slate-900 text-sm">{total}</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px]">Resolvidas</span>
              <strong className="text-emerald-600 text-sm">{resolvidas}</strong>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px]">Pendentes</span>
              <strong className="text-rose-600 text-sm">{pendentes + emAnalise}</strong>
            </div>
          </div>
        </div>

        {/* Financial & Status Breakdown */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Débitos Totais em Aberto (RFB / PGFN)
              </span>
              <div className="p-2 bg-rose-50 text-rose-600 rounded-lg">
                <DollarSign className="w-5 h-5" />
              </div>
            </div>
            <p className="text-2xl font-black text-rose-600 mt-2">
              R$ {totalValorDebitosAbertos.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Valores sujeitos a parcelamento, compensação de créditos ou impugnação
            </p>
          </div>

          {/* Quick status breakdown */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">Pendências Críticas</span>
                <AlertOctagon className="w-4 h-4 text-rose-600" />
              </div>
              <p className="text-xl font-bold text-slate-900 mt-1">
                {pendencias.filter((p) => p.gravidade === 'critica' && p.status !== 'resolvida').length}
              </p>
              <p className="text-[11px] text-rose-600 font-medium mt-0.5">Risco de perda da CND</p>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">Em Análise / Defesa</span>
                <Clock className="w-4 h-4 text-amber-600" />
              </div>
              <p className="text-xl font-bold text-slate-900 mt-1">{emAnalise}</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Aguardando deferimento RFB</p>
            </div>
          </div>

          {/* Instructions Box */}
          <div className="bg-blue-50/60 border border-blue-200 rounded-xl p-4 text-xs text-blue-900 flex items-start gap-3">
            <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <strong className="block font-semibold">Como funciona o Velocímetro de Regularidade:</strong>
              Conforme cada pendência fiscal do e-CAC é regularizada (por meio de transmissão de retificadora, DARF
              quitado ou protocolo de impugnação), clique em <strong>"Regularizar"</strong>. A agulha do velocímetro se
              deslocará imediatamente em direção a <strong>100% de conformidade</strong>.
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            id="input-busca-pendencias"
            type="text"
            placeholder="Buscar por descrição, código ou protocolo..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={filterGravidade}
              onChange={(e) => setFilterGravidade(e.target.value)}
              className="bg-transparent border-none focus:outline-none text-xs text-slate-700 font-medium"
            >
              <option value="todos">Todas as Gravidades</option>
              <option value="critica">Crítica (Impedimento CND)</option>
              <option value="alta">Alta</option>
              <option value="media">Média</option>
              <option value="baixa">Baixa</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="bg-transparent border-none focus:outline-none text-xs text-slate-700 font-medium"
            >
              <option value="todos">Todos os Status</option>
              <option value="pendente">Apenas Pendentes</option>
              <option value="resolvida">Apenas Resolvidas</option>
              <option value="em_analise">Em Análise</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table of e-CAC Pendencies */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600 uppercase tracking-wider">
              <tr>
                <th className="px-5 py-3">Pendência / Órgão</th>
                <th className="px-5 py-3">Período / Código</th>
                <th className="px-5 py-3">Gravidade</th>
                <th className="px-5 py-3">Valor Envolvido</th>
                <th className="px-5 py-3">Status Atual</th>
                <th className="px-5 py-3 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPendencias.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-8 text-center text-slate-400">
                    Nenhuma pendência encontrada para os filtros selecionados.
                  </td>
                </tr>
              ) : (
                filteredPendencias.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-5 py-4">
                      <p className="font-semibold text-slate-900">{item.descricao}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-xs text-slate-500 font-medium">{item.orgao}</span>
                        <span className="text-slate-300">•</span>
                        <span className="text-xs text-slate-400">{item.tipo}</span>
                      </div>
                      {item.protocoloRegularizacao && (
                        <span className="inline-block text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded mt-1 border border-emerald-200">
                          Protocolo RFB: {item.protocoloRegularizacao}
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-4">
                      <p className="text-xs font-semibold text-slate-800">{item.periodoApuracao || 'Geral'}</p>
                      {item.codigoReceita && (
                        <p className="text-xs text-slate-500 font-mono">Cód: {item.codigoReceita}</p>
                      )}
                    </td>
                    <td className="px-5 py-4">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wide ${
                          item.gravidade === 'critica'
                            ? 'bg-rose-100 text-rose-800'
                            : item.gravidade === 'alta'
                            ? 'bg-orange-100 text-orange-800'
                            : item.gravidade === 'media'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {item.gravidade}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      {item.valor ? (
                        <span className="font-semibold text-slate-900">
                          R$ {item.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </span>
                      ) : (
                        <span className="text-xs text-slate-400 italic">Obrigação Acessória</span>
                      )}
                    </td>
                    <td className="px-5 py-4">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
                          item.status === 'resolvida'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : item.status === 'em_analise'
                            ? 'bg-amber-50 text-amber-700 border border-amber-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}
                      >
                        {item.status === 'resolvida' ? (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Resolvida
                          </>
                        ) : item.status === 'em_analise' ? (
                          <>
                            <Clock className="w-3.5 h-3.5 text-amber-600" /> Em Análise
                          </>
                        ) : (
                          <>
                            <AlertTriangle className="w-3.5 h-3.5 text-rose-600" /> Pendente
                          </>
                        )}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-right">
                      {item.status !== 'resolvida' ? (
                        <button
                          id={`btn-regularizar-${item.id}`}
                          onClick={() => {
                            setSelectedPendenciaForResolve(item);
                            setProtocoloRegularizacao(`REC-RFB-${Math.floor(100000000 + Math.random() * 900000000)}`);
                          }}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors"
                        >
                          <Check className="w-3.5 h-3.5" />
                          Regularizar
                        </button>
                      ) : (
                        <span className="text-xs font-semibold text-emerald-600 inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Regularizada
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Regularizar Pendência */}
      {selectedPendenciaForResolve && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                  <FileCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Regularizar Pendência Fiscal</h3>
                  <p className="text-xs text-slate-500">
                    O velocímetro de regularidade aumentará imediatamente após confirmação
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedPendenciaForResolve(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1 text-xs">
              <p className="font-bold text-slate-900">{selectedPendenciaForResolve.descricao}</p>
              <p className="text-slate-600">Órgão: {selectedPendenciaForResolve.orgao}</p>
              {selectedPendenciaForResolve.valor && (
                <p className="text-slate-900 font-semibold">
                  Valor:{' '}
                  R${' '}
                  {selectedPendenciaForResolve.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
              )}
            </div>

            <form onSubmit={handleResolverPendencia} className="mt-4 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Número do Protocolo / Recibo SEFAZ/RFB *
                </label>
                <input
                  type="text"
                  value={protocoloRegularizacao}
                  onChange={(e) => setProtocoloRegularizacao(e.target.value)}
                  placeholder="Ex: REC-RFB-984729104"
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                  required
                />
                <span className="text-[11px] text-slate-500 block mt-1">
                  Informe o número do comprovante de entrega da declaração ou recolhimento do DARF/GPS.
                </span>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedPendenciaForResolve(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-colors disabled:opacity-50"
                >
                  <Check className="w-3.5 h-3.5" />
                  {isSubmitting ? 'Salvando...' : 'Confirmar e Subir Velocímetro'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
