import React, { useState, useMemo, useEffect } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  Printer,
  RefreshCw,
  Filter,
  Search,
  Building2,
  TrendingUp,
  FileText,
  DollarSign,
  AlertOctagon,
  ExternalLink,
  ChevronRight,
  Activity,
  Calendar,
  Store,
  Layers,
  ArrowDownRight,
  HelpCircle,
  BarChart3,
  X,
  FileSpreadsheet,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  Cell,
} from 'recharts';
import {
  Empresa,
  NavSection,
  ApuracaoSimplesNacional,
  GuiaDasMei,
  DeclaracaoAnualMei,
  PendenciaEcac,
  Obrigacao,
  FunilEtapaConformidade,
  ResumoConformidadeEmpresa,
} from '../types';
import {
  calcularConformidadeFiscal,
  ResultadoConformidadeFiscal,
} from '../utils/conformidadeFiscalCalculator';
import { api } from '../services/api';

interface ConformidadeFiscalViewProps {
  empresas: Empresa[];
  selectedEmpresa?: Empresa;
  onNavigate: (section: NavSection, empresaId?: string) => void;
  onRefresh?: () => void;
}

export const ConformidadeFiscalView: React.FC<ConformidadeFiscalViewProps> = ({
  empresas,
  selectedEmpresa,
  onNavigate,
  onRefresh,
}) => {
  // Filtros
  const [filtroEmpresaId, setFiltroEmpresaId] = useState<string>(selectedEmpresa?.id || 'todas');
  const [filtroRegime, setFiltroRegime] = useState<string>('todos');
  const [filtroAno, setFiltroAno] = useState<number>(2026);
  const [filtroRisco, setFiltroRisco] = useState<'todos' | 'critico' | 'alto' | 'medio' | 'baixo'>('todos');
  const [buscaTexto, setBuscaTexto] = useState<string>('');
  const [abaFunilAtiva, setAbaFunilAtiva] = useState<'todos' | 'simples' | 'mei' | 'ecac'>('todos');

  // Estados de dados externos
  const [loading, setLoading] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);
  const [apuracoesSimples, setApuracoesSimples] = useState<ApuracaoSimplesNacional[]>([]);
  const [guiasMei, setGuiasMei] = useState<GuiaDasMei[]>([]);
  const [declaracoesMei, setDeclaracoesMei] = useState<DeclaracaoAnualMei[]>([]);
  const [pendenciasEcac, setPendenciasEcac] = useState<PendenciaEcac[]>([]);
  const [obrigacoes, setObrigacoes] = useState<Obrigacao[]>([]);

  // Modal de Relatório Executivo
  const [modalRelatorioAberto, setModalRelatorioAberto] = useState(false);

  // Sincroniza filtro se a empresa ativa do cabeçalho mudar
  useEffect(() => {
    if (selectedEmpresa?.id) {
      setFiltroEmpresaId(selectedEmpresa.id);
    }
  }, [selectedEmpresa]);

  // Carrega dados integrados de todas as fontes
  const carregarDadosConsolidados = async () => {
    setLoading(true);
    try {
      const data = await api.getConformidadeFiscalConsolidado(filtroAno);
      setApuracoesSimples(data.apuracoes || []);
      setGuiasMei(data.guiasMei || []);
      setDeclaracoesMei(data.declaracoesMei || []);
      setPendenciasEcac(data.pendenciasEcac || []);
      setObrigacoes(data.obrigacoes || []);
    } catch (err) {
      console.warn('Usando dados carregados localmente para conformidade:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregarDadosConsolidados();
  }, [filtroAno]);

  // Executa o cálculo analítico com os dados atuais
  const resultado: ResultadoConformidadeFiscal = useMemo(() => {
    return calcularConformidadeFiscal({
      empresas,
      apuracoesSimples,
      guiasMei,
      declaracoesMei,
      pendenciasEcac,
      obrigacoes,
      ano: filtroAno,
      filtroRegime,
      filtroEmpresaId,
    });
  }, [
    empresas,
    apuracoesSimples,
    guiasMei,
    declaracoesMei,
    pendenciasEcac,
    obrigacoes,
    filtroAno,
    filtroRegime,
    filtroEmpresaId,
  ]);

  // Filtra a lista da tabela por texto de busca e grau de risco
  const empresasTabela = useMemo(() => {
    return resultado.resumoEmpresas.filter((emp) => {
      if (filtroRisco !== 'todos' && emp.grauRisco !== filtroRisco) {
        return false;
      }
      if (buscaTexto.trim()) {
        const termo = buscaTexto.toLowerCase();
        const bateRazao = emp.razaoSocial.toLowerCase().includes(termo);
        const bateFantasia = emp.nomeFantasia.toLowerCase().includes(termo);
        const bateCnpj = emp.cnpj.includes(termo);
        if (!bateRazao && !bateFantasia && !bateCnpj) return false;
      }
      return true;
    });
  }, [resultado.resumoEmpresas, filtroRisco, buscaTexto]);

  // Ação de sincronizar e-CAC e SEFAZ
  const handleSincronizarGeral = async () => {
    setLoading(true);
    setSyncFeedback('Varrendo bases da RFB, PGFN e SEFAZ...');
    try {
      await api.sincronizarReceitaFederal();
      await carregarDadosConsolidados();
      if (onRefresh) onRefresh();
      setSyncFeedback('Sincronização concluída com sucesso!');
      setTimeout(() => setSyncFeedback(null), 3500);
    } catch (err) {
      setSyncFeedback('Concluída com pendências atualizadas.');
      setTimeout(() => setSyncFeedback(null), 3500);
    } finally {
      setLoading(false);
    }
  };

  // Helper para renderizar barra de funil
  const renderCardFunil = (
    etapa: FunilEtapaConformidade,
    index: number,
    totalEtapas: number,
    corTema: string
  ) => {
    return (
      <div
        key={etapa.id}
        className={`relative p-4 rounded-xl border transition-all duration-200 ${
          etapa.gargalo
            ? 'bg-amber-500/5 border-amber-500/40 shadow-xs'
            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
        }`}
      >
        <div className="flex items-start justify-between gap-3 mb-2">
          <div className="flex items-center gap-2">
            <span
              className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-xs shrink-0"
              style={{ backgroundColor: etapa.cor || corTema }}
            >
              {index + 1}
            </span>
            <h5 className="font-semibold text-sm text-slate-800 dark:text-slate-100">
              {etapa.etapa}
            </h5>
          </div>
          <div className="text-right">
            <span className="text-lg font-bold text-slate-900 dark:text-white">
              {etapa.contagem}
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400 ml-1">
              ({etapa.percentual}%)
            </span>
          </div>
        </div>

        {/* Barra de progresso visual */}
        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden mb-2">
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{
              width: `${Math.max(8, etapa.percentual)}%`,
              backgroundColor: etapa.cor || corTema,
            }}
          />
        </div>

        <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <span className="line-clamp-1">{etapa.detalhe}</span>
          {etapa.valorFinanceiro !== undefined && etapa.valorFinanceiro > 0 && (
            <span className="font-semibold text-emerald-600 dark:text-emerald-400 shrink-0 ml-2">
              R$ {etapa.valorFinanceiro.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </span>
          )}
        </div>

        {etapa.gargalo && (
          <div className="mt-2.5 pt-2 border-t border-amber-200 dark:border-amber-900/50 flex items-center gap-1.5 text-xs text-amber-700 dark:text-amber-400 font-medium">
            <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
            <span>Atenção: Queda de retenção detectada nesta etapa operacional</span>
          </div>
        )}
      </div>
    );
  };

  // Cores dinâmicas para o score global
  const corScore =
    resultado.indiceGeralConformidade >= 85
      ? 'text-emerald-600 dark:text-emerald-400'
      : resultado.indiceGeralConformidade >= 70
      ? 'text-amber-600 dark:text-amber-400'
      : 'text-rose-600 dark:text-rose-400';

  const bgScore =
    resultado.indiceGeralConformidade >= 85
      ? 'bg-emerald-500/10 border-emerald-500/30'
      : resultado.indiceGeralConformidade >= 70
      ? 'bg-amber-500/10 border-amber-500/30'
      : 'bg-rose-500/10 border-rose-500/30';

  return (
    <div className="space-y-6 pb-12">
      {/* ========================================================================= */}
      {/* 1. CABEÇALHO DO MÓDULO & CONTROLES EXECUTIVOS */}
      {/* ========================================================================= */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 lg:p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-gradient-to-br from-indigo-500 to-indigo-700 text-white shadow-sm">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl lg:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
                  Dashboard de Conformidade Fiscal
                  <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                    Visão Geral do Escritório
                  </span>
                </h1>
                <p className="text-sm text-slate-600 dark:text-slate-400 mt-0.5">
                  Consolidação estratégica de prazos do Simples Nacional, obrigações MEI e pendências do e-CAC / RFB.
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Feedback de Sincronização */}
            {syncFeedback && (
              <span className="text-xs font-medium px-3 py-1.5 rounded-lg bg-indigo-50 text-indigo-700 dark:bg-indigo-950/80 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 animate-pulse flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 animate-spin" />
                {syncFeedback}
              </span>
            )}

            <button
              onClick={handleSincronizarGeral}
              disabled={loading}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-xl text-slate-700 dark:text-slate-200 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 transition"
              title="Recarregar pendências e obrigações da SEFAZ e RFB"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span>Sincronizar Bases</span>
            </button>

            <button
              onClick={() => setModalRelatorioAberto(true)}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-xl text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm transition"
            >
              <Printer className="w-4 h-4" />
              <span>Relatório Executivo</span>
            </button>
          </div>
        </div>

        {/* Barra de Filtros Interativos */}
        <div className="mt-5 pt-5 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Seletor de Empresa */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
              Empresa / Cliente
            </label>
            <div className="relative">
              <select
                value={filtroEmpresaId}
                onChange={(e) => setFiltroEmpresaId(e.target.value)}
                className="w-full text-sm font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              >
                <option value="todas">🏢 Todas as Empresas ({empresas.length})</option>
                {empresas.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.nomeFantasia || emp.razaoSocial} ({emp.regimeTributario})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Seletor de Regime Tributário */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
              Regime Tributário
            </label>
            <select
              value={filtroRegime}
              onChange={(e) => setFiltroRegime(e.target.value)}
              className="w-full text-sm font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
            >
              <option value="todos">Todos os Regimes</option>
              <option value="Simples Nacional">Simples Nacional</option>
              <option value="MEI">MEI (Microempreendedor)</option>
              <option value="Lucro Presumido">Lucro Presumido</option>
              <option value="Lucro Real">Lucro Real</option>
            </select>
          </div>

          {/* Seletor de Ano Calendário */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
              Ano-Calendário
            </label>
            <select
              value={filtroAno}
              onChange={(e) => setFiltroAno(parseInt(e.target.value, 10))}
              className="w-full text-sm font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
            >
              <option value={2026}>Exercício 2026 (Atual)</option>
              <option value={2025}>Exercício 2025 (Anterior)</option>
            </select>
          </div>

          {/* Filtro de Grau de Risco */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
              Grau de Risco Fiscal
            </label>
            <select
              value={filtroRisco}
              onChange={(e) => setFiltroRisco(e.target.value as any)}
              className="w-full text-sm font-medium rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
            >
              <option value="todos">Todos os Riscos</option>
              <option value="critico">🚨 Crítico (Ação Imediata)</option>
              <option value="alto">⚠️ Alto Risco</option>
              <option value="medio">🟡 Médio Risco</option>
              <option value="baixo">✅ Baixo Risco (Regular)</option>
            </select>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. CARDS DE INDICADORES CHAVE (KPIS) */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Índice Global de Conformidade */}
        <div className={`p-5 rounded-2xl border ${bgScore} transition-all`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400">
              Índice de Conformidade
            </span>
            <ShieldCheck className={`w-5 h-5 ${corScore}`} />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className={`text-3xl font-extrabold ${corScore}`}>
              {resultado.indiceGeralConformidade}%
            </span>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              {resultado.statusCarteira === 'excelente'
                ? 'Nível Pleno'
                : resultado.statusCarteira === 'atencao'
                ? 'Atenção Requerida'
                : 'Risco Alto'}
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 pt-2.5 border-t border-slate-200/50 dark:border-slate-700/50">
            <span>
              <strong>{resultado.empresasRegulares}</strong> regulares
            </span>
            <span>
              <strong>{resultado.empresasAlerta}</strong> em alerta
            </span>
            <span className="text-rose-600 dark:text-rose-400 font-bold">
              {resultado.empresasCriticas} críticas
            </span>
          </div>
        </div>

        {/* Card 2: Simples Nacional & PGDAS-D */}
        <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Simples Nacional & PGDAS
            </span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
              {resultado.simplesNacional.totalEmpresas} empresas
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 dark:text-white">
              {resultado.simplesNacional.apuracoesTransmitidas}
            </span>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              transmitidas à RFB
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2.5 border-t border-slate-100 dark:border-slate-800">
            <span className="flex items-center gap-1 font-medium text-indigo-600 dark:text-indigo-400">
              <Clock className="w-3.5 h-3.5" />
              DAS Vence dia 20 ({resultado.simplesNacional.diasAteVencimento}d)
            </span>
            <button
              onClick={() => onNavigate('simples_nacional')}
              className="text-xs font-bold text-slate-700 dark:text-slate-200 hover:text-indigo-600 dark:hover:text-indigo-400 inline-flex items-center"
            >
              Ver PGDAS <ChevronRight className="w-3 h-3 ml-0.5" />
            </button>
          </div>
        </div>

        {/* Card 3: Fechamento MEI & DAS-MEI */}
        <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Obrigações MEI (PGMEI)
            </span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
              {resultado.mei.totalEmpresas} MEIs
            </span>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900 dark:text-white">
              {resultado.mei.guiasPagas}
            </span>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              guias quitadas ({Math.round((resultado.mei.guiasPagas / Math.max(1, resultado.mei.totalGuiasAno)) * 100)}%)
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2.5 border-t border-slate-100 dark:border-slate-800">
            <span>
              <strong>{resultado.mei.declaracoesTransmitidas}</strong> DASN entregue(s)
            </span>
            <button
              onClick={() => onNavigate('mei')}
              className="text-xs font-bold text-slate-700 dark:text-slate-200 hover:text-amber-600 dark:hover:text-amber-400 inline-flex items-center"
            >
              Ver MEI <ChevronRight className="w-3 h-3 ml-0.5" />
            </button>
          </div>
        </div>

        {/* Card 4: Pendências e-CAC / RFB */}
        <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Pendências e-CAC / RFB
            </span>
            {resultado.ecac.pendenciasCriticas > 0 && (
              <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 animate-pulse">
                {resultado.ecac.pendenciasCriticas} críticas
              </span>
            )}
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-rose-600 dark:text-rose-400">
              {resultado.ecac.totalPendenciasAtivas}
            </span>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              em aberto no e-CAC
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2.5 border-t border-slate-100 dark:border-slate-800">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              R$ {resultado.ecac.valorTotalEnvolvido.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </span>
            <button
              onClick={() => onNavigate('ecac_pendencias')}
              className="text-xs font-bold text-rose-600 dark:text-rose-400 hover:underline inline-flex items-center"
            >
              Sanear <ChevronRight className="w-3 h-3 ml-0.5" />
            </button>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. FUNIS DE STATUS DE CONFORMIDADE (STATUS FUNNELS) */}
      {/* ========================================================================= */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 lg:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              Funis de Status Operacional
            </h2>
            <p className="text-xs lg:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
              Acompanhamento passo a passo do fluxo de cumprimento tributário e detecção de gargalos.
            </p>
          </div>

          {/* Abas dos Funis */}
          <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-medium">
            <button
              onClick={() => setAbaFunilAtiva('todos')}
              className={`px-3 py-1.5 rounded-lg transition ${
                abaFunilAtiva === 'todos'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white font-bold shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Todos os Funis
            </button>
            <button
              onClick={() => setAbaFunilAtiva('simples')}
              className={`px-3 py-1.5 rounded-lg transition ${
                abaFunilAtiva === 'simples'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white font-bold shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Simples Nacional
            </button>
            <button
              onClick={() => setAbaFunilAtiva('mei')}
              className={`px-3 py-1.5 rounded-lg transition ${
                abaFunilAtiva === 'mei'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white font-bold shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              MEI & DASN
            </button>
            <button
              onClick={() => setAbaFunilAtiva('ecac')}
              className={`px-3 py-1.5 rounded-lg transition ${
                abaFunilAtiva === 'ecac'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white font-bold shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              e-CAC & Saneamento
            </button>
          </div>
        </div>

        {/* Visualização dos Funis */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Funil 1: Simples Nacional */}
          {(abaFunilAtiva === 'todos' || abaFunilAtiva === 'simples') && (
            <div className={`space-y-3 ${abaFunilAtiva === 'simples' ? 'lg:col-span-3' : ''}`}>
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">
                    Funil Simples Nacional & PGDAS-D
                  </h4>
                </div>
                <span className="text-xs text-slate-500 font-medium">5 Etapas</span>
              </div>
              <div className="space-y-2.5">
                {resultado.simplesNacional.funil.map((etapa, idx) =>
                  renderCardFunil(etapa, idx, resultado.simplesNacional.funil.length, '#10b981')
                )}
              </div>
            </div>
          )}

          {/* Funil 2: MEI & DASN */}
          {(abaFunilAtiva === 'todos' || abaFunilAtiva === 'mei') && (
            <div className={`space-y-3 ${abaFunilAtiva === 'mei' ? 'lg:col-span-3' : ''}`}>
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">
                    Funil de Regularidade MEI
                  </h4>
                </div>
                <span className="text-xs text-slate-500 font-medium">5 Etapas</span>
              </div>
              <div className="space-y-2.5">
                {resultado.mei.funil.map((etapa, idx) =>
                  renderCardFunil(etapa, idx, resultado.mei.funil.length, '#f59e0b')
                )}
              </div>
            </div>
          )}

          {/* Funil 3: Saneamento e-CAC */}
          {(abaFunilAtiva === 'todos' || abaFunilAtiva === 'ecac') && (
            <div className={`space-y-3 ${abaFunilAtiva === 'ecac' ? 'lg:col-span-3' : ''}`}>
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">
                    Funil de Saneamento e-CAC / RFB
                  </h4>
                </div>
                <span className="text-xs text-slate-500 font-medium">4 Etapas</span>
              </div>
              <div className="space-y-2.5">
                {resultado.ecac.funil.map((etapa, idx) =>
                  renderCardFunil(etapa, idx, resultado.ecac.funil.length, '#ef4444')
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. GRÁFICOS DE BARRAS DE PRAZOS E EXPOSIÇÃO (RECHARTS) */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gráfico 1: Prazos e Entregas Mensais por Competência */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 lg:p-6 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                Prazos & Entregas Mensais por Competência
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Volume de apurações PGDAS e guias DAS-MEI concluídas vs pendentes no ano {filtroAno}
              </p>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={resultado.evolucaoMensal}
                margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis dataKey="mes" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip
                  formatter={(val: any, name: any) => {
                    const labels: Record<string, string> = {
                      simplesTransmitidos: 'Simples Transmitido',
                      simplesPendentes: 'Simples Pendente',
                      meiGuiasPagas: 'DAS-MEI Paga',
                      meiGuiasPendentes: 'DAS-MEI Pendente',
                    };
                    return [val, labels[name] || name];
                  }}
                  contentStyle={{
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    borderColor: '#334155',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Legend
                  wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }}
                  formatter={(value) => {
                    const mapNames: Record<string, string> = {
                      simplesTransmitidos: 'Simples Entregue',
                      simplesPendentes: 'Simples Pendente',
                      meiGuiasPagas: 'MEI Pago',
                      meiGuiasPendentes: 'MEI Pendente',
                    };
                    return mapNames[value] || value;
                  }}
                />
                <Bar dataKey="simplesTransmitidos" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="simplesPendentes" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                <Bar dataKey="meiGuiasPagas" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="meiGuiasPendentes" fill="#a855f7" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Gráfico 2: Exposição Financeira e Débitos por Órgão no e-CAC */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 lg:p-6 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <AlertOctagon className="w-5 h-5 text-rose-600 dark:text-rose-400" />
                Exposição Financeira no e-CAC por Órgão
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Valores apontados em malha fiscal, parcelamentos ou dívida ativa (RFB/PGFN)
              </p>
            </div>
            <span className="text-xs font-bold text-rose-700 dark:text-rose-400 bg-rose-50 dark:bg-rose-950 px-2.5 py-1 rounded-lg border border-rose-200 dark:border-rose-900">
              Total: R$ {resultado.ecac.valorTotalEnvolvido.toLocaleString('pt-BR', { minimumFractionDigits: 0 })}
            </span>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                layout="vertical"
                data={resultado.ecac.distribuicaoPorOrgao}
                margin={{ top: 10, right: 20, left: 30, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                <XAxis
                  type="number"
                  tickFormatter={(val) => `R$ ${(val / 1000).toFixed(0)}k`}
                  tick={{ fontSize: 11 }}
                />
                <YAxis
                  dataKey="orgao"
                  type="category"
                  tick={{ fontSize: 11 }}
                  width={100}
                />
                <Tooltip
                  formatter={(val: any) => [
                    `R$ ${Number(val).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
                    'Valor Envolvido',
                  ]}
                  contentStyle={{
                    backgroundColor: 'rgba(15, 23, 42, 0.95)',
                    borderColor: '#334155',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="valorTotal" fill="#ef4444" radius={[0, 4, 4, 0]}>
                  {resultado.ecac.distribuicaoPorOrgao.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={index === 0 ? '#ef4444' : index === 1 ? '#f97316' : '#eab308'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 5. MATRIZ OPERACIONAL DE PRAZOS & AÇÕES PRIORITÁRIAS POR EMPRESA */}
      {/* ========================================================================= */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="p-5 lg:p-6 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Building2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              Matriz Operacional da Carteira & Ações Prioritárias
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Visão consolidada por cliente com atalhos de resolução rápida de prazos e pendências.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={buscaTexto}
                onChange={(e) => setBuscaTexto(e.target.value)}
                placeholder="Buscar por nome ou CNPJ..."
                className="text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 pl-9 pr-3 py-2 text-slate-800 dark:text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 w-52 sm:w-64"
              />
            </div>
            {buscaTexto && (
              <button
                onClick={() => setBuscaTexto('')}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Tabela de Empresas */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="bg-slate-50/75 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-xs uppercase tracking-wider">
                <th className="py-3 px-4">Empresa / CNPJ</th>
                <th className="py-3 px-3">Regime</th>
                <th className="py-3 px-3 text-center">Score Fiscal</th>
                <th className="py-3 px-3">Status Simples (PGDAS)</th>
                <th className="py-3 px-3">Status MEI (PGMEI/DASN)</th>
                <th className="py-3 px-3">e-CAC / RFB</th>
                <th className="py-3 px-3">Ação Prioritária</th>
                <th className="py-3 px-4 text-right">Ação Direta</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {empresasTabela.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-10 text-slate-400 text-sm">
                    Nenhuma empresa encontrada com os filtros selecionados.
                  </td>
                </tr>
              ) : (
                empresasTabela.map((emp) => {
                  const badgeRisco =
                    emp.grauRisco === 'critico'
                      ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 border-rose-200'
                      : emp.grauRisco === 'alto'
                      ? 'bg-orange-100 text-orange-700 dark:bg-orange-950 dark:text-orange-300 border-orange-200'
                      : emp.grauRisco === 'medio'
                      ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border-amber-200'
                      : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-200';

                  return (
                    <tr
                      key={emp.empresaId}
                      className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition"
                    >
                      {/* Empresa */}
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900 dark:text-white">
                          {emp.nomeFantasia || emp.razaoSocial}
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                          {emp.cnpj}
                        </div>
                      </td>

                      {/* Regime */}
                      <td className="py-3 px-3">
                        <span className="inline-block px-2 py-0.5 rounded-md text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {emp.regimeTributario}
                        </span>
                      </td>

                      {/* Score */}
                      <td className="py-3 px-3 text-center">
                        <span
                          className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold border ${badgeRisco}`}
                        >
                          {emp.scoreConformidade}%
                        </span>
                      </td>

                      {/* Simples */}
                      <td className="py-3 px-3">
                        {emp.regimeTributario === 'Simples Nacional' ? (
                          emp.simplesStatus === 'concluido' ? (
                            <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              Transmitido ({emp.simplesCompetencia})
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-600 dark:text-amber-400">
                              <AlertTriangle className="w-3.5 h-3.5" />
                              Pendente dia 20
                            </span>
                          )
                        ) : (
                          <span className="text-slate-400 text-xs">—</span>
                        )}
                      </td>

                      {/* MEI */}
                      <td className="py-3 px-3">
                        {emp.regimeTributario === 'MEI' ? (
                          <div className="space-y-0.5">
                            <span
                              className={`inline-flex items-center gap-1 text-xs font-semibold ${
                                emp.meiStatus === 'em_dia'
                                  ? 'text-emerald-600 dark:text-emerald-400'
                                  : 'text-amber-600 dark:text-amber-400'
                              }`}
                            >
                              {emp.meiStatus === 'em_dia' ? 'Guias em dia' : 'Guia em aberto'}
                            </span>
                            <div className="text-[11px] text-slate-500">
                              DASN: {emp.meiDasnStatus === 'transmitida' ? '✅ Entregue' : '⏳ Pendente'}
                            </div>
                          </div>
                        ) : (
                          <span className="text-slate-400 text-xs">—</span>
                        )}
                      </td>

                      {/* e-CAC */}
                      <td className="py-3 px-3">
                        {emp.pendenciasEcacTotal > 0 ? (
                          <div className="space-y-0.5">
                            <span
                              className={`inline-flex items-center gap-1 text-xs font-bold ${
                                emp.pendenciasEcacCriticas > 0
                                  ? 'text-rose-600 dark:text-rose-400'
                                  : 'text-amber-600 dark:text-amber-400'
                              }`}
                            >
                              <AlertOctagon className="w-3.5 h-3.5" />
                              {emp.pendenciasEcacTotal} pendência(s)
                            </span>
                            {emp.valorEcacEnvolvido > 0 && (
                              <div className="text-[11px] text-slate-500">
                                R$ {emp.valorEcacEnvolvido.toLocaleString('pt-BR', { minimumFractionDigits: 0 })}
                              </div>
                            )}
                          </div>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            CND Regular
                          </span>
                        )}
                      </td>

                      {/* Ação Prioritária */}
                      <td className="py-3 px-3">
                        <span className="text-xs font-medium text-slate-700 dark:text-slate-300 line-clamp-1">
                          {emp.proximaAcao}
                        </span>
                      </td>

                      {/* Ação Direta */}
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => onNavigate(emp.linkAcao, emp.empresaId)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-950/80 dark:hover:bg-indigo-900 dark:text-indigo-300 transition"
                          title="Abrir módulo correspondente"
                        >
                          <span>Acessar</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 6. MODAL DE RELATÓRIO EXECUTIVO DE CONFORMIDADE FISCAL */}
      {/* ========================================================================= */}
      {modalRelatorioAberto && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-slate-200 dark:border-slate-800 shadow-2xl">
            {/* Topo do Modal */}
            <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between sticky top-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs z-10">
              <div className="flex items-center gap-2.5">
                <FileSpreadsheet className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Relatório Executivo de Conformidade Fiscal do Escritório
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Imprimir / Salvar PDF
                </button>
                <button
                  onClick={() => setModalRelatorioAberto(false)}
                  className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Conteúdo do Relatório */}
            <div className="p-6 space-y-6 text-slate-800 dark:text-slate-200">
              {/* Cabeçalho do Relatório */}
              <div className="border-b border-slate-200 dark:border-slate-700 pb-4 flex justify-between items-start">
                <div>
                  <h4 className="text-xl font-bold text-slate-900 dark:text-white">
                    Auditoria Periódica de Saúde Tributária & Prazos
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Competência Referencial: Exercício {filtroAno} | Emissão: {new Date().toLocaleDateString('pt-BR')} às {new Date().toLocaleTimeString('pt-BR')}
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-xs uppercase font-bold text-slate-400">Score Global</div>
                  <div className="text-2xl font-black text-indigo-600 dark:text-indigo-400">
                    {resultado.indiceGeralConformidade}%
                  </div>
                </div>
              </div>

              {/* Quadro Resumo */}
              <div className="grid grid-cols-3 gap-4">
                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                  <span className="text-xs font-semibold text-slate-500 block">Simples Nacional</span>
                  <span className="text-lg font-bold text-slate-900 dark:text-white mt-1 block">
                    {resultado.simplesNacional.apuracoesTransmitidas} de {resultado.simplesNacional.totalEmpresas} entregues
                  </span>
                  <span className="text-xs text-emerald-600 font-medium">
                    Próximo Vencimento: 20 do mês
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                  <span className="text-xs font-semibold text-slate-500 block">Microempreendedor (MEI)</span>
                  <span className="text-lg font-bold text-slate-900 dark:text-white mt-1 block">
                    {resultado.mei.guiasPagas} guias quitadas
                  </span>
                  <span className="text-xs text-slate-500 font-medium">
                    {resultado.mei.declaracoesTransmitidas} DASN-SIMEI transmitidas
                  </span>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
                  <span className="text-xs font-semibold text-slate-500 block">Exposição e-CAC</span>
                  <span className="text-lg font-bold text-rose-600 dark:text-rose-400 mt-1 block">
                    R$ {resultado.ecac.valorTotalEnvolvido.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </span>
                  <span className="text-xs text-slate-500 font-medium">
                    {resultado.ecac.totalPendenciasAtivas} apontamentos em aberto
                  </span>
                </div>
              </div>

              {/* Tabela Resumo para o Contador */}
              <div>
                <h5 className="font-bold text-sm text-slate-900 dark:text-white mb-2">
                  Diagnóstico por Empresa e Recomendações
                </h5>
                <div className="border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 dark:bg-slate-800 font-semibold text-slate-700 dark:text-slate-300">
                      <tr>
                        <th className="p-2.5">Empresa</th>
                        <th className="p-2.5">Regime</th>
                        <th className="p-2.5">Score</th>
                        <th className="p-2.5">Pendências e-CAC</th>
                        <th className="p-2.5">Recomendação Operacional</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {resultado.resumoEmpresas.map((emp) => (
                        <tr key={emp.empresaId}>
                          <td className="p-2.5 font-medium">{emp.nomeFantasia || emp.razaoSocial}</td>
                          <td className="p-2.5">{emp.regimeTributario}</td>
                          <td className="p-2.5 font-bold">{emp.scoreConformidade}%</td>
                          <td className="p-2.5">
                            {emp.pendenciasEcacTotal > 0
                              ? `${emp.pendenciasEcacTotal} (${emp.pendenciasEcacCriticas} críticas)`
                              : 'Regular'}
                          </td>
                          <td className="p-2.5 text-slate-600 dark:text-slate-300 font-medium">
                            {emp.proximaAcao}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Termo de Encerramento */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-400 flex justify-between">
                <span>Relatório gerado automaticamente pelo Sistema Integrado de Gestão Contábil.</span>
                <span>Página 1 de 1</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
