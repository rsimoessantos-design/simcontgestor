import React, { useState, useMemo, useEffect } from 'react';
import {
  Bell,
  MessageCircle,
  Mail,
  Play,
  Pause,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Send,
  Sliders,
  FileText,
  History,
  RotateCcw,
  Sparkles,
  Eye,
  Smartphone,
  Copy,
  Plus,
  Trash2,
  Filter,
  Check,
  Building2,
  DollarSign,
  Calendar,
  ExternalLink,
} from 'lucide-react';
import {
  Empresa,
  ContratoHonorario,
  MensalidadeHonorario,
  RegraLembreteCobranca,
  LogEnvioLembrete,
  LembreteFilaItem,
} from '../types';
import {
  REGRAS_LEMBRETES_PADRAO,
  carregarRegrasStorage,
  salvarRegrasStorage,
  carregarLogsStorage,
  salvarLogStorage,
  avaliarFilaLembretes,
  compilarTemplateMensagem,
  gerarUrlWhatsApp,
  gerarMailto,
} from '../utils/lembretesCobrancaUtils';
import { ModalDisparoLembrete } from './ModalDisparoLembrete';
import { api } from '../services/api';

interface AbaLembretesAutomaticosProps {
  mensalidades: MensalidadeHonorario[];
  empresas: Empresa[];
  contratos: ContratoHonorario[];
  onAtualizarMensalidade: (mensalidade: MensalidadeHonorario) => void;
  onFeedback: (mensagem: string) => void;
}

export const AbaLembretesAutomaticos: React.FC<AbaLembretesAutomaticosProps> = ({
  mensalidades,
  empresas,
  contratos,
  onAtualizarMensalidade,
  onFeedback,
}) => {
  // Sub-abas internas
  const [subAbaAtiva, setSubAbaAtiva] = useState<'fila' | 'regua' | 'templates' | 'logs'>('fila');

  // Estado da automação (Robô ativo/pausado)
  const [automacaoAtiva, setAutomacaoAtiva] = useState<boolean>(() => {
    const salvo = localStorage.getItem('contabgest_automacao_ativa');
    return salvo !== null ? salvo === 'true' : true;
  });

  const handleToggleAutomacao = () => {
    const novoValor = !automacaoAtiva;
    setAutomacaoAtiva(novoValor);
    localStorage.setItem('contabgest_automacao_ativa', String(novoValor));
    onFeedback(
      novoValor
        ? 'Robô de Lembretes Automáticos ATIVADO! Varreduras automáticas em execução.'
        : 'Robô de Lembretes Automáticos PAUSADO.'
    );
  };

  // Regras da Régua
  const [regras, setRegras] = useState<RegraLembreteCobranca[]>(carregarRegrasStorage);

  // Logs de Disparos
  const [logs, setLogs] = useState<LogEnvioLembrete[]>(carregarLogsStorage);

  // Data de referência do sistema (2026-09-17)
  const dataReferenciaHoje = '2026-09-17';

  // Fila calculada de lembretes elegíveis hoje
  const filaLembretes = useMemo(() => {
    return avaliarFilaLembretes(
      mensalidades,
      empresas,
      contratos,
      regras,
      dataReferenciaHoje
    );
  }, [mensalidades, empresas, contratos, regras]);

  // Filtros na Fila
  const [filtroTipo, setFiltroTipo] = useState<'todos' | 'preventivo' | 'vencimento' | 'atraso'>('todos');
  const [filtroStatusEnvio, setFiltroStatusEnvio] = useState<'todos' | 'pendentes' | 'enviados'>('todos');
  const [buscaCliente, setBuscaCliente] = useState('');

  const filaFiltrada = useMemo(() => {
    return filaLembretes.filter((item) => {
      if (filtroTipo !== 'todos' && item.tipo !== filtroTipo) return false;
      if (filtroStatusEnvio === 'pendentes' && item.jaEnviadoHoje) return false;
      if (filtroStatusEnvio === 'enviados' && !item.jaEnviadoHoje) return false;
      if (buscaCliente.trim()) {
        const q = buscaCliente.toLowerCase();
        const nome = (item.empresa.nomeFantasia || item.empresa.razaoSocial).toLowerCase();
        const cnpj = item.empresa.cnpj.toLowerCase();
        return nome.includes(q) || cnpj.includes(q);
      }
      return true;
    });
  }, [filaLembretes, filtroTipo, filtroStatusEnvio, buscaCliente]);

  // Seleção múltipla para lote
  const [selecionadosIds, setSelecionadosIds] = useState<string[]>([]);

  const handleToggleSelectAll = () => {
    if (selecionadosIds.length === filaFiltrada.length && filaFiltrada.length > 0) {
      setSelecionadosIds([]);
    } else {
      setSelecionadosIds(filaFiltrada.map((item) => item.mensalidade.id));
    }
  };

  const handleToggleSelectRow = (id: string) => {
    setSelecionadosIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  // Modal de Disparo Individual
  const [modalDisparoOpen, setModalDisparoOpen] = useState(false);
  const [itemParaDisparo, setItemParaDisparo] = useState<LembreteFilaItem | null>(null);

  const handleAbrirDisparoIndividual = (item: LembreteFilaItem) => {
    setItemParaDisparo(item);
    setModalDisparoOpen(true);
  };

  // Disparo Rápido WhatsApp (1 clique)
  const handleDisparoRapidoWhatsApp = async (item: LembreteFilaItem) => {
    try {
      const urlWa = gerarUrlWhatsApp(item.destinatarioWhatsApp, item.mensagemFormatada);
      window.open(urlWa, '_blank');

      await confirmarEnvioBackend(
        item.mensalidade.id,
        'whatsapp',
        item.destinatarioWhatsApp,
        item.mensagemFormatada,
        'disparo_manual'
      );
      onFeedback(`Lembrete WhatsApp aberto e registrado para ${item.empresa.razaoSocial}!`);
    } catch (e: any) {
      onFeedback(`Erro ao registrar envio: ${e.message}`);
    }
  };

  // Disparo Rápido E-mail (1 clique)
  const handleDisparoRapidoEmail = async (item: LembreteFilaItem) => {
    try {
      const urlMail = gerarMailto(
        item.destinatarioEmail,
        item.assuntoFormatado,
        item.mensagemFormatada
      );
      window.location.href = urlMail;

      await confirmarEnvioBackend(
        item.mensalidade.id,
        'email',
        item.destinatarioEmail,
        item.mensagemFormatada,
        'disparo_manual'
      );
      onFeedback(`Lembrete por E-mail registrado para ${item.empresa.razaoSocial}!`);
    } catch (e: any) {
      onFeedback(`Erro ao registrar envio: ${e.message}`);
    }
  };

  // Confirmar Envio (atualiza API, histórico e logs)
  const confirmarEnvioBackend = async (
    mensalidadeId: string,
    canal: 'whatsapp' | 'email',
    destinatario: string,
    mensagemEnviada: string,
    origem: 'robo_automatico' | 'disparo_manual' = 'disparo_manual'
  ) => {
    const item = filaLembretes.find((f) => f.mensalidade.id === mensalidadeId);
    if (!item) return;

    // Chamada à API
    const resp = await api.enviarCobranca(mensalidadeId, canal, destinatario);
    if (resp && resp.mensalidade) {
      onAtualizarMensalidade(resp.mensalidade);
    }

    // Cria Log
    const novoLog: LogEnvioLembrete = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      mensalidadeId,
      empresaId: item.empresa.id,
      clienteNome: item.empresa.nomeFantasia || item.empresa.razaoSocial,
      valor: item.mensalidade.valor,
      competencia: item.mensalidade.competencia,
      dataVencimento: item.mensalidade.dataVencimento,
      tipoLembrete: item.tipo,
      diasReferencia: item.diasDiferenca,
      canal,
      destinatario,
      dataHoraEnvio: new Date().toISOString(),
      status: 'entregue',
      origem,
      mensagemEnviada,
    };

    salvarLogStorage(novoLog);
    setLogs((prev) => [novoLog, ...prev]);
  };

  // Disparo em Lote Automatizado (O Robô em Ação)
  const [modalLoteRoboOpen, setModalLoteRoboOpen] = useState(false);
  const [processandoLote, setProcessandoLote] = useState(false);
  const [progressoLote, setProgressoLote] = useState({ total: 0, concluidos: 0 });
  const [canalLote, setCanalLote] = useState<'preferencial' | 'whatsapp' | 'email' | 'ambos'>('preferencial');
  const [apenasNaoEnviadosLote, setApenasNaoEnviadosLote] = useState(true);

  const itensAlvoLote = useMemo(() => {
    let base = selecionadosIds.length > 0
      ? filaFiltrada.filter((i) => selecionadosIds.includes(i.mensalidade.id))
      : filaFiltrada;

    if (apenasNaoEnviadosLote) {
      base = base.filter((i) => !i.jaEnviadoHoje);
    }
    return base;
  }, [filaFiltrada, selecionadosIds, apenasNaoEnviadosLote]);

  const handleExecutarLoteRobo = async () => {
    if (itensAlvoLote.length === 0) {
      onFeedback('Nenhum lembrete pendente para disparo no lote selecionado.');
      return;
    }

    setProcessandoLote(true);
    setProgressoLote({ total: itensAlvoLote.length, concluidos: 0 });

    try {
      for (let i = 0; i < itensAlvoLote.length; i++) {
        const item = itensAlvoLote[i];

        // Determinar canal a disparar
        let canalEfetivo: 'whatsapp' | 'email' = 'whatsapp';
        if (canalLote === 'preferencial') {
          canalEfetivo = item.canalSugerido === 'email' ? 'email' : 'whatsapp';
        } else if (canalLote === 'email') {
          canalEfetivo = 'email';
        } else if (canalLote === 'whatsapp') {
          canalEfetivo = 'whatsapp';
        } else if (canalLote === 'ambos') {
          // Dispara ambos
          await confirmarEnvioBackend(
            item.mensalidade.id,
            'whatsapp',
            item.destinatarioWhatsApp,
            item.mensagemFormatada,
            'robo_automatico'
          );
          canalEfetivo = 'email';
        }

        const dest = canalEfetivo === 'whatsapp' ? item.destinatarioWhatsApp : item.destinatarioEmail;
        await confirmarEnvioBackend(
          item.mensalidade.id,
          canalEfetivo,
          dest,
          item.mensagemFormatada,
          'robo_automatico'
        );

        setProgressoLote({ total: itensAlvoLote.length, concluidos: i + 1 });
        // Pequeno intervalo entre requisições
        await new Promise((r) => setTimeout(r, 120));
      }

      onFeedback(
        `Disparo em Lote Concluído com Sucesso! ${itensAlvoLote.length} clientes notificados automaticamente.`
      );
      setModalLoteRoboOpen(false);
      setSelecionadosIds([]);
    } catch (err: any) {
      onFeedback(`Erro durante o processamento do lote: ${err.message}`);
    } finally {
      setProcessandoLote(false);
    }
  };

  // Estado para Edição de Templates
  const [templateSelecionadoId, setTemplateSelecionadoId] = useState<string>(regras[0]?.id || '');
  const regraTemplateAtual = useMemo(() => {
    return regras.find((r) => r.id === templateSelecionadoId) || regras[0];
  }, [regras, templateSelecionadoId]);

  const [templateMensagemEdit, setTemplateMensagemEdit] = useState(
    regraTemplateAtual?.templateMensagem || ''
  );
  const [templateAssuntoEdit, setTemplateAssuntoEdit] = useState(
    regraTemplateAtual?.templateAssunto || ''
  );

  useEffect(() => {
    if (regraTemplateAtual) {
      setTemplateMensagemEdit(regraTemplateAtual.templateMensagem);
      setTemplateAssuntoEdit(regraTemplateAtual.templateAssunto);
    }
  }, [regraTemplateAtual]);

  const handleInserirVariavel = (tag: string) => {
    setTemplateMensagemEdit((prev) => `${prev} ${tag}`);
  };

  const handleSalvarTemplateAtual = () => {
    const atualizadas = regras.map((r) => {
      if (r.id === templateSelecionadoId) {
        return {
          ...r,
          templateMensagem: templateMensagemEdit,
          templateAssunto: templateAssuntoEdit,
        };
      }
      return r;
    });
    setRegras(atualizadas);
    salvarRegrasStorage(atualizadas);
    onFeedback('Modelo de mensagem salvo com sucesso!');
  };

  // Preview ao vivo da mensagem no simulador de celular
  const previewAoVivoTexto = useMemo(() => {
    const exemploEmpresa = empresas[0] || {
      razaoSocial: 'Padaria e Confeitaria Estrela do Bairro Ltda',
      nomeFantasia: 'Padaria Estrela',
      cnpj: '12.345.678/0001-90',
    };
    return compilarTemplateMensagem(templateMensagemEdit, {
      cliente: exemploEmpresa.nomeFantasia || exemploEmpresa.razaoSocial,
      valor: 850,
      vencimento: '2026-09-20',
      competencia: '09/2026',
      pix: 'financeiro@contabgest.com.br',
      codigoBarras: '34191.79001 01043.510047 91020.150008 7 98350000085000',
      diasAtraso: regraTemplateAtual?.tipo === 'atraso' ? 4 : 0,
      escritorio: 'ContabGest Contabilidade & Auditoria',
    });
  }, [templateMensagemEdit, empresas, regraTemplateAtual]);

  // Salvar Regras da Régua
  const handleToggleRegraAtiva = (regraId: string) => {
    const atualizadas = regras.map((r) =>
      r.id === regraId ? { ...r, ativo: !r.ativo } : r
    );
    setRegras(atualizadas);
    salvarRegrasStorage(atualizadas);
  };

  const handleChangeRegraCanal = (regraId: string, canal: 'whatsapp' | 'email' | 'ambos') => {
    const atualizadas = regras.map((r) =>
      r.id === regraId ? { ...r, canalPadrao: canal } : r
    );
    setRegras(atualizadas);
    salvarRegrasStorage(atualizadas);
  };

  const handleRestaurarPadroes = () => {
    if (window.confirm('Deseja restaurar todas as regras e templates para os padrões recomendados de escritório contábil?')) {
      setRegras(REGRAS_LEMBRETES_PADRAO);
      salvarRegrasStorage(REGRAS_LEMBRETES_PADRAO);
      onFeedback('Régua e templates restaurados para o padrão contábil!');
    }
  };

  // Limpar Logs
  const handleLimparLogs = () => {
    if (window.confirm('Tem certeza que deseja limpar todo o histórico de logs de envios?')) {
      localStorage.removeItem('contabgest_logs_lembretes_v1');
      setLogs([]);
      onFeedback('Histórico de logs de lembretes limpo.');
    }
  };

  // Modal para ver mensagem do Log
  const [logMensagemModal, setLogMensagemModal] = useState<LogEnvioLembrete | null>(null);

  // Formatação de moeda
  const fmtMoeda = (v: number) =>
    v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  // Contadores de métricas da Fila
  const metricasFila = useMemo(() => {
    const preventivos = filaLembretes.filter((i) => i.tipo === 'preventivo').length;
    const vencimentoHoje = filaLembretes.filter((i) => i.tipo === 'vencimento').length;
    const atrasados = filaLembretes.filter((i) => i.tipo === 'atraso').length;
    const jaEnviadosHoje = filaLembretes.filter((i) => i.jaEnviadoHoje).length;
    const pendentesEnvio = filaLembretes.filter((i) => !i.jaEnviadoHoje).length;

    return {
      total: filaLembretes.length,
      preventivos,
      vencimentoHoje,
      atrasados,
      jaEnviadosHoje,
      pendentesEnvio,
    };
  }, [filaLembretes]);

  return (
    <div id="aba-lembretes-automaticos" className="space-y-6">
      {/* ========================================================================= */}
      {/* 1. CARD SUPERIOR: ROBÔ DE LEMBRETES AUTOMÁTICOS                           */}
      {/* ========================================================================= */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white rounded-2xl p-6 shadow-md border border-slate-700/60">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <Bell className="w-5 h-5" />
              </span>
              <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
                Sistema Inteligente de Lembretes & Cobranças Automáticas
              </h2>
              {automacaoAtiva ? (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  Robô Operando
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                  Pausado
                </span>
              )}
            </div>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Disparo automático de notificações preventivas antes do vencimento e cobranças formais de
              inadimplência via <strong>WhatsApp Web</strong> e <strong>E-mail</strong> com chave Pix Copia e Cola,
              código de barras e atualização em tempo real do histórico financeiro.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            {/* Toggle Switch da Automação */}
            <button
              id="btn-toggle-automacao"
              onClick={handleToggleAutomacao}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer ${
                automacaoAtiva
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  : 'bg-slate-700 hover:bg-slate-600 text-slate-200'
              }`}
            >
              {automacaoAtiva ? (
                <>
                  <Pause className="w-4 h-4" />
                  Pausar Robô Automático
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Ativar Automação Diária
                </>
              )}
            </button>

            {/* Botão de Disparo em Lote */}
            <button
              id="btn-executar-disparo-lote"
              onClick={() => setModalLoteRoboOpen(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white transition-all shadow-md cursor-pointer border border-indigo-400/40"
            >
              <Send className="w-4 h-4 text-indigo-200" />
              Executar Disparo em Lote ({metricasFila.pendentesEnvio} pendentes)
            </button>
          </div>
        </div>

        {/* Métricas Rápidas */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6 pt-5 border-t border-slate-700/50">
          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-slate-400 block font-medium">Elegíveis Hoje</span>
            <span className="text-xl font-bold text-white">{metricasFila.total}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">na régua atual</span>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-emerald-400 block font-medium">A Vencer (D-5 a D-1)</span>
            <span className="text-xl font-bold text-emerald-300">{metricasFila.preventivos}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">lembretes cordiais</span>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-amber-400 block font-medium">Vencendo Hoje (D-0)</span>
            <span className="text-xl font-bold text-amber-300">{metricasFila.vencimentoHoje}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">aviso no dia</span>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-rose-400 block font-medium">Em Atraso (D+1 a D+15)</span>
            <span className="text-xl font-bold text-rose-300">{metricasFila.atrasados}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">cobrança ativa</span>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-teal-400 block font-medium">Disparados Hoje</span>
            <span className="text-xl font-bold text-teal-300">{metricasFila.jaEnviadosHoje}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">já notificados</span>
          </div>

          <div className="bg-white/5 rounded-xl p-3 border border-white/10">
            <span className="text-[11px] text-indigo-400 block font-medium">Total de Logs</span>
            <span className="text-xl font-bold text-indigo-300">{logs.length}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">histórico gravado</span>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. NAVEGAÇÃO DE SUB-ABAS                                                 */}
      {/* ========================================================================= */}
      <div className="flex items-center justify-between border-b border-slate-200">
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setSubAbaAtiva('fila')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              subAbaAtiva === 'fila'
                ? 'border-emerald-600 text-emerald-800 bg-emerald-50/50'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <Clock className="w-4 h-4" />
            Fila de Disparos de Hoje
            <span className="px-2 py-0.5 text-[11px] rounded-full bg-emerald-100 text-emerald-800 font-bold">
              {metricasFila.pendentesEnvio}
            </span>
          </button>

          <button
            onClick={() => setSubAbaAtiva('regua')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              subAbaAtiva === 'regua'
                ? 'border-emerald-600 text-emerald-800 bg-emerald-50/50'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <Sliders className="w-4 h-4" />
            Régua de Cobrança & Gatilhos ({regras.filter((r) => r.ativo).length} ativas)
          </button>

          <button
            onClick={() => setSubAbaAtiva('templates')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              subAbaAtiva === 'templates'
                ? 'border-emerald-600 text-emerald-800 bg-emerald-50/50'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <FileText className="w-4 h-4" />
            Modelos de Mensagens & Tags
          </button>

          <button
            onClick={() => setSubAbaAtiva('logs')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
              subAbaAtiva === 'logs'
                ? 'border-emerald-600 text-emerald-800 bg-emerald-50/50'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <History className="w-4 h-4" />
            Histórico & Logs de Envios ({logs.length})
          </button>
        </div>

        <div className="text-xs text-slate-400 hidden sm:block">
          Data Ref: <strong>17/09/2026</strong>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. CONTEÚDO DA SUB-ABA 1: FILA DE DISPAROS DE HOJE                        */}
      {/* ========================================================================= */}
      {subAbaAtiva === 'fila' && (
        <div className="space-y-4">
          {/* Barra de Filtros e Busca */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="flex flex-1 flex-wrap items-center gap-2.5 w-full">
              <input
                type="text"
                placeholder="Filtrar por nome do cliente ou CNPJ..."
                value={buscaCliente}
                onChange={(e) => setBuscaCliente(e.target.value)}
                className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs flex-1 min-w-[200px] focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />

              <select
                value={filtroTipo}
                onChange={(e) => setFiltroTipo(e.target.value as any)}
                className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white text-slate-700 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                <option value="todos">Todos os Tipos de Lembrete</option>
                <option value="preventivo">Preventivos (Antes do Vencimento)</option>
                <option value="vencimento">Vencendo Hoje (Dia D)</option>
                <option value="atraso">Em Atraso (Cobrança)</option>
              </select>

              <select
                value={filtroStatusEnvio}
                onChange={(e) => setFiltroStatusEnvio(e.target.value as any)}
                className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white text-slate-700 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                <option value="todos">Todos os Status de Envio</option>
                <option value="pendentes">Aguardando Envio Hoje</option>
                <option value="enviados">Já Enviados Hoje</option>
              </select>
            </div>

            {/* Ações em Lote Selecionado */}
            {selecionadosIds.length > 0 && (
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs font-semibold text-slate-700">
                  {selecionadosIds.length} selecionado(s)
                </span>
                <button
                  onClick={() => setModalLoteRoboOpen(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  Disparar Selecionados
                </button>
              </div>
            )}
          </div>

          {/* Tabela da Fila */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50 text-slate-700 text-[11px] font-semibold uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="px-3 py-3 w-10 text-center">
                      <input
                        type="checkbox"
                        checked={
                          filaFiltrada.length > 0 &&
                          selecionadosIds.length === filaFiltrada.length
                        }
                        onChange={handleToggleSelectAll}
                        className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      />
                    </th>
                    <th className="px-4 py-3">Cliente / Contrato</th>
                    <th className="px-4 py-3">Competência & Vencimento</th>
                    <th className="px-4 py-3">Situação na Régua</th>
                    <th className="px-4 py-3 text-right">Valor</th>
                    <th className="px-4 py-3">Canal & Contatos</th>
                    <th className="px-4 py-3">Envio Hoje</th>
                    <th className="px-4 py-3 text-center">Ações Rápidas</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filaFiltrada.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="px-4 py-12 text-center text-slate-400">
                        <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-emerald-500/60" />
                        <span className="font-semibold text-slate-600 block">Tudo em dia!</span>
                        Nenhuma cobrança aguarda lembretes para os filtros selecionados.
                      </td>
                    </tr>
                  ) : (
                    filaFiltrada.map((item) => {
                      const isSelecionado = selecionadosIds.includes(item.mensalidade.id);
                      return (
                        <tr
                          key={item.mensalidade.id}
                          className={`hover:bg-slate-50/80 transition-colors ${
                            isSelecionado ? 'bg-emerald-50/40' : ''
                          }`}
                        >
                          <td className="px-3 py-3 text-center">
                            <input
                              type="checkbox"
                              checked={isSelecionado}
                              onChange={() => handleToggleSelectRow(item.mensalidade.id)}
                              className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                            />
                          </td>

                          {/* Cliente */}
                          <td className="px-4 py-3">
                            <div className="font-bold text-slate-900">
                              {item.empresa.nomeFantasia || item.empresa.razaoSocial}
                            </div>
                            <div className="text-[11px] text-slate-400 font-mono">
                              CNPJ: {item.empresa.cnpj}
                            </div>
                          </td>

                          {/* Competência & Vencimento */}
                          <td className="px-4 py-3">
                            <div className="font-semibold text-slate-800">
                              Comp. {item.mensalidade.competencia}
                            </div>
                            <div className="text-[11px] text-slate-500 flex items-center gap-1">
                              <Calendar className="w-3 h-3 text-slate-400" />
                              Venc: {item.mensalidade.dataVencimento}
                            </div>
                          </td>

                          {/* Situação */}
                          <td className="px-4 py-3">
                            {item.tipo === 'atraso' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                                <AlertTriangle className="w-3 h-3 text-rose-600" />
                                Atrasada há {item.diasDiferenca} dias
                              </span>
                            ) : item.tipo === 'vencimento' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-200 animate-pulse">
                                <Clock className="w-3 h-3 text-amber-600" />
                                Vence Hoje (Dia D)
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                                <Bell className="w-3 h-3 text-emerald-600" />
                                Vence em {Math.abs(item.diasDiferenca)} dias
                              </span>
                            )}
                            <div className="text-[10px] text-slate-400 mt-0.5">
                              {item.regraAplicada.nome}
                            </div>
                          </td>

                          {/* Valor */}
                          <td className="px-4 py-3 text-right">
                            <div className="font-bold text-slate-900 text-sm">
                              {fmtMoeda(item.mensalidade.valor)}
                            </div>
                            <div className="text-[10px] text-emerald-700 font-mono">
                              Pix Disponível
                            </div>
                          </td>

                          {/* Canal e Contatos */}
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-1.5 font-medium text-slate-700">
                              {item.canalSugerido === 'whatsapp' || item.canalSugerido === 'ambos' ? (
                                <span className="inline-flex items-center gap-1 text-emerald-700">
                                  <MessageCircle className="w-3.5 h-3.5" />
                                  {item.empresa.telefone || 'Sem tel'}
                                </span>
                              ) : null}
                            </div>
                            <div className="text-[10px] text-slate-400 truncate max-w-[140px]" title={item.empresa.email}>
                              {item.empresa.email || 'Sem e-mail'}
                            </div>
                          </td>

                          {/* Envio Hoje */}
                          <td className="px-4 py-3">
                            {item.jaEnviadoHoje ? (
                              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                                <CheckCircle2 className="w-3 h-3" />
                                Enviado Hoje
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                                <Clock className="w-3 h-3 text-slate-400" />
                                Aguardando
                              </span>
                            )}
                          </td>

                          {/* Ações Rápidas */}
                          <td className="px-4 py-3 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              {/* WhatsApp Rápido */}
                              <button
                                onClick={() => handleDisparoRapidoWhatsApp(item)}
                                title="Abrir WhatsApp com texto formatado e registrar envio"
                                className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 transition-colors cursor-pointer"
                              >
                                <MessageCircle className="w-4 h-4" />
                              </button>

                              {/* E-mail Rápido */}
                              <button
                                onClick={() => handleDisparoRapidoEmail(item)}
                                title="Abrir envio por E-mail e registrar"
                                className="p-1.5 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 transition-colors cursor-pointer"
                              >
                                <Mail className="w-4 h-4" />
                              </button>

                              {/* Pré-visualizar & Personalizar */}
                              <button
                                onClick={() => handleAbrirDisparoIndividual(item)}
                                title="Pré-visualizar e editar mensagem antes de enviar"
                                className="p-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
                              >
                                <Eye className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. CONTEÚDO DA SUB-ABA 2: RÉGUA DE COBRANÇA & GATILHOS                    */}
      {/* ========================================================================= */}
      {subAbaAtiva === 'regua' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                  <Sliders className="w-5 h-5 text-emerald-600" />
                  Régua de Comunicação e Cobrança Automática
                </h3>
                <p className="text-xs text-slate-500">
                  Configure quais gatilhos acionam lembretes para os clientes, canais padrão e horários de disparo.
                </p>
              </div>

              <button
                onClick={handleRestaurarPadroes}
                className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Restaurar Padrões Contábeis
              </button>
            </div>

            {/* Linha do Tempo Visual */}
            <div className="my-6 p-4 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-xs font-bold text-slate-700 block mb-3">
                Fluxo da Régua de Notificações:
              </span>
              <div className="flex flex-wrap items-center gap-2 text-xs font-medium">
                <span className="px-3 py-1.5 rounded-lg bg-emerald-100 text-emerald-800 font-bold border border-emerald-200">
                  1. D-3 (Preventivo 3d)
                </span>
                <span className="text-slate-400">→</span>
                <span className="px-3 py-1.5 rounded-lg bg-emerald-100 text-emerald-800 font-bold border border-emerald-200">
                  2. D-1 (Aviso Amanhã)
                </span>
                <span className="text-slate-400">→</span>
                <span className="px-3 py-1.5 rounded-lg bg-amber-100 text-amber-800 font-bold border border-amber-200">
                  3. D-0 (Vencimento Hoje)
                </span>
                <span className="text-slate-400">→</span>
                <span className="px-3 py-1.5 rounded-lg bg-rose-100 text-rose-800 font-bold border border-rose-200">
                  4. D+2 (Aviso Amigável)
                </span>
                <span className="text-slate-400">→</span>
                <span className="px-3 py-1.5 rounded-lg bg-rose-200 text-rose-900 font-bold border border-rose-300">
                  5. D+7 (Cobrança Formal / Cláusula Contratual)
                </span>
              </div>
            </div>

            {/* Lista de Regras Configuráveis */}
            <div className="space-y-3">
              {regras.map((regra) => (
                <div
                  key={regra.id}
                  className={`p-4 rounded-xl border transition-all ${
                    regra.ativo
                      ? 'bg-white border-slate-300 shadow-xs'
                      : 'bg-slate-50/60 border-slate-200 opacity-60'
                  }`}
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={regra.ativo}
                        onChange={() => handleToggleRegraAtiva(regra.id)}
                        className="mt-1 w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 text-sm">
                            {regra.nome}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              regra.tipo === 'atraso'
                                ? 'bg-rose-100 text-rose-800'
                                : regra.tipo === 'vencimento'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {regra.tipo === 'atraso'
                              ? `D+${regra.diasGatilho} dias`
                              : regra.tipo === 'vencimento'
                              ? 'No Vencimento'
                              : `D${regra.diasGatilho} dias`}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Assunto E-mail: <em>{regra.templateAssunto}</em>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 flex-wrap">
                      <div className="text-xs">
                        <label className="text-slate-500 block text-[10px] uppercase font-semibold">
                          Canal Padrão
                        </label>
                        <select
                          value={regra.canalPadrao}
                          onChange={(e) =>
                            handleChangeRegraCanal(regra.id, e.target.value as any)
                          }
                          disabled={!regra.ativo}
                          className="px-2.5 py-1 text-xs border border-slate-300 rounded-lg bg-white font-medium text-slate-700"
                        >
                          <option value="whatsapp">WhatsApp</option>
                          <option value="email">E-mail</option>
                          <option value="ambos">Ambos (WhatsApp + E-mail)</option>
                        </select>
                      </div>

                      <div className="text-xs">
                        <label className="text-slate-500 block text-[10px] uppercase font-semibold">
                          Horário de Envio
                        </label>
                        <span className="inline-block px-2 py-1 text-xs bg-slate-100 text-slate-700 font-mono rounded-lg border border-slate-200">
                          {regra.horarioDisparo}
                        </span>
                      </div>

                      <button
                        onClick={() => {
                          setTemplateSelecionadoId(regra.id);
                          setSubAbaAtiva('templates');
                        }}
                        className="px-3 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors cursor-pointer"
                      >
                        Editar Template
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. CONTEÚDO DA SUB-ABA 3: EDITOR DE TEMPLATES & VARIÁVEIS                 */}
      {/* ========================================================================= */}
      {subAbaAtiva === 'templates' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Coluna Esquerda: Editor */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
            <div className="border-b border-slate-100 pb-3">
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
                Selecione o Gatilho para Editar o Modelo:
              </label>
              <select
                value={templateSelecionadoId}
                onChange={(e) => setTemplateSelecionadoId(e.target.value)}
                className="w-full px-3 py-2 text-sm font-bold border border-slate-300 rounded-xl bg-slate-50 text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              >
                {regras.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.nome} ({r.tipo.toUpperCase()})
                  </option>
                ))}
              </select>
            </div>

            {/* Tags Clicáveis */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Variáveis Dinâmicas (Clique para Inserir no Texto):
              </label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { tag: '{CLIENTE}', desc: 'Nome Fantasia / Razão' },
                  { tag: '{VALOR}', desc: 'Valor da Fatura em R$' },
                  { tag: '{VENCIMENTO}', desc: 'Data de Vencimento' },
                  { tag: '{COMPETENCIA}', desc: 'Mês/Ano Ref.' },
                  { tag: '{PIX}', desc: 'Chave Pix Copia e Cola' },
                  { tag: '{CODIGO_BARRAS}', desc: 'Linha Digitável' },
                  { tag: '{DIAS_ATRASO}', desc: 'Quantidade de dias em aberto' },
                  { tag: '{ESCRITORIO}', desc: 'Nome do Escritório Contábil' },
                ].map((item) => (
                  <button
                    key={item.tag}
                    type="button"
                    onClick={() => handleInserirVariavel(item.tag)}
                    title={item.desc}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-100 hover:text-emerald-800 text-slate-700 text-xs font-mono font-bold rounded-lg border border-slate-200 transition-colors cursor-pointer"
                  >
                    {item.tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Assunto do E-mail */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Assunto do E-mail:
              </label>
              <input
                type="text"
                value={templateAssuntoEdit}
                onChange={(e) => setTemplateAssuntoEdit(e.target.value)}
                className="w-full px-3 py-2 text-xs font-medium border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            {/* Corpo da Mensagem */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">
                  Corpo da Mensagem (WhatsApp e E-mail):
                </label>
                <span className="text-[11px] text-slate-400 font-mono">
                  {templateMensagemEdit.length} caracteres
                </span>
              </div>
              <textarea
                rows={12}
                value={templateMensagemEdit}
                onChange={(e) => setTemplateMensagemEdit(e.target.value)}
                className="w-full p-3 font-mono text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-slate-50/50 leading-relaxed"
              />
            </div>

            {/* Ações */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={handleSalvarTemplateAtual}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors cursor-pointer"
              >
                <Check className="w-4 h-4" />
                Salvar Alterações do Modelo
              </button>
            </div>
          </div>

          {/* Coluna Direita: Simulador de Mensagem WhatsApp */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-900 text-white p-4 rounded-2xl shadow-sm flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span className="font-bold text-xs">Simulador ao Vivo do WhatsApp</span>
              </div>
              <span className="text-[10px] text-slate-400">Visão do Cliente</span>
            </div>

            {/* Moldura do Celular */}
            <div className="bg-[#EFEAE2] border-8 border-slate-800 rounded-3xl p-4 shadow-xl min-h-[480px] flex flex-col justify-between relative overflow-hidden">
              {/* Header do WhatsApp */}
              <div className="bg-[#075E54] text-white p-3 -mx-4 -mt-4 flex items-center gap-2.5 shadow-xs">
                <div className="w-8 h-8 rounded-full bg-emerald-700 flex items-center justify-center font-bold text-xs">
                  CG
                </div>
                <div>
                  <div className="font-bold text-xs leading-tight">ContabGest Contabilidade</div>
                  <div className="text-[10px] text-emerald-200">Conta Comercial Oficial</div>
                </div>
              </div>

              {/* Balão de Mensagem */}
              <div className="my-4 self-start max-w-[92%] bg-white rounded-xl rounded-tl-none p-3.5 shadow-sm text-slate-800 text-[11px] leading-relaxed whitespace-pre-wrap font-sans border border-slate-200/60 relative">
                {previewAoVivoTexto}
                <div className="text-[9px] text-slate-400 text-right mt-2 flex items-center justify-end gap-1 font-mono">
                  <span>09:00</span>
                  <span className="text-emerald-600 font-bold">✓✓</span>
                </div>
              </div>

              {/* Input Fake do WhatsApp */}
              <div className="bg-white rounded-full p-2 -mx-1 -mb-1 flex items-center justify-between text-slate-400 text-[11px] px-4 shadow-xs">
                <span>Mensagem</span>
                <Send className="w-3.5 h-3.5 text-emerald-600" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. CONTEÚDO DA SUB-ABA 4: HISTÓRICO & LOGS DE ENVIOS                       */}
      {/* ========================================================================= */}
      {subAbaAtiva === 'logs' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                Registro de Disparos e Notificações Entregues
              </h3>
              <p className="text-xs text-slate-500">
                Auditoria de todos os envios automáticos e manuais realizados pelo sistema.
              </p>
            </div>

            {logs.length > 0 && (
              <button
                onClick={handleLimparLogs}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-rose-700 hover:bg-rose-50 border border-rose-200 rounded-lg transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Limpar Logs
              </button>
            )}
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50 text-slate-700 text-[11px] font-semibold uppercase tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Data & Hora</th>
                    <th className="px-4 py-3">Cliente</th>
                    <th className="px-4 py-3">Competência</th>
                    <th className="px-4 py-3">Canal & Destinatário</th>
                    <th className="px-4 py-3">Tipo / Origem</th>
                    <th className="px-4 py-3 text-right">Valor</th>
                    <th className="px-4 py-3 text-center">Status</th>
                    <th className="px-4 py-3 text-center">Mensagem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {logs.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="px-4 py-12 text-center text-slate-400">
                        <History className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                        Nenhum disparo registrado ainda. Os envios automáticos e manuais aparecerão aqui.
                      </td>
                    </tr>
                  ) : (
                    logs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-4 py-3 font-mono text-[11px]">
                          {new Date(log.dataHoraEnvio).toLocaleString('pt-BR')}
                        </td>
                        <td className="px-4 py-3 font-bold text-slate-900">
                          {log.clienteNome}
                        </td>
                        <td className="px-4 py-3 font-semibold text-slate-700">
                          {log.competencia}
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`inline-flex items-center gap-1 font-semibold ${
                              log.canal === 'whatsapp' ? 'text-emerald-700' : 'text-blue-700'
                            }`}
                          >
                            {log.canal === 'whatsapp' ? (
                              <MessageCircle className="w-3.5 h-3.5" />
                            ) : (
                              <Mail className="w-3.5 h-3.5" />
                            )}
                            {log.destinatario}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-semibold text-slate-800 capitalize">
                            {log.tipoLembrete}
                          </span>
                          <div className="text-[10px] text-slate-400">
                            {log.origem === 'robo_automatico' ? 'Robô Automático' : 'Disparo Manual'}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-right font-bold text-slate-900">
                          {fmtMoeda(log.valor)}
                        </td>
                        <td className="px-4 py-3 text-center">
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                            <CheckCircle2 className="w-3 h-3" />
                            Entregue
                          </span>
                        </td>
                        <td className="px-4 py-3 text-center">
                          {log.mensagemEnviada && (
                            <button
                              onClick={() => setLogMensagemModal(log)}
                              className="p-1 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100"
                              title="Ver texto enviado"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. MODAL DE DISPARO EM LOTE AUTOMÁTICO (ROBÔ)                             */}
      {/* ========================================================================= */}
      {modalLoteRoboOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-900 text-white">
              <div className="flex items-center gap-2">
                <Send className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-base">Disparo em Lote de Lembretes</h3>
              </div>
              {!processandoLote && (
                <button
                  onClick={() => setModalLoteRoboOpen(false)}
                  className="text-slate-400 hover:text-white p-1"
                >
                  ✕
                </button>
              )}
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
                <span className="text-slate-500 block text-xs">Faturas Elegíveis Selecionadas:</span>
                <span className="text-2xl font-bold text-slate-900 block mt-1">
                  {itensAlvoLote.length} cliente(s)
                </span>
                <span className="text-slate-500 text-[11px] block mt-0.5">
                  Total Financeiro: {fmtMoeda(itensAlvoLote.reduce((acc, i) => acc + i.mensalidade.valor, 0))}
                </span>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1.5">
                  Canal de Disparo para o Lote:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCanalLote('preferencial')}
                    className={`py-2 px-3 rounded-lg border font-semibold text-xs cursor-pointer ${
                      canalLote === 'preferencial'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-800'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Canal Sugerido da Régua
                  </button>

                  <button
                    type="button"
                    onClick={() => setCanalLote('whatsapp')}
                    className={`py-2 px-3 rounded-lg border font-semibold text-xs cursor-pointer ${
                      canalLote === 'whatsapp'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-800'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Apenas WhatsApp
                  </button>

                  <button
                    type="button"
                    onClick={() => setCanalLote('email')}
                    className={`py-2 px-3 rounded-lg border font-semibold text-xs cursor-pointer ${
                      canalLote === 'email'
                        ? 'border-blue-600 bg-blue-50 text-blue-800'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Apenas E-mail
                  </button>

                  <button
                    type="button"
                    onClick={() => setCanalLote('ambos')}
                    className={`py-2 px-3 rounded-lg border font-semibold text-xs cursor-pointer ${
                      canalLote === 'ambos'
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-800'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    Ambos (WhatsApp + E-mail)
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-700">
                  <input
                    type="checkbox"
                    checked={apenasNaoEnviadosLote}
                    onChange={(e) => setApenasNaoEnviadosLote(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  Ignorar clientes que já receberam lembrete hoje (Anti-Spam)
                </label>
              </div>

              {processandoLote && (
                <div className="space-y-2 pt-3 border-t border-slate-200">
                  <div className="flex justify-between text-xs font-bold text-slate-700">
                    <span>Disparando lembretes...</span>
                    <span>
                      {progressoLote.concluidos} de {progressoLote.total}
                    </span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-600 transition-all duration-150"
                      style={{
                        width: `${(progressoLote.concluidos / Math.max(progressoLote.total, 1)) * 100}%`,
                      }}
                    ></div>
                  </div>
                </div>
              )}
            </div>

            <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex justify-end gap-3">
              {!processandoLote && (
                <button
                  type="button"
                  onClick={() => setModalLoteRoboOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-xl text-slate-700 hover:bg-slate-100 font-medium text-xs"
                >
                  Cancelar
                </button>
              )}
              <button
                type="button"
                onClick={handleExecutarLoteRobo}
                disabled={processandoLote || itensAlvoLote.length === 0}
                className="inline-flex items-center gap-2 px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-300 text-white rounded-xl text-xs font-bold shadow-sm transition-all cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                {processandoLote ? 'Processando Lote...' : 'Iniciar Disparo Automático'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 8. MODAL DE DISPARO INDIVIDUAL (PRÉVIA COMPLETA)                           */}
      {/* ========================================================================= */}
      <ModalDisparoLembrete
        isOpen={modalDisparoOpen}
        onClose={() => setModalDisparoOpen(false)}
        item={itemParaDisparo}
        onConfirmarEnvio={async (mensId, canal, dest, msg) => {
          await confirmarEnvioBackend(mensId, canal, dest, msg, 'disparo_manual');
          onFeedback('Lembrete de cobrança disparado e registrado com sucesso!');
        }}
      />

      {/* Modal de Exibição de Mensagem do Log */}
      {logMensagemModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-slate-900 text-sm">Mensagem Registrada no Envio</h3>
              <button
                onClick={() => setLogMensagemModal(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                ✕
              </button>
            </div>
            <div className="p-6">
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 font-mono text-xs whitespace-pre-wrap leading-relaxed">
                {logMensagemModal.mensagemEnviada}
              </div>
            </div>
            <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setLogMensagemModal(null)}
                className="px-4 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-semibold"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
