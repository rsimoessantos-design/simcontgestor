import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  FileCode,
  CheckCircle2,
  AlertCircle,
  X,
  FileText,
  ShieldCheck,
  Building,
  DollarSign,
  Layers,
  Sparkles,
  ArrowRight,
  Loader2,
  Copy,
} from 'lucide-react';
import { Empresa, NotaFiscal } from '../types';
import { api } from '../services/api';

interface ImportarXmlSaidaModalProps {
  isOpen: boolean;
  onClose: () => void;
  empresas: Empresa[];
  selectedEmpresa?: Empresa;
  onSuccess: (notasImportadas: NotaFiscal[]) => void;
}

export const ImportarXmlSaidaModal: React.FC<ImportarXmlSaidaModalProps> = ({
  isOpen,
  onClose,
  empresas,
  selectedEmpresa,
  onSuccess,
}) => {
  const [empresaId, setEmpresaId] = useState(selectedEmpresa?.id || empresas[0]?.id || '');
  const [arquivos, setArquivos] = useState<{ nome: string; conteudo: string; tamanho: number }[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const [resultadoSucesso, setResultadoSucesso] = useState<{
    quantidade: number;
    valorTotal: number;
    notas: NotaFiscal[];
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const processarArquivos = (fileList: FileList) => {
    setErro(null);
    setResultadoSucesso(null);
    const novosArquivos: { nome: string; conteudo: string; tamanho: number }[] = [];

    Array.from(fileList).forEach((file) => {
      if (!file.name.toLowerCase().endsWith('.xml')) {
        setErro('Selecione apenas arquivos com extensão .xml (Notas Fiscais Modelo 55)');
        return;
      }

      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        if (text) {
          novosArquivos.push({
            nome: file.name,
            conteudo: text,
            tamanho: file.size,
          });
          if (novosArquivos.length === fileList.length) {
            setArquivos((prev) => [...prev, ...novosArquivos]);
          }
        }
      };
      reader.readAsText(file);
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processarArquivos(e.dataTransfer.files);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processarArquivos(e.target.files);
    }
  };

  const removerArquivo = (index: number) => {
    setArquivos((prev) => prev.filter((_, i) => i !== index));
  };

  const carregarExemploXml = () => {
    const randomNf = Math.floor(2000 + Math.random() * 8000);
    const randomChave = `352609${Math.random().toString().slice(2, 16)}${Math.random().toString().slice(2, 16)}${Math.random().toString().slice(2, 16)}`.slice(0, 44);
    const valorProd = (Math.random() * 4500 + 850).toFixed(2);
    const icmsVal = (parseFloat(valorProd) * 0.12).toFixed(2);
    const pisVal = (parseFloat(valorProd) * 0.0065).toFixed(2);
    const cofinsVal = (parseFloat(valorProd) * 0.03).toFixed(2);

    const exemploXml = `<?xml version="1.0" encoding="UTF-8"?>
<nfeProc versao="4.00" xmlns="http://www.portalfiscal.inf.br/nfe">
  <NFe xmlns="http://www.portalfiscal.inf.br/nfe">
    <infNFe Id="NFe${randomChave}" versao="4.00">
      <ide>
        <cUF>35</cUF>
        <cNF>00892182</cNF>
        <natOp>VENDA MERCADORIA ADQ. DE TERCEIROS (ERP EXTERNO)</natOp>
        <mod>55</mod>
        <serie>1</serie>
        <nNF>${randomNf}</nNF>
        <dhEmi>${new Date().toISOString()}</dhEmi>
        <tpNF>1</tpNF>
        <idDest>1</idDest>
        <cMunFG>3550308</cMunFG>
        <tpImp>1</tpImp>
        <tpEmis>1</tpEmis>
      </ide>
      <emit>
        <CNPJ>12345678000195</CNPJ>
        <xNome>EMPRESA CLIENTE DO ESCRITORIO CONTABIL</xNome>
        <xFant>CLIENTE ERP</xFant>
      </emit>
      <dest>
        <CNPJ>45982014000188</CNPJ>
        <xNome>DISTRIBUIDORA COMERCIAL PAULISTA S.A.</xNome>
        <email>compras@distribuidorapaulista.com.br</email>
      </dest>
      <det nItem="1">
        <prod>
          <cProd>PROD-ERP-091</cProd>
          <cEAN>SEM GTIN</cEAN>
          <xProd>Componentes e Insumos Eletronicos Industriais</xProd>
          <NCM>84713012</NCM>
          <CFOP>5102</CFOP>
          <uCom>UN</uCom>
          <qCom>10.0000</qCom>
          <vUnCom>${(parseFloat(valorProd) / 10).toFixed(2)}</vUnCom>
          <vProd>${valorProd}</vProd>
        </prod>
        <imposto>
          <ICMS>
            <ICMSSN102>
              <orig>0</orig>
              <CSOSN>102</CSOSN>
            </ICMSSN102>
          </ICMS>
        </imposto>
      </det>
      <total>
        <ICMSTot>
          <vBC>${valorProd}</vBC>
          <vICMS>${icmsVal}</vICMS>
          <vProd>${valorProd}</vProd>
          <vNF>${valorProd}</vNF>
          <vPIS>${pisVal}</vPIS>
          <vCOFINS>${cofinsVal}</vCOFINS>
        </ICMSTot>
      </total>
    </infNFe>
  </NFe>
  <protNFe versao="4.00">
    <infProt>
      <tpAmb>1</tpAmb>
      <chNFe>${randomChave}</chNFe>
      <dhRecbto>${new Date().toISOString()}</dhRecbto>
      <nProt>135260084918234</nProt>
      <cStat>100</cStat>
      <xMotivo>Autorizado o uso da NF-e</xMotivo>
    </infProt>
  </protNFe>
</nfeProc>`;

    setArquivos((prev) => [
      ...prev,
      {
        nome: `NFe_${randomChave.slice(0, 12)}..._Mod55.xml`,
        conteudo: exemploXml,
        tamanho: exemploXml.length,
      },
    ]);
  };

  const handleImportar = async () => {
    if (arquivos.length === 0) {
      setErro('Adicione ao menos um arquivo XML para importar.');
      return;
    }
    if (!empresaId) {
      setErro('Selecione a empresa correspondente às notas de saída.');
      return;
    }

    setIsProcessing(true);
    setErro(null);

    try {
      const xmlContents = arquivos.map((a) => a.conteudo);
      const res = await api.importarLoteXmlSaida(empresaId, xmlContents);

      setResultadoSucesso({
        quantidade: res.totalImportadas,
        valorTotal: res.valorTotal,
        notas: res.importadas,
      });

      onSuccess(res.importadas);
    } catch (err: any) {
      setErro(err.message || 'Erro ao importar arquivos XML');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-xs">
              <FileCode className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                Importação de XMLs de Saída (Modelo 55 - NF-e)
                <span className="text-xs bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded-full">
                  Outro ERP
                </span>
              </h2>
              <p className="text-xs text-slate-500">
                Capture notas emitidas pelo cliente em outros sistemas para apuração do Simples Nacional
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Seleção de Empresa */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Empresa Emitente (Cliente do Escritório)
            </label>
            <div className="relative">
              <Building className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <select
                value={empresaId}
                onChange={(e) => setEmpresaId(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all font-medium"
              >
                {empresas.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.razaoSocial} ({emp.cnpj}) — {emp.regimeTributario}
                  </option>
                ))}
              </select>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              As notas serão vinculadas a esta empresa e integradas à memória de cálculo da apuração do Simples Nacional (PGDAS-D).
            </p>
          </div>

          {/* Área de Drop / Upload */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all ${
              isDragging
                ? 'border-emerald-500 bg-emerald-50/50'
                : 'border-slate-300 bg-slate-50/60 hover:bg-slate-100/60 hover:border-slate-400'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileInputChange}
              multiple
              accept=".xml"
              className="hidden"
            />
            <div className="w-12 h-12 bg-white rounded-full shadow-xs border border-slate-200 text-emerald-600 flex items-center justify-center mx-auto mb-3">
              <UploadCloud className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-semibold text-slate-800">
              Arraste os arquivos XML (Modelo 55) aqui ou clique para selecionar
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Suporta importação individual ou em lote (múltiplos XMLs de saída simultâneos)
            </p>

            <div className="mt-4 flex items-center justify-center gap-2">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  carregarExemploXml();
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-md hover:bg-emerald-100 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Carregar XML de Exemplo (Modelo 55)
              </button>
            </div>
          </div>

          {/* Lista de Arquivos Carregados */}
          {arquivos.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                <span>Arquivos prontos para importação ({arquivos.length})</span>
                <button
                  type="button"
                  onClick={() => setArquivos([])}
                  className="text-red-600 hover:text-red-700 font-medium"
                >
                  Limpar todos
                </button>
              </div>
              <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1">
                {arquivos.map((arq, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  >
                    <div className="flex items-center space-x-2.5 overflow-hidden">
                      <FileCode className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="font-medium text-slate-700 truncate">{arq.nome}</span>
                      <span className="text-slate-400 shrink-0">({(arq.tamanho / 1024).toFixed(1)} KB)</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => removerArquivo(idx)}
                      className="text-slate-400 hover:text-red-600 p-1 transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Mensagem de Erro */}
          {erro && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{erro}</span>
            </div>
          )}

          {/* Sucesso */}
          {resultadoSucesso && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg space-y-2">
              <div className="flex items-center gap-2 text-emerald-800 font-semibold text-sm">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span>{resultadoSucesso.quantidade} notas fiscais importadas com sucesso!</span>
              </div>
              <p className="text-xs text-emerald-700">
                Valor total faturado importado:{' '}
                <strong>
                  {resultadoSucesso.valorTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </strong>
                . Todas as notas foram marcadas com origem <em>"Importado de Outro ERP"</em> e já estão computadas
                nas estatísticas de faturamento e fechamento fiscal.
              </p>
            </div>
          )}

          {/* Dica Contábil do Simples Nacional */}
          <div className="p-3.5 bg-sky-50 border border-sky-200 rounded-lg flex items-start gap-3 text-xs text-sky-900">
            <ShieldCheck className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Apuração Fiscal Automática:</span>
              <p className="mt-0.5 text-sky-800 leading-relaxed">
                Ao importar os XMLs de notas de saída (Mod. 55), o ContabGest categoriza automaticamente o CFOP
                nos Anexos do Simples Nacional (ex: 5.102 / 6.102 no Anexo I de Comércio, 5.101 no Anexo II de Indústria),
                alimentando o faturamento mensal (RPA) e a Receita Bruta Acumulada dos últimos 12 meses (RBT12).
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-100 transition-colors"
          >
            {resultadoSucesso ? 'Concluir e Fechar' : 'Cancelar'}
          </button>

          {!resultadoSucesso ? (
            <button
              type="button"
              onClick={handleImportar}
              disabled={isProcessing || arquivos.length === 0}
              className="px-5 py-2 bg-emerald-600 text-white rounded-lg text-sm font-semibold hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 shadow-xs transition-colors"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Processando XMLs...
                </>
              ) : (
                <>
                  <UploadCloud className="w-4 h-4" />
                  Importar {arquivos.length > 0 ? `(${arquivos.length}) XMLs` : 'Notas de Saída'}
                </>
              )}
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                setResultadoSucesso(null);
                setArquivos([]);
              }}
              className="px-4 py-2 bg-slate-800 text-white rounded-lg text-sm font-semibold hover:bg-slate-900 transition-colors"
            >
              Importar Mais Arquivos
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
