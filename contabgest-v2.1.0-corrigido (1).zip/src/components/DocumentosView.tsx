import React, { useState } from 'react';
import {
  FolderArchive,
  Upload,
  FileText,
  FileSpreadsheet,
  Download,
  CheckCircle2,
  Clock,
  Search,
  Plus,
} from 'lucide-react';
import { Documento, Empresa } from '../types';

interface DocumentosViewProps {
  documentos: Documento[];
  empresas: Empresa[];
  selectedEmpresa?: Empresa;
  onAddDocument: (doc: Omit<Documento, 'id'>) => void;
}

export const DocumentosView: React.FC<DocumentosViewProps> = ({
  documentos,
  empresas,
  selectedEmpresa,
  onAddDocument,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('todas');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [newDocNome, setNewDocNome] = useState('');
  const [newDocCategoria, setNewDocCategoria] = useState<Documento['categoria']>('Fiscal');

  const categories = ['todas', 'Fiscal', 'Contábil', 'DP/RH', 'Legal', 'Certidão'];

  const filtered = documentos.filter((d) => {
    const matchesSearch =
      d.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.enviadoPor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = activeCategory === 'todas' || d.categoria === activeCategory;
    return matchesSearch && matchesCat;
  });

  const getEmpresaName = (empresaId: string) => {
    const emp = empresas.find((e) => e.id === empresaId);
    return emp ? emp.nomeFantasia : 'Todas';
  };

  const handleUploadSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocNome) return;

    onAddDocument({
      empresaId: selectedEmpresa ? selectedEmpresa.id : 'emp_1',
      nome: newDocNome.endsWith('.pdf') ? newDocNome : `${newDocNome}.pdf`,
      categoria: newDocCategoria,
      tamanho: '1.4 MB',
      dataEnvio: new Date().toISOString().split('T')[0],
      status: 'pendente',
      enviadoPor: 'Contador Administrador',
      extensao: 'PDF',
      isDemo: true,
    });

    setNewDocNome('');
    setShowUploadModal(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900">Gestão de Documentos Digitais</h1>
            <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded">
              DEMO
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Armazenamento, envio de extratos bancários, XMLs de notas e relatórios contábeis
          </p>
        </div>

        <button
          onClick={() => setShowUploadModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-all"
        >
          <Upload className="w-4 h-4" />
          <span>Enviar Documento</span>
        </button>
      </div>

      {/* Category Pills & Search */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all ${
                activeCategory === cat
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat === 'todas' ? 'Todos os Documentos' : cat}
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Filtrar por nome de arquivo ou remetente..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-slate-800"
          />
        </div>
      </div>

      {/* Documents Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Nome do Arquivo</th>
                <th className="py-3 px-4">Categoria</th>
                <th className="py-3 px-4">Empresa</th>
                <th className="py-3 px-4">Tamanho</th>
                <th className="py-3 px-4">Data Envio</th>
                <th className="py-3 px-4">Enviado Por</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((doc) => (
                <tr key={doc.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center shrink-0">
                        <FileText className="w-4 h-4 text-emerald-600" />
                      </div>
                      <span className="font-semibold text-slate-900">{doc.nome}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
                      {doc.categoria}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-700">
                    {getEmpresaName(doc.empresaId)}
                  </td>
                  <td className="py-3 px-4 text-slate-500">{doc.tamanho}</td>
                  <td className="py-3 px-4 font-mono">{doc.dataEnvio}</td>
                  <td className="py-3 px-4 text-slate-600">{doc.enviadoPor}</td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        doc.status === 'aprovado'
                          ? 'bg-emerald-100 text-emerald-800'
                          : doc.status === 'pendente'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {doc.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <button
                      onClick={() => alert(`Download simulado do arquivo DEMO: ${doc.nome}`)}
                      className="p-1.5 rounded-lg text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 transition-colors inline-flex items-center gap-1"
                      title="Baixar arquivo"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-1">
              Enviar Novo Documento [DEMO]
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Faça upload de guias, extratos bancários, certidões ou balancetes.
            </p>

            <form onSubmit={handleUploadSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nome descritivo do arquivo
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Extrato_Setembro_2026.pdf"
                  value={newDocNome}
                  onChange={(e) => setNewDocNome(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Categoria Contábil
                </label>
                <select
                  value={newDocCategoria}
                  onChange={(e) => setNewDocCategoria(e.target.value as any)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none bg-slate-50"
                >
                  <option value="Fiscal">Fiscal</option>
                  <option value="Contábil">Contábil</option>
                  <option value="DP/RH">DP / RH</option>
                  <option value="Legal">Societário & Legal</option>
                  <option value="Certidão">Certidão</option>
                </select>
              </div>

              <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-emerald-500 cursor-pointer bg-slate-50 transition-colors">
                <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <p className="font-semibold text-slate-700">Clique ou arraste o arquivo aqui</p>
                <p className="text-[10px] text-slate-400 mt-1">
                  Suporte a PDF, OFX, XML, XLSX (até 25MB)
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 font-medium"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold shadow-xs"
                >
                  Registrar Envio
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
