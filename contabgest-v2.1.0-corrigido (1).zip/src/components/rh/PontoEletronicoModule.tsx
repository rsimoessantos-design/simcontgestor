import React, { useState, useEffect, useMemo } from 'react';
import {
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  FileText,
  UserCheck,
  Calendar,
  Filter,
  Search,
  RefreshCw,
  Printer,
  ChevronRight,
  Coffee,
  LogIn,
  LogOut,
  MapPin,
  Laptop,
  Building2,
  FileEdit,
  SlidersHorizontal,
  ThumbsUp,
  AlertCircle,
  Hash,
  Download,
  Check,
  Award,
} from 'lucide-react';
import {
  Funcionario,
  RegistroPontoDia,
  TipoBatidaPonto,
  StatusAuditoriaPonto,
  ComprovantePontoEmitido,
  EspelhoPontoMensal,
  Empresa,
} from '../../types';
import { api } from '../../services/api';
import { ComprovantePontoModal } from './ComprovantePontoModal';
import { AjustarPontoModal } from './AjustarPontoModal';
import { EspelhoPontoModal } from './EspelhoPontoModal';

interface PontoEletronicoModuleProps {
  empresaId?: string;
  empresaNome?: string;
  funcionarios: Funcionario[];
}

type PontoTab = 'monitor' | 'bater' | 'auditoria' | 'espelho';

export const PontoEletronicoModule: React.FC<PontoEletronicoModuleProps> = ({
  empresaId,
  empresaNome = 'Todas as Empresas',
  funcionarios,
}) => {
  const [activeTab, setActiveTab] = useState<PontoTab>('monitor');
  const [loading, setLoading] = useState(false);
  const [pontos, setPontos] = useState<RegistroPontoDia[]>([]);
  const [painelHoje, setPainelHoje] = useState<{
    dataHoje: string;
    totalFuncionarios: number;
    trabalhandoAgora: number;
    emIntervalo: number;
    expedienteConcluido: number;
    semRegistro: number;
    comInconsistencia: number;
    registros: RegistroPontoDia[];
    colaboradoresSemRegistro: Funcionario[];
  } | null>(null);

  // Filtros de Auditoria
  const [filtroCompetencia, setFiltroCompetencia] = useState('09/2026');
  const [filtroStatus, setFiltroStatus] = useState<string>('todos');
  const [filtroInconsistencias, setFiltroInconsistencias] = useState(false);
  const [filtroFuncionario, setFiltroFuncionario] = useState<string>('todos');
  const [searchTerm, setSearchTerm] = useState('');

  // Terminal de Ponto (Bater Ponto)
  const [selectedFuncionarioPonto, setSelectedFuncionarioPonto] = useState<Funcionario | null>(
    funcionarios.length > 0 ? funcionarios[0] : null
  );
  const [observacaoPonto, setObservacaoPonto] = useState('');
  const [horaAtual, setHoraAtual] = useState(new Date());
  const [registrandoPonto, setRegistrandoPonto] = useState(false);

  // Espelho de Ponto Individual
  const [selectedEspelhoFuncionario, setSelectedEspelhoFuncionario] = useState<Funcionario | null>(
    funcionarios.length > 0 ? funcionarios[0] : null
  );
  const [espelhoData, setEspelhoData] = useState<EspelhoPontoMensal | null>(null);
  const [loadingEspelho, setLoadingEspelho] = useState(false);

  // Modals
  const [comprovanteAtual, setComprovanteAtual] = useState<ComprovantePontoEmitido | null>(null);
  const [isComprovanteModalOpen, setIsComprovanteModalOpen] = useState(false);
  const [pontoParaAjustar, setPontoParaAjustar] = useState<RegistroPontoDia | null>(null);
  const [isAjustarModalOpen, setIsAjustarModalOpen] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<{ tipo: 'success' | 'error'; texto: string } | null>(null);

  // Relógio digital em tempo real
  useEffect(() => {
    const timer = setInterval(() => {
      setHoraAtual(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Carregar dados de pontos e monitor
  const carregarDados = async () => {
    try {
      setLoading(true);
      const [listaPontos, hoje] = await Promise.all([
        api.getPontos({
          empresaId: empresaId && empresaId !== 'todas' ? empresaId : undefined,
          competencia: filtroCompetencia,
          status: filtroStatus !== 'todos' ? filtroStatus : undefined,
          funcionarioId: filtroFuncionario !== 'todos' ? filtroFuncionario : undefined,
          inconsistenciasApenas: filtroInconsistencias,
        }),
        api.getPontosHoje(empresaId && empresaId !== 'todas' ? empresaId : undefined),
      ]);
      setPontos(listaPontos);
      setPainelHoje(hoje);
    } catch (err) {
      console.error('Erro ao carregar dados do ponto eletrônico:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregarDados();
  }, [empresaId, filtroCompetencia, filtroStatus, filtroFuncionario, filtroInconsistencias]);

  // Carregar espelho quando selecionado
  useEffect(() => {
    if (selectedEspelhoFuncionario) {
      carregarEspelho(selectedEspelhoFuncionario.id, filtroCompetencia);
    }
  }, [selectedEspelhoFuncionario, filtroCompetencia]);

  const carregarEspelho = async (funcId: string, comp: string) => {
    try {
      setLoadingEspelho(true);
      const espelho = await api.getEspelhoPonto(funcId, comp);
      setEspelhoData(espelho);
    } catch (err) {
      console.error('Erro ao carregar espelho de ponto:', err);
    } finally {
      setLoadingEspelho(false);
    }
  };

  // Identificar próximo tipo de batida sugerido para o colaborador selecionado no dia de hoje
  const proximaBatidaSugerida = useMemo<{
    tipo: TipoBatidaPonto;
    label: string;
    icon: any;
    color: string;
  }>(() => {
    if (!selectedFuncionarioPonto || !painelHoje) {
      return {
        tipo: 'entrada_1',
        label: '1ª Entrada (Início da Jornada)',
        icon: LogIn,
        color: 'emerald',
      };
    }

    const regHoje = painelHoje.registros.find(
      (p) => p.funcionarioId === selectedFuncionarioPonto.id
    );

    if (!regHoje || !regHoje.entrada1) {
      return {
        tipo: 'entrada_1',
        label: '1ª Entrada (Início da Jornada)',
        icon: LogIn,
        color: 'emerald',
      };
    }
    if (!regHoje.saidaIntervalo) {
      return {
        tipo: 'saida_intervalo',
        label: '1ª Saída (Intervalo de Almoço)',
        icon: Coffee,
        color: 'amber',
      };
    }
    if (!regHoje.retornoIntervalo) {
      return {
        tipo: 'retorno_intervalo',
        label: '2ª Entrada (Retorno do Intervalo)',
        icon: LogIn,
        color: 'blue',
      };
    }
    if (!regHoje.saida2) {
      return {
        tipo: 'saida_2',
        label: '2ª Saída (Término do Expediente)',
        icon: LogOut,
        color: 'indigo',
      };
    }
    return {
      tipo: 'saida_2',
      label: 'Expediente Concluído (Batida Extra)',
      icon: LogOut,
      color: 'slate',
    };
  }, [selectedFuncionarioPonto, painelHoje]);

  // Ação de Bater Ponto
  const handleBaterPonto = async (tipo: TipoBatidaPonto) => {
    if (!selectedFuncionarioPonto) return;
    try {
      setRegistrandoPonto(true);
      const res = await api.baterPonto({
        funcionarioId: selectedFuncionarioPonto.id,
        tipo,
        observacao: observacaoPonto.trim() || undefined,
        geolocalizacao: {
          latitude: -23.5614,
          longitude: -46.6560,
          precisao: 8,
          endereco: 'Av. Paulista, 1842 - Bela Vista, São Paulo - SP',
        },
        origem: 'rep_p',
      });

      setObservacaoPonto('');
      setComprovanteAtual(res.comprovante);
      setIsComprovanteModalOpen(true);
      setFeedbackMsg({
        tipo: 'success',
        texto: `Marcação registrada com sucesso! NSR #${res.comprovante.nsr}`,
      });
      setTimeout(() => setFeedbackMsg(null), 4000);
      carregarDados();
    } catch (err: any) {
      setFeedbackMsg({
        tipo: 'error',
        texto: err.message || 'Erro ao registrar ponto eletrônico',
      });
    } finally {
      setRegistrandoPonto(false);
    }
  };

  // Salvar Ajuste do RH
  const handleSalvarAjuste = async (
    pontoId: string,
    ajustes: {
      entrada1?: string;
      saidaIntervalo?: string;
      retornoIntervalo?: string;
      saida2?: string;
      motivoAjuste: string;
      observacaoRH?: string;
      auditadoPor: string;
      statusAuditoria?: StatusAuditoriaPonto;
    }
  ) => {
    const res = await api.ajustarPontoDia(pontoId, ajustes);
    setFeedbackMsg({
      tipo: 'success',
      texto: 'Registro de jornada retificado e salvo com sucesso!',
    });
    setTimeout(() => setFeedbackMsg(null), 4000);
    carregarDados();
  };

  // Homologar Ponto Individual
  const handleHomologarPonto = async (ponto: RegistroPontoDia) => {
    try {
      await api.auditarPontoDia(ponto.id, {
        status: 'aprovado',
        auditadoPor: 'Carlos Eduardo Silveira (Contador Responsável)',
        observacaoRH: 'Homologado e aprovado pelo RH.',
      });
      setFeedbackMsg({
        tipo: 'success',
        texto: `Ponto do dia ${ponto.data} homologado com sucesso!`,
      });
      setTimeout(() => setFeedbackMsg(null), 3000);
      carregarDados();
    } catch (err: any) {
      setFeedbackMsg({ tipo: 'error', texto: err.message || 'Erro ao homologar' });
    }
  };

  // Homologação em Lote
  const handleHomologarLote = async () => {
    try {
      const res = await api.homologarPontosLote({
        empresaId: empresaId && empresaId !== 'todas' ? empresaId : undefined,
        competencia: filtroCompetencia,
        apenasSemInconsistencia: true,
        auditadoPor: 'Carlos Eduardo Silveira (Contador Responsável)',
      });
      setFeedbackMsg({
        tipo: 'success',
        texto: `${res.totalHomologados} registros de ponto homologados com sucesso!`,
      });
      setTimeout(() => setFeedbackMsg(null), 4000);
      carregarDados();
    } catch (err: any) {
      setFeedbackMsg({ tipo: 'error', texto: err.message || 'Erro na homologação em lote' });
    }
  };

  // Formatação de minutos em HH:MM
  const formatMinutosParaHoras = (minutos?: number) => {
    if (minutos === undefined || minutos === null) return '00h00';
    const h = Math.floor(Math.abs(minutos) / 60);
    const m = Math.abs(minutos) % 60;
    const sinal = minutos < 0 ? '-' : '';
    return `${sinal}${String(h).padStart(2, '0')}h${String(m).padStart(2, '0')}`;
  };

  // Lista filtrada de auditoria
  const pontosFiltrados = useMemo(() => {
    return pontos.filter((p) => {
      if (!searchTerm) return true;
      const term = searchTerm.toLowerCase();
      return (
        p.funcionarioNome.toLowerCase().includes(term) ||
        p.funcionarioMatricula.toLowerCase().includes(term) ||
        p.data.includes(term)
      );
    });
  }, [pontos, searchTerm]);

  // Contagem de inconsistências pendentes
  const totalInconsistencias = useMemo(() => {
    return pontos.filter(
      (p) => p.statusAuditoria === 'com_inconsistencia' || (p.inconsistencias && p.inconsistencias.length > 0)
    ).length;
  }, [pontos]);

  return (
    <div id="modulo_ponto_eletronico" className="space-y-6 animate-in fade-in duration-200">
      {/* Feedback Toast */}
      {feedbackMsg && (
        <div
          id="toast_feedback_ponto"
          className={`p-4 rounded-xl border flex items-center justify-between text-sm shadow-md animate-in slide-in-from-top-4 duration-200 ${
            feedbackMsg.tipo === 'success'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
              : 'bg-rose-50 border-rose-300 text-rose-800'
          }`}
        >
          <div className="flex items-center space-x-2">
            {feedbackMsg.tipo === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-rose-600" />
            )}
            <span className="font-medium">{feedbackMsg.texto}</span>
          </div>
          <button
            onClick={() => setFeedbackMsg(null)}
            className="text-xs opacity-70 hover:opacity-100 font-bold ml-4"
          >
            ✕
          </button>
        </div>
      )}

      {/* Header Principal do Módulo de Ponto */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl border border-blue-100">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-xl font-bold text-slate-800">Ponto Eletrônico & Auditoria de Jornada</h2>
                <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>REP-P Portaria 671 MTE</span>
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Controle de assiduidade em tempo real, banco de horas CLT e certificação digital por hash SHA-256
              </p>
            </div>
          </div>
        </div>

        {/* Abas Superiores */}
        <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-100 rounded-xl border border-slate-200 text-xs font-semibold">
          <button
            id="tab_ponto_monitor"
            onClick={() => setActiveTab('monitor')}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all ${
              activeTab === 'monitor'
                ? 'bg-white text-blue-700 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>Monitor de Hoje</span>
            {painelHoje && painelHoje.trabalhandoAgora > 0 && (
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse ml-1" />
            )}
          </button>

          <button
            id="tab_ponto_bater"
            onClick={() => setActiveTab('bater')}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all ${
              activeTab === 'bater'
                ? 'bg-white text-blue-700 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Terminal de Ponto</span>
          </button>

          <button
            id="tab_ponto_auditoria"
            onClick={() => setActiveTab('auditoria')}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all ${
              activeTab === 'auditoria'
                ? 'bg-white text-blue-700 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileEdit className="w-4 h-4" />
            <span>Auditoria & Banco de Horas</span>
            {totalInconsistencias > 0 && (
              <span className="px-1.5 py-0.2 bg-amber-500 text-white rounded-full text-[10px] font-bold">
                {totalInconsistencias}
              </span>
            )}
          </button>

          <button
            id="tab_ponto_espelho"
            onClick={() => setActiveTab('espelho')}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg transition-all ${
              activeTab === 'espelho'
                ? 'bg-white text-blue-700 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Espelho de Ponto Individual (PDF)</span>
          </button>
        </div>
      </div>

      {/* ===================================================================== */}
      {/* ABA 1: MONITOR EM TEMPO REAL (HOJE) */}
      {/* ===================================================================== */}
      {activeTab === 'monitor' && (
        <div id="aba_conteudo_monitor" className="space-y-6">
          {/* Cards de Métricas de Hoje */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Total Ativos</p>
              <p className="text-2xl font-bold text-slate-800 mt-1">
                {painelHoje?.totalFuncionarios ?? funcionarios.length}
              </p>
              <span className="text-[10px] text-slate-400 mt-0.5 block">Quadro CLT</span>
            </div>

            <div className="bg-emerald-50/50 p-4 rounded-xl border border-emerald-200 shadow-2xs">
              <div className="flex items-center justify-between">
                <p className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider">Trabalhando</p>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              </div>
              <p className="text-2xl font-bold text-emerald-800 mt-1">
                {painelHoje?.trabalhandoAgora ?? 0}
              </p>
              <span className="text-[10px] text-emerald-600 mt-0.5 block">Presentes agora</span>
            </div>

            <div className="bg-amber-50/50 p-4 rounded-xl border border-amber-200 shadow-2xs">
              <div className="flex items-center justify-between">
                <p className="text-[11px] font-semibold text-amber-700 uppercase tracking-wider">Em Intervalo</p>
                <Coffee className="w-3.5 h-3.5 text-amber-600" />
              </div>
              <p className="text-2xl font-bold text-amber-800 mt-1">
                {painelHoje?.emIntervalo ?? 0}
              </p>
              <span className="text-[10px] text-amber-600 mt-0.5 block">Almoço / Refeição</span>
            </div>

            <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-200 shadow-2xs">
              <p className="text-[11px] font-semibold text-blue-700 uppercase tracking-wider">Concluído</p>
              <p className="text-2xl font-bold text-blue-800 mt-1">
                {painelHoje?.expedienteConcluido ?? 0}
              </p>
              <span className="text-[10px] text-blue-600 mt-0.5 block">Saída 2 registrada</span>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 shadow-2xs">
              <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Sem Registro</p>
              <p className="text-2xl font-bold text-slate-700 mt-1">
                {painelHoje?.semRegistro ?? 0}
              </p>
              <span className="text-[10px] text-slate-400 mt-0.5 block">Aguardando entrada</span>
            </div>

            <div className="bg-rose-50/50 p-4 rounded-xl border border-rose-200 shadow-2xs">
              <p className="text-[11px] font-semibold text-rose-700 uppercase tracking-wider">Inconsistências</p>
              <p className="text-2xl font-bold text-rose-800 mt-1">
                {painelHoje?.comInconsistencia ?? 0}
              </p>
              <span className="text-[10px] text-rose-600 mt-0.5 block">Requer atenção RH</span>
            </div>
          </div>

          {/* Lista de Colaboradores Hoje com Timeline */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
              <div>
                <h3 className="text-base font-bold text-slate-800">Quadro de Jornada em Tempo Real</h3>
                <p className="text-xs text-slate-500">
                  Data: {painelHoje?.dataHoje || '2026-09-13'} • Terminal REP-P ContabGest
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  id="btn_atualizar_monitor"
                  onClick={carregarDados}
                  disabled={loading}
                  className="flex items-center space-x-1 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors shadow-2xs"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  <span>Atualizar</span>
                </button>
                <button
                  id="btn_ir_terminal_ponto"
                  onClick={() => setActiveTab('bater')}
                  className="flex items-center space-x-1.5 px-3.5 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-semibold hover:bg-blue-700 transition-colors shadow-2xs"
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>Bater Ponto Agora</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-100/70 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                    <th className="py-3 px-4">Colaborador & Matrícula</th>
                    <th className="py-3 px-3">Status Atual</th>
                    <th className="py-3 px-3 text-center">1ª Entrada</th>
                    <th className="py-3 px-3 text-center">Saída Almoço</th>
                    <th className="py-3 px-3 text-center">Retorno Almoço</th>
                    <th className="py-3 px-3 text-center">2ª Saída</th>
                    <th className="py-3 px-3 text-center">Horas Hoje</th>
                    <th className="py-3 px-4 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {/* Colaboradores com registros hoje */}
                  {(painelHoje?.registros || []).map((ponto) => {
                    let statusBadge = (
                      <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-700">
                        Pendente
                      </span>
                    );
                    if (ponto.saida2) {
                      statusBadge = (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-100 text-blue-800">
                          <Check className="w-3 h-3" />
                          <span>Expediente Concluído</span>
                        </span>
                      );
                    } else if (ponto.saidaIntervalo && !ponto.retornoIntervalo) {
                      statusBadge = (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-100 text-amber-800">
                          <Coffee className="w-3 h-3" />
                          <span>Em Intervalo</span>
                        </span>
                      );
                    } else if (ponto.entrada1) {
                      statusBadge = (
                        <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse mr-1" />
                          <span>Trabalhando</span>
                        </span>
                      );
                    }

                    return (
                      <tr key={ponto.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3.5 px-4">
                          <div className="flex items-center space-x-2.5">
                            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold flex items-center justify-center text-xs shrink-0">
                              {ponto.funcionarioNome
                                .split(' ')
                                .map((n) => n[0])
                                .slice(0, 2)
                                .join('')}
                            </div>
                            <div>
                              <p className="font-bold text-slate-800 text-xs">{ponto.funcionarioNome}</p>
                              <p className="text-[11px] text-slate-500 font-mono">{ponto.funcionarioMatricula} • {ponto.funcionarioCargo}</p>
                            </div>
                          </div>
                        </td>

                        <td className="py-3.5 px-3">{statusBadge}</td>

                        <td className="py-3.5 px-3 text-center font-mono font-medium text-slate-700">
                          {ponto.entrada1 ? (
                            <span className="bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                              {ponto.entrada1}
                            </span>
                          ) : (
                            <span className="text-slate-300">--:--</span>
                          )}
                        </td>

                        <td className="py-3.5 px-3 text-center font-mono font-medium text-slate-700">
                          {ponto.saidaIntervalo ? (
                            <span className="bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                              {ponto.saidaIntervalo}
                            </span>
                          ) : (
                            <span className="text-slate-300">--:--</span>
                          )}
                        </td>

                        <td className="py-3.5 px-3 text-center font-mono font-medium text-slate-700">
                          {ponto.retornoIntervalo ? (
                            <span className="bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                              {ponto.retornoIntervalo}
                            </span>
                          ) : (
                            <span className="text-slate-300">--:--</span>
                          )}
                        </td>

                        <td className="py-3.5 px-3 text-center font-mono font-medium text-slate-700">
                          {ponto.saida2 ? (
                            <span className="bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                              {ponto.saida2}
                            </span>
                          ) : (
                            <span className="text-slate-300">--:--</span>
                          )}
                        </td>

                        <td className="py-3.5 px-3 text-center">
                          <span className="font-bold text-slate-800 font-mono">
                            {formatMinutosParaHoras(ponto.horasTrabalhadasMinutos)}
                          </span>
                        </td>

                        <td className="py-3.5 px-4 text-right space-x-1">
                          <button
                            id={`btn_ajustar_ponto_${ponto.id}`}
                            onClick={() => {
                              setPontoParaAjustar(ponto);
                              setIsAjustarModalOpen(true);
                            }}
                            className="px-2 py-1 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded text-xs transition-colors"
                            title="Ajustar batida"
                          >
                            Ajustar
                          </button>
                          <button
                            id={`btn_espelho_ponto_${ponto.funcionarioId}`}
                            onClick={() => {
                              const f = funcionarios.find((func) => func.id === ponto.funcionarioId);
                              if (f) setSelectedEspelhoFuncionario(f);
                              setActiveTab('espelho');
                            }}
                            className="px-2 py-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded text-xs transition-colors"
                            title="Ver espelho mensal"
                          >
                            Espelho
                          </button>
                        </td>
                      </tr>
                    );
                  })}

                  {/* Colaboradores sem registro hoje */}
                  {(painelHoje?.colaboradoresSemRegistro || []).map((colab) => (
                    <tr key={colab.id} className="hover:bg-slate-50/40 text-slate-400">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center space-x-2.5 opacity-75">
                          <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-600 font-bold flex items-center justify-center text-xs shrink-0">
                            {colab.nomeCompleto
                              .split(' ')
                              .map((n) => n[0])
                              .slice(0, 2)
                              .join('')}
                          </div>
                          <div>
                            <p className="font-medium text-slate-700 text-xs">{colab.nomeCompleto}</p>
                            <p className="text-[11px] text-slate-400 font-mono">{colab.matricula} • {colab.cargoNome}</p>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-3">
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-500">
                          Aguardando Chegada
                        </span>
                      </td>

                      <td className="py-3.5 px-3 text-center text-slate-300 font-mono">--:--</td>
                      <td className="py-3.5 px-3 text-center text-slate-300 font-mono">--:--</td>
                      <td className="py-3.5 px-3 text-center text-slate-300 font-mono">--:--</td>
                      <td className="py-3.5 px-3 text-center text-slate-300 font-mono">--:--</td>
                      <td className="py-3.5 px-3 text-center text-slate-300 font-mono">00h00</td>

                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => {
                            setSelectedFuncionarioPonto(colab);
                            setActiveTab('bater');
                          }}
                          className="px-2.5 py-1 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded text-xs font-semibold transition-colors"
                        >
                          Registrar Ponto
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* ABA 2: TERMINAL DE PONTO ELETRÔNICO (REP-P) */}
      {/* ===================================================================== */}
      {activeTab === 'bater' && (
        <div id="aba_conteudo_bater" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Relógio Digital e Seletor do Colaborador */}
          <div className="lg:col-span-1 space-y-6">
            {/* Display do Relógio Oficial */}
            <div className="bg-slate-900 text-white rounded-2xl p-6 border border-slate-800 shadow-md text-center">
              <p className="text-xs text-slate-400 uppercase tracking-widest font-semibold">
                Horário Oficial de Brasília (BRT)
              </p>
              <div className="my-3 font-mono text-4xl sm:text-5xl font-extrabold tracking-tight text-white select-none">
                {horaAtual.toLocaleTimeString('pt-BR', {
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit',
                })}
              </div>
              <p className="text-xs text-slate-300 capitalize">
                {horaAtual.toLocaleDateString('pt-BR', {
                  weekday: 'long',
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                })}
              </p>
              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-center space-x-2 text-[11px] text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>Terminal REP-P Homologado & Ativo</span>
              </div>
            </div>

            {/* Seletor de Colaborador */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Selecione o Colaborador
              </label>
              <select
                id="select_colaborador_ponto"
                value={selectedFuncionarioPonto?.id || ''}
                onChange={(e) => {
                  const f = funcionarios.find((item) => item.id === e.target.value);
                  if (f) setSelectedFuncionarioPonto(f);
                }}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
              >
                {funcionarios.map((func) => (
                  <option key={func.id} value={func.id}>
                    {func.nomeCompleto} ({func.matricula})
                  </option>
                ))}
              </select>

              {/* Card Resumo do Colaborador Selecionado */}
              {selectedFuncionarioPonto && (
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5">
                  <div className="flex items-center space-x-2">
                    <Building2 className="w-3.5 h-3.5 text-slate-400" />
                    <span className="text-slate-600 font-medium">{selectedFuncionarioPonto.empresaNome}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Laptop className="w-3.5 h-3.5 text-slate-400" />
                    <span className="text-slate-600 font-medium">{selectedFuncionarioPonto.cargoNome} ({selectedFuncionarioPonto.departamento})</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Hash className="w-3.5 h-3.5 text-slate-400" />
                    <span className="text-slate-500 font-mono">CPF: {selectedFuncionarioPonto.cpf} • PIS: {selectedFuncionarioPonto.pisPasep || 'Cadastrado'}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Painel de Ações de Batida */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
              <div>
                <h3 className="text-base font-bold text-slate-800">Marcação de Ponto Eletrônico</h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Clique no botão correspondente à etapa da sua jornada para registrar a marcação instantânea.
                </p>
              </div>

              {/* Botões de Ação de Ponto */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* 1ª Entrada */}
                <button
                  id="btn_bater_entrada1"
                  onClick={() => handleBaterPonto('entrada_1')}
                  disabled={registrandoPonto}
                  className={`p-4 rounded-xl border-2 text-left flex items-start space-x-3.5 transition-all ${
                    proximaBatidaSugerida.tipo === 'entrada_1'
                      ? 'border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-500/20 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-emerald-300 hover:bg-emerald-50/20'
                  }`}
                >
                  <div className="p-2.5 rounded-lg bg-emerald-600 text-white shadow-2xs">
                    <LogIn className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">1ª Entrada</span>
                    <span className="text-[11px] text-slate-600">Início do expediente diário</span>
                    {proximaBatidaSugerida.tipo === 'entrada_1' && (
                      <span className="mt-1 inline-block text-[10px] font-bold text-emerald-800 bg-emerald-200/80 px-2 py-0.5 rounded">
                        ★ Sugerida Agora
                      </span>
                    )}
                  </div>
                </button>

                {/* 1ª Saída (Almoço) */}
                <button
                  id="btn_bater_saida_intervalo"
                  onClick={() => handleBaterPonto('saida_intervalo')}
                  disabled={registrandoPonto}
                  className={`p-4 rounded-xl border-2 text-left flex items-start space-x-3.5 transition-all ${
                    proximaBatidaSugerida.tipo === 'saida_intervalo'
                      ? 'border-amber-500 bg-amber-50/60 ring-2 ring-amber-500/20 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-amber-300 hover:bg-amber-50/20'
                  }`}
                >
                  <div className="p-2.5 rounded-lg bg-amber-500 text-white shadow-2xs">
                    <Coffee className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">1ª Saída (Almoço)</span>
                    <span className="text-[11px] text-slate-600">Início do intervalo intrajornada (mín 1h)</span>
                    {proximaBatidaSugerida.tipo === 'saida_intervalo' && (
                      <span className="mt-1 inline-block text-[10px] font-bold text-amber-800 bg-amber-200/80 px-2 py-0.5 rounded">
                        ★ Sugerida Agora
                      </span>
                    )}
                  </div>
                </button>

                {/* 2ª Entrada (Volta do Almoço) */}
                <button
                  id="btn_bater_retorno_intervalo"
                  onClick={() => handleBaterPonto('retorno_intervalo')}
                  disabled={registrandoPonto}
                  className={`p-4 rounded-xl border-2 text-left flex items-start space-x-3.5 transition-all ${
                    proximaBatidaSugerida.tipo === 'retorno_intervalo'
                      ? 'border-blue-500 bg-blue-50/60 ring-2 ring-blue-500/20 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-blue-300 hover:bg-blue-50/20'
                  }`}
                >
                  <div className="p-2.5 rounded-lg bg-blue-600 text-white shadow-2xs">
                    <LogIn className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">2ª Entrada</span>
                    <span className="text-[11px] text-slate-600">Retorno do intervalo intrajornada</span>
                    {proximaBatidaSugerida.tipo === 'retorno_intervalo' && (
                      <span className="mt-1 inline-block text-[10px] font-bold text-blue-800 bg-blue-200/80 px-2 py-0.5 rounded">
                        ★ Sugerida Agora
                      </span>
                    )}
                  </div>
                </button>

                {/* 2ª Saída Final */}
                <button
                  id="btn_bater_saida2"
                  onClick={() => handleBaterPonto('saida_2')}
                  disabled={registrandoPonto}
                  className={`p-4 rounded-xl border-2 text-left flex items-start space-x-3.5 transition-all ${
                    proximaBatidaSugerida.tipo === 'saida_2'
                      ? 'border-indigo-500 bg-indigo-50/60 ring-2 ring-indigo-500/20 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-indigo-300 hover:bg-indigo-50/20'
                  }`}
                >
                  <div className="p-2.5 rounded-lg bg-indigo-600 text-white shadow-2xs">
                    <LogOut className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-900 block">2ª Saída</span>
                    <span className="text-[11px] text-slate-600">Término da jornada do dia</span>
                    {proximaBatidaSugerida.tipo === 'saida_2' && (
                      <span className="mt-1 inline-block text-[10px] font-bold text-indigo-800 bg-indigo-200/80 px-2 py-0.5 rounded">
                        ★ Sugerida Agora
                      </span>
                    )}
                  </div>
                </button>
              </div>

              {/* Observação / Justificativa Opcional */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Observação ou Justificativa (Opcional)
                </label>
                <input
                  id="input_obs_ponto"
                  type="text"
                  value={observacaoPonto}
                  onChange={(e) => setObservacaoPonto(e.target.value)}
                  placeholder="Ex: Trabalho externo autorizado, início antecipado para manutenção..."
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              {/* Rodapé Legal com Garantias de Conformidade */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-600">
                <div className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Geolocalização capturada: <strong>Av. Paulista, 1842 - SP (Precisão: 8m)</strong></span>
                </div>
                <div className="flex items-center space-x-1.5 text-blue-700 font-semibold">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Emissão Automática de Comprovante NSR</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* ABA 3: AUDITORIA DE JORNADA & BANCO DE HORAS */}
      {/* ===================================================================== */}
      {activeTab === 'auditoria' && (
        <div id="aba_conteudo_auditoria" className="space-y-6">
          {/* Barra de Filtros e Ações em Lote */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3">
              {/* Competência */}
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Competência
                </label>
                <input
                  id="filtro_competencia_auditoria"
                  type="text"
                  value={filtroCompetencia}
                  onChange={(e) => setFiltroCompetencia(e.target.value)}
                  placeholder="MM/AAAA"
                  className="w-28 px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none font-mono"
                />
              </div>

              {/* Colaborador */}
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Colaborador
                </label>
                <select
                  id="filtro_funcionario_auditoria"
                  value={filtroFuncionario}
                  onChange={(e) => setFiltroFuncionario(e.target.value)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="todos">Todos os Colaboradores</option>
                  {funcionarios.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.nomeCompleto}
                    </option>
                  ))}
                </select>
              </div>

              {/* Status */}
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Status Auditoria
                </label>
                <select
                  id="filtro_status_auditoria"
                  value={filtroStatus}
                  onChange={(e) => setFiltroStatus(e.target.value)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="todos">Todos os Status</option>
                  <option value="pendente">Pendente de Auditoria</option>
                  <option value="com_inconsistencia">Com Inconsistência (Alerta)</option>
                  <option value="aprovado">Aprovado / Regular</option>
                  <option value="ajustado">Ajustado pelo RH</option>
                  <option value="abonado">Abonado</option>
                </select>
              </div>

              {/* Checkbox Apenas Inconsistências */}
              <div className="flex items-center pt-5">
                <label className="flex items-center space-x-2 cursor-pointer text-xs font-semibold text-amber-700 bg-amber-50 px-3 py-1.5 rounded-lg border border-amber-200">
                  <input
                    id="checkbox_apenas_inconsistencias"
                    type="checkbox"
                    checked={filtroInconsistencias}
                    onChange={(e) => setFiltroInconsistencias(e.target.checked)}
                    className="rounded text-amber-600 focus:ring-amber-500"
                  />
                  <span>Apenas com Pendências ({totalInconsistencias})</span>
                </label>
              </div>
            </div>

            {/* Ações em Lote */}
            <div className="flex items-center space-x-2 pt-2 lg:pt-0">
              <button
                id="btn_homologar_lote"
                onClick={handleHomologarLote}
                className="flex items-center space-x-1.5 px-4 py-2 bg-emerald-600 text-white rounded-lg text-xs font-bold hover:bg-emerald-700 transition-colors shadow-2xs"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Homologar Regulares em Lote</span>
              </button>
            </div>
          </div>

          {/* Tabela de Auditoria de Ponto */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center space-x-2">
                <FileEdit className="w-4 h-4 text-blue-600" />
                <h3 className="text-sm font-bold text-slate-800">
                  Registros de Ponto para Auditoria ({pontosFiltrados.length})
                </h3>
              </div>

              {/* Busca por texto */}
              <div className="relative w-64">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                <input
                  id="input_busca_auditoria"
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Buscar colaborador ou data..."
                  className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-100/70 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                    <th className="py-3 px-4">Data / Dia</th>
                    <th className="py-3 px-3">Colaborador</th>
                    <th className="py-3 px-2 text-center">E1</th>
                    <th className="py-3 px-2 text-center">S1 (Almoço)</th>
                    <th className="py-3 px-2 text-center">E2 (Volta)</th>
                    <th className="py-3 px-2 text-center">S2 (Saída)</th>
                    <th className="py-3 px-3 text-center">Trabalhadas</th>
                    <th className="py-3 px-3 text-center">Saldo Diário</th>
                    <th className="py-3 px-3">Status / Inconsistência</th>
                    <th className="py-3 px-4 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {pontosFiltrados.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="py-8 text-center text-slate-400">
                        Nenhum registro de ponto localizado com os filtros atuais.
                      </td>
                    </tr>
                  ) : (
                    pontosFiltrados.map((ponto) => {
                      const hasInconsistencia =
                        ponto.statusAuditoria === 'com_inconsistencia' ||
                        (ponto.inconsistencias && ponto.inconsistencias.length > 0);

                      return (
                        <tr
                          key={ponto.id}
                          className={`hover:bg-slate-50 transition-colors ${
                            hasInconsistencia ? 'bg-amber-50/30' : ''
                          }`}
                        >
                          {/* Data e Dia */}
                          <td className="py-3 px-4 whitespace-nowrap">
                            <p className="font-mono font-bold text-slate-800">{ponto.data}</p>
                            <p className="text-[10px] text-slate-500">{ponto.diaSemana}</p>
                          </td>

                          {/* Colaborador */}
                          <td className="py-3 px-3">
                            <p className="font-bold text-slate-800 text-xs">{ponto.funcionarioNome}</p>
                            <p className="text-[10px] text-slate-500 font-mono">{ponto.funcionarioMatricula}</p>
                          </td>

                          {/* E1 */}
                          <td className="py-3 px-2 text-center font-mono text-xs">
                            {ponto.entrada1 ? (
                              <span className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-800 font-medium">
                                {ponto.entrada1}
                              </span>
                            ) : (
                              <span className="text-slate-300">--:--</span>
                            )}
                          </td>

                          {/* S1 */}
                          <td className="py-3 px-2 text-center font-mono text-xs">
                            {ponto.saidaIntervalo ? (
                              <span className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-800 font-medium">
                                {ponto.saidaIntervalo}
                              </span>
                            ) : (
                              <span className="text-slate-300">--:--</span>
                            )}
                          </td>

                          {/* E2 */}
                          <td className="py-3 px-2 text-center font-mono text-xs">
                            {ponto.retornoIntervalo ? (
                              <span className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-800 font-medium">
                                {ponto.retornoIntervalo}
                              </span>
                            ) : (
                              <span className="text-slate-300">--:--</span>
                            )}
                          </td>

                          {/* S2 */}
                          <td className="py-3 px-2 text-center font-mono text-xs">
                            {ponto.saida2 ? (
                              <span className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-800 font-medium">
                                {ponto.saida2}
                              </span>
                            ) : (
                              <span className="text-slate-300">--:--</span>
                            )}
                          </td>

                          {/* Trabalhadas */}
                          <td className="py-3 px-3 text-center font-mono font-bold text-slate-800">
                            {formatMinutosParaHoras(ponto.horasTrabalhadasMinutos)}
                          </td>

                          {/* Saldo Diário */}
                          <td className="py-3 px-3 text-center font-mono font-bold">
                            {ponto.horasExtrasMinutos > 0 ? (
                              <span className="text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded text-[11px]">
                                +{formatMinutosParaHoras(ponto.horasExtrasMinutos)}
                              </span>
                            ) : ponto.horasNegativasMinutos > 0 ? (
                              <span className="text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded text-[11px]">
                                -{formatMinutosParaHoras(ponto.horasNegativasMinutos)}
                              </span>
                            ) : (
                              <span className="text-slate-400 text-[11px]">00h00</span>
                            )}
                          </td>

                          {/* Status / Inconsistência */}
                          <td className="py-3 px-3">
                            {hasInconsistencia ? (
                              <div className="space-y-1">
                                <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                                  <AlertTriangle className="w-3 h-3 text-amber-600" />
                                  <span>Inconsistência</span>
                                </span>
                                {ponto.inconsistencias?.map((inc, i) => (
                                  <p key={i} className="text-[10px] text-amber-700 leading-tight">
                                    • {inc}
                                  </p>
                                ))}
                              </div>
                            ) : ponto.statusAuditoria === 'aprovado' ? (
                              <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                                <Check className="w-3 h-3" />
                                <span>Aprovado</span>
                              </span>
                            ) : ponto.statusAuditoria === 'ajustado' ? (
                              <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-100 text-blue-800">
                                <span>Ajustado pelo RH</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-600">
                                Pendente
                              </span>
                            )}
                          </td>

                          {/* Ações */}
                          <td className="py-3 px-4 text-right space-x-1 whitespace-nowrap">
                            <button
                              id={`btn_auditar_ajuste_${ponto.id}`}
                              onClick={() => {
                                setPontoParaAjustar(ponto);
                                setIsAjustarModalOpen(true);
                              }}
                              className="px-2.5 py-1 text-slate-700 hover:text-blue-700 hover:bg-blue-50 rounded text-xs font-semibold transition-colors border border-slate-200"
                            >
                              Retificar
                            </button>
                            {ponto.statusAuditoria !== 'aprovado' && !hasInconsistencia && (
                              <button
                                id={`btn_aprovar_ponto_${ponto.id}`}
                                onClick={() => handleHomologarPonto(ponto)}
                                className="px-2.5 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded text-xs font-semibold transition-colors border border-emerald-200"
                              >
                                Aprovar
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* ABA 4: ESPELHO DE PONTO INDIVIDUAL (REP-P & GERADOR DE PDF CLT) */}
      {/* ===================================================================== */}
      {activeTab === 'espelho' && (
        <div id="aba_conteudo_espelho">
          <EspelhoPontoModal
            funcionarioId={selectedEspelhoFuncionario?.id || (funcionarios[0]?.id ?? '')}
            funcionarios={funcionarios}
            initialCompetencia={filtroCompetencia}
            isEmbedded={true}
          />
        </div>
      )}

      {/* Modais */}
      <ComprovantePontoModal
        isOpen={isComprovanteModalOpen}
        onClose={() => setIsComprovanteModalOpen(false)}
        comprovante={comprovanteAtual}
      />

      <AjustarPontoModal
        isOpen={isAjustarModalOpen}
        onClose={() => {
          setIsAjustarModalOpen(false);
          setPontoParaAjustar(null);
        }}
        ponto={pontoParaAjustar}
        onSave={handleSalvarAjuste}
      />
    </div>
  );
};
