import React from 'react';
import {
  Printer,
  FileCheck,
  Building2,
  User,
  Calendar,
  DollarSign,
  AlertCircle,
  Download,
  Copy,
  Check,
  ArrowLeft,
} from 'lucide-react';
import { DocumentoTRCT } from '../../types';

interface TRCTDocumentViewerProps {
  trct: DocumentoTRCT;
  onClose?: () => void;
}

export const TRCTDocumentViewer: React.FC<TRCTDocumentViewerProps> = ({ trct, onClose }) => {
  const [copiedKey, setCopiedKey] = React.useState(false);

  const handlePrint = () => {
    window.print();
  };

  const handleCopyChave = () => {
    if (trct.dadosFgts.chaveConectividade) {
      navigator.clipboard.writeText(trct.dadosFgts.chaveConectividade);
      setCopiedKey(true);
      setTimeout(() => setCopiedKey(false), 2000);
    }
  };

  const proventos = trct.rubricas.filter((r) => r.tipo === 'provento');
  const descontos = trct.rubricas.filter((r) => r.tipo === 'desconto');

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '-';
    if (dateStr.includes('/')) return dateStr;
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      return `${parts[2]}/${parts[1]}/${parts[0]}`;
    }
    return dateStr;
  };

  return (
    <div className="space-y-6">
      {/* Barra de Ações Superior (oculta na impressão) */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-sm print:hidden">
        <div className="flex items-center gap-3">
          {onClose && (
            <button
              onClick={onClose}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Voltar ao Cálculo
            </button>
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                Portaria MTE nº 1.057/2012
              </span>
              <span className="text-xs font-medium text-slate-500">
                Termo Homologatório Oficial
              </span>
            </div>
            <h3 className="text-base font-bold text-slate-900">
              TRCT Oficial: {trct.numeroTermo}
            </h3>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {trct.dadosFgts.chaveConectividade && (
            <button
              onClick={handleCopyChave}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors"
              title="Copiar Chave Conectividade Social"
            >
              {copiedKey ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  Chave Copiada!
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-500" />
                  Chave FGTS: {trct.dadosFgts.chaveConectividade}
                </>
              )}
            </button>
          )}

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-colors"
          >
            <Printer className="w-4 h-4" />
            Imprimir / Gerar PDF
          </button>
        </div>
      </div>

      {/* DOCUMENTO OFICIAL TRCT (Folha A4 formatada) */}
      <div
        id="trct-document-printable"
        className="bg-white p-6 sm:p-10 rounded-xl border border-slate-300 shadow-md text-slate-900 print:border-none print:shadow-none print:p-0 print:m-0 text-[11px] leading-tight"
        style={{ fontFamily: 'Arial, Helvetica, sans-serif' }}
      >
        {/* Cabeçalho Oficial do Ministério do Trabalho */}
        <div className="border border-black p-3 text-center mb-4">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-700">
            República Federativa do Brasil — Ministério do Trabalho e Emprego
          </div>
          <h1 className="text-base font-extrabold uppercase mt-1">
            Termo de Rescisão do Contrato de Trabalho
          </h1>
          <div className="text-[10px] font-semibold text-slate-600 mt-0.5">
            Conforme Portaria MTE nº 1.057/2012 e Artigo 477 da Consolidação das Leis do Trabalho (CLT)
          </div>
          <div className="mt-1 inline-block px-3 py-0.5 border border-black font-mono text-xs font-bold">
            Nº DO TERMO: {trct.numeroTermo}
          </div>
        </div>

        {/* 1. IDENTIFICAÇÃO DO EMPREGADOR */}
        <div className="mb-4">
          <div className="bg-slate-200 border border-black px-2 py-1 font-bold text-[11px] uppercase">
            Identificação do Empregador
          </div>
          <div className="border-x border-b border-black grid grid-cols-12 text-[10px]">
            <div className="col-span-12 sm:col-span-4 p-1.5 border-b sm:border-b-0 sm:border-r border-black">
              <span className="font-bold text-slate-600">01 CNPJ/CEI/CAEPF:</span>
              <div className="font-mono font-bold text-xs mt-0.5">{trct.empresa.cnpj}</div>
            </div>
            <div className="col-span-12 sm:col-span-8 p-1.5">
              <span className="font-bold text-slate-600">02 Razão Social / Nome:</span>
              <div className="font-bold text-xs mt-0.5">{trct.empresa.razaoSocial}</div>
            </div>
          </div>
          <div className="border-x border-b border-black grid grid-cols-12 text-[10px]">
            <div className="col-span-12 sm:col-span-8 p-1.5 border-b sm:border-b-0 sm:border-r border-black">
              <span className="font-bold text-slate-600">03 Endereço (Logradouro, Nº, Bairro):</span>
              <div className="mt-0.5">{trct.empresa.endereco}</div>
            </div>
            <div className="col-span-12 sm:col-span-4 p-1.5">
              <span className="font-bold text-slate-600">04 Município / UF:</span>
              <div className="mt-0.5 font-medium">{trct.empresa.cidadeUf}</div>
            </div>
          </div>
        </div>

        {/* 2. IDENTIFICAÇÃO DO TRABALHADOR */}
        <div className="mb-4">
          <div className="bg-slate-200 border border-black px-2 py-1 font-bold text-[11px] uppercase">
            Identificação do Trabalhador
          </div>
          <div className="border-x border-b border-black grid grid-cols-12 text-[10px]">
            <div className="col-span-12 sm:col-span-3 p-1.5 border-b sm:border-b-0 sm:border-r border-black">
              <span className="font-bold text-slate-600">10 PIS/PASEP:</span>
              <div className="font-mono font-semibold text-xs mt-0.5">{trct.funcionario.pisPasep}</div>
            </div>
            <div className="col-span-12 sm:col-span-6 p-1.5 border-b sm:border-b-0 sm:border-r border-black">
              <span className="font-bold text-slate-600">11 Nome do Trabalhador:</span>
              <div className="font-bold text-xs mt-0.5">{trct.funcionario.nome}</div>
            </div>
            <div className="col-span-12 sm:col-span-3 p-1.5">
              <span className="font-bold text-slate-600">15 CPF:</span>
              <div className="font-mono font-semibold text-xs mt-0.5">{trct.funcionario.cpf}</div>
            </div>
          </div>
          <div className="border-x border-b border-black grid grid-cols-12 text-[10px]">
            <div className="col-span-12 sm:col-span-4 p-1.5 border-b sm:border-b-0 sm:border-r border-black">
              <span className="font-bold text-slate-600">14 CTPS (Nº, Série, UF):</span>
              <div className="mt-0.5 font-medium">{trct.funcionario.ctps}</div>
            </div>
            <div className="col-span-12 sm:col-span-4 p-1.5 border-b sm:border-b-0 sm:border-r border-black">
              <span className="font-bold text-slate-600">16 Data de Nascimento:</span>
              <div className="mt-0.5 font-medium">{formatDate(trct.funcionario.dataNascimento)}</div>
            </div>
            <div className="col-span-12 sm:col-span-4 p-1.5">
              <span className="font-bold text-slate-600">17 Nome da Mãe:</span>
              <div className="mt-0.5 font-medium truncate">{trct.funcionario.nomeMae || '-'}</div>
            </div>
          </div>
          <div className="border-x border-b border-black grid grid-cols-12 text-[10px]">
            <div className="col-span-12 p-1.5">
              <span className="font-bold text-slate-600">12 Endereço Completo:</span>
              <div className="mt-0.5">{trct.funcionario.endereco || '-'}</div>
            </div>
          </div>
        </div>

        {/* 3. DADOS DO CONTRATO DE TRABALHO */}
        <div className="mb-4">
          <div className="bg-slate-200 border border-black px-2 py-1 font-bold text-[11px] uppercase">
            Dados do Contrato
          </div>
          <div className="border-x border-b border-black grid grid-cols-12 text-[10px]">
            <div className="col-span-12 sm:col-span-4 p-1.5 border-b sm:border-b-0 sm:border-r border-black">
              <span className="font-bold text-slate-600">20 Tipo de Contrato:</span>
              <div className="mt-0.5 font-semibold">{trct.dadosRescisao.tipoContrato}</div>
            </div>
            <div className="col-span-12 sm:col-span-5 p-1.5 border-b sm:border-b-0 sm:border-r border-black">
              <span className="font-bold text-slate-600">21 Causa do Afastamento:</span>
              <div className="mt-0.5 font-semibold text-slate-900">{trct.dadosRescisao.motivoDescricao}</div>
            </div>
            <div className="col-span-12 sm:col-span-3 p-1.5">
              <span className="font-bold text-slate-600">22 Remuneração p/ Fins Resc.:</span>
              <div className="mt-0.5 font-mono font-bold text-xs">{formatCurrency(trct.funcionario.remuneracaoMesAnterior)}</div>
            </div>
          </div>
          <div className="border-x border-b border-black grid grid-cols-12 text-[10px]">
            <div className="col-span-6 sm:col-span-2 p-1.5 border-r border-b sm:border-b-0 border-black">
              <span className="font-bold text-slate-600">23 Data Admissão:</span>
              <div className="mt-0.5 font-medium">{formatDate(trct.funcionario.dataAdmissao)}</div>
            </div>
            <div className="col-span-6 sm:col-span-2 p-1.5 border-r border-b sm:border-b-0 border-black">
              <span className="font-bold text-slate-600">24 Data do Aviso:</span>
              <div className="mt-0.5 font-medium">{formatDate(trct.funcionario.dataAviso)}</div>
            </div>
            <div className="col-span-6 sm:col-span-2 p-1.5 border-r border-b sm:border-b-0 border-black">
              <span className="font-bold text-slate-600">25 Data Afastamento:</span>
              <div className="mt-0.5 font-bold text-red-700">{formatDate(trct.funcionario.dataAfastamento)}</div>
            </div>
            <div className="col-span-6 sm:col-span-2 p-1.5 border-r border-b sm:border-b-0 border-black">
              <span className="font-bold text-slate-600">26 Limite Pagamento:</span>
              <div className="mt-0.5 font-bold text-blue-700">{formatDate(trct.dadosRescisao.dataLimitePagamento)}</div>
            </div>
            <div className="col-span-6 sm:col-span-2 p-1.5 border-r border-black">
              <span className="font-bold text-slate-600">27 Cód. Afastamento:</span>
              <div className="mt-0.5 font-semibold text-slate-800">{trct.dadosRescisao.codigoAfastamento}</div>
            </div>
            <div className="col-span-6 sm:col-span-2 p-1.5">
              <span className="font-bold text-slate-600">Tipo de Aviso:</span>
              <div className="mt-0.5 font-medium">{trct.dadosRescisao.tipoAvisoDescricao}</div>
            </div>
          </div>
          <div className="border-x border-b border-black grid grid-cols-12 text-[10px]">
            <div className="col-span-12 sm:col-span-6 p-1.5 border-b sm:border-b-0 sm:border-r border-black">
              <span className="font-bold text-slate-600">Cargo do Trabalhador / CBO:</span>
              <div className="mt-0.5 font-medium">{trct.funcionario.cargo} (CBO: {trct.funcionario.cbo})</div>
            </div>
            <div className="col-span-12 sm:col-span-6 p-1.5">
              <span className="font-bold text-slate-600">30 Entidade Sindical Laboral:</span>
              <div className="mt-0.5 font-medium truncate">{trct.dadosRescisao.sindicatoNome || 'Sindicato da Categoria Profissional'}</div>
            </div>
          </div>
        </div>

        {/* 4. DISCRIMINAÇÃO DAS VERBAS RESCISÓRIAS (RUBRICAS PORTARIA 1.057/2012) */}
        <div className="mb-4">
          <div className="bg-slate-200 border border-black px-2 py-1 font-bold text-[11px] uppercase flex items-center justify-between">
            <span>Discriminação das Verbas Rescisórias</span>
            <span className="text-[9px] font-normal text-slate-600">Rubricas oficiais do Ministério do Trabalho</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border-x border-b border-black text-[10px]">
            {/* Coluna 1: Proventos */}
            <div className="border-b md:border-b-0 md:border-r border-black">
              <div className="bg-emerald-50 border-b border-black px-2 py-1 font-bold text-[10px] text-emerald-900 flex justify-between uppercase">
                <span>Rubricas de Proventos / Vencimentos</span>
                <span>Valor (R$)</span>
              </div>
              <div className="divide-y divide-slate-200">
                {proventos.map((item, idx) => (
                  <div key={idx} className="p-1.5 flex items-center justify-between hover:bg-slate-50">
                    <div className="flex-1 pr-2">
                      <span className="font-mono font-bold text-slate-700 mr-1.5">[{item.codigo}]</span>
                      <span className="font-medium text-slate-900">{item.descricao}</span>
                      <span className="text-slate-500 text-[9px] ml-1.5">({item.referencia})</span>
                    </div>
                    <div className="font-mono font-bold text-slate-900 whitespace-nowrap">
                      {formatCurrency(item.valor)}
                    </div>
                  </div>
                ))}
              </div>
              <div className="bg-slate-100 border-t border-black p-2 flex justify-between font-bold text-xs">
                <span>99 TOTAL BRUTO DOS PROVENTOS:</span>
                <span className="font-mono text-emerald-700">{formatCurrency(trct.totais.totalBruto)}</span>
              </div>
            </div>

            {/* Coluna 2: Deduções */}
            <div>
              <div className="bg-rose-50 border-b border-black px-2 py-1 font-bold text-[10px] text-rose-900 flex justify-between uppercase">
                <span>Rubricas de Descontos / Deduções</span>
                <span>Valor (R$)</span>
              </div>
              <div className="divide-y divide-slate-200">
                {descontos.length === 0 ? (
                  <div className="p-3 text-center text-slate-400 italic">
                    Nenhuma dedução rescisória apurada.
                  </div>
                ) : (
                  descontos.map((item, idx) => (
                    <div key={idx} className="p-1.5 flex items-center justify-between hover:bg-slate-50">
                      <div className="flex-1 pr-2">
                        <span className="font-mono font-bold text-slate-700 mr-1.5">[{item.codigo}]</span>
                        <span className="font-medium text-slate-900">{item.descricao}</span>
                        <span className="text-slate-500 text-[9px] ml-1.5">({item.referencia})</span>
                      </div>
                      <div className="font-mono font-bold text-rose-600 whitespace-nowrap">
                        - {formatCurrency(item.valor)}
                      </div>
                    </div>
                  ))
                )}
              </div>
              <div className="bg-slate-100 border-t border-black p-2 flex justify-between font-bold text-xs">
                <span>115 TOTAL DAS DEDUÇÕES:</span>
                <span className="font-mono text-rose-700">- {formatCurrency(trct.totais.totalDescontos)}</span>
              </div>
            </div>
          </div>

          {/* TOTAL LÍQUIDO RESCISÓRIO */}
          <div className="border-x border-b-2 border-black bg-emerald-50 p-2.5 flex items-center justify-between">
            <div>
              <div className="text-xs font-black uppercase text-emerald-950">
                116 VALOR RESCISÓRIO LÍQUIDO A PAGAR AO TRABALHADOR
              </div>
              <div className="text-[10px] text-emerald-800">
                Pagamento até {formatDate(trct.dadosRescisao.dataLimitePagamento)} (Art. 477 § 6º CLT)
              </div>
            </div>
            <div className="text-right">
              <div className="text-lg font-black font-mono text-emerald-700">
                {formatCurrency(trct.totais.totalLiquido)}
              </div>
            </div>
          </div>
        </div>

        {/* 5. DADOS DO FGTS & MULTA RESCISÓRIA */}
        <div className="mb-4">
          <div className="bg-slate-200 border border-black px-2 py-1 font-bold text-[11px] uppercase">
            Dados para Fins Rescisórios do FGTS & Seguro-Desemprego
          </div>
          <div className="border-x border-b border-black grid grid-cols-12 text-[10px]">
            <div className="col-span-12 sm:col-span-3 p-1.5 border-b sm:border-b-0 sm:border-r border-black">
              <span className="font-bold text-slate-600">Saldo FGTS p/ Fins Rescisórios:</span>
              <div className="font-mono font-bold text-xs mt-0.5">{formatCurrency(trct.dadosFgts.saldoBaseFgts)}</div>
            </div>
            <div className="col-span-12 sm:col-span-3 p-1.5 border-b sm:border-b-0 sm:border-r border-black">
              <span className="font-bold text-slate-600">Multa Rescisória ({trct.dadosFgts.aliquotaMulta}%):</span>
              <div className="font-mono font-bold text-xs text-emerald-700 mt-0.5">
                {formatCurrency(trct.dadosFgts.multaRescisoria)}
              </div>
            </div>
            <div className="col-span-12 sm:col-span-3 p-1.5 border-b sm:border-b-0 sm:border-r border-black">
              <span className="font-bold text-slate-600">Código de Saque FGTS:</span>
              <div className="font-semibold text-xs mt-0.5">{trct.dadosFgts.codigoSaque}</div>
            </div>
            <div className="col-span-12 sm:col-span-3 p-1.5">
              <span className="font-bold text-slate-600">Direito Seguro-Desemprego:</span>
              <div className="font-bold text-xs mt-0.5">
                {trct.dadosFgts.direitoSeguroDesemprego ? (
                  <span className="text-emerald-700">SIM (Requerimento Gerado)</span>
                ) : (
                  <span className="text-slate-500">NÃO APLICÁVEL</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* 6. TERMO DE HOMOLOGAÇÃO, QUITAÇÃO E ASSINATURAS */}
        <div className="border border-black p-3 text-[10px]">
          <div className="font-bold text-xs uppercase mb-1">
            Termo de Quitação de Rescisão de Contrato de Trabalho
          </div>
          <p className="text-justify text-slate-700 mb-4 leading-normal">
            {trct.declaracaoQuitacao} Foi realizada a entrega ao trabalhador dos documentos que comprovam a comunicação da extinção contratual aos órgãos competentes, bem como o recolhimento das importâncias devidas na conta vinculada do FGTS e as guias para habilitação ao seguro-desemprego, se devido.
          </p>

          <div className="mb-6 flex justify-between items-center text-[10px] text-slate-600">
            <div>
              <span className="font-bold">150 Local e Data:</span> {trct.empresa.cidadeUf}, {trct.dataEmissao}
            </div>
            <div>
              Prazo limite p/ quitação: <strong className="text-black">{formatDate(trct.dadosRescisao.dataLimitePagamento)}</strong>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4 border-t border-slate-300">
            <div className="text-center">
              <div className="border-t border-black w-4/5 mx-auto mb-1"></div>
              <div className="font-bold text-xs">{trct.empresa.razaoSocial}</div>
              <div className="text-[9px] text-slate-600">151 Assinatura do Empregador ou Preposto</div>
            </div>

            <div className="text-center">
              <div className="border-t border-black w-4/5 mx-auto mb-1"></div>
              <div className="font-bold text-xs">{trct.funcionario.nome}</div>
              <div className="text-[9px] text-slate-600">152 Assinatura do Empregado</div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-dashed border-slate-300 text-center">
            <div className="border-t border-black w-3/5 mx-auto mb-1"></div>
            <div className="font-bold text-[10px] text-slate-700">
              154 Órgão Homologador (Secretaria de Relações do Trabalho / Sindicato Profissional)
            </div>
            <div className="text-[9px] text-slate-500">
              Homologação efetuada nos termos do Art. 477 da Consolidação das Leis do Trabalho (CLT)
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
