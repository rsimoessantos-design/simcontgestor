import React, { useState, useEffect } from 'react';
import {
  X,
  Clock,
  User,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  FileEdit,
  Save,
  Info,
} from 'lucide-react';
import { RegistroPontoDia, StatusAuditoriaPonto } from '../../types';

interface AjustarPontoModalProps {
  isOpen: boolean;
  onClose: () => void;
  ponto: RegistroPontoDia | null;
  onSave: (
    pontoId: string,
    ajustes: {
      entrada1?: string;
      saidaIntervalo?: string;
      retornoIntervalo?: string;
      saida2?: string;
      motivoAjuste: string;
      observacaoRH?: string;
      auditadoPor: string;
      statusAuditoria?: StatusAuditoriaPonto;
    }
  ) => Promise<void>;
}

export const AjustarPontoModal: React.FC<AjustarPontoModalProps> = ({
  isOpen,
  onClose,
  ponto,
  onSave,
}) => {
  const [entrada1, setEntrada1] = useState('');
  const [saidaIntervalo, setSaidaIntervalo] = useState('');
  const [retornoIntervalo, setRetornoIntervalo] = useState('');
  const [saida2, setSaida2] = useState('');
  const [motivoAjuste, setMotivoAjuste] = useState('');
  const [observacaoRH, setObservacaoRH] = useState('');
  const [auditadoPor, setAuditadoPor] = useState('Carlos Eduardo Silveira (Contador Responsável)');
  const [statusAuditoria, setStatusAuditoria] = useState<StatusAuditoriaPonto>('ajustado');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (ponto) {
      setEntrada1(ponto.entrada1 || '');
      setSaidaIntervalo(ponto.saidaIntervalo || '');
      setRetornoIntervalo(ponto.retornoIntervalo || '');
      setSaida2(ponto.saida2 || '');
      setMotivoAjuste(ponto.observacaoRH || '');
      setObservacaoRH(ponto.observacaoRH || '');
      setStatusAuditoria(ponto.statusAuditoria === 'com_inconsistencia' ? 'ajustado' : ponto.statusAuditoria);
      setError(null);
    }
  }, [ponto]);

  if (!isOpen || !ponto) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!motivoAjuste.trim()) {
      setError('A justificativa legal / motivo do ajuste é obrigatório conforme a Portaria MTE 671/2021.');
      return;
    }

    try {
      setSaving(true);
      setError(null);
      await onSave(ponto.id, {
        entrada1: entrada1 || undefined,
        saidaIntervalo: saidaIntervalo || undefined,
        retornoIntervalo: retornoIntervalo || undefined,
        saida2: saida2 || undefined,
        motivoAjuste: motivoAjuste.trim(),
        observacaoRH: observacaoRH.trim() || motivoAjuste.trim(),
        auditadoPor,
        statusAuditoria,
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Falha ao salvar ajuste no ponto');
    } finally {
      setSaving(false);
    }
  };

  const motivosPredefinidos = [
    'Esquecimento de registro no relógio REP presencial',
    'Trabalho externo / Atendimento em cliente',
    'Apresentação de atestado médico para ausência parcial',
    'Falha temporária de conexão ou energia no terminal REP',
    'Compensação autorizada de banco de horas',
  ];

  return (
    <div
      id="modal_ajustar_ponto_backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto"
    >
      <div
        id="modal_ajustar_ponto_content"
        className="bg-white rounded-2xl shadow-2xl max-w-xl w-full border border-slate-200 overflow-hidden flex flex-col my-8 animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-lg">
              <FileEdit className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold">Ajuste e Retificação de Ponto</h3>
              <p className="text-xs text-slate-300">Portaria 671 MTE - Auditoria de Jornada</p>
            </div>
          </div>
          <button
            id="btn_fechar_ajuste_top"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5 flex-1 overflow-y-auto">
          {/* Informações do Colaborador e Dia */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <User className="w-4 h-4 text-blue-600" />
                <span className="font-semibold text-slate-800 text-sm">{ponto.funcionarioNome}</span>
              </div>
              <span className="text-xs text-slate-500 font-mono">Matrícula: {ponto.funcionarioMatricula}</span>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-600">
              <div className="flex items-center space-x-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Data: {ponto.data} ({ponto.diaSemana})</span>
              </div>
              <span className="font-medium text-slate-700">{ponto.funcionarioCargo}</span>
            </div>

            {/* Inconsistências Detectadas */}
            {ponto.inconsistencias && ponto.inconsistencias.length > 0 && (
              <div className="mt-2 pt-2 border-t border-slate-200 text-xs text-amber-700 bg-amber-50 p-2.5 rounded-lg border border-amber-200 flex items-start space-x-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
                <div>
                  <p className="font-semibold">Pendência apontada pelo sistema:</p>
                  <ul className="list-disc list-inside mt-0.5 space-y-0.5">
                    {ponto.inconsistencias.map((inc, idx) => (
                      <li key={idx}>{inc}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>

          {/* Horários da Jornada */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Horários de Batida da Jornada (HH:MM)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs text-slate-600 mb-1">1ª Entrada</label>
                <div className="relative">
                  <input
                    id="input_ajuste_entrada1"
                    type="time"
                    value={entrada1}
                    onChange={(e) => setEntrada1(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-800 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-600 mb-1">Saída Intervalo</label>
                <div className="relative">
                  <input
                    id="input_ajuste_saida_intervalo"
                    type="time"
                    value={saidaIntervalo}
                    onChange={(e) => setSaidaIntervalo(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-800 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-600 mb-1">Retorno Intervalo</label>
                <div className="relative">
                  <input
                    id="input_ajuste_retorno_intervalo"
                    type="time"
                    value={retornoIntervalo}
                    onChange={(e) => setRetornoIntervalo(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-800 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-600 mb-1">2ª Saída Final</label>
                <div className="relative">
                  <input
                    id="input_ajuste_saida2"
                    type="time"
                    value={saida2}
                    onChange={(e) => setSaida2(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm text-slate-800 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-mono"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Status de Auditoria */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Status de Auditoria
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                id="btn_status_ajustado"
                onClick={() => setStatusAuditoria('ajustado')}
                className={`px-3 py-2 rounded-lg text-xs font-medium border text-center transition-all ${
                  statusAuditoria === 'ajustado'
                    ? 'bg-amber-50 border-amber-400 text-amber-800 ring-2 ring-amber-400/20'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Ajustado pelo RH
              </button>
              <button
                type="button"
                id="btn_status_aprovado"
                onClick={() => setStatusAuditoria('aprovado')}
                className={`px-3 py-2 rounded-lg text-xs font-medium border text-center transition-all ${
                  statusAuditoria === 'aprovado'
                    ? 'bg-emerald-50 border-emerald-400 text-emerald-800 ring-2 ring-emerald-400/20'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Aprovado / Regular
              </button>
              <button
                type="button"
                id="btn_status_abonado"
                onClick={() => setStatusAuditoria('abonado')}
                className={`px-3 py-2 rounded-lg text-xs font-medium border text-center transition-all ${
                  statusAuditoria === 'abonado'
                    ? 'bg-blue-50 border-blue-400 text-blue-800 ring-2 ring-blue-400/20'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Dia Abonado
              </button>
            </div>
          </div>

          {/* Justificativa Legal Obrigatória */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                Justificativa Legal / Motivo da Retificação *
              </label>
              <span className="text-[11px] text-slate-400">Exigido pela CLT</span>
            </div>
            <textarea
              id="textarea_motivo_ajuste"
              value={motivoAjuste}
              onChange={(e) => setMotivoAjuste(e.target.value)}
              rows={3}
              placeholder="Descreva o motivo legal do ajuste (ex: esquecimento com validação do gestor, serviço externo, atestado médico nº...)"
              className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-sm text-slate-800 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none"
              required
            />
            {/* Sugestões rápidas */}
            <div className="flex flex-wrap gap-1.5 mt-2">
              {motivosPredefinidos.map((sug, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setMotivoAjuste(sug)}
                  className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-700 px-2 py-1 rounded-md border border-slate-200 transition-colors"
                >
                  + {sug}
                </button>
              ))}
            </div>
          </div>

          {/* Responsável pelo Ajuste */}
          <div>
            <label className="block text-xs text-slate-600 mb-1 font-medium">
              Auditor / Responsável Técnico pelo Ajuste
            </label>
            <input
              id="input_auditado_por"
              type="text"
              value={auditadoPor}
              onChange={(e) => setAuditadoPor(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            />
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Footer Actions */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-200">
            <button
              id="btn_cancelar_ajuste"
              type="button"
              onClick={onClose}
              disabled={saving}
              className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg text-sm font-medium transition-colors"
            >
              Cancelar
            </button>
            <button
              id="btn_salvar_ajuste"
              type="submit"
              disabled={saving}
              className="flex items-center space-x-2 px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium shadow-sm transition-colors disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Gravando Ajuste...' : 'Salvar Retificação'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
