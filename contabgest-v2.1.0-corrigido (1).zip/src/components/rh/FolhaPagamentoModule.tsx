import React, { useState, useEffect, useMemo } from 'react';
import {
  DollarSign,
  Calculator,
  Download,
  Printer,
  FileText,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  TrendingDown,
  TrendingUp,
  ShieldAlert,
  Calendar,
  Building2,
  Users,
  ChevronDown,
  Info,
  RefreshCw,
  ExternalLink,
  Layers,
} from 'lucide-react';
import { Funcionario, HoleriteCalculado } from '../../types';
import { api } from '../../services/api';
import { PayrollCalculatorModal } from './PayrollCalculatorModal';
import { BatchHoleriteModal } from './BatchHoleriteModal';
import { HoleriteModal } from './HoleriteModal';

interface FolhaPagamentoModuleProps {
  empresaId?: string;
  empresaNome?: string;
  funcionarios: Funcionario[];
  onNavigateFinanceiro?: () => void;
}

export const FolhaPagamentoModule: React.FC<FolhaPagamentoModuleProps> = ({
  empresaId,
  empresaNome = 'Todas as Empresas',
  funcionarios,
  onNavigateFinanceiro,
}) => {
  const [competencia, setCompetencia] = useState('09/2026');
  const [loading, setLoading] = useState(false);
  const [folhaData, setFolhaData] = useState<{
    competencia: string;
    totalFuncionarios: number;
    totalSalarioBase: number;
    totalBruto: number;
    totalDescontos: number;
    totalLiquido: number;
    totalInssEmpregados: number;
    totalIrrf: number;
    totalFgts: number;
    inssPatronalEstimado: number;
    holerites: Array<{ funcionario: Funcionario; holerite: HoleriteCalculado }>;
  } | null>(null);

  // Custom adjustments made via calculator
  const [customCalculations, setCustomCalculations] = useState<Record<string, HoleriteCalculado>>({});

  // Modals state
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);
  const [calculatorInitialFunc, setCalculatorInitialFunc] = useState<Funcionario | null>(null);
  const [isBatchOpen, setIsBatchOpen] = useState(false);

  // Single Holerite modal
  const [selectedHolerite, setSelectedHolerite] = useState<HoleriteCalculado | null>(null);
  const [selectedHoleriteFunc, setSelectedHoleriteFunc] = useState<Funcionario | null>(null);

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [departamentoFilter, setDepartamentoFilter] = useState('todos');
  const [showTaxGuide, setShowTaxGuide] = useState(false);

  // Feedback notifications
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [fechandoFolha, setFechandoFolha] = useState(false);
  const [folhaFechada, setFolhaFechada] = useState(false);

  const carregarSimulacao = async () => {
    try {
      setLoading(true);
      const data = await api.getFolhaPagamentoSimulada(empresaId, competencia);
      setFolhaData(data);
    } catch (err) {
      console.error('Erro ao carregar simulação de folha:', err);
      setFeedbackMessage({ type: 'error', text: 'Não foi possível carregar a simulação da folha de pagamento.' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregarSimulacao();
  }, [empresaId, competencia]);

  // Merge backend holerites with any custom calculated adjustments
  const mergedHolerites = useMemo(() => {
    if (!folhaData) return [];
    return folhaData.holerites.map((item) => {
      const custom = customCalculations[item.funcionario.id];
      if (custom) {
        return {
          funcionario: item.funcionario,
          holerite: custom,
        };
      }
      return item;
    });
  }, [folhaData, customCalculations]);

  // Recalculated consolidated totals
  const totals = useMemo(() => {
    if (mergedHolerites.length === 0) {
      return {
        totalBruto: 0,
        totalDescontos: 0,
        totalLiquido: 0,
        totalInss: 0,
        totalIrrf: 0,
        totalFgts: 0,
        totalPatronal: 0,
      };
    }

    const totalBruto = mergedHolerites.reduce((acc, h) => acc + h.holerite.totalProventos, 0);
    const totalDescontos = mergedHolerites.reduce((acc, h) => acc + h.holerite.totalDescontos, 0);
    const totalLiquido = mergedHolerites.reduce(
      (acc, h) => acc + (h.holerite.valorLiquido ?? h.holerite.salarioLiquido),
      0
    );
    const totalInss = mergedHolerites.reduce((acc, h) => acc + h.holerite.valorInss, 0);
    const totalIrrf = mergedHolerites.reduce((acc, h) => acc + h.holerite.valorIrrf, 0);
    const totalFgts = mergedHolerites.reduce((acc, h) => acc + h.holerite.valorFgts, 0);
    const totalPatronal = Math.round(totalBruto * 0.2 * 100) / 100;

    return {
      totalBruto,
      totalDescontos,
      totalLiquido,
      totalInss,
      totalIrrf,
      totalFgts,
      totalPatronal,
    };
  }, [mergedHolerites]);

  // Departamentos disponíveis para filtro
  const departamentos = useMemo(() => {
    const set = new Set<string>();
    funcionarios.forEach((f) => {
      if (f.departamento) set.add(f.departamento);
    });
    return Array.from(set);
  }, [funcionarios]);

  // Filtered employees
  const filteredHolerites = useMemo(() => {
    return mergedHolerites.filter((item) => {
      const matchesSearch =
        item.funcionario.nomeCompleto.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.funcionario.cpf.includes(searchTerm) ||
        item.funcionario.cargoNome.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesDept =
        departamentoFilter === 'todos' || item.funcionario.departamento === departamentoFilter;

      return matchesSearch && matchesDept;
    });
  }, [mergedHolerites, searchTerm, departamentoFilter]);

  // Fechar folha e integrar com Contas a Pagar
  const handleFecharFolha = async () => {
    if (!window.confirm(`Deseja realmente fechar a folha da competência ${competencia} e gerar os lançamentos no Contas a Pagar?`)) {
      return;
    }

    try {
      setFechandoFolha(true);
      const res = await api.fecharFolhaPagamento({
        empresaId,
        competencia,
        totalLiquido: totals.totalLiquido,
        totalInss: totals.totalInss,
        totalFgts: totals.totalFgts,
      });

      setFolhaFechada(true);
      setFeedbackMessage({
        type: 'success',
        text: `Folha da competência ${competencia} encerrada com sucesso! ${res.contasCriadas.length} contas a pagar foram geradas (Salários, INSS e FGTS).`,
      });
    } catch (err: any) {
      setFeedbackMessage({ type: 'error', text: err.message || 'Erro ao fechar folha de pagamento.' });
    } finally {
      setFechandoFolha(false);
    }
  };

  // Exportar resumo da folha em CSV
  const handleExportCSV = () => {
    const headers = [
      'Matrícula',
      'Nome do Colaborador',
      'CPF',
      'Cargo',
      'Departamento',
      'Salário Base (R$)',
      'Total Proventos (R$)',
      'Total Descontos (R$)',
      'INSS Retido (R$)',
      'Alíquota INSS',
      'IRRF Retido (R$)',
      'Alíquota IRRF',
      'Salário Líquido (R$)',
      'FGTS 8% (R$)',
    ];

    const rows = filteredHolerites.map((item) => [
      item.funcionario.matricula,
      `"${item.funcionario.nomeCompleto}"`,
      item.funcionario.cpf,
      `"${item.funcionario.cargoNome}"`,
      `"${item.funcionario.departamento || '-'}"`,
      item.holerite.salarioBase.toFixed(2),
      item.holerite.totalProventos.toFixed(2),
      item.holerite.totalDescontos.toFixed(2),
      item.holerite.valorInss.toFixed(2),
      `"${item.holerite.faixaInssAliquotaEfetiva}"`,
      item.holerite.valorIrrf.toFixed(2),
      `"${item.holerite.faixaIrrfAliquota}"`,
      (item.holerite.valorLiquido ?? item.holerite.salarioLiquido).toFixed(2),
      item.holerite.valorFgts.toFixed(2),
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(';'), ...rows.map((r) => r.join(';'))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `folha_pagamento_${competencia.replace('/', '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleOpenCalculatorForFunc = (func: Funcionario) => {
    setCalculatorInitialFunc(func);
    setIsCalculatorOpen(true);
  };

  const handleApplyCalculation = (calc: HoleriteCalculado, func: Funcionario) => {
    setCustomCalculations((prev) => ({
      ...prev,
      [func.id]: calc,
    }));
    setFeedbackMessage({
      type: 'success',
      text: `Lançamentos calculados com sucesso para o colaborador ${func.nomeCompleto}!`,
    });
    setTimeout(() => setFeedbackMessage(null), 4000);
  };

  const handleOpenHolerite = (calc: HoleriteCalculado, func: Funcionario) => {
    setSelectedHolerite(calc);
    setSelectedHoleriteFunc(func);
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {feedbackMessage && (
        <div
          className={`p-4 rounded-xl flex items-center justify-between shadow-sm border transition-all ${
            feedbackMessage.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-rose-50 border-rose-200 text-rose-900'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {feedbackMessage.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            )}
            <p className="text-xs font-semibold">{feedbackMessage.text}</p>
          </div>
          <button
            onClick={() => setFeedbackMessage(null)}
            className="text-xs font-bold px-2 py-1 hover:bg-black/5 rounded"
          >
            Fechar
          </button>
        </div>
      )}

      {/* Top Header & Competence Controls */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-black text-slate-900">Módulo de Folha de Pagamento</h2>
            <span
              className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                folhaFechada
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                  : 'bg-indigo-50 text-indigo-700 border-indigo-200'
              }`}
            >
              {folhaFechada ? '✓ Folha Fechada' : 'Em Aberto / Simulação'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Empresa: <strong className="text-slate-800">{empresaNome}</strong> • Apuração automatizada de vencimentos,
            tabelas progressivas do INSS e IRRF, e geração de holerites.
          </p>
        </div>

        {/* Actions Bar */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Competence Selector */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-700">
            <Calendar className="w-3.5 h-3.5 text-slate-500" />
            <span>Comp:</span>
            <select
              value={competencia}
              onChange={(e) => setCompetencia(e.target.value)}
              className="bg-transparent font-bold text-indigo-700 focus:outline-hidden cursor-pointer"
            >
              <option value="09/2026">Setembro/2026</option>
              <option value="08/2026">Agosto/2026</option>
              <option value="07/2026">Julho/2026</option>
              <option value="10/2026">Outubro/2026</option>
              <option value="11/2026">Novembro/2026</option>
              <option value="12/2026">Dezembro/2026 (13º)</option>
            </select>
          </div>

          <button
            onClick={() => {
              setCalculatorInitialFunc(null);
              setIsCalculatorOpen(true);
            }}
            className="px-3.5 py-2 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg flex items-center gap-1.5 shadow-2xs transition-colors"
          >
            <Calculator className="w-4 h-4 text-indigo-600" />
            <span>Calculadora Salarial</span>
          </button>

          <button
            onClick={() => setIsBatchOpen(true)}
            className="px-3.5 py-2 text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg flex items-center gap-1.5 shadow-2xs transition-colors"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span>Emitir Lote de Holerites</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg flex items-center gap-1.5 shadow-2xs transition-colors"
            title="Exportar Resumo da Folha em planilha CSV"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>CSV</span>
          </button>

          <button
            onClick={handleFecharFolha}
            disabled={fechandoFolha}
            className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 rounded-lg flex items-center gap-1.5 shadow-xs transition-colors"
          >
            {fechandoFolha ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <CheckCircle2 className="w-4 h-4" />
            )}
            <span>Fechar Folha & Contas a Pagar</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Bruto */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase">Total Proventos Brutos</span>
            <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-xl font-black text-slate-900 mt-2">
            {totals.totalBruto.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
          </p>
          <p className="text-[11px] text-slate-500 mt-1">
            {mergedHolerites.length} colaboradores ativos na competência
          </p>
        </div>

        {/* Total Descontos */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase">Total Descontos Folha</span>
            <div className="p-1.5 bg-rose-50 text-rose-600 rounded-lg">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <p className="text-xl font-black text-rose-600 mt-2">
            {totals.totalDescontos.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
          </p>
          <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-1">
            <span>INSS: {totals.totalInss.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
            <span>•</span>
            <span>IRRF: {totals.totalIrrf.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
          </div>
        </div>

        {/* Total Líquido */}
        <div className="bg-white rounded-xl border border-indigo-200 p-4 shadow-xs bg-linear-to-br from-indigo-50/40 to-white">
          <div className="flex items-center justify-between text-indigo-700">
            <span className="text-xs font-bold uppercase">Líquido a Pagar</span>
            <div className="p-1.5 bg-indigo-600 text-white rounded-lg shadow-xs">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-indigo-700 mt-2">
            {totals.totalLiquido.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
          </p>
          <p className="text-[11px] text-indigo-600/80 mt-1 font-medium">
            Vencimento: 5º dia útil do mês seguinte
          </p>
        </div>

        {/* Encargos e FGTS */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-bold uppercase">Encargos Sociais & FGTS</span>
            <div className="p-1.5 bg-slate-100 text-slate-600 rounded-lg">
              <ShieldAlert className="w-4 h-4" />
            </div>
          </div>
          <p className="text-xl font-black text-slate-900 mt-2">
            {(totals.totalFgts + totals.totalPatronal).toLocaleString('pt-BR', {
              style: 'currency',
              currency: 'BRL',
            })}
          </p>
          <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-1">
            <span>FGTS: {totals.totalFgts.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
            <span>•</span>
            <span>CPP Est.: {totals.totalPatronal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</span>
          </div>
        </div>
      </div>

      {/* Tax Guide / Educational Accordion */}
      <div className="border border-slate-200 bg-white rounded-xl overflow-hidden shadow-xs">
        <button
          onClick={() => setShowTaxGuide(!showTaxGuide)}
          className="w-full px-5 py-3 text-left flex items-center justify-between bg-slate-50 hover:bg-slate-100/80 transition-colors"
        >
          <div className="flex items-center gap-2.5">
            <Info className="w-4 h-4 text-indigo-600" />
            <span className="text-xs font-bold text-slate-800">
              Tabelas e Parâmetros Vigentes de Cálculo (INSS Progressivo & IRRF com Desconto Simplificado)
            </span>
          </div>
          <div className="flex items-center gap-1 text-xs font-semibold text-indigo-600">
            <span>{showTaxGuide ? 'Ocultar Detalhes' : 'Ver Regras e Faixas'}</span>
            <ChevronDown
              className={`w-4 h-4 transition-transform duration-200 ${showTaxGuide ? 'rotate-180' : ''}`}
            />
          </div>
        </button>

        {showTaxGuide && (
          <div className="p-5 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-6 text-xs bg-white animate-in fade-in duration-200">
            {/* INSS Table */}
            <div className="space-y-2">
              <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
                Tabela Progressiva do INSS (Emenda Constitucional 103/2019)
              </h4>
              <p className="text-[11px] text-slate-500">
                O cálculo é feito por faixas salariais progressivas; a contribuição incide somente sobre a fatia correspondente a cada alíquota.
              </p>
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-left text-[11px]">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="p-2">Faixa Salarial</th>
                      <th className="p-2 text-center">Alíquota</th>
                      <th className="p-2 text-right">Recolhimento Máximo</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    <tr>
                      <td className="p-2">Até R$ 1.412,00</td>
                      <td className="p-2 text-center font-semibold text-indigo-600">7,5%</td>
                      <td className="p-2 text-right">R$ 105,90</td>
                    </tr>
                    <tr>
                      <td className="p-2">De R$ 1.412,01 até R$ 2.666,68</td>
                      <td className="p-2 text-center font-semibold text-indigo-600">9,0%</td>
                      <td className="p-2 text-right">R$ 112,92</td>
                    </tr>
                    <tr>
                      <td className="p-2">De R$ 2.666,69 até R$ 4.000,03</td>
                      <td className="p-2 text-center font-semibold text-indigo-600">12,0%</td>
                      <td className="p-2 text-right">R$ 160,00</td>
                    </tr>
                    <tr>
                      <td className="p-2">De R$ 4.000,04 até R$ 7.786,02</td>
                      <td className="p-2 text-center font-semibold text-indigo-600">14,0%</td>
                      <td className="p-2 text-right">R$ 530,04</td>
                    </tr>
                    <tr className="bg-indigo-50/50 font-bold text-slate-800">
                      <td className="p-2">Teto Máximo de Contribuição</td>
                      <td className="p-2 text-center">Teto</td>
                      <td className="p-2 text-right text-indigo-700">R$ 908,86</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* IRRF Table */}
            <div className="space-y-2">
              <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-600"></span>
                Tabela Mensal do IRRF na Fonte & Dedução Simplificada
              </h4>
              <p className="text-[11px] text-slate-500">
                O sistema compara automaticamente as <strong>Deduções Legais</strong> (INSS + R$ 189,59 por dependente + pensão) com o <strong>Desconto Simplificado de R$ 564,80</strong> e aplica a opção mais vantajosa ao colaborador.
              </p>
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-left text-[11px]">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="p-2">Base de Cálculo Mensal</th>
                      <th className="p-2 text-center">Alíquota</th>
                      <th className="p-2 text-right">Parcela a Deduzir</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    <tr>
                      <td className="p-2">Até R$ 2.259,20</td>
                      <td className="p-2 text-center font-semibold text-emerald-600">Isento</td>
                      <td className="p-2 text-right">-</td>
                    </tr>
                    <tr>
                      <td className="p-2">De R$ 2.259,21 até R$ 2.826,65</td>
                      <td className="p-2 text-center font-semibold text-rose-600">7,5%</td>
                      <td className="p-2 text-right">R$ 169,44</td>
                    </tr>
                    <tr>
                      <td className="p-2">De R$ 2.826,66 até R$ 3.751,05</td>
                      <td className="p-2 text-center font-semibold text-rose-600">15,0%</td>
                      <td className="p-2 text-right">R$ 381,44</td>
                    </tr>
                    <tr>
                      <td className="p-2">De R$ 3.751,06 até R$ 4.664,68</td>
                      <td className="p-2 text-center font-semibold text-rose-600">22,5%</td>
                      <td className="p-2 text-right">R$ 662,77</td>
                    </tr>
                    <tr>
                      <td className="p-2">Acima de R$ 4.664,68</td>
                      <td className="p-2 text-center font-semibold text-rose-600">27,5%</td>
                      <td className="p-2 text-right">R$ 896,00</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Employees Table Section */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Table Search & Filter Bar */}
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-50/50">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar colaborador por nome, cargo ou CPF..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <div className="flex items-center gap-1.5 text-xs text-slate-600">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <span>Depto:</span>
              <select
                value={departamentoFilter}
                onChange={(e) => setDepartamentoFilter(e.target.value)}
                className="px-2 py-1 text-xs border border-slate-300 rounded-md bg-white font-medium focus:ring-1 focus:ring-indigo-500"
              >
                <option value="todos">Todos os Departamentos</option>
                {departamentos.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={carregarSimulacao}
              disabled={loading}
              className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-200 rounded-lg transition-colors"
              title="Recarregar Dados"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4">Colaborador / Cargo</th>
                <th className="py-3 px-3 text-right">Salário Base</th>
                <th className="py-3 px-3 text-right">Proventos Brutos</th>
                <th className="py-3 px-3 text-right text-rose-700">INSS Retido</th>
                <th className="py-3 px-3 text-right text-rose-700">IRRF Retido</th>
                <th className="py-3 px-3 text-right">Total Descontos</th>
                <th className="py-3 px-3 text-right text-indigo-700 font-black">Líquido a Receber</th>
                <th className="py-3 px-3 text-right text-slate-600">FGTS 8%</th>
                <th className="py-3 px-4 text-center">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {loading ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-600" />
                    <span>Calculando encargos e folha de pagamento...</span>
                  </td>
                </tr>
              ) : filteredHolerites.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500">
                    Nenhum colaborador encontrado para os filtros selecionados.
                  </td>
                </tr>
              ) : (
                filteredHolerites.map(({ funcionario, holerite }) => {
                  const valorLiquido = holerite.valorLiquido ?? holerite.salarioLiquido;
                  const hasCustom = Boolean(customCalculations[funcionario.id]);

                  return (
                    <tr key={funcionario.id} className="hover:bg-slate-50/80 transition-colors">
                      {/* Name & Role */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs shrink-0">
                            {funcionario.nomeCompleto.substring(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-slate-900">{funcionario.nomeCompleto}</span>
                              {hasCustom && (
                                <span className="px-1.5 py-0.2 bg-amber-100 text-amber-800 rounded text-[9px] font-bold">
                                  Ajustado
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-500">
                              {funcionario.cargoNome} • {funcionario.departamento || 'Geral'}
                            </p>
                          </div>
                        </div>
                      </td>

                      {/* Salário Base */}
                      <td className="py-3 px-3 text-right font-medium text-slate-700">
                        {holerite.salarioBase.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </td>

                      {/* Proventos Brutos */}
                      <td className="py-3 px-3 text-right font-bold text-emerald-700">
                        {holerite.totalProventos.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </td>

                      {/* INSS Retido */}
                      <td className="py-3 px-3 text-right">
                        <span className="font-bold text-rose-700 block">
                          {holerite.valorInss.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {holerite.faixaInssAliquotaEfetiva}
                        </span>
                      </td>

                      {/* IRRF Retido */}
                      <td className="py-3 px-3 text-right">
                        <span className="font-bold text-rose-700 block">
                          {holerite.valorIrrf.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {holerite.valorIrrf > 0 ? holerite.faixaIrrfAliquota : 'Isento'}
                        </span>
                      </td>

                      {/* Total Descontos */}
                      <td className="py-3 px-3 text-right font-bold text-rose-600">
                        {holerite.totalDescontos.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </td>

                      {/* Líquido */}
                      <td className="py-3 px-3 text-right">
                        <span className="text-sm font-black text-indigo-700">
                          {valorLiquido.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </span>
                      </td>

                      {/* FGTS 8% */}
                      <td className="py-3 px-3 text-right text-slate-600 font-medium">
                        {holerite.valorFgts.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => handleOpenHolerite(holerite, funcionario)}
                            className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-md flex items-center gap-1 transition-colors"
                            title="Visualizar e Imprimir Holerite Oficial"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            <span>Holerite</span>
                          </button>

                          <button
                            onClick={() => handleOpenCalculatorForFunc(funcionario)}
                            className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-md transition-colors"
                            title="Simular / Lançar Horas Extras, Faltas e Eventos"
                          >
                            <Calculator className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Integration with Financial Module Footer Callout */}
      <div className="p-4 rounded-xl border border-slate-200 bg-linear-to-r from-slate-50 to-indigo-50/40 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-600 text-white rounded-lg">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-900">
              Integração Financeira Contábil Automática
            </p>
            <p className="text-[11px] text-slate-500">
              Ao fechar a folha, o sistema gera automaticamente os títulos de Salários Líquidos, Guias de INSS/DARF e FGTS Digital no módulo de Contas a Pagar.
            </p>
          </div>
        </div>

        {onNavigateFinanceiro && (
          <button
            onClick={onNavigateFinanceiro}
            className="px-3 py-1.5 text-xs font-bold text-indigo-700 hover:text-indigo-800 flex items-center gap-1 transition-colors"
          >
            <span>Ir para Financeiro</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Modals */}
      {isCalculatorOpen && (
        <PayrollCalculatorModal
          isOpen={isCalculatorOpen}
          onClose={() => setIsCalculatorOpen(false)}
          funcionarios={funcionarios}
          initialFuncionario={calculatorInitialFunc}
          competencia={competencia}
          onApplyCalculation={handleApplyCalculation}
          onOpenHoleriteModal={handleOpenHolerite}
        />
      )}

      {isBatchOpen && (
        <BatchHoleriteModal
          isOpen={isBatchOpen}
          onClose={() => setIsBatchOpen(false)}
          competencia={competencia}
          empresaNome={empresaNome}
          holerites={filteredHolerites}
        />
      )}

      {selectedHolerite && selectedHoleriteFunc && (
        <HoleriteModal
          isOpen={Boolean(selectedHolerite)}
          onClose={() => {
            setSelectedHolerite(null);
            setSelectedHoleriteFunc(null);
          }}
          holerite={selectedHolerite}
          funcionario={selectedHoleriteFunc}
          empresaNome={empresaNome}
        />
      )}
    </div>
  );
};
