import React, { useState } from 'react';
import { X, Printer, Download, Search, CheckCircle2, User, Building2, Calendar, FileText } from 'lucide-react';
import { Funcionario, HoleriteCalculado } from '../../types';

interface BatchHoleriteModalProps {
  isOpen: boolean;
  onClose: () => void;
  competencia: string;
  empresaNome?: string;
  holerites: Array<{ funcionario: Funcionario; holerite: HoleriteCalculado }>;
}

export const BatchHoleriteModal: React.FC<BatchHoleriteModalProps> = ({
  isOpen,
  onClose,
  competencia,
  empresaNome = 'Escritório Contábil & Clientes',
  holerites,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  if (!isOpen) return null;

  const filtered = holerites.filter(
    (item) =>
      item.funcionario.nomeCompleto.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.funcionario.cpf.includes(searchTerm) ||
      item.funcionario.cargoNome.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handlePrint = () => {
    window.print();
  };

  const handleExportSummaryCSV = () => {
    const headers = [
      'Matrícula',
      'Nome Completo',
      'CPF',
      'Cargo',
      'Salário Base',
      'Total Proventos',
      'Total Descontos',
      'INSS',
      'IRRF',
      'Salário Líquido',
      'FGTS Recolhido',
    ];

    const rows = filtered.map((item) => [
      item.funcionario.matricula,
      `"${item.funcionario.nomeCompleto}"`,
      item.funcionario.cpf,
      `"${item.funcionario.cargoNome}"`,
      item.holerite.salarioBase.toFixed(2),
      item.holerite.totalProventos.toFixed(2),
      item.holerite.totalDescontos.toFixed(2),
      item.holerite.valorInss.toFixed(2),
      item.holerite.valorIrrf.toFixed(2),
      (item.holerite.valorLiquido ?? item.holerite.salarioLiquido).toFixed(2),
      item.holerite.valorFgts.toFixed(2),
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(';'), ...rows.map((r) => r.join(';'))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `folha_pagamento_${competencia.replace('/', '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50 print:hidden">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-600 text-white rounded-xl shadow-xs">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Emissão em Lote de Holerites ({holerites.length} Colaboradores)
              </h2>
              <p className="text-xs text-slate-500">
                Competência: <strong className="text-indigo-600">{competencia}</strong> • Visualização pronta para impressão e distribuição
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportSummaryCSV}
              className="px-3 py-2 text-xs font-bold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-4 h-4 text-slate-500" />
              <span>Exportar CSV</span>
            </button>

            <button
              onClick={handlePrint}
              className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimir Todos (PDF)</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="px-6 py-3 border-b border-slate-200 bg-white flex items-center justify-between print:hidden">
          <div className="relative w-72">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar por colaborador ou CPF..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="text-xs text-slate-500">
            Exibindo <strong className="text-slate-900">{filtered.length}</strong> de {holerites.length} holerites
          </div>
        </div>

        {/* Scrollable Holerites Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-8 bg-slate-100/70 print:bg-white print:p-0 print:space-y-6">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-sm">
              Nenhum colaborador encontrado com o filtro informado.
            </div>
          ) : (
            filtered.map(({ funcionario, holerite }, index) => {
              const valorLiquido = holerite.valorLiquido ?? holerite.salarioLiquido;
              return (
                <div
                  key={funcionario.id}
                  className="bg-white rounded-xl border border-slate-300 shadow-xs p-5 space-y-4 print:border-slate-800 print:shadow-none print:break-after-page"
                >
                  {/* Holerite Header */}
                  <div className="border-b border-slate-300 pb-3 flex justify-between items-start">
                    <div>
                      <h3 className="text-sm font-black tracking-wide text-slate-900 uppercase">
                        RECIBO DE PAGAMENTO DE SALÁRIO
                      </h3>
                      <p className="text-xs text-slate-600 font-medium">
                        {empresaNome} • Folha Mensal
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded border border-indigo-200 print:border-none">
                        COMPETÊNCIA: {competencia}
                      </span>
                      <p className="text-[10px] text-slate-400 mt-1 font-mono">
                        Nº {funcionario.matricula}
                      </p>
                    </div>
                  </div>

                  {/* Employee Info Strip */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase">Colaborador</span>
                      <strong className="text-slate-800">{funcionario.nomeCompleto}</strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase">CPF</span>
                      <span className="font-mono text-slate-700">{funcionario.cpf}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase">Cargo / Função</span>
                      <span className="text-slate-700">{funcionario.cargoNome}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase">Admissão</span>
                      <span className="text-slate-700">
                        {new Date(funcionario.dataAdmissao).toLocaleDateString('pt-BR')}
                      </span>
                    </div>
                  </div>

                  {/* Items Table */}
                  <table className="w-full text-xs text-left border-collapse border border-slate-200">
                    <thead>
                      <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 text-[11px]">
                        <th className="py-1.5 px-2 w-16">Cód.</th>
                        <th className="py-1.5 px-2">Descrição da Rubrica</th>
                        <th className="py-1.5 px-2 text-center w-24">Ref.</th>
                        <th className="py-1.5 px-2 text-right w-28 text-emerald-700">Vencimentos</th>
                        <th className="py-1.5 px-2 text-right w-28 text-rose-700">Descontos</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {holerite.itens.map((item, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="py-1 px-2 font-mono text-slate-500">{item.codigo}</td>
                          <td className="py-1 px-2 font-medium text-slate-800">{item.descricao}</td>
                          <td className="py-1 px-2 text-center text-slate-500">{item.referencia}</td>
                          <td className="py-1 px-2 text-right font-semibold text-emerald-700">
                            {item.tipo === 'provento'
                              ? item.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })
                              : '-'}
                          </td>
                          <td className="py-1 px-2 text-right font-semibold text-rose-700">
                            {item.tipo === 'desconto'
                              ? item.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })
                              : '-'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  {/* Totals & Net Pay */}
                  <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-lg border border-slate-200 text-center">
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase font-bold">Total Proventos</span>
                      <strong className="text-sm text-emerald-700">
                        {holerite.totalProventos.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </strong>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase font-bold">Total Descontos</span>
                      <strong className="text-sm text-rose-700">
                        {holerite.totalDescontos.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </strong>
                    </div>
                    <div className="bg-indigo-50 border border-indigo-200 rounded-md p-1">
                      <span className="text-[10px] text-indigo-900 block uppercase font-black">Líquido a Receber</span>
                      <strong className="text-base text-indigo-700">
                        {valorLiquido.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </strong>
                    </div>
                  </div>

                  {/* Legal Bases */}
                  <div className="grid grid-cols-4 gap-2 text-[11px] text-slate-600 border-t border-slate-200 pt-2">
                    <div>
                      <span>Sal. Base: </span>
                      <strong>
                        {(holerite.bases?.salarioBase ?? holerite.salarioBase).toLocaleString('pt-BR', {
                          style: 'currency',
                          currency: 'BRL',
                        })}
                      </strong>
                    </div>
                    <div>
                      <span>Base INSS: </span>
                      <strong>
                        {(holerite.bases?.baseInss ?? holerite.baseInss ?? holerite.totalProventos).toLocaleString(
                          'pt-BR',
                          { style: 'currency', currency: 'BRL' }
                        )}
                      </strong>
                    </div>
                    <div>
                      <span>Base IRRF: </span>
                      <strong>
                        {(holerite.bases?.baseIrrf ?? holerite.baseIrrf ?? 0).toLocaleString('pt-BR', {
                          style: 'currency',
                          currency: 'BRL',
                        })}
                      </strong>
                    </div>
                    <div>
                      <span>FGTS do Mês: </span>
                      <strong className="text-indigo-600">
                        {(holerite.bases?.fgtsMes ?? holerite.valorFgts ?? 0).toLocaleString('pt-BR', {
                          style: 'currency',
                          currency: 'BRL',
                        })}
                      </strong>
                    </div>
                  </div>

                  {/* Signature strip for printed paper */}
                  <div className="pt-4 border-t border-dashed border-slate-300 grid grid-cols-2 gap-6 text-[10px] text-slate-500 print:grid">
                    <div>
                      <p>
                        Declaro ter recebido a importância líquida discriminada neste recibo, nada tendo a reclamar.
                      </p>
                      <div className="mt-6 border-b border-slate-400 w-48"></div>
                      <p className="mt-1 font-semibold">{funcionario.nomeCompleto}</p>
                    </div>
                    <div className="text-right flex flex-col justify-end">
                      <p>Data de Pagamento: ___/___/______</p>
                      <p className="text-[9px] text-slate-400 mt-1">Autenticação: {funcionario.id}-{competencia.replace('/', '')}</p>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
