import React, { useRef } from 'react';
import { X, Printer, Download, User, Building, DollarSign } from 'lucide-react';
import { Funcionario, HoleriteCalculado, Empresa } from '../../types';

interface HoleriteModalProps {
  isOpen: boolean;
  onClose: () => void;
  funcionario: Funcionario | null;
  empresa: Empresa | null;
  holerite: HoleriteCalculado | null;
}

export const HoleriteModal: React.FC<HoleriteModalProps> = ({
  isOpen,
  onClose,
  funcionario,
  empresa,
  holerite,
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !funcionario || !holerite) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-100 overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-6">
        {/* Top bar with action buttons */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50 print:hidden">
          <div className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-indigo-600" />
            <h3 className="text-base font-bold text-slate-800">
              Demonstrativo de Pagamento de Salário (Holerite)
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center gap-1.5 shadow-sm transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimir / Salvar PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Paystub Body */}
        <div ref={printRef} className="p-8 text-slate-800 font-sans text-xs bg-white space-y-4">
          {/* Header */}
          <div className="border border-slate-300 rounded-lg p-4 bg-slate-50/50">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-base font-bold uppercase text-slate-900">
                  {empresa?.razaoSocial || 'EMPRESA CONTRATANTE LTDA'}
                </h2>
                <p className="text-xs text-slate-600">CNPJ: {empresa?.cnpj || '00.000.000/0001-00'}</p>
                <p className="text-xs text-slate-500">{empresa?.cidade || 'São Paulo'} - {empresa?.estado || 'SP'}</p>
              </div>
              <div className="text-right">
                <span className="inline-block px-3 py-1 bg-indigo-100 text-indigo-800 font-bold rounded text-xs">
                  RECIBO DE PAGAMENTO
                </span>
                <p className="text-xs font-semibold text-slate-700 mt-1">
                  Competência: <span className="text-indigo-600">{holerite.competencia}</span>
                </p>
              </div>
            </div>
          </div>

          {/* Employee Info Header */}
          <div className="border border-slate-300 rounded-lg p-3 bg-white grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
            <div>
              <span className="text-slate-500 block">Matrícula / Cód:</span>
              <span className="font-bold text-slate-900">{funcionario.matricula}</span>
            </div>
            <div className="md:col-span-2">
              <span className="text-slate-500 block">Nome do Empregado:</span>
              <span className="font-bold text-slate-900">{funcionario.nomeCompleto}</span>
            </div>
            <div>
              <span className="text-slate-500 block">CPF:</span>
              <span className="font-bold text-slate-900">{funcionario.cpf}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Cargo / Função:</span>
              <span className="font-semibold text-slate-900">{funcionario.cargoNome}</span>
            </div>
            <div>
              <span className="text-slate-500 block">CBO:</span>
              <span className="font-semibold text-slate-900">{funcionario.cbo || '---'}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Departamento:</span>
              <span className="font-semibold text-slate-900">{funcionario.departamento}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Data de Admissão:</span>
              <span className="font-semibold text-slate-900">
                {funcionario.dataAdmissao ? new Date(funcionario.dataAdmissao).toLocaleDateString('pt-BR') : '---'}
              </span>
            </div>
          </div>

          {/* Table of Items (Proventos & Descontos) */}
          <div className="border border-slate-300 rounded-lg overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-300 text-slate-700 text-xs font-bold uppercase">
                  <th className="p-2 w-16">Cód.</th>
                  <th className="p-2">Descrição da Rubrica</th>
                  <th className="p-2 w-24 text-right">Referência</th>
                  <th className="p-2 w-28 text-right">Proventos (R$)</th>
                  <th className="p-2 w-28 text-right">Descontos (R$)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {holerite.itens.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50">
                    <td className="p-2 text-slate-500 font-mono">{item.codigo}</td>
                    <td className="p-2 font-medium text-slate-800">{item.descricao}</td>
                    <td className="p-2 text-right text-slate-600">{item.referencia}</td>
                    <td className="p-2 text-right font-medium text-emerald-700">
                      {item.tipo === 'provento'
                        ? item.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })
                        : '-'}
                    </td>
                    <td className="p-2 text-right font-medium text-rose-700">
                      {item.tipo === 'desconto'
                        ? item.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })
                        : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals Section */}
          <div className="border border-slate-300 rounded-lg p-4 bg-slate-50 grid grid-cols-3 gap-4 text-center">
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase block">Total Proventos Brutos</span>
              <span className="text-base font-bold text-emerald-600">
                {holerite.totalProventos.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </span>
            </div>
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase block">Total Descontos</span>
              <span className="text-base font-bold text-rose-600">
                {holerite.totalDescontos.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </span>
            </div>
            <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-2">
              <span className="text-xs font-bold text-indigo-900 uppercase block">Valor Líquido a Receber</span>
              <span className="text-lg font-black text-indigo-700">
                {(holerite.valorLiquido ?? holerite.salarioLiquido).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </span>
            </div>
          </div>

          {/* Legal Bases (INSS, IRRF, FGTS) */}
          <div className="border border-slate-300 rounded-lg p-3 grid grid-cols-2 md:grid-cols-4 gap-3 bg-white text-xs">
            <div>
              <span className="text-slate-500 block">Salário Base:</span>
              <span className="font-semibold text-slate-800">
                {(holerite.bases?.salarioBase ?? holerite.salarioBase).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Base INSS:</span>
              <span className="font-semibold text-slate-800">
                {(holerite.bases?.baseInss ?? holerite.baseInss ?? holerite.totalProventos).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Base IRRF:</span>
              <span className="font-semibold text-slate-800">
                {(holerite.bases?.baseIrrf ?? holerite.baseIrrf ?? 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </span>
            </div>
            <div className="border-l border-slate-200 pl-3">
              <span className="text-slate-500 block">FGTS do Mês (8% Recolhido):</span>
              <span className="font-bold text-indigo-600">
                {(holerite.bases?.fgtsMes ?? holerite.valorFgts ?? 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
              </span>
            </div>
          </div>

          {/* Bank / Pix confirmation */}
          <div className="border border-slate-200 rounded-lg p-3 bg-slate-50/50 flex justify-between items-center text-xs">
            <div>
              <span className="font-medium text-slate-700">Crédito em Conta:</span>{' '}
              <span className="text-slate-600">
                {funcionario.bancoNome || 'Banco'} | Agência: {funcionario.bancoAgencia || '---'} | Conta: {funcionario.bancoConta || '---'}
              </span>
              {funcionario.chavePix && (
                <span className="ml-2 text-indigo-600 font-mono font-medium">(Pix: {funcionario.chavePix})</span>
              )}
            </div>
            <span className="text-slate-400 font-mono">Autenticação: eSocial-{Math.random().toString(36).substring(2, 10).toUpperCase()}</span>
          </div>

          {/* Employee Signature Receipt */}
          <div className="pt-6 border-t border-slate-300 flex justify-between items-end text-xs text-slate-500">
            <div>
              <p>Recebi o valor líquido indicado acima referente ao mês trabalhado.</p>
              <p className="mt-1">Data: ____/____/________</p>
            </div>
            <div className="text-center w-64">
              <div className="border-t border-slate-400 pt-1">
                <span className="font-semibold text-slate-800">{funcionario.nomeCompleto}</span>
                <p className="text-[10px] text-slate-400">Assinatura do Colaborador</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
