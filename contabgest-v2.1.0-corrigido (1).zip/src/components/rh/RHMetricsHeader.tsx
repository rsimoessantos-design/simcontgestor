import React from 'react';
import { Users, UserCheck, DollarSign, Briefcase, AlertTriangle, Calendar } from 'lucide-react';
import { Funcionario, FuncaoRH } from '../../types';

interface RHMetricsHeaderProps {
  funcionarios: Funcionario[];
  funcoes: FuncaoRH[];
  folhaTotal: number;
  onSelectTab?: (tab: string) => void;
}

export const RHMetricsHeader: React.FC<RHMetricsHeaderProps> = ({
  funcionarios,
  funcoes,
  folhaTotal,
}) => {
  const ativos = funcionarios.filter((f) => f.status === 'ativo').length;
  const emFerias = funcionarios.filter((f) => f.status === 'ferias').length;
  const afastados = funcionarios.filter((f) => f.status === 'afastado').length;

  // Alertas: ASO vencendo em 30 dias ou vencido
  const hoje = new Date();
  const asoAlertas = funcionarios.filter((f) => {
    if (!f.dataValidadeAso) return false;
    const val = new Date(f.dataValidadeAso);
    const diff = (val.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24);
    return diff <= 30;
  }).length;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
        <div>
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Total Colaboradores</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-slate-900">{funcionarios.length}</span>
            <span className="text-xs text-emerald-600 font-semibold">{ativos} ativos</span>
          </div>
          <p className="text-xs text-slate-400 mt-1">{emFerias} em férias • {afastados} afastados</p>
        </div>
        <div className="w-12 h-12 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
          <Users className="w-6 h-6" />
        </div>
      </div>

      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
        <div>
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Folha Salarial Bruta</p>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold text-slate-900">
              {folhaTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">Competência mensal vigente</p>
        </div>
        <div className="w-12 h-12 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600">
          <DollarSign className="w-6 h-6" />
        </div>
      </div>

      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
        <div>
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Cargos & Funções</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-slate-900">{funcoes.length}</span>
            <span className="text-xs text-indigo-600 font-medium">CBOs registrados</span>
          </div>
          <p className="text-xs text-slate-400 mt-1">Quadro de vagas ativo</p>
        </div>
        <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600">
          <Briefcase className="w-6 h-6" />
        </div>
      </div>

      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
        <div>
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Em Férias / Programadas</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-slate-900">{emFerias}</span>
            <span className="text-xs text-amber-600 font-medium">em descanso</span>
          </div>
          <p className="text-xs text-slate-400 mt-1">Saldo controlado</p>
        </div>
        <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600">
          <Calendar className="w-6 h-6" />
        </div>
      </div>

      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
        <div>
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Alertas SST / ASO</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-rose-600">{asoAlertas}</span>
            <span className="text-xs text-rose-600 font-medium">vencendo/vencidos</span>
          </div>
          <p className="text-xs text-slate-400 mt-1">Controle de Saúde Ocupacional</p>
        </div>
        <div className="w-12 h-12 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600">
          <AlertTriangle className="w-6 h-6" />
        </div>
      </div>
    </div>
  );
};
