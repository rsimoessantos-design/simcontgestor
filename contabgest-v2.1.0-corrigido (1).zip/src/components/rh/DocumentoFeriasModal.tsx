import React, { useRef } from 'react';
import { X, Printer, Download, ShieldCheck, FileText, Calendar, Building2, User } from 'lucide-react';
import { DocumentoAvisoReciboFerias } from '../../types';

interface DocumentoFeriasModalProps {
  isOpen: boolean;
  onClose: () => void;
  documento: DocumentoAvisoReciboFerias | null;
  loading?: boolean;
}

export const DocumentoFeriasModal: React.FC<DocumentoFeriasModalProps> = ({
  isOpen,
  onClose,
  documento,
  loading = false,
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const formatMoney = (val?: number) => {
    return (val || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '---';
    const [ano, mes, dia] = dateStr.split('-');
    if (ano && mes && dia) return `${dia}/${mes}/${ano}`;
    return new Date(dateStr).toLocaleDateString('pt-BR');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50 print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-sm">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Aviso Prévio e Recibo Oficial de Férias CLT
              </h3>
              <p className="text-xs text-slate-500">
                Documento de cumprimento legal dos Arts. 135 e 145 da CLT
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              disabled={!documento || loading}
              className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg flex items-center gap-1.5 shadow-sm transition-colors disabled:opacity-50"
            >
              <Printer className="w-4 h-4 text-slate-600" />
              <span>Imprimir / Salvar PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Content Body */}
        <div className="overflow-y-auto p-6 sm:p-8 space-y-8 bg-slate-50/50 print:bg-white print:p-0 print:overflow-visible">
          {loading ? (
            <div className="py-20 text-center text-slate-500">
              <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
              <p className="text-sm">Gerando documento oficial e demonstrativo de férias...</p>
            </div>
          ) : !documento ? (
            <div className="py-16 text-center text-slate-400 text-sm">
              Nenhum dado de documento disponível para exibição.
            </div>
          ) : (
            <div ref={printRef} className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm print:border-0 print:shadow-none print:p-0 space-y-8 text-slate-800 font-sans">
              
              {/* ================================================================= */}
              {/* DOCUMENTO 1: AVISO PRÉVIO DE FÉRIAS (ART. 135 CLT) */}
              {/* ================================================================= */}
              <section className="space-y-4 border-b-2 border-dashed border-slate-200 pb-8 print:border-b print:pb-6">
                <div className="text-center border-b border-slate-200 pb-3">
                  <span className="text-[11px] font-bold tracking-wider uppercase text-indigo-700 bg-indigo-50 px-3 py-0.5 rounded-full inline-block mb-1">
                    Art. 135 da CLT — Comunicação Prévia Obrigatória com 30 dias de antecedência
                  </span>
                  <h1 className="text-xl font-black uppercase text-slate-900 tracking-tight">
                    Aviso Prévio de Concessão de Férias
                  </h1>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <div>
                    <p className="text-slate-500 font-medium">Empregador:</p>
                    <p className="font-bold text-slate-900">{documento.empresa.razaoSocial}</p>
                    <p className="text-slate-600">CNPJ: {documento.empresa.cnpj}</p>
                  </div>
                  <div>
                    <p className="text-slate-500 font-medium">Empregado(a):</p>
                    <p className="font-bold text-slate-900">{documento.funcionario.nome}</p>
                    <p className="text-slate-600">
                      CPF: {documento.funcionario.cpf} • CTPS: {documento.funcionario.ctps}
                    </p>
                    <p className="text-slate-600">
                      Cargo: {documento.funcionario.cargo} • Matrícula eSocial: {documento.funcionario.matricula}
                    </p>
                  </div>
                </div>

                <div className="text-xs leading-relaxed text-slate-700 space-y-2 text-justify">
                  <p>
                    Vimos por meio deste comunicar-lhe formalmente que, em conformidade com o disposto no 
                    <strong> Art. 135 da Consolidação das Leis do Trabalho (CLT)</strong>, ser-lhe-ão concedidas 
                    férias relativas ao <strong>Período Aquisitivo de {formatDate(documento.periodoAquisitivo.inicio)} a {formatDate(documento.periodoAquisitivo.fim)}</strong>.
                  </p>
                  <p>
                    O período de gozo terá início em <strong>{formatDate(documento.periodoGozo.inicio)}</strong> e término 
                    em <strong>{formatDate(documento.periodoGozo.fim)}</strong>, totalizando <strong>{documento.periodoGozo.dias} dias</strong> de descanso legal remunerado.
                    Deverá retornar às suas atividades regulares na empresa em <strong>{formatDate(documento.periodoGozo.dataRetorno)}</strong>.
                  </p>
                  {documento.abono.solicitado && (
                    <p className="bg-amber-50 p-2 rounded border border-amber-200 text-amber-900">
                      * Conforme sua opção de conversão parcial de férias em abono pecuniário (Art. 143 CLT), 
                      foram convertidos <strong>{documento.abono.dias} dias</strong> em pecúnia indenizatória.
                    </p>
                  )}
                  {documento.adiantamento13.solicitado && (
                    <p className="bg-indigo-50 p-2 rounded border border-indigo-200 text-indigo-900">
                      * Foi incluído o adiantamento da 1ª parcela do 13º salário no valor de <strong>{formatMoney(documento.adiantamento13.valor)}</strong> (Lei nº 4.749/65).
                    </p>
                  )}
                </div>

                <div className="text-xs pt-2 flex justify-between items-center text-slate-600">
                  <p>Data de emissão do aviso: <strong>{formatDate(documento.datasLegais.dataComunicacaoAviso)}</strong></p>
                  <p>Data limite de pagamento (Art. 145): <strong>{formatDate(documento.datasLegais.dataLimitePagamento)}</strong></p>
                </div>

                {/* Assinaturas Aviso */}
                <div className="grid grid-cols-2 gap-8 pt-8 text-xs text-center">
                  <div className="border-t border-slate-400 pt-1.5">
                    <p className="font-bold text-slate-800">{documento.empresa.razaoSocial}</p>
                    <p className="text-slate-500 text-[11px]">Empregador / Recursos Humanos</p>
                  </div>
                  <div className="border-t border-slate-400 pt-1.5">
                    <p className="font-bold text-slate-800">{documento.funcionario.nome}</p>
                    <p className="text-slate-500 text-[11px]">Ciente do Empregado em ____/____/________</p>
                  </div>
                </div>
              </section>

              {/* ================================================================= */}
              {/* DOCUMENTO 2: RECIBO DE PAGAMENTO DE FÉRIAS (ART. 145 CLT) */}
              {/* ================================================================= */}
              <section className="space-y-4">
                <div className="text-center border-b border-slate-200 pb-3">
                  <span className="text-[11px] font-bold tracking-wider uppercase text-emerald-700 bg-emerald-50 px-3 py-0.5 rounded-full inline-block mb-1">
                    Art. 145 da CLT — Quitação Financeira e Terço Constitucional (Art. 7º, XVII da CF/88)
                  </span>
                  <h2 className="text-xl font-black uppercase text-slate-900 tracking-tight">
                    Recibo de Quitação de Férias Remuneradas
                  </h2>
                </div>

                <div className="text-xs text-justify leading-relaxed text-slate-700">
                  Recebi de <strong>{documento.empresa.razaoSocial}</strong> (CNPJ: {documento.empresa.cnpj}) a 
                  importância líquida discriminada abaixo, relativa à remuneração das minhas férias regulamentares 
                  usufruídas no período de <strong>{formatDate(documento.periodoGozo.inicio)} a {formatDate(documento.periodoGozo.fim)}</strong>, 
                  referentes ao período aquisitivo de <strong>{formatDate(documento.periodoAquisitivo.inicio)} a {formatDate(documento.periodoAquisitivo.fim)}</strong>, 
                  para as quais dou plena e irrevogável quitação.
                </div>

                {/* Demonstrativo Contábil e de Encargos */}
                <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 text-[11px] uppercase tracking-wider">
                        <th className="py-2.5 px-4">Verba / Descrição Legal</th>
                        <th className="py-2.5 px-4 text-center">Ref.</th>
                        <th className="py-2.5 px-4 text-right">Proventos (R$)</th>
                        <th className="py-2.5 px-4 text-right">Descontos (R$)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      <tr>
                        <td className="py-2 px-4 font-semibold text-slate-800">
                          Férias Gozadas
                        </td>
                        <td className="py-2 px-4 text-center text-slate-500">{documento.periodoGozo.dias}d</td>
                        <td className="py-2 px-4 text-right text-slate-800 font-mono font-medium">
                          {formatMoney(documento.demonstrativo.valorFeriasGozadas)}
                        </td>
                        <td className="py-2 px-4 text-right text-slate-400 font-mono">-</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-4 font-semibold text-slate-800">
                          1/3 Constitucional sobre Férias (Art. 7º, XVII CF/88)
                        </td>
                        <td className="py-2 px-4 text-center text-slate-500">33,33%</td>
                        <td className="py-2 px-4 text-right text-slate-800 font-mono font-medium">
                          {formatMoney(documento.demonstrativo.tercoConstitucional)}
                        </td>
                        <td className="py-2 px-4 text-right text-slate-400 font-mono">-</td>
                      </tr>
                      {documento.abono.solicitado && (
                        <>
                          <tr>
                            <td className="py-2 px-4 font-semibold text-slate-800">
                              Abono Pecuniário de Férias (Art. 143 CLT) - Isento
                            </td>
                            <td className="py-2 px-4 text-center text-slate-500">{documento.abono.dias}d</td>
                            <td className="py-2 px-4 text-right text-slate-800 font-mono font-medium">
                              {formatMoney(documento.demonstrativo.valorAbonoPecuniario)}
                            </td>
                            <td className="py-2 px-4 text-right text-slate-400 font-mono">-</td>
                          </tr>
                          <tr>
                            <td className="py-2 px-4 font-semibold text-slate-800">
                              1/3 Constitucional sobre Abono Pecuniário - Isento
                            </td>
                            <td className="py-2 px-4 text-center text-slate-500">33,33%</td>
                            <td className="py-2 px-4 text-right text-slate-800 font-mono font-medium">
                              {formatMoney(documento.demonstrativo.tercoConstitucionalAbono)}
                            </td>
                            <td className="py-2 px-4 text-right text-slate-400 font-mono">-</td>
                          </tr>
                        </>
                      )}
                      {documento.adiantamento13.solicitado && (
                        <tr>
                          <td className="py-2 px-4 font-semibold text-slate-800">
                            Adiantamento 1ª Parcela 13º Salário (Lei 4.749/65)
                          </td>
                          <td className="py-2 px-4 text-center text-slate-500">50%</td>
                          <td className="py-2 px-4 text-right text-slate-800 font-mono font-medium">
                            {formatMoney(documento.demonstrativo.adiantamentoDecimoTerceiro)}
                          </td>
                          <td className="py-2 px-4 text-right text-slate-400 font-mono">-</td>
                        </tr>
                      )}
                      {documento.demonstrativo.descontoInss > 0 && (
                        <tr>
                          <td className="py-2 px-4 text-rose-700 font-medium">
                            Previdência Social (INSS sobre Férias)
                          </td>
                          <td className="py-2 px-4 text-center text-slate-500">Tabela</td>
                          <td className="py-2 px-4 text-right text-slate-400 font-mono">-</td>
                          <td className="py-2 px-4 text-right text-rose-700 font-mono font-medium">
                            {formatMoney(documento.demonstrativo.descontoInss)}
                          </td>
                        </tr>
                      )}
                      {documento.demonstrativo.descontoIrrf > 0 && (
                        <tr>
                          <td className="py-2 px-4 text-rose-700 font-medium">
                            Imposto de Renda Retido na Fonte (IRRF Férias)
                          </td>
                          <td className="py-2 px-4 text-center text-slate-500">Tabela</td>
                          <td className="py-2 px-4 text-right text-slate-400 font-mono">-</td>
                          <td className="py-2 px-4 text-right text-rose-700 font-mono font-medium">
                            {formatMoney(documento.demonstrativo.descontoIrrf)}
                          </td>
                        </tr>
                      )}
                    </tbody>
                    <tfoot>
                      <tr className="bg-slate-50 font-bold text-slate-800 border-t border-slate-200">
                        <td colSpan={2} className="py-2.5 px-4 text-right uppercase text-[11px]">
                          Totais de Proventos e Descontos:
                        </td>
                        <td className="py-2.5 px-4 text-right font-mono text-emerald-700">
                          {formatMoney(documento.demonstrativo.totalBruto)}
                        </td>
                        <td className="py-2.5 px-4 text-right font-mono text-rose-700">
                          {formatMoney(documento.demonstrativo.totalDescontos)}
                        </td>
                      </tr>
                      <tr className="bg-emerald-50 text-emerald-950 font-black border-t-2 border-emerald-300">
                        <td colSpan={2} className="py-3 px-4 text-right uppercase text-xs">
                          Valor Líquido Efetivamente Creditado:
                        </td>
                        <td colSpan={2} className="py-3 px-4 text-right font-mono text-base text-emerald-800">
                          {formatMoney(documento.demonstrativo.totalLiquidoReceber)}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                <div className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded border border-slate-200">
                  <p>
                    * Conforme previsto na legislação tributária vigente, o abono pecuniário e seu respectivo terço 
                    possuem caráter estritamente indenizatório, não integrando a base de cálculo para incidência de 
                    contribuição previdenciária (INSS) ou imposto de renda (IRRF).
                  </p>
                </div>

                {/* Assinaturas Recibo */}
                <div className="grid grid-cols-2 gap-8 pt-8 text-xs text-center">
                  <div className="border-t border-slate-400 pt-1.5">
                    <p className="font-bold text-slate-800">{documento.empresa.razaoSocial}</p>
                    <p className="text-slate-500 text-[11px]">Responsável pelo Pagamento / DP</p>
                  </div>
                  <div className="border-t border-slate-400 pt-1.5">
                    <p className="font-bold text-slate-800">{documento.funcionario.nome}</p>
                    <p className="text-slate-500 text-[11px]">Assinatura do Empregado / Quitação</p>
                  </div>
                </div>
              </section>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-3.5 border-t border-slate-200 bg-slate-50 print:hidden text-xs text-slate-500">
          <span className="flex items-center gap-1.5 text-emerald-700 font-medium">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            Em conformidade com a Consolidação das Leis do Trabalho e eSocial
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200 rounded-lg transition-colors"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
