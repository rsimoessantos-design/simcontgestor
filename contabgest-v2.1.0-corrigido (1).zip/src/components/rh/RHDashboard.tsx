import React, { useState, useMemo } from 'react';
import {
  Users,
  UserCheck,
  Cake,
  CalendarClock,
  AlertTriangle,
  Clock,
  DollarSign,
  TrendingUp,
  Building,
  CheckCircle2,
  Calendar,
  Eye,
  FileText,
  UserX,
  Umbrella,
  ShieldAlert,
  ArrowRight,
  Filter,
  Sparkles,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { Funcionario, FuncaoRH, Empresa, StatusFuncionario } from '../../types';

interface RHDashboardProps {
  funcionarios: Funcionario[];
  funcoes: FuncaoRH[];
  empresas: Empresa[];
  selectedEmpresa?: Empresa | null;
  onOpenDossieModal: (func: Funcionario) => void;
  onOpenFuncionarioModal?: (func?: Funcionario | null) => void;
  onNavigateTab: (tab: any, filterStatus?: string) => void;
}

// Cores para gráficos
const PIE_COLORS = [
  '#4f46e5', // Indigo
  '#0ea5e9', // Sky
  '#10b981', // Emerald
  '#f59e0b', // Amber
  '#ec4899', // Pink
  '#8b5cf6', // Purple
  '#64748b', // Slate
];

const MESES_NOMES = [
  'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun',
  'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'
];

const MESES_COMPLETOS = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

export const RHDashboard: React.FC<RHDashboardProps> = ({
  funcionarios,
  empresas,
  selectedEmpresa,
  onOpenDossieModal,
  onOpenFuncionarioModal,
  onNavigateTab,
}) => {
  // Filtros internos dos painéis
  const [aniversarioFiltro, setAniversarioFiltro] = useState<'60dias' | 'mesAtual' | 'proximoMes' | 'todos'>('60dias');
  const [contratoFiltro, setContratoFiltro] = useState<'todos' | 'critico' | '30dias' | '60dias' | 'estagio'>('todos');

  // Data de referência: Setembro de 2026 (ou data de hoje caso ano atual seja maior)
  const dataReferencia = useMemo(() => {
    // Usamos a data corrente do sistema ou base padrão 2026-09-13
    const now = new Date();
    return now;
  }, []);

  // 1. Contagens de Funcionários Ativos & Status
  const metricsStatus = useMemo(() => {
    const total = funcionarios.length;
    const ativos = funcionarios.filter((f) => f.status === 'ativo').length;
    const ferias = funcionarios.filter((f) => f.status === 'ferias').length;
    const afastados = funcionarios.filter((f) => f.status === 'afastado').length;
    const avisoPrevio = funcionarios.filter((f) => (f.status as any) === 'aviso_previo').length;
    const desligados = funcionarios.filter((f) => f.status === 'desligado').length;

    const percentAtivos = total > 0 ? Math.round((ativos / total) * 100) : 0;

    // Folha bruta estimada e média
    const somaSalarios = funcionarios
      .filter((f) => f.status === 'ativo' || f.status === 'ferias')
      .reduce((acc, curr) => acc + (curr.salarioBase || 0) + (curr.adicionaisTotal || 0), 0);
    const mediaSalario = (ativos + ferias) > 0 ? somaSalarios / (ativos + ferias) : 0;

    return {
      total,
      ativos,
      ferias,
      afastados,
      avisoPrevio,
      desligados,
      percentAtivos,
      somaSalarios,
      mediaSalario,
    };
  }, [funcionarios]);

  // 2. Próximos Aniversariantes
  const aniversariantesCalculados = useMemo(() => {
    const refYear = dataReferencia.getFullYear();
    const refMonth = dataReferencia.getMonth(); // 0-index
    const refDay = dataReferencia.getDate();

    // Criamos uma data "hoje" limpa (sem hora) para comparação
    const hojeLimpo = new Date(refYear, refMonth, refDay);

    return funcionarios
      .filter((f) => f.dataNascimento)
      .map((f) => {
        const parts = f.dataNascimento.split('-');
        const birthYear = parseInt(parts[0], 10);
        const birthMonth = parseInt(parts[1], 10) - 1; // 0-11
        const birthDay = parseInt(parts[2], 10);

        // O aniversário neste ano civil
        let nextBirthday = new Date(refYear, birthMonth, birthDay);

        // Se já passou neste ano civil, a próxima comemoração será no próximo ano
        if (nextBirthday.getTime() < hojeLimpo.getTime()) {
          nextBirthday = new Date(refYear + 1, birthMonth, birthDay);
        }

        const diffTime = nextBirthday.getTime() - hojeLimpo.getTime();
        const diasRestantes = Math.round(diffTime / (1000 * 60 * 60 * 24));
        const idadeACompletar = nextBirthday.getFullYear() - birthYear;

        return {
          funcionario: f,
          dia: birthDay,
          mes: birthMonth,
          mesNome: MESES_COMPLETOS[birthMonth],
          dataNascimento: f.dataNascimento,
          proximoAniversario: nextBirthday,
          diasRestantes,
          idadeACompletar,
          isMesAtual: birthMonth === refMonth,
          isProximoMes: birthMonth === (refMonth + 1) % 12,
        };
      })
      .sort((a, b) => a.diasRestantes - b.diasRestantes);
  }, [funcionarios, dataReferencia]);

  // Aniversariantes filtrados para exibição
  const aniversariantesFiltrados = useMemo(() => {
    if (aniversarioFiltro === 'mesAtual') {
      return aniversariantesCalculados.filter((a) => a.isMesAtual);
    }
    if (aniversarioFiltro === 'proximoMes') {
      return aniversariantesCalculados.filter((a) => a.isProximoMes);
    }
    if (aniversarioFiltro === '60dias') {
      return aniversariantesCalculados.filter((a) => a.diasRestantes <= 60);
    }
    return aniversariantesCalculados;
  }, [aniversariantesCalculados, aniversarioFiltro]);

  // Contagem de aniversariantes por mês para o gráfico anual
  const aniversariosPorMesData = useMemo(() => {
    const counts = new Array(12).fill(0);
    funcionarios.forEach((f) => {
      if (f.dataNascimento) {
        const parts = f.dataNascimento.split('-');
        const m = parseInt(parts[1], 10) - 1;
        if (m >= 0 && m < 12) {
          counts[m] += 1;
        }
      }
    });

    const currentMonthIdx = dataReferencia.getMonth();

    return MESES_NOMES.map((nome, index) => ({
      mes: nome,
      nomeCompleto: MESES_COMPLETOS[index],
      quantidade: counts[index],
      isMesAtual: index === currentMonthIdx,
    }));
  }, [funcionarios, dataReferencia]);

  // 3. Vencimentos de Contratos & Período de Experiência
  const vencimentosCalculados = useMemo(() => {
    const hojeLimpo = new Date(
      dataReferencia.getFullYear(),
      dataReferencia.getMonth(),
      dataReferencia.getDate()
    );

    const items: Array<{
      funcionario: Funcionario;
      tipoVencimento: 'Experiência CLT (45/90d)' | 'Contrato Determinado' | 'Estágio (Lei 11.788)' | 'Temporário';
      dataVencimento: string;
      diasRestantes: number;
      statusUrgencia: 'critico' | 'atencao' | 'moderado' | 'planejamento' | 'vencido';
      observacaoLegal: string;
    }> = [];

    funcionarios.forEach((f) => {
      // Analisar término de experiência
      if (f.terminoExperiencia) {
        const expDate = new Date(f.terminoExperiencia + 'T00:00:00');
        if (!isNaN(expDate.getTime())) {
          const diffTime = expDate.getTime() - hojeLimpo.getTime();
          const dias = Math.round(diffTime / (1000 * 60 * 60 * 24));

          let urgencia: 'critico' | 'atencao' | 'moderado' | 'planejamento' | 'vencido' = 'planejamento';
          if (dias < 0) urgencia = 'vencido';
          else if (dias <= 15) urgencia = 'critico';
          else if (dias <= 30) urgencia = 'atencao';
          else if (dias <= 60) urgencia = 'moderado';

          items.push({
            funcionario: f,
            tipoVencimento: f.tipoContrato === 'Estágio' ? 'Estágio (Lei 11.788)' : 'Experiência CLT (45/90d)',
            dataVencimento: f.terminoExperiencia,
            diasRestantes: dias,
            statusUrgencia: urgencia,
            observacaoLegal:
              dias <= 15
                ? 'Ação imediata: prorrogar, efetivar ou rescindir no término para evitar estabilidade tácita.'
                : 'Acompanhamento do período de adaptação e desempenho.',
          });
        }
      }

      // Analisar término de contrato determinado específico
      if (f.terminoContrato && f.terminoContrato !== f.terminoExperiencia) {
        const cDate = new Date(f.terminoContrato + 'T00:00:00');
        if (!isNaN(cDate.getTime())) {
          const diffTime = cDate.getTime() - hojeLimpo.getTime();
          const dias = Math.round(diffTime / (1000 * 60 * 60 * 24));

          let urgencia: 'critico' | 'atencao' | 'moderado' | 'planejamento' | 'vencido' = 'planejamento';
          if (dias < 0) urgencia = 'vencido';
          else if (dias <= 15) urgencia = 'critico';
          else if (dias <= 30) urgencia = 'atencao';
          else if (dias <= 60) urgencia = 'moderado';

          items.push({
            funcionario: f,
            tipoVencimento: f.tipoContrato === 'Estágio' ? 'Estágio (Lei 11.788)' : 'Contrato Determinado',
            dataVencimento: f.terminoContrato,
            diasRestantes: dias,
            statusUrgencia: urgencia,
            observacaoLegal:
              f.tipoContrato === 'Estágio'
                ? 'Término de vigência do Termo de Compromisso de Estágio (TCE).'
                : 'Fim do prazo contratual estipulado.',
          });
        }
      }
    });

    return items.sort((a, b) => a.diasRestantes - b.diasRestantes);
  }, [funcionarios, dataReferencia]);

  // Vencimentos filtrados
  const vencimentosFiltrados = useMemo(() => {
    if (contratoFiltro === 'critico') {
      return vencimentosCalculados.filter((v) => v.statusUrgencia === 'critico' || v.statusUrgencia === 'vencido');
    }
    if (contratoFiltro === '30dias') {
      return vencimentosCalculados.filter((v) => v.diasRestantes >= 0 && v.diasRestantes <= 30);
    }
    if (contratoFiltro === '60dias') {
      return vencimentosCalculados.filter((v) => v.diasRestantes >= 0 && v.diasRestantes <= 60);
    }
    if (contratoFiltro === 'estagio') {
      return vencimentosCalculados.filter((v) => v.funcionario.tipoContrato === 'Estágio');
    }
    return vencimentosCalculados;
  }, [vencimentosCalculados, contratoFiltro]);

  // Dados para o Gráfico de Faixas de Vencimento de Contratos
  const faixasVencimentoData = useMemo(() => {
    let critico = 0; // <= 15 dias
    let atencao = 0; // 16 a 30 dias
    let moderado = 0; // 31 a 60 dias
    let longoPrazo = 0; // > 60 dias
    let vencidos = 0; // < 0 dias

    vencimentosCalculados.forEach((v) => {
      if (v.diasRestantes < 0) vencidos += 1;
      else if (v.diasRestantes <= 15) critico += 1;
      else if (v.diasRestantes <= 30) atencao += 1;
      else if (v.diasRestantes <= 60) moderado += 1;
      else longoPrazo += 1;
    });

    // Colaboradores em contrato indeterminado sem vencimento próximo
    const semVencimento = Math.max(0, funcionarios.length - vencimentosCalculados.length);

    return [
      { faixa: 'Vencidos', quantidade: vencidos, color: '#e11d48' },
      { faixa: 'Até 15 dias', quantidade: critico, color: '#f43f5e' },
      { faixa: '16 a 30 dias', quantidade: atencao, color: '#f59e0b' },
      { faixa: '31 a 60 dias', quantidade: moderado, color: '#0ea5e9' },
      { faixa: '> 60 dias', quantidade: longoPrazo, color: '#10b981' },
      { faixa: 'Indeterminado', quantidade: semVencimento, color: '#94a3b8' },
    ];
  }, [vencimentosCalculados, funcionarios]);

  // 4. Distribuição por Departamento e Status (Gráfico Recharts)
  const departamentoData = useMemo(() => {
    const map = new Map<string, { departamento: string; ativos: number; ferias: number; afastados: number; total: number }>();

    funcionarios.forEach((f) => {
      const dep = f.departamento || 'Geral';
      if (!map.has(dep)) {
        map.set(dep, { departamento: dep, ativos: 0, ferias: 0, afastados: 0, total: 0 });
      }
      const entry = map.get(dep)!;
      entry.total += 1;
      if (f.status === 'ativo') entry.ativos += 1;
      else if (f.status === 'ferias') entry.ferias += 1;
      else if (f.status === 'afastado') entry.afastados += 1;
    });

    return Array.from(map.values()).sort((a, b) => b.total - a.total);
  }, [funcionarios]);

  // 5. Composição por Tipo de Contrato (PieChart)
  const tipoContratoData = useMemo(() => {
    const counts = new Map<string, number>();
    funcionarios.forEach((f) => {
      const tipo = f.tipoContrato || 'CLT Indeterminado';
      counts.set(tipo, (counts.get(tipo) || 0) + 1);
    });

    return Array.from(counts.entries()).map(([name, value]) => ({
      name,
      value,
    }));
  }, [funcionarios]);

  // 6. Composição por Regime de Trabalho (Presencial, Híbrido, Remoto)
  const regimeTrabalhoData = useMemo(() => {
    const counts = { presencial: 0, hibrido: 0, remoto: 0 };
    funcionarios.forEach((f) => {
      if (f.regimeTrabalho === 'hibrido') counts.hibrido += 1;
      else if (f.regimeTrabalho === 'remoto') counts.remoto += 1;
      else counts.presencial += 1;
    });

    return [
      { name: 'Presencial', value: counts.presencial, color: '#3b82f6' },
      { name: 'Híbrido', value: counts.hibrido, color: '#8b5cf6' },
      { name: '100% Remoto', value: counts.remoto, color: '#10b981' },
    ].filter((item) => item.value > 0);
  }, [funcionarios]);

  // Próximo aniversariante em destaque
  const proximoAniversariante = aniversariantesCalculados[0];

  // Contratos críticos vencendo em <= 15 dias
  const contratosCriticos = vencimentosCalculados.filter(
    (v) => v.statusUrgencia === 'critico' || v.statusUrgencia === 'vencido'
  );

  return (
    <div id="rh-dashboard-container" className="space-y-6">
      {/* CABEÇALHO DO DASHBOARD */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/60">
              <Sparkles className="w-3.5 h-3.5" />
              Painel Estratégico de RH & Departamento Pessoal
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Competência: 09/2026
            </span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            {selectedEmpresa ? selectedEmpresa.razaoSocial : 'Visão Geral Consolidada de Recursos Humanos'}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Monitoramento em tempo real de funcionários ativos, aniversários, vencimentos de períodos de experiência e regimes contratuais.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="rh-dash-btn-turnover"
            onClick={() => onNavigateTab('turnover')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-xl transition-colors"
          >
            <TrendingUp className="w-3.5 h-3.5" />
            Turnover & Cargos
          </button>
          {onOpenFuncionarioModal && (
            <button
              id="rh-dash-btn-novo-colab"
              onClick={() => onOpenFuncionarioModal(null)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors shadow-xs"
            >
              <Users className="w-3.5 h-3.5" />
              Novo Colaborador
            </button>
          )}
          <button
            id="rh-dash-btn-ver-colaboradores"
            onClick={() => onNavigateTab('colaboradores')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200/80 rounded-xl transition-colors"
          >
            Ver Quadro Completo
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 4 CARDS PRINCIPAIS DE KPI */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* CARD 1: FUNCIONÁRIOS ATIVOS */}
        <div
          id="kpi-funcionarios-ativos"
          onClick={() => onNavigateTab('colaboradores', 'ativo')}
          className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-indigo-300 transition-all cursor-pointer group"
        >
          <div className="flex items-start justify-between">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Colaboradores Ativos
              </span>
              <div className="flex items-baseline gap-2 mt-1.5">
                <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
                  {metricsStatus.ativos}
                </span>
                <span className="text-xs text-slate-500 font-medium">
                  de {metricsStatus.total} totais ({metricsStatus.percentAtivos}%)
                </span>
              </div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center group-hover:scale-105 transition-transform">
              <UserCheck className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="inline-flex items-center gap-1 text-emerald-600 font-medium">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              {metricsStatus.ativos} Ativos
            </span>
            <span className="inline-flex items-center gap-1 text-amber-600 font-medium">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              {metricsStatus.ferias} Férias
            </span>
            <span className="inline-flex items-center gap-1 text-rose-600 font-medium">
              <span className="w-2 h-2 rounded-full bg-rose-500"></span>
              {metricsStatus.afastados} Afastados
            </span>
          </div>
        </div>

        {/* CARD 2: PRÓXIMOS ANIVERSARIANTES */}
        <div
          id="kpi-proximos-aniversariantes"
          onClick={() => setAniversarioFiltro('60dias')}
          className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-pink-300 transition-all cursor-pointer group"
        >
          <div className="flex items-start justify-between">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Próximos Aniversariantes
              </span>
              <div className="flex items-baseline gap-2 mt-1.5">
                <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
                  {aniversariantesCalculados.filter((a) => a.diasRestantes <= 60).length}
                </span>
                <span className="text-xs text-pink-600 font-semibold bg-pink-50 px-2 py-0.5 rounded-md border border-pink-100">
                  {aniversariantesCalculados.filter((a) => a.isMesAtual).length} neste mês
                </span>
              </div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-pink-50 border border-pink-100 text-pink-600 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Cake className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 text-xs text-slate-600 truncate">
            {proximoAniversariante ? (
              <span className="flex items-center gap-1.5 truncate">
                <span className="font-semibold text-slate-900 truncate">
                  {proximoAniversariante.funcionario.nomeCompleto.split(' ')[0]}:
                </span>
                <span className="text-pink-600 font-medium">
                  {proximoAniversariante.dia}/{MESES_NOMES[proximoAniversariante.mes]} ({proximoAniversariante.diasRestantes === 0 ? 'Hoje!' : `em ${proximoAniversariante.diasRestantes}d`})
                </span>
              </span>
            ) : (
              <span className="text-slate-400">Nenhum aniversário nos próximos 60 dias</span>
            )}
          </div>
        </div>

        {/* CARD 3: VENCIMENTOS DE CONTRATOS & EXPERIÊNCIA */}
        <div
          id="kpi-vencimentos-contratos"
          onClick={() => setContratoFiltro('todos')}
          className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-amber-300 transition-all cursor-pointer group"
        >
          <div className="flex items-start justify-between">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Vencimentos de Contrato
              </span>
              <div className="flex items-baseline gap-2 mt-1.5">
                <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
                  {vencimentosCalculados.filter((v) => v.diasRestantes >= 0 && v.diasRestantes <= 60).length}
                </span>
                {contratosCriticos.length > 0 ? (
                  <span className="text-xs text-rose-700 font-semibold bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200/60 animate-pulse">
                    {contratosCriticos.length} crítico(s)
                  </span>
                ) : (
                  <span className="text-xs text-emerald-600 font-medium">Regular</span>
                )}
              </div>
            </div>
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform ${
              contratosCriticos.length > 0
                ? 'bg-rose-50 border border-rose-200 text-rose-600'
                : 'bg-amber-50 border border-amber-100 text-amber-600'
            }`}>
              <CalendarClock className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-500">
              Períodos de Experiência & Estágio
            </span>
            <span className="font-semibold text-slate-700">
              {vencimentosCalculados.length} monitorados
            </span>
          </div>
        </div>

        {/* CARD 4: MASSA SALARIAL & MÉDIA */}
        <div
          id="kpi-folha-salarial"
          onClick={() => onNavigateTab('folha')}
          className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-300 transition-all cursor-pointer group"
        >
          <div className="flex items-start justify-between">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Folha Salarial Estimada
              </span>
              <div className="flex items-baseline gap-1 mt-1.5">
                <span className="text-2xl font-extrabold text-slate-900 tracking-tight">
                  {metricsStatus.somaSalarios.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </span>
              </div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-100 text-emerald-600 flex items-center justify-center group-hover:scale-105 transition-transform">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
            <span>Salário Médio Base:</span>
            <span className="font-semibold text-emerald-700">
              {metricsStatus.mediaSalario.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
            </span>
          </div>
        </div>
      </div>

      {/* SEÇÃO PRINCIPAL DE GRÁFICOS (RECHARTS) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* GRÁFICO 1: DISTRIBUIÇÃO POR DEPARTAMENTO E STATUS (COLUNA 7) */}
        <div className="lg:col-span-7 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Força de Trabalho por Departamento & Status
              </h3>
              <p className="text-xs text-slate-500">
                Alocação de colaboradores ativos, em férias e com licença/afastamento
              </p>
            </div>
            <span className="text-xs font-semibold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-lg">
              {departamentoData.length} Setores
            </span>
          </div>

          <div className="h-72 w-full">
            {departamentoData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={departamentoData}
                  margin={{ top: 10, right: 10, left: -20, bottom: 25 }}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis
                    dataKey="departamento"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    interval={0}
                    angle={-15}
                    textAnchor="end"
                  />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderRadius: '12px',
                      border: '1px solid #e2e8f0',
                      boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                      fontSize: '12px',
                    }}
                    formatter={(value: any, name: any) => {
                      const label = name === 'ativos' ? 'Ativos' : name === 'ferias' ? 'Férias' : 'Afastados';
                      return [`${value} colaborador(es)`, label];
                    }}
                  />
                  <Legend
                    verticalAlign="top"
                    align="right"
                    wrapperStyle={{ paddingBottom: '10px', fontSize: '12px' }}
                    formatter={(val) => (val === 'ativos' ? 'Ativos' : val === 'ferias' ? 'Em Férias' : 'Afastados')}
                  />
                  <Bar dataKey="ativos" stackId="a" fill="#4f46e5" radius={[0, 0, 0, 0]} />
                  <Bar dataKey="ferias" stackId="a" fill="#f59e0b" radius={[0, 0, 0, 0]} />
                  <Bar dataKey="afastados" stackId="a" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                Nenhum colaborador registrado.
              </div>
            )}
          </div>
        </div>

        {/* GRÁFICO 2: COMPOSIÇÃO DE CONTRATOS & REGIME (COLUNA 5) */}
        <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold text-slate-900">
                Modalidades Contratuais & Vínculos
              </h3>
              <span className="text-xs text-slate-400 font-medium">
                CLT / Estágio / PJ
              </span>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Proporção de tipos de contratos vigentes na organização
            </p>
          </div>

          <div className="h-64 w-full">
            {tipoContratoData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={tipoContratoData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {tipoContratoData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderRadius: '12px',
                      border: '1px solid #e2e8f0',
                      fontSize: '12px',
                    }}
                    formatter={(val: any) => [`${val} colaborador(es)`, 'Total']}
                  />
                  <Legend
                    verticalAlign="bottom"
                    align="center"
                    layout="horizontal"
                    wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                Sem dados de contratos.
              </div>
            )}
          </div>

          {/* BADGES DE REGIME DE TRABALHO */}
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-around text-xs">
            {regimeTrabalhoData.map((reg) => (
              <div key={reg.name} className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: reg.color }}></span>
                <span className="text-slate-600 font-medium">{reg.name}:</span>
                <span className="font-bold text-slate-900">{reg.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* SEGUNDA LINHA DE GRÁFICOS: CALENDÁRIO DE ANIVERSARIANTES & CRONOGRAMA DE VENCIMENTOS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* GRÁFICO 3: CALENDÁRIO ANUAL DE ANIVERSARIANTES (COLUNA 6) */}
        <div className="lg:col-span-6 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-pink-50 text-pink-600 flex items-center justify-center">
                <Cake className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Distribuição Anual de Aniversariantes
                </h3>
                <p className="text-xs text-slate-500">
                  Volume de aniversários por mês civil (com destaque para o mês atual)
                </p>
              </div>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 bg-pink-50 text-pink-700 border border-pink-200 rounded-lg">
              Mês Atual: Setembro
            </span>
          </div>

          <div className="h-56 w-full mt-3">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={aniversariosPorMesData}
                margin={{ top: 10, right: 10, left: -25, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="mes" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderRadius: '12px',
                    border: '1px solid #e2e8f0',
                    fontSize: '12px',
                  }}
                  formatter={(val: any, _, item: any) => [
                    `${val} aniversariante(s)`,
                    item.payload.nomeCompleto,
                  ]}
                />
                <Bar dataKey="quantidade" radius={[6, 6, 0, 0]}>
                  {aniversariosPorMesData.map((entry, index) => (
                    <Cell
                      key={`month-cell-${index}`}
                      fill={entry.isMesAtual ? '#ec4899' : '#cbd5e1'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* GRÁFICO 4: FAIXAS DE VENCIMENTO DE CONTRATOS (COLUNA 6) */}
        <div className="lg:col-span-6 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                <CalendarClock className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Cronograma de Vencimento de Contratos & Experiência
                </h3>
                <p className="text-xs text-slate-500">
                  Previsão temporal para avaliação de efetivação ou renovação contratual
                </p>
              </div>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded-lg">
              CLT Art. 445 e Lei 11.788
            </span>
          </div>

          <div className="h-56 w-full mt-3">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={faixasVencimentoData}
                margin={{ top: 10, right: 10, left: -25, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="faixa" tick={{ fontSize: 10, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderRadius: '12px',
                    border: '1px solid #e2e8f0',
                    fontSize: '12px',
                  }}
                  formatter={(val: any, _, item: any) => [
                    `${val} contrato(s)`,
                    item.payload.faixa,
                  ]}
                />
                <Bar dataKey="quantidade" radius={[6, 6, 0, 0]}>
                  {faixasVencimentoData.map((entry, index) => (
                    <Cell key={`faixa-cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* PAINÉIS DETALHADOS INTERATIVOS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* PAINEL A: PRÓXIMOS ANIVERSARIANTES COM FILTROS */}
        <div id="painel-aniversariantes" className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-pink-100 text-pink-700 flex items-center justify-center font-bold">
                <Cake className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Próximos Aniversariantes
                </h3>
                <p className="text-xs text-slate-500">
                  Celebrações e datas especiais da equipe
                </p>
              </div>
            </div>

            {/* FILTRO DE PERÍODO */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
              <button
                onClick={() => setAniversarioFiltro('60dias')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                  aniversarioFiltro === '60dias'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                60 Dias
              </button>
              <button
                onClick={() => setAniversarioFiltro('mesAtual')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                  aniversarioFiltro === 'mesAtual'
                    ? 'bg-white text-pink-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Neste Mês
              </button>
              <button
                onClick={() => setAniversarioFiltro('proximoMes')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                  aniversarioFiltro === 'proximoMes'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Outubro
              </button>
              <button
                onClick={() => setAniversarioFiltro('todos')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                  aniversarioFiltro === 'todos'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Todos
              </button>
            </div>
          </div>

          {/* LISTA DE ANIVERSARIANTES */}
          <div className="mt-4 space-y-2.5 max-h-96 overflow-y-auto pr-1">
            {aniversariantesFiltrados.length > 0 ? (
              aniversariantesFiltrados.map((item) => {
                const f = item.funcionario;
                const iniciais = f.nomeCompleto
                  .split(' ')
                  .slice(0, 2)
                  .map((n) => n[0])
                  .join('')
                  .toUpperCase();

                const isToday = item.diasRestantes === 0;

                return (
                  <div
                    key={f.id}
                    className={`p-3 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                      isToday
                        ? 'bg-pink-50/70 border-pink-200'
                        : item.isMesAtual
                        ? 'bg-slate-50/70 border-slate-200 hover:border-pink-200'
                        : 'bg-white border-slate-200/80 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                          isToday
                            ? 'bg-pink-600 text-white shadow-xs'
                            : item.isMesAtual
                            ? 'bg-pink-100 text-pink-700'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {iniciais}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <p className="text-sm font-semibold text-slate-900 truncate">
                            {f.nomeCompleto}
                          </p>
                          {isToday && (
                            <span className="px-2 py-0.5 text-[10px] font-extrabold uppercase bg-pink-600 text-white rounded-full animate-bounce">
                              É Hoje! 🎉
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 truncate">
                          {f.cargoNome} • <span className="font-medium text-slate-600">{f.departamento}</span>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <div className="text-right">
                        <span className="text-xs font-bold text-slate-900 block">
                          {String(item.dia).padStart(2, '0')} de {item.mesNome}
                        </span>
                        <span className="text-[11px] text-slate-500 block">
                          {isToday
                            ? `Completa ${item.idadeACompletar} anos`
                            : `Em ${item.diasRestantes} dias (${item.idadeACompletar} anos)`}
                        </span>
                      </div>

                      <button
                        onClick={() => onOpenDossieModal(f)}
                        title="Ver ficha do colaborador"
                        className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <Cake className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="text-xs text-slate-500 font-medium">
                  Nenhum aniversariante encontrado para o filtro selecionado.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* PAINEL B: VENCIMENTOS DE CONTRATOS & EXPERIÊNCIA COM FILTROS */}
        <div id="painel-vencimentos" className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
                <CalendarClock className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Vencimentos de Contrato & Experiência
                </h3>
                <p className="text-xs text-slate-500">
                  Prazos de 45/90 dias e vigências contratuais
                </p>
              </div>
            </div>

            {/* FILTROS DE CONTRATOS */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
              <button
                onClick={() => setContratoFiltro('todos')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                  contratoFiltro === 'todos'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Todos ({vencimentosCalculados.length})
              </button>
              <button
                onClick={() => setContratoFiltro('critico')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                  contratoFiltro === 'critico'
                    ? 'bg-white text-rose-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Crítico (≤15d)
              </button>
              <button
                onClick={() => setContratoFiltro('30dias')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                  contratoFiltro === '30dias'
                    ? 'bg-white text-amber-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                30 Dias
              </button>
              <button
                onClick={() => setContratoFiltro('estagio')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                  contratoFiltro === 'estagio'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Estágio
              </button>
            </div>
          </div>

          {/* LISTA DE VENCIMENTOS */}
          <div className="mt-4 space-y-2.5 max-h-96 overflow-y-auto pr-1">
            {vencimentosFiltrados.length > 0 ? (
              vencimentosFiltrados.map((item, idx) => {
                const f = item.funcionario;
                const isCritico = item.statusUrgencia === 'critico' || item.statusUrgencia === 'vencido';
                const isAtencao = item.statusUrgencia === 'atencao';

                return (
                  <div
                    key={`${f.id}-${idx}`}
                    className={`p-3.5 rounded-xl border transition-all ${
                      isCritico
                        ? 'bg-rose-50/60 border-rose-200'
                        : isAtencao
                        ? 'bg-amber-50/60 border-amber-200'
                        : 'bg-white border-slate-200/80 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-semibold text-slate-900">
                            {f.nomeCompleto}
                          </span>
                          <span
                            className={`px-2 py-0.5 text-[10px] font-bold rounded-md uppercase tracking-wider ${
                              isCritico
                                ? 'bg-rose-100 text-rose-800'
                                : isAtencao
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {item.tipoVencimento}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          {f.cargoNome} • {f.departamento}
                        </p>
                      </div>

                      <div className="text-right shrink-0">
                        <span
                          className={`text-xs font-bold block ${
                            isCritico ? 'text-rose-700' : isAtencao ? 'text-amber-700' : 'text-slate-900'
                          }`}
                        >
                          {item.diasRestantes < 0
                            ? 'VENCIDO!'
                            : item.diasRestantes === 0
                            ? 'Vence Hoje!'
                            : `Vence em ${item.diasRestantes} dias`}
                        </span>
                        <span className="text-[11px] text-slate-500 block">
                          Término: {item.dataVencimento.split('-').reverse().join('/')}
                        </span>
                      </div>
                    </div>

                    <div className="mt-2 pt-2 border-t border-slate-100/80 flex items-center justify-between text-xs">
                      <span className="text-slate-500 text-[11px] flex items-center gap-1 truncate">
                        {isCritico && <AlertTriangle className="w-3.5 h-3.5 text-rose-500 shrink-0" />}
                        {item.observacaoLegal}
                      </span>

                      <div className="flex items-center gap-1.5 shrink-0 ml-2">
                        <button
                          onClick={() => onOpenDossieModal(f)}
                          className="px-2 py-1 text-[11px] font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors"
                        >
                          Ver Ficha
                        </button>
                        {onOpenFuncionarioModal && (
                          <button
                            onClick={() => onOpenFuncionarioModal(f)}
                            className="px-2 py-1 text-[11px] font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors"
                          >
                            Efetivar / Editar
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <CalendarClock className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="text-xs text-slate-500 font-medium">
                  Nenhum contrato a vencer no filtro selecionado.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
