import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  FileText,
  Building,
  CreditCard,
  HeartHandshake,
  Check,
  AlertCircle,
  Plus,
  Trash2,
  Calendar,
} from 'lucide-react';
import {
  Funcionario,
  FuncaoRH,
  Empresa,
  Dependente,
  TipoContrato,
  RegimeTrabalho,
  StatusFuncionario,
} from '../../types';

interface FuncionarioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (func: Omit<Funcionario, 'id' | 'isDemo'>) => Promise<void>;
  funcionarioToEdit?: Funcionario | null;
  empresas: Empresa[];
  funcoes: FuncaoRH[];
  selectedEmpresaId?: string;
}

type TabType = 'pessoal' | 'trabalhista' | 'contratual' | 'financeiro' | 'dependentes' | 'sst';

export const FuncionarioModal: React.FC<FuncionarioModalProps> = ({
  isOpen,
  onClose,
  onSave,
  funcionarioToEdit,
  empresas,
  funcoes,
  selectedEmpresaId,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('pessoal');

  // Form State
  const [empresaId, setEmpresaId] = useState('');
  const [matricula, setMatricula] = useState('');
  const [nomeCompleto, setNomeCompleto] = useState('');
  const [cpf, setCpf] = useState('');
  const [rg, setRg] = useState('');
  const [rgOrgaoEmissor, setRgOrgaoEmissor] = useState('SSP/SP');
  const [dataNascimento, setDataNascimento] = useState('1995-01-01');
  const [sexo, setSexo] = useState<'M' | 'F' | 'Outro'>('M');
  const [estadoCivil, setEstadoCivil] = useState('Solteiro(a)');
  const [nomeMae, setNomeMae] = useState('');
  const [nomePai, setNomePai] = useState('');
  const [email, setEmail] = useState('');
  const [telefone, setTelefone] = useState('');
  const [whatsapp, setWhatsapp] = useState('');

  // Endereço
  const [cep, setCep] = useState('');
  const [logradouro, setLogradouro] = useState('');
  const [numero, setNumero] = useState('');
  const [complemento, setComplemento] = useState('');
  const [bairro, setBairro] = useState('');
  const [cidade, setCidade] = useState('');
  const [uf, setUf] = useState('SP');

  // Dados Trabalhistas
  const [pisPasep, setPisPasep] = useState('');
  const [ctpsNumero, setCtpsNumero] = useState('');
  const [ctpsSerie, setCtpsSerie] = useState('001');
  const [ctpsUf, setCtpsUf] = useState('SP');

  // Contrato
  const [funcaoId, setFuncaoId] = useState('');
  const [cargoNome, setCargoNome] = useState('');
  const [cbo, setCbo] = useState('');
  const [departamento, setDepartamento] = useState('');
  const [tipoContrato, setTipoContrato] = useState<TipoContrato>('CLT Indeterminado');
  const [regimeTrabalho, setRegimeTrabalho] = useState<RegimeTrabalho>('presencial');
  const [dataAdmissao, setDataAdmissao] = useState(new Date().toISOString().split('T')[0]);
  const [terminoExperiencia, setTerminoExperiencia] = useState('');
  const [salarioBase, setSalarioBase] = useState<number>(3000);
  const [adicionaisTotal, setAdicionaisTotal] = useState<number>(0);
  const [status, setStatus] = useState<StatusFuncionario>('ativo');

  // Financeiro & Benefícios
  const [bancoNome, setBancoNome] = useState('Banco Itaú (341)');
  const [bancoAgencia, setBancoAgencia] = useState('');
  const [bancoConta, setBancoConta] = useState('');
  const [chavePix, setChavePix] = useState('');
  const [valeTransporte, setValeTransporte] = useState(false);
  const [valorVrVaMensal, setValorVrVaMensal] = useState<number>(800);
  const [planoSaude, setPlanoSaude] = useState(true);

  // SST & Férias
  const [periodoAquisitivoInicio, setPeriodoAquisitivoInicio] = useState('');
  const [periodoAquisitivoFim, setPeriodoAquisitivoFim] = useState('');
  const [limiteConcessivoFerias, setLimiteConcessivoFerias] = useState('');
  const [diasFeriasSaldo, setDiasFeriasSaldo] = useState<number>(30);
  const [dataUltimoAso, setDataUltimoAso] = useState('');
  const [dataValidadeAso, setDataValidadeAso] = useState('');
  const [observacoes, setObservacoes] = useState('');

  // Dependentes
  const [dependentes, setDependentes] = useState<Dependente[]>([]);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (funcionarioToEdit) {
      setEmpresaId(funcionarioToEdit.empresaId || '');
      setMatricula(funcionarioToEdit.matricula || '');
      setNomeCompleto(funcionarioToEdit.nomeCompleto || '');
      setCpf(funcionarioToEdit.cpf || '');
      setRg(funcionarioToEdit.rg || '');
      setRgOrgaoEmissor(funcionarioToEdit.rgOrgaoEmissor || 'SSP/SP');
      setDataNascimento(funcionarioToEdit.dataNascimento || '');
      setSexo(funcionarioToEdit.sexo || 'M');
      setEstadoCivil(funcionarioToEdit.estadoCivil || 'Solteiro(a)');
      setNomeMae(funcionarioToEdit.nomeMae || '');
      setNomePai(funcionarioToEdit.nomePai || '');
      setEmail(funcionarioToEdit.email || '');
      setTelefone(funcionarioToEdit.telefone || '');
      setWhatsapp(funcionarioToEdit.whatsapp || '');
      setCep(funcionarioToEdit.cep || '');
      setLogradouro(funcionarioToEdit.logradouro || '');
      setNumero(funcionarioToEdit.numero || '');
      setComplemento(funcionarioToEdit.complemento || '');
      setBairro(funcionarioToEdit.bairro || '');
      setCidade(funcionarioToEdit.cidade || '');
      setUf(funcionarioToEdit.uf || 'SP');
      setPisPasep(funcionarioToEdit.pisPasep || '');
      setCtpsNumero(funcionarioToEdit.ctpsNumero || '');
      setCtpsSerie(funcionarioToEdit.ctpsSerie || '001');
      setCtpsUf(funcionarioToEdit.ctpsUf || 'SP');
      setFuncaoId(funcionarioToEdit.funcaoId || '');
      setCargoNome(funcionarioToEdit.cargoNome || '');
      setCbo(funcionarioToEdit.cbo || '');
      setDepartamento(funcionarioToEdit.departamento || '');
      setTipoContrato(funcionarioToEdit.tipoContrato || 'CLT Indeterminado');
      setRegimeTrabalho(funcionarioToEdit.regimeTrabalho || 'presencial');
      setDataAdmissao(funcionarioToEdit.dataAdmissao || '');
      setTerminoExperiencia(funcionarioToEdit.terminoExperiencia || '');
      setSalarioBase(funcionarioToEdit.salarioBase || 0);
      setAdicionaisTotal(funcionarioToEdit.adicionaisTotal || 0);
      setStatus(funcionarioToEdit.status || 'ativo');
      setBancoNome(funcionarioToEdit.bancoNome || '');
      setBancoAgencia(funcionarioToEdit.bancoAgencia || '');
      setBancoConta(funcionarioToEdit.bancoConta || '');
      setChavePix(funcionarioToEdit.chavePix || '');
      setValeTransporte(Boolean(funcionarioToEdit.valeTransporte));
      setValorVrVaMensal(funcionarioToEdit.valorVrVaMensal || 0);
      setPlanoSaude(Boolean(funcionarioToEdit.planoSaude));
      setPeriodoAquisitivoInicio(funcionarioToEdit.periodoAquisitivoInicio || '');
      setPeriodoAquisitivoFim(funcionarioToEdit.periodoAquisitivoFim || '');
      setLimiteConcessivoFerias(funcionarioToEdit.limiteConcessivoFerias || '');
      setDiasFeriasSaldo(funcionarioToEdit.diasFeriasSaldo ?? 30);
      setDataUltimoAso(funcionarioToEdit.dataUltimoAso || '');
      setDataValidadeAso(funcionarioToEdit.dataValidadeAso || '');
      setObservacoes(funcionarioToEdit.observacoes || '');
      setDependentes(funcionarioToEdit.dependentes ? [...funcionarioToEdit.dependentes] : []);
    } else {
      const defaultEmpId = selectedEmpresaId && selectedEmpresaId !== 'todas'
        ? selectedEmpresaId
        : (empresas[0]?.id || '');
      setEmpresaId(defaultEmpId);
      setMatricula(`ESOC-${Math.floor(10000 + Math.random() * 90000)}`);
      setNomeCompleto('');
      setCpf('');
      setRg('');
      setRgOrgaoEmissor('SSP/SP');
      setDataNascimento('1996-05-15');
      setSexo('M');
      setEstadoCivil('Solteiro(a)');
      setNomeMae('');
      setNomePai('');
      setEmail('');
      setTelefone('');
      setWhatsapp('');
      setCep('');
      setLogradouro('');
      setNumero('');
      setComplemento('');
      setBairro('');
      setCidade('');
      setUf('SP');
      setPisPasep('');
      setCtpsNumero('');
      setCtpsSerie('001');
      setCtpsUf('SP');
      setFuncaoId('');
      setCargoNome('');
      setCbo('');
      setDepartamento('');
      setTipoContrato('CLT Indeterminado');
      setRegimeTrabalho('presencial');
      setDataAdmissao(new Date().toISOString().split('T')[0]);
      setTerminoExperiencia('');
      setSalarioBase(3000);
      setAdicionaisTotal(0);
      setStatus('ativo');
      setBancoNome('Banco Itaú (341)');
      setBancoAgencia('');
      setBancoConta('');
      setChavePix('');
      setValeTransporte(false);
      setValorVrVaMensal(800);
      setPlanoSaude(true);
      setPeriodoAquisitivoInicio(new Date().toISOString().split('T')[0]);
      setPeriodoAquisitivoFim('');
      setLimiteConcessivoFerias('');
      setDiasFeriasSaldo(30);
      setDataUltimoAso(new Date().toISOString().split('T')[0]);
      setDataValidadeAso('');
      setObservacoes('');
      setDependentes([]);
    }
    setError(null);
    setActiveTab('pessoal');
  }, [funcionarioToEdit, selectedEmpresaId, empresas, isOpen]);

  // Sincronizar cargo selecionado com CBO e departamento
  const handleFuncaoChange = (fId: string) => {
    setFuncaoId(fId);
    const selectedFnc = funcoes.find((f) => f.id === fId);
    if (selectedFnc) {
      setCargoNome(selectedFnc.titulo);
      setCbo(selectedFnc.cbo);
      setDepartamento(selectedFnc.departamento);
      if (!salarioBase || salarioBase === 3000) {
        setSalarioBase(selectedFnc.salarioBase);
      }
      if (selectedFnc.adicionalPericulosidade) {
        setAdicionaisTotal(Math.round(selectedFnc.salarioBase * 0.3 * 100) / 100);
      }
    }
  };

  const handleAddDependente = () => {
    const novo: Dependente = {
      id: `dep_${Date.now()}`,
      nome: '',
      parentesco: 'Filho(a)',
      cpf: '',
      dataNascimento: '',
      deducaoIrrf: true,
      salarioFamilia: false,
    };
    setDependentes([...dependentes, novo]);
  };

  const handleUpdateDependente = (index: number, field: keyof Dependente, value: any) => {
    const updated = [...dependentes];
    updated[index] = { ...updated[index], [field]: value };
    setDependentes(updated);
  };

  const handleRemoveDependente = (index: number) => {
    setDependentes(dependentes.filter((_, i) => i !== index));
  };

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nomeCompleto.trim()) {
      setError('O nome completo do colaborador é obrigatório.');
      setActiveTab('pessoal');
      return;
    }
    if (!cpf.trim()) {
      setError('O CPF do colaborador é obrigatório.');
      setActiveTab('pessoal');
      return;
    }
    if (!cargoNome.trim()) {
      setError('O cargo / função do colaborador é obrigatório.');
      setActiveTab('contratual');
      return;
    }
    if (!empresaId) {
      setError('Selecione a empresa vinculada.');
      setActiveTab('contratual');
      return;
    }

    try {
      setSaving(true);
      setError(null);
      await onSave({
        empresaId,
        matricula: matricula || `ESOC-${Math.floor(10000 + Math.random() * 90000)}`,
        nomeCompleto: nomeCompleto.trim(),
        cpf: cpf.trim(),
        rg: rg.trim(),
        rgOrgaoEmissor,
        dataNascimento,
        sexo,
        estadoCivil,
        nomeMae: nomeMae.trim(),
        nomePai: nomePai.trim(),
        pisPasep: pisPasep.trim(),
        ctpsNumero: ctpsNumero.trim(),
        ctpsSerie: ctpsSerie.trim(),
        ctpsUf,
        email: email.trim(),
        telefone: telefone.trim(),
        whatsapp: whatsapp.trim(),
        cep: cep.trim(),
        logradouro: logradouro.trim(),
        numero: numero.trim(),
        complemento: complemento.trim(),
        bairro: bairro.trim(),
        cidade: cidade.trim(),
        uf,
        funcaoId,
        cargoNome: cargoNome.trim(),
        cbo: cbo.trim(),
        departamento: departamento.trim(),
        tipoContrato,
        regimeTrabalho,
        dataAdmissao,
        terminoExperiencia,
        salarioBase: Number(salarioBase),
        adicionaisTotal: Number(adicionaisTotal),
        status,
        bancoNome,
        bancoAgencia,
        bancoConta,
        chavePix,
        valeTransporte,
        valorVrVaMensal: Number(valorVrVaMensal),
        planoSaude,
        dependentes,
        periodoAquisitivoInicio,
        periodoAquisitivoFim,
        limiteConcessivoFerias,
        diasFeriasSaldo: Number(diasFeriasSaldo),
        dataUltimoAso,
        dataValidadeAso,
        observacoes: observacoes.trim(),
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Erro ao salvar colaborador');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-100 overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-8">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-800">
                {funcionarioToEdit ? 'Editar Colaborador' : 'Admissão & Cadastro de Colaborador'}
              </h2>
              <p className="text-xs text-slate-500">
                Ficha completa de registro de empregado conforme diretrizes do eSocial
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50/50 px-6 overflow-x-auto">
          {[
            { id: 'pessoal', label: '1. Pessoal & Contato', icon: User },
            { id: 'trabalhista', label: '2. Doc. Trabalhistas', icon: FileText },
            { id: 'contratual', label: '3. Contrato & Cargo', icon: Building },
            { id: 'financeiro', label: '4. Salário & Benefícios', icon: CreditCard },
            { id: 'dependentes', label: `5. Dependentes (${dependentes.length})`, icon: HeartHandshake },
            { id: 'sst', label: '6. Férias & SST', icon: Calendar },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`py-3 px-4 text-xs font-semibold whitespace-nowrap border-b-2 flex items-center gap-2 transition-colors ${
                  active
                    ? 'border-indigo-600 text-indigo-600 bg-white'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          {error && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-rose-700 text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* TAB 1: PESSOAL & CONTATO */}
          {activeTab === 'pessoal' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nome Completo <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={nomeCompleto}
                    onChange={(e) => setNomeCompleto(e.target.value)}
                    placeholder="Ex: Carlos Eduardo da Silva"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    CPF <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={cpf}
                    onChange={(e) => setCpf(e.target.value)}
                    placeholder="000.000.000-00"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">RG</label>
                  <input
                    type="text"
                    value={rg}
                    onChange={(e) => setRg(e.target.value)}
                    placeholder="00.000.000-0"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Órgão Emissor</label>
                  <input
                    type="text"
                    value={rgOrgaoEmissor}
                    onChange={(e) => setRgOrgaoEmissor(e.target.value)}
                    placeholder="SSP/SP"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Data de Nascimento</label>
                  <input
                    type="date"
                    value={dataNascimento}
                    onChange={(e) => setDataNascimento(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Sexo</label>
                  <select
                    value={sexo}
                    onChange={(e) => setSexo(e.target.value as any)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white"
                  >
                    <option value="M">Masculino</option>
                    <option value="F">Feminino</option>
                    <option value="Outro">Outro</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Estado Civil</label>
                  <select
                    value={estadoCivil}
                    onChange={(e) => setEstadoCivil(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white"
                  >
                    <option value="Solteiro(a)">Solteiro(a)</option>
                    <option value="Casado(a)">Casado(a)</option>
                    <option value="União Estável">União Estável</option>
                    <option value="Divorciado(a)">Divorciado(a)</option>
                    <option value="Viúvo(a)">Viúvo(a)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Nome da Mãe</label>
                  <input
                    type="text"
                    value={nomeMae}
                    onChange={(e) => setNomeMae(e.target.value)}
                    placeholder="Nome materno completo"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Nome do Pai</label>
                  <input
                    type="text"
                    value={nomePai}
                    onChange={(e) => setNomePai(e.target.value)}
                    placeholder="Nome paterno (opcional)"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 border-t border-slate-100">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">E-mail Corporativo/Pessoal</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="colaborador@empresa.com.br"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Telefone Fixo / Recado</label>
                  <input
                    type="text"
                    value={telefone}
                    onChange={(e) => setTelefone(e.target.value)}
                    placeholder="(11) 3321-0000"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Celular / WhatsApp</label>
                  <input
                    type="text"
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    placeholder="(11) 99999-9999"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              {/* Endereço */}
              <div className="pt-2 border-t border-slate-100">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Endereço Residencial</h4>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">CEP</label>
                    <input
                      type="text"
                      value={cep}
                      onChange={(e) => setCep(e.target.value)}
                      placeholder="00000-000"
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-xs font-medium text-slate-600 mb-1">Logradouro</label>
                    <input
                      type="text"
                      value={logradouro}
                      onChange={(e) => setLogradouro(e.target.value)}
                      placeholder="Rua, Avenida, Praça..."
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Número</label>
                    <input
                      type="text"
                      value={numero}
                      onChange={(e) => setNumero(e.target.value)}
                      placeholder="123"
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mt-2">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Complemento</label>
                    <input
                      type="text"
                      value={complemento}
                      onChange={(e) => setComplemento(e.target.value)}
                      placeholder="Apto 42, Bloco B"
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Bairro</label>
                    <input
                      type="text"
                      value={bairro}
                      onChange={(e) => setBairro(e.target.value)}
                      placeholder="Bairro"
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Cidade</label>
                    <input
                      type="text"
                      value={cidade}
                      onChange={(e) => setCidade(e.target.value)}
                      placeholder="São Paulo"
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">UF</label>
                    <input
                      type="text"
                      value={uf}
                      maxLength={2}
                      onChange={(e) => setUf(e.target.value.toUpperCase())}
                      placeholder="SP"
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg text-center"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: DOCUMENTOS TRABALHISTAS */}
          {activeTab === 'trabalhista' && (
            <div className="space-y-4">
              <div className="p-4 bg-indigo-50/60 border border-indigo-100 rounded-xl">
                <h4 className="text-xs font-bold text-indigo-900 uppercase tracking-wider mb-1">
                  Identificação Trabalhista & eSocial
                </h4>
                <p className="text-xs text-indigo-700">
                  Dados necessários para transmissão aos eventos do eSocial (S-2200 - Admissão)
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Matrícula Interna / eSocial
                  </label>
                  <input
                    type="text"
                    value={matricula}
                    onChange={(e) => setMatricula(e.target.value)}
                    placeholder="ESOC-00001"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Número PIS / PASEP / NIT
                  </label>
                  <input
                    type="text"
                    value={pisPasep}
                    onChange={(e) => setPisPasep(e.target.value)}
                    placeholder="000.00000.00-0"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Carteira de Trabalho (CTPS Física/Digital)
                  </label>
                  <input
                    type="text"
                    value={ctpsNumero}
                    onChange={(e) => setCtpsNumero(e.target.value)}
                    placeholder="Número da CTPS"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Série da CTPS</label>
                  <input
                    type="text"
                    value={ctpsSerie}
                    onChange={(e) => setCtpsSerie(e.target.value)}
                    placeholder="001"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">UF de Emissão da CTPS</label>
                  <input
                    type="text"
                    value={ctpsUf}
                    maxLength={2}
                    onChange={(e) => setCtpsUf(e.target.value.toUpperCase())}
                    placeholder="SP"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: CONTRATO & CARGO */}
          {activeTab === 'contratual' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Empresa Vinculada (Empregador) <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={empresaId}
                    onChange={(e) => setEmpresaId(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white"
                    required
                  >
                    <option value="">Selecione uma empresa...</option>
                    {empresas.map((emp) => (
                      <option key={emp.id} value={emp.id}>
                        {emp.razaoSocial} ({emp.cnpj})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Cargo / Função Pré-cadastrada
                  </label>
                  <select
                    value={funcaoId}
                    onChange={(e) => handleFuncaoChange(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white"
                  >
                    <option value="">Selecione um cargo pré-cadastrado...</option>
                    {funcoes
                      .filter((f) => f.empresaId === 'todas' || f.empresaId === empresaId)
                      .map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.titulo} (CBO: {f.cbo}) - {f.departamento}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Nome do Cargo Contratual <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={cargoNome}
                    onChange={(e) => setCargoNome(e.target.value)}
                    placeholder="Ex: Engenheiro de Software"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">CBO (Ocupação)</label>
                  <input
                    type="text"
                    value={cbo}
                    onChange={(e) => setCbo(e.target.value)}
                    placeholder="Ex: 2124-05"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Departamento</label>
                  <input
                    type="text"
                    value={departamento}
                    onChange={(e) => setDepartamento(e.target.value)}
                    placeholder="Ex: Tecnologia"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Tipo de Contrato</label>
                  <select
                    value={tipoContrato}
                    onChange={(e) => setTipoContrato(e.target.value as TipoContrato)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white"
                  >
                    <option value="CLT Indeterminado">CLT Indeterminado</option>
                    <option value="CLT Determinado">CLT Determinado</option>
                    <option value="PJ">Pessoa Jurídica (PJ)</option>
                    <option value="Estágio">Estágio (Lei 11.788/08)</option>
                    <option value="Jovem Aprendiz">Jovem Aprendiz</option>
                    <option value="Temporário">Temporário (Lei 6.019/74)</option>
                    <option value="Autônomo">Autônomo</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Regime de Trabalho</label>
                  <select
                    value={regimeTrabalho}
                    onChange={(e) => setRegimeTrabalho(e.target.value as RegimeTrabalho)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white"
                  >
                    <option value="presencial">Presencial</option>
                    <option value="hibrido">Híbrido</option>
                    <option value="remoto">100% Remoto (Home Office)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Status do Colaborador</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as StatusFuncionario)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white"
                  >
                    <option value="ativo">Ativo</option>
                    <option value="ferias">Em Gozo de Férias</option>
                    <option value="afastado">Afastado (INSS/Licença)</option>
                    <option value="desligado">Desligado / Rescindido</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Data de Admissão</label>
                  <input
                    type="date"
                    value={dataAdmissao}
                    onChange={(e) => setDataAdmissao(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Término do Período de Experiência</label>
                  <input
                    type="date"
                    value={terminoExperiencia}
                    onChange={(e) => setTerminoExperiencia(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: SALÁRIO & BENEFÍCIOS */}
          {activeTab === 'financeiro' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-emerald-50/50 border border-emerald-100 rounded-xl">
                  <label className="block text-xs font-bold text-emerald-900 uppercase tracking-wider mb-1">
                    Salário Base Mensal Contratual (R$) <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative mt-2">
                    <span className="absolute left-3 top-2 text-emerald-600 font-bold text-sm">R$</span>
                    <input
                      type="number"
                      step="0.01"
                      value={salarioBase}
                      onChange={(e) => setSalarioBase(Number(e.target.value))}
                      className="w-full pl-10 pr-3 py-2 text-base font-bold border border-emerald-300 rounded-lg focus:ring-2 focus:ring-emerald-500 bg-white"
                      required
                    />
                  </div>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Adicionais Salariais Fixos (Periculosidade / Insalubridade)
                  </label>
                  <div className="relative mt-2">
                    <span className="absolute left-3 top-2 text-slate-400 font-bold text-sm">R$</span>
                    <input
                      type="number"
                      step="0.01"
                      value={adicionaisTotal}
                      onChange={(e) => setAdicionaisTotal(Number(e.target.value))}
                      className="w-full pl-10 pr-3 py-2 text-base font-semibold border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* Benefícios */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Benefícios Corporativos</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
                    <input
                      type="checkbox"
                      checked={valeTransporte}
                      onChange={(e) => setValeTransporte(e.target.checked)}
                      className="w-4 h-4 rounded text-indigo-600"
                    />
                    <span>Optante Vale Transporte (Desconto de 6% CLT)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
                    <input
                      type="checkbox"
                      checked={planoSaude}
                      onChange={(e) => setPlanoSaude(e.target.checked)}
                      className="w-4 h-4 rounded text-indigo-600"
                    />
                    <span>Plano de Saúde e Odontológico</span>
                  </label>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Auxílio Alimentação / Refeição (R$)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={valorVrVaMensal}
                      onChange={(e) => setValorVrVaMensal(Number(e.target.value))}
                      className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* Dados Bancários */}
              <div className="pt-2 border-t border-slate-100">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Dados Bancários para Depósito de Salário
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Banco</label>
                    <input
                      type="text"
                      value={bancoNome}
                      onChange={(e) => setBancoNome(e.target.value)}
                      placeholder="Ex: Itaú, Bradesco..."
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Agência</label>
                    <input
                      type="text"
                      value={bancoAgencia}
                      onChange={(e) => setBancoAgencia(e.target.value)}
                      placeholder="0000"
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Conta com Dígito</label>
                    <input
                      type="text"
                      value={bancoConta}
                      onChange={(e) => setBancoConta(e.target.value)}
                      placeholder="00000-0"
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Chave Pix</label>
                    <input
                      type="text"
                      value={chavePix}
                      onChange={(e) => setChavePix(e.target.value)}
                      placeholder="CPF, E-mail ou Telefone"
                      className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: DEPENDENTES */}
          {activeTab === 'dependentes' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-800">Dependentes Legais</h4>
                  <p className="text-xs text-slate-500">
                    Utilizados para dedução legal na apuração de IRRF (R$ 189,59/mês cada) e Salário-Família
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleAddDependente}
                  className="px-3 py-1.5 text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg flex items-center gap-1.5 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>Adicionar Dependente</span>
                </button>
              </div>

              {dependentes.length === 0 ? (
                <div className="py-8 text-center border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                  <HeartHandshake className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-sm text-slate-600 font-medium">Nenhum dependente cadastrado.</p>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Clique no botão acima para adicionar filhos, cônjuges ou tutelados.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {dependentes.map((dep, idx) => (
                    <div
                      key={dep.id || idx}
                      className="p-4 border border-slate-200 rounded-xl bg-slate-50/60 grid grid-cols-1 md:grid-cols-6 gap-3 items-center"
                    >
                      <div className="md:col-span-2">
                        <label className="block text-xs font-medium text-slate-600 mb-1">Nome do Dependente</label>
                        <input
                          type="text"
                          value={dep.nome}
                          onChange={(e) => handleUpdateDependente(idx, 'nome', e.target.value)}
                          placeholder="Nome completo"
                          className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-600 mb-1">Parentesco</label>
                        <select
                          value={dep.parentesco}
                          onChange={(e) => handleUpdateDependente(idx, 'parentesco', e.target.value)}
                          className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                        >
                          <option value="Filho(a)">Filho(a)</option>
                          <option value="Cônjuge">Cônjuge</option>
                          <option value="Companheiro(a)">Companheiro(a)</option>
                          <option value="Pai/Mãe">Pai/Mãe</option>
                          <option value="Outro">Outro</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-600 mb-1">CPF</label>
                        <input
                          type="text"
                          value={dep.cpf}
                          onChange={(e) => handleUpdateDependente(idx, 'cpf', e.target.value)}
                          placeholder="000.000.000-00"
                          className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                        />
                      </div>

                      <div className="flex items-center gap-3">
                        <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={dep.deducaoIrrf}
                            onChange={(e) => handleUpdateDependente(idx, 'deducaoIrrf', e.target.checked)}
                            className="w-3.5 h-3.5 rounded text-indigo-600"
                          />
                          <span>Dedução IRRF</span>
                        </label>
                      </div>

                      <div className="flex justify-end">
                        <button
                          type="button"
                          onClick={() => handleRemoveDependente(idx)}
                          className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                          title="Remover"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 6: FÉRIAS & SST */}
          {activeTab === 'sst' && (
            <div className="space-y-4">
              <div className="p-4 bg-amber-50/60 border border-amber-100 rounded-xl space-y-3">
                <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wider">
                  Controle do Período Aquisitivo de Férias
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Início Período Aquisitivo</label>
                    <input
                      type="date"
                      value={periodoAquisitivoInicio}
                      onChange={(e) => setPeriodoAquisitivoInicio(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Fim Período Aquisitivo</label>
                    <input
                      type="date"
                      value={periodoAquisitivoFim}
                      onChange={(e) => setPeriodoAquisitivoFim(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Limite Concessivo</label>
                    <input
                      type="date"
                      value={limiteConcessivoFerias}
                      onChange={(e) => setLimiteConcessivoFerias(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Saldo em Dias</label>
                    <input
                      type="number"
                      value={diasFeriasSaldo}
                      onChange={(e) => setDiasFeriasSaldo(Number(e.target.value))}
                      className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* SST / Medicina do Trabalho */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Saúde e Segurança do Trabalho (SST / PCMSO / NR-7)
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Data do Último ASO Realizado</label>
                    <input
                      type="date"
                      value={dataUltimoAso}
                      onChange={(e) => setDataUltimoAso(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Data de Validade do ASO</label>
                    <input
                      type="date"
                      value={dataValidadeAso}
                      onChange={(e) => setDataValidadeAso(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Observações Internas / Prontuário</label>
                <textarea
                  rows={2}
                  value={observacoes}
                  onChange={(e) => setObservacoes(e.target.value)}
                  placeholder="Informações adicionais, anotações de RH ou histórico funcional..."
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg resize-none"
                />
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-between pt-6 mt-6 border-t border-slate-100">
            <div className="flex gap-2">
              {activeTab !== 'pessoal' && (
                <button
                  type="button"
                  onClick={() => {
                    const tabs: TabType[] = ['pessoal', 'trabalhista', 'contratual', 'financeiro', 'dependentes', 'sst'];
                    const curIdx = tabs.indexOf(activeTab);
                    if (curIdx > 0) setActiveTab(tabs[curIdx - 1]);
                  }}
                  className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  ← Aba Anterior
                </button>
              )}
              {activeTab !== 'sst' && (
                <button
                  type="button"
                  onClick={() => {
                    const tabs: TabType[] = ['pessoal', 'trabalhista', 'contratual', 'financeiro', 'dependentes', 'sst'];
                    const curIdx = tabs.indexOf(activeTab);
                    if (curIdx < tabs.length - 1) setActiveTab(tabs[curIdx + 1]);
                  }}
                  className="px-3 py-1.5 text-xs font-medium text-indigo-600 hover:bg-indigo-50 rounded-lg"
                >
                  Próxima Aba →
                </button>
              )}
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-6 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm flex items-center gap-2 transition-colors disabled:opacity-50"
              >
                <Check className="w-4 h-4" />
                <span>{saving ? 'Gravando...' : 'Salvar Colaborador'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
