import React, { useState, useEffect } from 'react';
import { X, Briefcase, DollarSign, Check, AlertCircle } from 'lucide-react';
import { FuncaoRH, Empresa, NivelCargo, GrauInsalubridade } from '../../types';

interface FuncaoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (funcao: Omit<FuncaoRH, 'id' | 'isDemo'>) => Promise<void>;
  funcaoToEdit?: FuncaoRH | null;
  empresas: Empresa[];
  selectedEmpresaId?: string;
}

const NIVEIS_CARGO: NivelCargo[] = [
  'Estagiário',
  'Júnior',
  'Pleno',
  'Sênior',
  'Especialista',
  'Coordenação',
  'Gerência',
  'Diretoria',
];

const GRAUS_INSALUBRIDADE: { value: GrauInsalubridade; label: string }[] = [
  { value: 'nenhum', label: 'Nenhum Adicional' },
  { value: 'grau_minimo', label: 'Grau Mínimo (10% SM)' },
  { value: 'grau_medio', label: 'Grau Médio (20% SM)' },
  { value: 'grau_maximo', label: 'Grau Máximo (40% SM)' },
];

export const FuncaoModal: React.FC<FuncaoModalProps> = ({
  isOpen,
  onClose,
  onSave,
  funcaoToEdit,
  empresas,
  selectedEmpresaId,
}) => {
  const [empresaId, setEmpresaId] = useState('todas');
  const [titulo, setTitulo] = useState('');
  const [cbo, setCbo] = useState('');
  const [departamento, setDepartamento] = useState('');
  const [salarioBase, setSalarioBase] = useState<number>(3000);
  const [cargaHorariaSemanal, setCargaHorariaSemanal] = useState<number>(40);
  const [nivel, setNivel] = useState<NivelCargo>('Pleno');
  const [descricao, setDescricao] = useState('');
  const [requisitos, setRequisitos] = useState('');
  const [adicionalPericulosidade, setAdicionalPericulosidade] = useState(false);
  const [adicionalInsalubridade, setAdicionalInsalubridade] = useState<GrauInsalubridade>('nenhum');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (funcaoToEdit) {
      setEmpresaId(funcaoToEdit.empresaId || 'todas');
      setTitulo(funcaoToEdit.titulo || '');
      setCbo(funcaoToEdit.cbo || '');
      setDepartamento(funcaoToEdit.departamento || '');
      setSalarioBase(funcaoToEdit.salarioBase || 0);
      setCargaHorariaSemanal(funcaoToEdit.cargaHorariaSemanal || 40);
      setNivel(funcaoToEdit.nivel || 'Pleno');
      setDescricao(funcaoToEdit.descricao || '');
      setRequisitos(funcaoToEdit.requisitos || '');
      setAdicionalPericulosidade(Boolean(funcaoToEdit.adicionalPericulosidade));
      setAdicionalInsalubridade(funcaoToEdit.adicionalInsalubridade || 'nenhum');
    } else {
      setEmpresaId(selectedEmpresaId && selectedEmpresaId !== 'todas' ? selectedEmpresaId : 'todas');
      setTitulo('');
      setCbo('');
      setDepartamento('');
      setSalarioBase(3500);
      setCargaHorariaSemanal(44);
      setNivel('Pleno');
      setDescricao('');
      setRequisitos('');
      setAdicionalPericulosidade(false);
      setAdicionalInsalubridade('nenhum');
    }
    setError(null);
  }, [funcaoToEdit, selectedEmpresaId, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!titulo.trim()) {
      setError('O título da função/cargo é obrigatório.');
      return;
    }
    if (!cbo.trim()) {
      setError('O código CBO é obrigatório.');
      return;
    }
    if (!departamento.trim()) {
      setError('O departamento é obrigatório.');
      return;
    }

    try {
      setSaving(true);
      setError(null);
      await onSave({
        empresaId,
        titulo: titulo.trim(),
        cbo: cbo.trim(),
        departamento: departamento.trim(),
        salarioBase: Number(salarioBase),
        cargaHorariaSemanal: Number(cargaHorariaSemanal),
        nivel,
        descricao: descricao.trim(),
        requisitos: requisitos.trim(),
        adicionalPericulosidade,
        adicionalInsalubridade,
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Erro ao salvar função');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-100 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-800">
                {funcaoToEdit ? 'Editar Função / Cargo' : 'Nova Função / Cargo'}
              </h2>
              <p className="text-xs text-slate-500">
                Cadastro estruturado de cargos, CBO e adicionais da empresa
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-rose-700 text-sm">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Empresa Vinculada</label>
              <select
                value={empresaId}
                onChange={(e) => setEmpresaId(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="todas">Disponível para Todas as Empresas</option>
                {empresas.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.razaoSocial}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Nível Hierárquico</label>
              <select
                value={nivel}
                onChange={(e) => setNivel(e.target.value as NivelCargo)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {NIVEIS_CARGO.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Título do Cargo / Função <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={titulo}
                onChange={(e) => setTitulo(e.target.value)}
                placeholder="Ex: Desenvolvedor Full Stack Pleno"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Código CBO <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={cbo}
                onChange={(e) => setCbo(e.target.value)}
                placeholder="Ex: 2124-05"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Departamento / Setor <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={departamento}
                onChange={(e) => setDepartamento(e.target.value)}
                placeholder="Ex: Tecnologia da Informação"
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Salário Base Padrão (R$)</label>
              <div className="relative">
                <span className="absolute left-3 top-2 text-slate-400 text-xs font-bold">R$</span>
                <input
                  type="number"
                  step="0.01"
                  value={salarioBase}
                  onChange={(e) => setSalarioBase(Number(e.target.value))}
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Carga Horária Semanal</label>
              <div className="relative">
                <input
                  type="number"
                  value={cargaHorariaSemanal}
                  onChange={(e) => setCargaHorariaSemanal(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <span className="absolute right-3 top-2 text-slate-400 text-xs">horas</span>
              </div>
            </div>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Adicionais Legais (CLT)</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 items-center">
              <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
                <input
                  type="checkbox"
                  checked={adicionalPericulosidade}
                  onChange={(e) => setAdicionalPericulosidade(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span>Adicional de Periculosidade (30% sobre salário)</span>
              </label>

              <div>
                <select
                  value={adicionalInsalubridade}
                  onChange={(e) => setAdicionalInsalubridade(e.target.value as GrauInsalubridade)}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                >
                  {GRAUS_INSALUBRIDADE.map((g) => (
                    <option key={g.value} value={g.value}>
                      {g.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Descrição Sumária das Atividades</label>
            <textarea
              rows={2}
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              placeholder="Principais responsabilidades, atribuições e rotinas do cargo..."
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Requisitos & Competências</label>
            <textarea
              rows={2}
              value={requisitos}
              onChange={(e) => setRequisitos(e.target.value)}
              placeholder="Escolaridade, cursos técnicos, registros profissionais (CREA, CRM, CRN) ou certificações..."
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm flex items-center gap-2 transition-colors disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>{saving ? 'Salvando...' : 'Salvar Função'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
