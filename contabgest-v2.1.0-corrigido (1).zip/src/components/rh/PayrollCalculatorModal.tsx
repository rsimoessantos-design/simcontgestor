import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Calculator,
  DollarSign,
  TrendingDown,
  TrendingUp,
  ShieldAlert,
  Percent,
  HelpCircle,
  CheckCircle2,
  FileText,
  User,
  Clock,
  Award,
  AlertCircle,
} from 'lucide-react';
import { Funcionario, HoleriteCalculado } from '../../types';
import {
  calcularFolhaCompleta,
  ParametrosCalculoFolha,
  SALARIO_MINIMO_NACIONAL,
  TETO_INSS,
  TETO_VALOR_INSS,
  DEDUCAO_DEPENDENTE_IRRF,
  DESCONTO_SIMPLIFICADO_IRRF,
} from '../../utils/payrollCalculator';

interface PayrollCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  funcionarios: Funcionario[];
  initialFuncionario?: Funcionario | null;
  competencia: string;
  onApplyCalculation?: (calc: HoleriteCalculado, func: Funcionario) => void;
  onOpenHoleriteModal?: (calc: HoleriteCalculado, func: Funcionario) => void;
}

export const PayrollCalculatorModal: React.FC<PayrollCalculatorModalProps> = ({
  isOpen,
  onClose,
  funcionarios,
  initialFuncionario,
  competencia,
  onApplyCalculation,
  onOpenHoleriteModal,
}) => {
  const [selectedFuncId, setSelectedFuncId] = useState<string>(initialFuncionario?.id || '');

  // Form parameters
  const [salarioBase, setSalarioBase] = useState<number>(initialFuncionario?.salarioBase || 3500);
  const [horasExtras50, setHorasExtras50] = useState<number>(0);
  const [horasExtras100, setHorasExtras100] = useState<number>(0);
  const [horasNoturnas, setHorasNoturnas] = useState<number>(0);
  const [grauInsalubridade, setGrauInsalubridade] = useState<'nenhum' | 'minimo' | 'medio' | 'maximo'>('nenhum');
  const [adicionalPericulosidade, setAdicionalPericulosidade] = useState<boolean>(false);
  const [comissoes, setComissoes] = useState<number>(0);
  const [outrosProventos, setOutrosProventos] = useState<number>(0);
  const [faltasDias, setFaltasDias] = useState<number>(0);
  const [atrasosHoras, setAtrasosHoras] = useState<number>(0);
  const [valeTransporte, setValeTransporte] = useState<boolean>(false);
  const [copartVr, setCopartVr] = useState<number>(0);
  const [copartSaude, setCopartSaude] = useState<number>(0);
  const [adiantamentoSalarial, setAdiantamentoSalarial] = useState<number>(0);
  const [dependentesQtd, setDependentesQtd] = useState<number>(0);
  const [pensaoAlimenticia, setPensaoAlimenticia] = useState<number>(0);
  const [outrosDescontos, setOutrosDescontos] = useState<number>(0);

  // Tab de visualização da memória
  const [activeSubTab, setActiveSubTab] = useState<'resumo' | 'inss' | 'irrf' | 'encargos'>('resumo');

  // Load employee defaults when selected
  useEffect(() => {
    if (selectedFuncId) {
      const func = funcionarios.find((f) => f.id === selectedFuncId);
      if (func) {
        setSalarioBase(func.salarioBase || 0);
        setValeTransporte(Boolean(func.valeTransporte));
        const deps = (func.dependentes || []).filter((d) => d.deducaoIrrf).length;
        setDependentesQtd(deps);
        if (func.adicionaisTotal && func.adicionaisTotal > 0) {
          setComissoes(func.adicionaisTotal);
        }
      }
    }
  }, [selectedFuncId, funcionarios]);

  useEffect(() => {
    if (initialFuncionario) {
      setSelectedFuncId(initialFuncionario.id);
      setSalarioBase(initialFuncionario.salarioBase || 0);
      setValeTransporte(Boolean(initialFuncionario.valeTransporte));
      const deps = (initialFuncionario.dependentes || []).filter((d) => d.deducaoIrrf).length;
      setDependentesQtd(deps);
    }
  }, [initialFuncionario]);

  const currentFuncionario = useMemo(() => {
    return funcionarios.find((f) => f.id === selectedFuncId) || initialFuncionario || null;
  }, [selectedFuncId, funcionarios, initialFuncionario]);

  // Execute comprehensive calculation
  const resultado = useMemo(() => {
    const params: ParametrosCalculoFolha = {
      funcionario: currentFuncionario || undefined,
      competencia,
      salarioBase,
      horasExtras50Horas: horasExtras50,
      horasExtras100Horas: horasExtras100,
      adicionalNoturnoHoras: horasNoturnas,
      grauInsalubridade,
      adicionalPericulosidade,
      comissoesGratificacoes: comissoes,
      outrosProventos,
      faltasDias,
      atrasosHoras,
      valeTransporteOptante: valeTransporte,
      valeRefeicaoCoparticipacao: copartVr,
      planoSaudeCoparticipacao: copartSaude,
      adiantamentoSalarial,
      dependentesIrrf: dependentesQtd,
      pensaoAlimenticia,
      outrosDescontos,
    };
    return calcularFolhaCompleta(params);
  }, [
    currentFuncionario,
    competencia,
    salarioBase,
    horasExtras50,
    horasExtras100,
    horasNoturnas,
    grauInsalubridade,
    adicionalPericulosidade,
    comissoes,
    outrosProventos,
    faltasDias,
    atrasosHoras,
    valeTransporte,
    copartVr,
    copartSaude,
    adiantamentoSalarial,
    dependentesQtd,
    pensaoAlimenticia,
    outrosDescontos,
  ]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-4 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-600 text-white rounded-xl shadow-xs">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Calculadora & Simulador Salarial (INSS / IRRF / FGTS)
              </h2>
              <p className="text-xs text-slate-500">
                Competência: <span className="font-semibold text-indigo-600">{competencia}</span> •
                Cálculo em conformidade com as regras vigentes da CLT e Receita Federal
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Input Form (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            {/* Employee Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Colaborador Cadastrado:
              </label>
              <select
                value={selectedFuncId}
                onChange={(e) => setSelectedFuncId(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500 font-medium"
              >
                <option value="">-- Simulação Livre (Sem Colaborador) --</option>
                {funcionarios
                  .filter((f) => f.status !== 'desligado')
                  .map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.nomeCompleto} ({f.cargoNome} - R$ {f.salarioBase.toFixed(2)})
                    </option>
                  ))}
              </select>
            </div>

            {/* Base Salary */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Salário Base Contratual (R$):
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2 text-xs font-bold text-slate-400">R$</span>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={salarioBase}
                  onChange={(e) => setSalarioBase(Number(e.target.value))}
                  className="w-full pl-9 pr-3 py-2 text-sm font-bold text-slate-900 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Proventos Adicionais Accordion/Block */}
            <div className="border border-slate-200 rounded-xl p-3 bg-slate-50/50 space-y-3">
              <h4 className="text-xs font-bold text-emerald-800 uppercase flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Horas Extras & Proventos do Mês</span>
              </h4>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block">Horas Extras 50%:</label>
                  <input
                    type="number"
                    min="0"
                    step="0.5"
                    value={horasExtras50}
                    onChange={(e) => setHorasExtras50(Number(e.target.value))}
                    placeholder="Qtd horas"
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block">Horas Extras 100%:</label>
                  <input
                    type="number"
                    min="0"
                    step="0.5"
                    value={horasExtras100}
                    onChange={(e) => setHorasExtras100(Number(e.target.value))}
                    placeholder="Qtd horas"
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block">Adic. Noturno (Horas):</label>
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={horasNoturnas}
                    onChange={(e) => setHorasNoturnas(Number(e.target.value))}
                    placeholder="Qtd horas 22h-5h"
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block">Insalubridade:</label>
                  <select
                    value={grauInsalubridade}
                    onChange={(e) => setGrauInsalubridade(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white"
                  >
                    <option value="nenhum">Nenhum</option>
                    <option value="minimo">Mínimo (10% - R$ 141,20)</option>
                    <option value="medio">Médio (20% - R$ 282,40)</option>
                    <option value="maximo">Máximo (40% - R$ 564,80)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 items-center">
                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block">Comissões / Bônus (R$):</label>
                  <input
                    type="number"
                    min="0"
                    step="50"
                    value={comissoes}
                    onChange={(e) => setComissoes(Number(e.target.value))}
                    placeholder="R$ 0,00"
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white"
                  />
                </div>

                <div className="pt-3">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-700">
                    <input
                      type="checkbox"
                      checked={adicionalPericulosidade}
                      onChange={(e) => setAdicionalPericulosidade(e.target.checked)}
                      className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
                    />
                    <span>Periculosidade (30%)</span>
                  </label>
                </div>
              </div>
            </div>

            {/* Descontos e Benefícios Accordion/Block */}
            <div className="border border-slate-200 rounded-xl p-3 bg-slate-50/50 space-y-3">
              <h4 className="text-xs font-bold text-rose-800 uppercase flex items-center gap-1.5">
                <TrendingDown className="w-3.5 h-3.5" />
                <span>Descontos, Deduções & Benefícios</span>
              </h4>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block">Dependentes IRRF:</label>
                  <input
                    type="number"
                    min="0"
                    max="15"
                    value={dependentesQtd}
                    onChange={(e) => setDependentesQtd(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white"
                  />
                  <span className="text-[10px] text-slate-400">R$ 189,59 cada</span>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block">Pensão Alimentícia (R$):</label>
                  <input
                    type="number"
                    min="0"
                    step="50"
                    value={pensaoAlimenticia}
                    onChange={(e) => setPensaoAlimenticia(Number(e.target.value))}
                    placeholder="R$ 0,00"
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block">Faltas Injustificadas (dias):</label>
                  <input
                    type="number"
                    min="0"
                    max="30"
                    value={faltasDias}
                    onChange={(e) => setFaltasDias(Number(e.target.value))}
                    placeholder="Dias"
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block">Adiantamento / Vale (R$):</label>
                  <input
                    type="number"
                    min="0"
                    step="50"
                    value={adiantamentoSalarial}
                    onChange={(e) => setAdiantamentoSalarial(Number(e.target.value))}
                    placeholder="R$ 0,00"
                    className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md bg-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-700">
                  <input
                    type="checkbox"
                    checked={valeTransporte}
                    onChange={(e) => setValeTransporte(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
                  />
                  <span>Descontar Vale Transporte (6%)</span>
                </label>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Breakdown & Math Memory (7 cols) */}
          <div className="lg:col-span-7 space-y-4 flex flex-col justify-between">
            {/* Top Result KPI Header */}
            <div className="bg-slate-900 text-white rounded-xl p-4 shadow-md">
              <div className="grid grid-cols-3 gap-3 text-center divide-x divide-slate-800">
                <div>
                  <span className="text-[11px] text-slate-400 block uppercase font-medium">Total Bruto</span>
                  <p className="text-xl font-bold text-emerald-400 mt-0.5">
                    {resultado.totalProventos.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </p>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block uppercase font-medium">Total Descontos</span>
                  <p className="text-xl font-bold text-rose-400 mt-0.5">
                    {resultado.totalDescontos.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </p>
                </div>
                <div>
                  <span className="text-[11px] text-indigo-300 block uppercase font-bold">Salário Líquido</span>
                  <p className="text-2xl font-black text-white mt-0.5">
                    {resultado.salarioLiquido.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                  </p>
                </div>
              </div>
            </div>

            {/* Sub Tabs for Calculation Memory */}
            <div className="flex border-b border-slate-200 text-xs font-semibold">
              <button
                onClick={() => setActiveSubTab('resumo')}
                className={`py-2 px-3 border-b-2 transition-colors ${
                  activeSubTab === 'resumo'
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                Itens do Holerite ({resultado.itens.length})
              </button>
              <button
                onClick={() => setActiveSubTab('inss')}
                className={`py-2 px-3 border-b-2 transition-colors flex items-center gap-1 ${
                  activeSubTab === 'inss'
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <span>INSS Progressivo</span>
                <span className="px-1.5 py-0.2 text-[10px] bg-indigo-50 text-indigo-700 rounded-full font-bold">
                  {resultado.memoriaInss.aliquotaEfetiva.toFixed(2)}%
                </span>
              </button>
              <button
                onClick={() => setActiveSubTab('irrf')}
                className={`py-2 px-3 border-b-2 transition-colors flex items-center gap-1 ${
                  activeSubTab === 'irrf'
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <span>IRRF na Fonte</span>
                <span className="px-1.5 py-0.2 text-[10px] bg-rose-50 text-rose-700 rounded-full font-bold">
                  {resultado.memoriaIrrf.isento ? 'Isento' : `${resultado.memoriaIrrf.aliquotaNominal}%`}
                </span>
              </button>
              <button
                onClick={() => setActiveSubTab('encargos')}
                className={`py-2 px-3 border-b-2 transition-colors ${
                  activeSubTab === 'encargos'
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                Encargos & Custo Empresa
              </button>
            </div>

            {/* TAB CONTENT */}
            <div className="flex-1 bg-white border border-slate-200 rounded-xl p-4 min-h-[260px] overflow-y-auto">
              {/* 1. Resumo dos Itens do Holerite */}
              {activeSubTab === 'resumo' && (
                <div className="space-y-3">
                  <table className="w-full text-xs text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase text-[10px]">
                        <th className="py-2">Cód.</th>
                        <th className="py-2">Descrição da Rubrica</th>
                        <th className="py-2 text-right">Referência</th>
                        <th className="py-2 text-right text-emerald-700">Provento (R$)</th>
                        <th className="py-2 text-right text-rose-700">Desconto (R$)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {resultado.itens.map((item, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="py-2 font-mono text-slate-400">{item.codigo}</td>
                          <td className="py-2 font-medium text-slate-800">{item.descricao}</td>
                          <td className="py-2 text-right text-slate-500">{item.referencia}</td>
                          <td className="py-2 text-right font-semibold text-emerald-700">
                            {item.tipo === 'provento'
                              ? item.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })
                              : '-'}
                          </td>
                          <td className="py-2 text-right font-semibold text-rose-700">
                            {item.tipo === 'desconto'
                              ? item.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })
                              : '-'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* 2. Memória de Cálculo do INSS */}
              {activeSubTab === 'inss' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between bg-indigo-50 p-3 rounded-lg border border-indigo-100">
                    <div>
                      <p className="text-xs font-bold text-indigo-950">
                        Base de Incidência INSS: {resultado.baseInss.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </p>
                      <p className="text-[11px] text-indigo-700">
                        Alíquota Efetiva: <span className="font-bold">{resultado.memoriaInss.aliquotaEfetivaTexto}</span>
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-500 uppercase block font-semibold">Total Recolhido</span>
                      <span className="text-base font-black text-indigo-700">
                        {resultado.valorInss.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="text-xs font-bold text-slate-700">
                      Detalhamento Progressivo por Faixa Salarial:
                    </p>
                    {resultado.memoriaInss.faixas.map((fx) => (
                      <div
                        key={fx.faixaNumero}
                        className={`p-2.5 rounded-lg border text-xs flex items-center justify-between ${
                          fx.baseTributada > 0
                            ? 'bg-slate-50 border-indigo-200 text-slate-900'
                            : 'bg-white border-slate-100 text-slate-400 opacity-60'
                        }`}
                      >
                        <div>
                          <span className="font-bold block">{fx.descricao}</span>
                          <span className="text-[11px]">
                            Base na faixa: {fx.baseTributada.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-[11px] text-slate-500 block">{(fx.aliquota * 100).toFixed(1)}%</span>
                          <span className="font-bold text-slate-800">
                            {fx.valorContribuicao.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 3. Memória de Cálculo do IRRF */}
              {activeSubTab === 'irrf' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                      <span className="text-[11px] font-bold text-slate-500 uppercase block">Opção Deduções Legais</span>
                      <p className="text-sm font-semibold text-slate-800 mt-1">
                        Base: {resultado.memoriaIrrf.baseCalculoLegal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        (-) INSS: R$ {resultado.memoriaIrrf.deducaoInss.toFixed(2)}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        (-) {dependentesQtd} dependente(s): R$ {resultado.memoriaIrrf.deducaoDependentes.toFixed(2)}
                      </p>
                      {pensaoAlimenticia > 0 && (
                        <p className="text-[11px] text-slate-500">
                          (-) Pensão: R$ {pensaoAlimenticia.toFixed(2)}
                        </p>
                      )}
                    </div>

                    <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                      <span className="text-[11px] font-bold text-slate-500 uppercase block">Opção Desconto Simplificado</span>
                      <p className="text-sm font-semibold text-slate-800 mt-1">
                        Base: {resultado.memoriaIrrf.baseCalculoSimplificado.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        (-) Dedução padrão: R$ {DESCONTO_SIMPLIFICADO_IRRF.toFixed(2)}
                      </p>
                      <div className="mt-2">
                        {resultado.memoriaIrrf.opcaoMaisVantajosa === 'simplificada' ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3" /> Aplicado (Mais Vantajoso)
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                            Deduções Legais Mais Vantajosas
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-rose-50/70 border border-rose-200 rounded-lg text-xs flex justify-between items-center">
                    <div>
                      <p className="font-bold text-rose-950">
                        Faixa Aplicada: {resultado.memoriaIrrf.faixaNominal}
                      </p>
                      <p className="text-[11px] text-rose-800">
                        Parcela a deduzir oficial: R$ {resultado.memoriaIrrf.parcelaADeduzir.toFixed(2)}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-500 uppercase block font-semibold">IRRF Retido</span>
                      <span className="text-base font-black text-rose-700">
                        {resultado.valorIrrf.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* 4. Encargos da Empresa */}
              {activeSubTab === 'encargos' && (
                <div className="space-y-3 text-xs">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                      <span className="text-slate-500 block text-[11px]">FGTS Mensal (8%):</span>
                      <span className="font-bold text-indigo-600 text-sm">
                        {resultado.valorFgts.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </span>
                    </div>
                    <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                      <span className="text-slate-500 block text-[11px]">INSS Patronal (CPP 20%):</span>
                      <span className="font-bold text-slate-800 text-sm">
                        {resultado.encargosEmpresa.inssPatronal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </span>
                    </div>
                    <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                      <span className="text-slate-500 block text-[11px]">RAT / FAP (2% est.):</span>
                      <span className="font-bold text-slate-800 text-sm">
                        {resultado.encargosEmpresa.ratFap.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </span>
                    </div>
                    <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
                      <span className="text-slate-500 block text-[11px]">Sistema S / Terceiros (5,8%):</span>
                      <span className="font-bold text-slate-800 text-sm">
                        {resultado.encargosEmpresa.terceirosSistemaS.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </span>
                    </div>
                  </div>

                  <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl flex items-center justify-between">
                    <div>
                      <p className="font-bold text-indigo-950">Custo Total Empresa:</p>
                      <p className="text-[11px] text-indigo-700">Salário + Encargos Sociais Diretos</p>
                    </div>
                    <p className="text-lg font-black text-indigo-800">
                      {resultado.encargosEmpresa.custoTotalColaborador.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Actions */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-200">
              <div className="text-xs text-slate-500">
                {currentFuncionario ? (
                  <span>
                    Simulando para: <strong className="text-slate-800">{currentFuncionario.nomeCompleto}</strong>
                  </span>
                ) : (
                  <span>Modo Simulação Livre</span>
                )}
              </div>

              <div className="flex items-center gap-2">
                {currentFuncionario && onOpenHoleriteModal && (
                  <button
                    type="button"
                    onClick={() => {
                      onOpenHoleriteModal(resultado, currentFuncionario);
                    }}
                    className="px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 border border-slate-300 rounded-lg flex items-center gap-1.5 transition-colors"
                  >
                    <FileText className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Visualizar Holerite</span>
                  </button>
                )}

                {currentFuncionario && onApplyCalculation && (
                  <button
                    type="button"
                    onClick={() => {
                      onApplyCalculation(resultado, currentFuncionario);
                      onClose();
                    }}
                    className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs flex items-center gap-1.5 transition-colors"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Salvar e Lançar na Folha</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
