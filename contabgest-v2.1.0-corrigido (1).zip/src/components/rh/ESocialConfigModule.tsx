import React, { useState, useEffect } from 'react';
import {
  Settings2,
  CheckCircle2,
  AlertTriangle,
  Send,
  Download,
  FileCode2,
  RefreshCw,
  Building2,
  ShieldAlert,
  ShieldCheck,
  Calendar,
  Lock,
  Unlock,
  Coins,
  Receipt,
  FileCheck,
  Eye,
  X,
  Copy,
  ExternalLink,
} from 'lucide-react';
import {
  Empresa,
  ESocialConfiguracao,
  EventoESocialRegistro,
  FechamentoFolhaESocialPainel,
  InconsistenciaValidacaoESocial,
} from '../../types';
import { api } from '../../services/api';

interface ESocialConfigModuleProps {
  empresas: Empresa[];
  empresaSelecionadaId: string;
}

export const ESocialConfigModule: React.FC<ESocialConfigModuleProps> = ({
  empresas,
  empresaSelecionadaId,
}) => {
  const [empresaId, setEmpresaId] = useState<string>(
    empresaSelecionadaId && empresaSelecionadaId !== 'todas'
      ? empresaSelecionadaId
      : empresas[0]?.id || 'emp_1'
  );
  const [competencia, setCompetencia] = useState<string>('09/2026');
  const [subTab, setSubTab] = useState<'parametros' | 'validacao' | 'fechamento' | 'eventos'>('fechamento');

  // Dados da API
  const [config, setConfig] = useState<ESocialConfiguracao | null>(null);
  const [painel, setPainel] = useState<FechamentoFolhaESocialPainel | null>(null);
  const [eventos, setEventos] = useState<EventoESocialRegistro[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [savingConfig, setSavingConfig] = useState<boolean>(false);
  const [validating, setValidating] = useState<boolean>(false);
  const [submittingFechamento, setSubmittingFechamento] = useState<boolean>(false);
  const [reopening, setReopening] = useState<boolean>(false);

  // Mensagens e feedbacks
  const [feedbackMessage, setFeedbackMessage] = useState<{
    tipo: 'sucesso' | 'erro' | 'info';
    texto: string;
  } | null>(null);

  // Modal para prévia de XML / Inconsistências
  const [modalXml, setModalXml] = useState<{
    titulo: string;
    xml: string;
    eventoId: string;
  } | null>(null);

  const [modalInconsistencia, setModalInconsistencia] = useState<{
    colaborador?: string;
    inconsistencias: InconsistenciaValidacaoESocial[];
  } | null>(null);

  // Sincroniza empresa selecionada do pai se mudar
  useEffect(() => {
    if (empresaSelecionadaId && empresaSelecionadaId !== 'todas') {
      setEmpresaId(empresaSelecionadaId);
    }
  }, [empresaSelecionadaId]);

  // Carrega configurações e dados da empresa ativa
  useEffect(() => {
    if (empresaId) {
      carregarDadosEmpresa(empresaId, competencia);
    }
  }, [empresaId, competencia]);

  const carregarDadosEmpresa = async (targetEmpresaId: string, comp: string) => {
    setLoading(true);
    setFeedbackMessage(null);
    try {
      const [cfgData, painelData, eventosData] = await Promise.all([
        api.getESocialConfiguracao(targetEmpresaId),
        api.getPainelFechamentoESocial(targetEmpresaId, comp),
        api.getESocialEventos({ empresaId: targetEmpresaId, competencia: comp }),
      ]);
      setConfig(cfgData);
      setPainel(painelData);
      setEventos(eventosData);
    } catch (err: any) {
      console.error('Erro ao carregar dados do eSocial:', err);
      setFeedbackMessage({
        tipo: 'erro',
        texto: err.message || 'Falha ao carregar configurações do eSocial.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSalvarConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!config || !empresaId) return;

    setSavingConfig(true);
    setFeedbackMessage(null);
    try {
      const resp = await api.salvarESocialConfiguracao(empresaId, config);
      setConfig(resp.config);
      setFeedbackMessage({
        tipo: 'sucesso',
        texto: 'Parâmetros e alíquotas do eSocial atualizados com sucesso!',
      });
      // Atualiza painel para recalcular RAT e DCTFWeb com os novos parâmetros
      const updatedPainel = await api.getPainelFechamentoESocial(empresaId, competencia);
      setPainel(updatedPainel);
    } catch (err: any) {
      setFeedbackMessage({
        tipo: 'erro',
        texto: err.message || 'Erro ao salvar parametrizações do eSocial.',
      });
    } finally {
      setSavingConfig(false);
    }
  };

  const handleExecutarValidacaoPeriodicos = async () => {
    if (!empresaId) return;
    setValidating(true);
    setFeedbackMessage(null);
    try {
      const resp = await api.validarEventosPeriodicos(empresaId, competencia);
      const updatedPainel = await api.getPainelFechamentoESocial(empresaId, competencia);
      const updatedEventos = await api.getESocialEventos({ empresaId, competencia });
      setPainel(updatedPainel);
      setEventos(updatedEventos);

      if (resp.totalEventosComErro > 0) {
        setFeedbackMessage({
          tipo: 'info',
          texto: `Validação concluída: ${resp.totalEventosValidados} eventos validados com sucesso e ${resp.totalEventosComErro} evento(s) com apontamentos de inconsistência.`,
        });
      } else {
        setFeedbackMessage({
          tipo: 'sucesso',
          texto: `Todos os ${resp.totalEventosValidados} eventos periódicos (S-1200 / S-1210) foram validados com 100% de conformidade!`,
        });
      }
    } catch (err: any) {
      setFeedbackMessage({
        tipo: 'erro',
        texto: err.message || 'Falha na validação de eventos periódicos.',
      });
    } finally {
      setValidating(false);
    }
  };

  const handleFecharFolhaS1299 = async () => {
    if (!empresaId) return;
    const confirmou = window.confirm(
      `Confirma a transmissão do Fechamento da Folha (S-1299) para a competência ${competencia}? Esta ação gerará o protocolo oficial no ambiente do eSocial e a guia DCTFWeb consolidada.`
    );
    if (!confirmou) return;

    setSubmittingFechamento(true);
    setFeedbackMessage(null);
    try {
      const resp = await api.fecharFolhaESocialS1299(empresaId, competencia);
      setFeedbackMessage({
        tipo: 'sucesso',
        texto: `Evento de Fechamento S-1299 transmitido com sucesso! Protocolo: ${resp.protocoloEnvio} | Recibo: ${resp.reciboS1299}`,
      });
      // Recarrega dados
      carregarDadosEmpresa(empresaId, competencia);
    } catch (err: any) {
      setFeedbackMessage({
        tipo: 'erro',
        texto: err.message || 'Erro ao transmitir o fechamento S-1299.',
      });
    } finally {
      setSubmittingFechamento(false);
    }
  };

  const handleReabrirFolhaS1298 = async () => {
    if (!empresaId) return;
    const confirmou = window.confirm(
      `Deseja reabrir a folha de pagamento da competência ${competencia} (Evento S-1298)? Isso permitirá retificar valores e reprocessar eventos periódicos.`
    );
    if (!confirmou) return;

    setReopening(true);
    setFeedbackMessage(null);
    try {
      const resp = await api.reabrirFolhaESocialS1298(empresaId, competencia);
      setFeedbackMessage({
        tipo: 'sucesso',
        texto: resp.mensagem,
      });
      carregarDadosEmpresa(empresaId, competencia);
    } catch (err: any) {
      setFeedbackMessage({
        tipo: 'erro',
        texto: err.message || 'Erro ao reabrir competência.',
      });
    } finally {
      setReopening(false);
    }
  };

  const handleDownloadXml = async (evento: EventoESocialRegistro) => {
    try {
      const { blob, filename } = await api.downloadXmlEventoESocial(evento.id);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err: any) {
      alert('Erro ao realizar download do arquivo XML: ' + err.message);
    }
  };

  const handleVisualizarXml = (evento: EventoESocialRegistro) => {
    setModalXml({
      titulo: `${evento.tipoEvento} - ${evento.descricaoEvento}`,
      xml: evento.xmlGerado || 'XML ainda não gerado ou em processamento.',
      eventoId: evento.id,
    });
  };

  const empresaAtivaObj = empresas.find((e) => e.id === empresaId);

  return (
    <div className="space-y-6">
      {/* Barra de Controle de Empresa e Competência */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-indigo-600" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Empresa:</span>
          </div>
          <select
            value={empresaId}
            onChange={(e) => setEmpresaId(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-sm font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none min-w-[280px]"
          >
            {empresas.map((emp) => (
              <option key={emp.id} value={emp.id}>
                {emp.razaoSocial} ({emp.cnpj})
              </option>
            ))}
          </select>

          <div className="flex items-center gap-2 ml-0 md:ml-4">
            <Calendar className="w-4 h-4 text-slate-500" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Competência:</span>
          </div>
          <select
            value={competencia}
            onChange={(e) => setCompetencia(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-sm font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
          >
            <option value="09/2026">09/2026 (Setembro/2026 - Aberta)</option>
            <option value="08/2026">08/2026 (Agosto/2026)</option>
            <option value="07/2026">07/2026 (Julho/2026)</option>
            <option value="13/2026">13/2026 (13º Salário Anual)</option>
          </select>
        </div>

        <div className="flex items-center gap-2">
          {config?.ambiente === 'producao' ? (
            <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-md border border-emerald-300 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
              Ambiente: Produção (Oficial RFB)
            </span>
          ) : (
            <span className="px-2.5 py-1 bg-amber-100 text-amber-800 text-xs font-bold rounded-md border border-amber-300 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              Ambiente: Produção Restrita (Testes)
            </span>
          )}

          <button
            type="button"
            onClick={() => carregarDadosEmpresa(empresaId, competencia)}
            disabled={loading}
            className="p-2 text-slate-600 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200"
            title="Atualizar dados do eSocial"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Alerta de Feedback */}
      {feedbackMessage && (
        <div
          className={`p-4 rounded-xl border flex items-start gap-3 transition-all ${
            feedbackMessage.tipo === 'sucesso'
              ? 'bg-emerald-50/90 border-emerald-200 text-emerald-800'
              : feedbackMessage.tipo === 'erro'
              ? 'bg-rose-50/90 border-rose-200 text-rose-800'
              : 'bg-amber-50/90 border-amber-200 text-amber-900'
          }`}
        >
          {feedbackMessage.tipo === 'sucesso' ? (
            <CheckCircle2 className="w-5 h-5 flex-shrink-0 text-emerald-600 mt-0.5" />
          ) : feedbackMessage.tipo === 'erro' ? (
            <ShieldAlert className="w-5 h-5 flex-shrink-0 text-rose-600 mt-0.5" />
          ) : (
            <AlertTriangle className="w-5 h-5 flex-shrink-0 text-amber-600 mt-0.5" />
          )}
          <div className="flex-1 text-sm font-medium">{feedbackMessage.texto}</div>
          <button
            type="button"
            onClick={() => setFeedbackMessage(null)}
            className="text-slate-400 hover:text-slate-600"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Sub-navegação do Módulo eSocial */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 pb-2">
        <button
          type="button"
          onClick={() => setSubTab('fechamento')}
          className={`px-4 py-2 text-sm font-bold rounded-lg flex items-center gap-2 transition-colors ${
            subTab === 'fechamento'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
        >
          <Receipt className="w-4 h-4" />
          <span>Fechamento da Folha (S-1299 & DCTFWeb)</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('validacao')}
          className={`px-4 py-2 text-sm font-bold rounded-lg flex items-center gap-2 transition-colors ${
            subTab === 'validacao'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span>Validação de Eventos Periódicos (S-1200 / S-1210)</span>
          {painel && painel.eventosPeriodicos.comErrosPendentes > 0 && (
            <span className="px-1.5 py-0.2 bg-rose-500 text-white text-[10px] font-black rounded-full">
              {painel.eventosPeriodicos.comErrosPendentes}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setSubTab('parametros')}
          className={`px-4 py-2 text-sm font-bold rounded-lg flex items-center gap-2 transition-colors ${
            subTab === 'parametros'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
        >
          <Settings2 className="w-4 h-4" />
          <span>Parametrizações & Alíquotas (S-1000)</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('eventos')}
          className={`px-4 py-2 text-sm font-bold rounded-lg flex items-center gap-2 transition-colors ${
            subTab === 'eventos'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
        >
          <FileCode2 className="w-4 h-4" />
          <span>Histórico de Arquivos XML & Recibos</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 1. ABA DE FECHAMENTO DA FOLHA (S-1299 & DCTFWEB) */}
      {/* ========================================================================= */}
      {subTab === 'fechamento' && painel && (
        <div className="space-y-6">
          {/* Status Geral do Fechamento */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Status da Competência {competencia}:
                </span>
                {painel.statusFechamento === 'fechado_transmitido' ? (
                  <span className="px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-black rounded-full flex items-center gap-1.5 border border-emerald-300">
                    <Lock className="w-3.5 h-3.5" />
                    FOLHA FECHADA & TRANSMITIDA (S-1299)
                  </span>
                ) : painel.statusFechamento === 'pronto_envio' ? (
                  <span className="px-3 py-1 bg-blue-100 text-blue-800 text-xs font-black rounded-full flex items-center gap-1.5 border border-blue-300">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    100% VALIDADA - PRONTA PARA FECHAMENTO
                  </span>
                ) : (
                  <span className="px-3 py-1 bg-amber-100 text-amber-800 text-xs font-black rounded-full flex items-center gap-1.5 border border-amber-300">
                    <Unlock className="w-3.5 h-3.5" />
                    FOLHA EM ABERTO / PENDÊNCIAS A CORRIGIR
                  </span>
                )}
              </div>
              <h2 className="text-xl font-bold text-slate-900">
                {painel.empresaNome}
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                CNPJ: {painel.cnpj} • Versão Manual eSocial: {painel.versaoManual} • Certificado: {config?.certificadoNome || 'ICP-Brasil A1'}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {painel.statusFechamento === 'fechado_transmitido' ? (
                <>
                  <button
                    type="button"
                    onClick={handleReabrirFolhaS1298}
                    disabled={reopening}
                    className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-lg shadow-sm transition-colors flex items-center gap-2"
                  >
                    <Unlock className="w-4 h-4" />
                    <span>{reopening ? 'Reabrindo...' : 'Reabrir Folha (S-1298)'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const s1299 = eventos.find((e) => e.tipoEvento === 'S-1299');
                      if (s1299) handleVisualizarXml(s1299);
                    }}
                    className="px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-lg shadow-sm transition-colors flex items-center gap-2"
                  >
                    <FileCode2 className="w-4 h-4" />
                    <span>Ver Recibo S-1299</span>
                  </button>
                </>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={handleExecutarValidacaoPeriodicos}
                    disabled={validating}
                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg border border-slate-300 transition-colors flex items-center gap-2"
                  >
                    <RefreshCw className={`w-4 h-4 ${validating ? 'animate-spin' : ''}`} />
                    <span>{validating ? 'Validando...' : 'Revalidar Eventos'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleFecharFolhaS1299}
                    disabled={
                      submittingFechamento ||
                      painel.eventosPeriodicos.comErrosPendentes > 0 ||
                      painel.inconsistenciasGerais.some((i) => i.tipo === 'erro')
                    }
                    className={`px-5 py-2.5 text-white text-xs font-bold rounded-lg shadow-sm transition-colors flex items-center gap-2 ${
                      painel.eventosPeriodicos.comErrosPendentes > 0 ||
                      painel.inconsistenciasGerais.some((i) => i.tipo === 'erro')
                        ? 'bg-slate-400 cursor-not-allowed opacity-70'
                        : 'bg-emerald-600 hover:bg-emerald-700'
                    }`}
                  >
                    <Send className="w-4 h-4" />
                    <span>
                      {submittingFechamento ? 'Assinando e Transmitindo...' : 'Transmitir Fechamento (S-1299)'}
                    </span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Cards de Totais e Alíquotas Apuradas da DCTFWeb */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                Remuneração Bruta Total
              </span>
              <p className="text-xl font-bold text-slate-900 mt-1">
                {painel.totais.remuneracaoBrutaTotal.toLocaleString('pt-BR', {
                  style: 'currency',
                  currency: 'BRL',
                })}
              </p>
              <span className="text-xs text-slate-500">
                {painel.totais.totalColaboradores} colaboradores apurados
              </span>
            </div>

            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                INSS Segurados (Descontado)
              </span>
              <p className="text-xl font-bold text-indigo-700 mt-1">
                {painel.totais.totalInssSegurados.toLocaleString('pt-BR', {
                  style: 'currency',
                  currency: 'BRL',
                })}
              </p>
              <span className="text-xs text-slate-500">Dedução em folha de pagamento</span>
            </div>

            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-sm">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                INSS Patronal + RAT + Terceiros
              </span>
              <p className="text-xl font-bold text-slate-900 mt-1">
                {(
                  painel.totais.totalInssPatronal +
                  painel.totais.totalRatAjustado +
                  painel.totais.totalTerceirosOutrasEntidades
                ).toLocaleString('pt-BR', {
                  style: 'currency',
                  currency: 'BRL',
                })}
              </p>
              <span className="text-xs text-slate-500">
                {config?.classificacaoTributaria === '01'
                  ? 'Simples Nacional (Isento CPP/Outros)'
                  : `CPP 20% + RAT ${config?.aliquotaRatAjustada}% + Outros ${config?.aliquotaTerceiros}%`}
              </span>
            </div>

            <div className="p-4 bg-emerald-50/70 border border-emerald-300 rounded-xl shadow-sm">
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">
                Total Previdenciário (DCTFWeb)
              </span>
              <p className="text-xl font-bold text-emerald-900 mt-1">
                {painel.totais.totalInssDctfWeb.toLocaleString('pt-BR', {
                  style: 'currency',
                  currency: 'BRL',
                })}
              </p>
              <span className="text-xs text-emerald-700">Guia DARF Previdenciária Única</span>
            </div>
          </div>

          {/* Card Detalhado de Fechamento / Recibo Oficial */}
          {painel.reciboFechamento && (
            <div className="p-5 bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-xl shadow-md border border-slate-800">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider mb-1">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Comprovante de Transmissão Oficial eSocial / RFB</span>
                  </div>
                  <h3 className="text-lg font-bold">
                    Recibo S-1299: {painel.reciboFechamento.numeroReciboS1299}
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Protocolo de Recepção: {painel.reciboFechamento.protocoloRecepcao} • Data/Hora:{' '}
                    {new Date(painel.reciboFechamento.dataHoraEnvio).toLocaleString('pt-BR')}
                  </p>
                </div>

                {painel.reciboFechamento.retornoS5011DctfWeb && (
                  <div className="bg-white/10 p-3 rounded-lg border border-white/10 text-right">
                    <span className="text-[10px] uppercase tracking-wider text-slate-300 block">
                      DCTFWeb Integrada (S-5011)
                    </span>
                    <span className="text-base font-bold text-white block">
                      {painel.reciboFechamento.retornoS5011DctfWeb.valorTotalGuiaDarfer.toLocaleString('pt-BR', {
                        style: 'currency',
                        currency: 'BRL',
                      })}
                    </span>
                    <span className="text-[11px] text-emerald-300">
                      Vencimento: {painel.reciboFechamento.retornoS5011DctfWeb.vencimentoDarfer}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Avisos e Inconsistências Gerais Bloqueantes */}
          {painel.inconsistenciasGerais.length > 0 && (
            <div className="bg-white p-5 rounded-xl border border-amber-200 shadow-sm">
              <div className="flex items-center gap-2 text-amber-900 font-bold text-sm mb-3">
                <ShieldAlert className="w-5 h-5 text-amber-600" />
                <span>Apontamentos e Regras de Validação do Fechamento S-1299</span>
              </div>
              <div className="space-y-2">
                {painel.inconsistenciasGerais.map((inc, i) => (
                  <div
                    key={i}
                    className={`p-3 rounded-lg border text-xs flex items-start gap-3 ${
                      inc.tipo === 'erro'
                        ? 'bg-rose-50 border-rose-200 text-rose-800'
                        : 'bg-amber-50 border-amber-200 text-amber-800'
                    }`}
                  >
                    <span className="px-1.5 py-0.5 font-bold uppercase rounded text-[10px] bg-white border">
                      {inc.codigoRegra}
                    </span>
                    <div className="flex-1">
                      <p className="font-semibold">{inc.descricao}</p>
                      <p className="text-[11px] opacity-90 mt-0.5">
                        <strong className="underline">Ação recomendada:</strong> {inc.sugestaoCorrecao}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tabela Resumo dos Eventos Periódicos da Folha */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Lote de Eventos Periódicos da Competência ({competencia})
                </h3>
                <p className="text-xs text-slate-500">
                  Total de {painel.eventosPeriodicos.itens.length} eventos (S-1200 Remunerações e S-1210 Pagamentos).
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="px-2 py-1 bg-emerald-100 text-emerald-800 font-bold rounded">
                  {painel.eventosPeriodicos.validadosComSucesso} validados
                </span>
                {painel.eventosPeriodicos.comErrosPendentes > 0 && (
                  <span className="px-2 py-1 bg-rose-100 text-rose-800 font-bold rounded">
                    {painel.eventosPeriodicos.comErrosPendentes} com erro
                  </span>
                )}
                <span className="px-2 py-1 bg-indigo-100 text-indigo-800 font-bold rounded">
                  {painel.eventosPeriodicos.transmitidos} transmitidos
                </span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs font-bold uppercase">
                    <th className="py-2.5 px-3">Tipo Evento</th>
                    <th className="py-2.5 px-3">Colaborador / Vínculo</th>
                    <th className="py-2.5 px-3">CPF</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                    <th className="py-2.5 px-3">Protocolo / Recibo</th>
                    <th className="py-2.5 px-3 text-right">Ações XML</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {painel.eventosPeriodicos.itens.map((ev) => (
                    <tr key={ev.id} className="hover:bg-slate-50/70">
                      <td className="py-2.5 px-3 font-mono font-bold text-xs text-indigo-600">
                        {ev.tipoEvento}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-900">
                        {ev.trabalhadorNome || ev.descricaoEvento}
                        {ev.trabalhadorMatricula && (
                          <span className="text-xs text-slate-400 block font-mono">
                            {ev.trabalhadorMatricula}
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-xs text-slate-600 font-mono">
                        {ev.trabalhadorCpf || '---'}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        {ev.status === 'transmitido_sucesso' ? (
                          <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full">
                            Transmitido
                          </span>
                        ) : ev.status === 'validado' ? (
                          <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-xs font-medium rounded-full">
                            Validado OK
                          </span>
                        ) : ev.status === 'rejeitado_erro' ? (
                          <button
                            type="button"
                            onClick={() =>
                              setModalInconsistencia({
                                colaborador: ev.trabalhadorNome,
                                inconsistencias: ev.inconsistencias || [],
                              })
                            }
                            className="px-2 py-0.5 bg-rose-100 text-rose-800 text-xs font-bold rounded-full hover:bg-rose-200 transition-colors"
                          >
                            Rejeição ({ev.inconsistencias?.length || 0})
                          </button>
                        ) : (
                          <span className="px-2 py-0.5 bg-slate-100 text-slate-700 text-xs rounded-full">
                            Pendente
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-xs font-mono text-slate-600">
                        {ev.numeroReciboEnvio || ev.protocoloEnvio || 'Aguardando envio'}
                      </td>
                      <td className="py-2.5 px-3 text-right space-x-1">
                        <button
                          type="button"
                          onClick={() => handleVisualizarXml(ev)}
                          className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-slate-100 rounded"
                          title="Visualizar XML do Evento"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDownloadXml(ev)}
                          className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-slate-100 rounded"
                          title="Baixar arquivo XML assinado"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. ABA DE VALIDAÇÃO DE EVENTOS PERIÓDICOS (S-1200 / S-1210) */}
      {/* ========================================================================= */}
      {subTab === 'validacao' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Auditoria de Conformidade e Validador Pré-eSocial
                </h3>
                <p className="text-xs text-slate-500">
                  Validação sintática e semântica com o leiaute oficial do eSocial (versão S-1.2/S-1.3) antes da assinatura digital.
                </p>
              </div>

              <button
                type="button"
                onClick={handleExecutarValidacaoPeriodicos}
                disabled={validating}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-2 transition-colors"
              >
                <RefreshCw className={`w-4 h-4 ${validating ? 'animate-spin' : ''}`} />
                <span>{validating ? 'Auditando...' : 'Executar Validação Completa'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-xs font-bold text-slate-600 uppercase block mb-1">
                  1. Qualificação Cadastral
                </span>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Valida coerência de CPF na Receita Federal, PIS/PASEP e vínculos ativos para garantir recolhimento do FGTS Digital.
                </p>
              </div>

              <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-xs font-bold text-slate-600 uppercase block mb-1">
                  2. Tabelas de Rubricas (S-1010)
                </span>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Incidências de INSS, FGTS e IRRF nas rubricas salariais, adicionais noturno/periculosidade e descontos legais.
                </p>
              </div>

              <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                <span className="text-xs font-bold text-slate-600 uppercase block mb-1">
                  3. Cálculos de Encargos & DCTFWeb
                </span>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Apuração de FAP, alíquota RAT ajustada e terceiros/outras entidades conforme classificação tributária da empresa.
                </p>
              </div>
            </div>

            {/* Listagem de Eventos e Inconsistências */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs font-bold uppercase">
                    <th className="py-2.5 px-3">Tipo</th>
                    <th className="py-2.5 px-3">Trabalhador</th>
                    <th className="py-2.5 px-3">Matrícula</th>
                    <th className="py-2.5 px-3 text-center">Status Validação</th>
                    <th className="py-2.5 px-3">Inconsistências / Erros</th>
                    <th className="py-2.5 px-3 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {eventos.map((ev) => (
                    <tr key={ev.id} className="hover:bg-slate-50/70">
                      <td className="py-2.5 px-3 font-mono font-bold text-xs text-indigo-600">
                        {ev.tipoEvento}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-900">
                        {ev.trabalhadorNome || ev.descricaoEvento}
                      </td>
                      <td className="py-2.5 px-3 text-xs font-mono text-slate-600">
                        {ev.trabalhadorMatricula || 'N/A'}
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        {ev.status === 'validado' ? (
                          <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-semibold rounded-full flex items-center justify-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Aprovado
                          </span>
                        ) : ev.status === 'rejeitado_erro' ? (
                          <span className="px-2.5 py-0.5 bg-rose-100 text-rose-800 text-xs font-semibold rounded-full flex items-center justify-center gap-1">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            Inconsistente
                          </span>
                        ) : ev.status === 'transmitido_sucesso' ? (
                          <span className="px-2.5 py-0.5 bg-blue-100 text-blue-800 text-xs font-semibold rounded-full flex items-center justify-center gap-1">
                            <ShieldCheck className="w-3.5 h-3.5" />
                            Transmitido
                          </span>
                        ) : (
                          <span className="px-2.5 py-0.5 bg-slate-100 text-slate-700 text-xs rounded-full">
                            Pendente
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-xs">
                        {ev.inconsistencias && ev.inconsistencias.length > 0 ? (
                          <button
                            type="button"
                            onClick={() =>
                              setModalInconsistencia({
                                colaborador: ev.trabalhadorNome,
                                inconsistencias: ev.inconsistencias || [],
                              })
                            }
                            className="text-rose-600 font-semibold hover:underline flex items-center gap-1"
                          >
                            <span>{ev.inconsistencias.length} apontamento(s)</span>
                          </button>
                        ) : (
                          <span className="text-slate-400">Nenhum erro encontrado</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          type="button"
                          onClick={() => handleVisualizarXml(ev)}
                          className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded transition-colors"
                        >
                          Ver XML
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. ABA DE PARAMETRIZAÇÕES E ALÍQUOTAS DO ESOCIAL (S-1000) */}
      {/* ========================================================================= */}
      {subTab === 'parametros' && config && (
        <form onSubmit={handleSalvarConfig} className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Configurações Tributárias e Empregador (Evento S-1000)
                </h3>
                <p className="text-xs text-slate-500">
                  Defina os parâmetros de enquadramento previdenciário, alíquotas RAT/FAP e certificado digital da empresa.
                </p>
              </div>

              <button
                type="submit"
                disabled={savingConfig}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg shadow-sm transition-colors flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{savingConfig ? 'Salvando...' : 'Salvar Alterações'}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Ambiente de Transmissão
                </label>
                <select
                  value={config.ambiente}
                  onChange={(e) =>
                    setConfig({ ...config, ambiente: e.target.value as any })
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="producao">1 - Produção (Ambiente Oficial RFB)</option>
                  <option value="producao_restrita">2 - Produção Restrita (Testes de Homologação)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Versão do Manual / Leiaute
                </label>
                <select
                  value={config.versaoManual}
                  onChange={(e) => setConfig({ ...config, versaoManual: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="S-1.2">S-1.2 (Vigente)</option>
                  <option value="S-1.3">S-1.3 (Atualizada)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Classificação Tributária (Tabela 08)
                </label>
                <select
                  value={config.classificacaoTributaria}
                  onChange={(e) =>
                    setConfig({ ...config, classificacaoTributaria: e.target.value })
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="01">01 - Empresa enquadrada no Simples Nacional (Anexos I a III e V)</option>
                  <option value="02">02 - Simples Nacional com tributação previdenciária substituída e não substituída</option>
                  <option value="03">03 - Simples Nacional - Atividades do Anexo IV</option>
                  <option value="99">99 - Pessoas Jurídicas em Geral (Lucro Presumido / Lucro Real)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Alíquota RAT (%)
                </label>
                <select
                  value={config.aliquotaRat}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      aliquotaRat: Number(e.target.value),
                    })
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="1">1.0% (Risco Mínimo)</option>
                  <option value="2">2.0% (Risco Médio)</option>
                  <option value="3">3.0% (Risco Grave / Industrial)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Fator FAP (0.5000 a 2.0000)
                </label>
                <input
                  type="number"
                  step="0.0001"
                  min="0.5"
                  max="2.0"
                  value={config.fap}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      fap: Number(e.target.value),
                    })
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  RAT Ajustado Calculado (%)
                </label>
                <input
                  type="text"
                  disabled
                  value={`${(config.aliquotaRat * config.fap).toFixed(4)}%`}
                  className="w-full px-3 py-2 bg-slate-100 border border-slate-300 rounded-lg text-sm font-bold text-indigo-700"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Outras Entidades / Terceiros (%)
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="10"
                  value={config.aliquotaTerceiros}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      aliquotaTerceiros: Number(e.target.value),
                    })
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Desoneração da Folha (CPRB)
                </label>
                <select
                  value={config.indicativoDesoneracaoFolha}
                  onChange={(e) =>
                    setConfig({ ...config, indicativoDesoneracaoFolha: e.target.value as any })
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800"
                >
                  <option value="0">0 - Não Aplicável</option>
                  <option value="1">1 - Empresa Enquadrada na CPRB (Lei 12.546/2011)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Indicativo de Construtora
                </label>
                <select
                  value={config.indicativoConstrutora}
                  onChange={(e) =>
                    setConfig({ ...config, indicativoConstrutora: e.target.value as any })
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800"
                >
                  <option value="0">0 - Não é Construtora</option>
                  <option value="1">1 - Empresa Construtora (Obras Civis)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Indicativo de Cooperativa
                </label>
                <select
                  value={config.indicativoCooperativa}
                  onChange={(e) =>
                    setConfig({ ...config, indicativoCooperativa: e.target.value as any })
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800"
                >
                  <option value="0">0 - Não é Cooperativa</option>
                  <option value="1">1 - Cooperativa de Trabalho</option>
                  <option value="2">2 - Cooperativa de Produção</option>
                  <option value="3">3 - Outras Cooperativas</option>
                </select>
              </div>
            </div>

            {/* Certificado Digital e Transmissão Automática */}
            <div className="pt-4 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Certificado Digital Vinculado para Assinatura
                </label>
                <input
                  type="text"
                  value={config.certificadoNome || 'Certificado Digital ICP-Brasil A1'}
                  onChange={(e) => setConfig({ ...config, certificadoNome: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800"
                />
                <span className="text-[11px] text-slate-500 mt-1 block">
                  Validade:{' '}
                  {config.certificadoValidade
                    ? new Date(config.certificadoValidade).toLocaleDateString('pt-BR')
                    : '15/01/2027'}
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Contato Técnico / Contador Responsável
                </label>
                <input
                  type="text"
                  value={config.contatoResponsavelNome}
                  onChange={(e) =>
                    setConfig({ ...config, contatoResponsavelNome: e.target.value })
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800"
                />
                <div className="flex gap-2 mt-1">
                  <input
                    type="text"
                    placeholder="E-mail"
                    value={config.contatoResponsavelEmail}
                    onChange={(e) =>
                      setConfig({ ...config, contatoResponsavelEmail: e.target.value })
                    }
                    className="flex-1 px-2 py-1 bg-slate-50 border border-slate-300 rounded text-xs text-slate-700"
                  />
                  <input
                    type="text"
                    placeholder="Telefone"
                    value={config.contatoResponsavelTelefone}
                    onChange={(e) =>
                      setConfig({ ...config, contatoResponsavelTelefone: e.target.value })
                    }
                    className="w-36 px-2 py-1 bg-slate-50 border border-slate-300 rounded text-xs text-slate-700"
                  />
                </div>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="transmissaoAuto"
                  checked={config.transmissaoAutomatica}
                  onChange={(e) =>
                    setConfig({ ...config, transmissaoAutomatica: e.target.checked })
                  }
                  className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                />
                <label htmlFor="transmissaoAuto" className="text-xs font-medium text-slate-700">
                  Transmitir automaticamente após homologação da folha pelo Departamento Pessoal
                </label>
              </div>

              <span className="text-xs text-slate-400">
                Última atualização: {new Date(config.atualizadoEm).toLocaleString('pt-BR')}
              </span>
            </div>
          </div>
        </form>
      )}

      {/* ========================================================================= */}
      {/* 4. ABA DE HISTÓRICO DE EVENTOS E ARQUIVOS XML */}
      {/* ========================================================================= */}
      {subTab === 'eventos' && (
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Histórico de Eventos Transmitidos e Arquivos XML Assinados
              </h3>
              <p className="text-xs text-slate-500">
                Arquivo digital oficial para fiscalização do Ministério do Trabalho e Receita Federal.
              </p>
            </div>
            <span className="text-xs font-bold text-slate-600">
              {eventos.length} evento(s) localizados
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-xs font-bold uppercase">
                  <th className="py-3 px-4">Evento</th>
                  <th className="py-3 px-4">Descrição</th>
                  <th className="py-3 px-4">Competência</th>
                  <th className="py-3 px-4">Recibo / Protocolo</th>
                  <th className="py-3 px-4">Data Transmissão</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">XML</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {eventos.map((ev) => (
                  <tr key={ev.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-mono font-bold text-xs text-indigo-600">
                      {ev.tipoEvento}
                    </td>
                    <td className="py-3 px-4 text-xs font-medium text-slate-900">
                      {ev.descricaoEvento}
                    </td>
                    <td className="py-3 px-4 text-xs font-mono text-slate-700">
                      {ev.competencia || '---'}
                    </td>
                    <td className="py-3 px-4 text-xs font-mono text-slate-600">
                      {ev.numeroReciboEnvio || ev.protocoloEnvio || '---'}
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-600">
                      {ev.dataTransmissao
                        ? new Date(ev.dataTransmissao).toLocaleString('pt-BR')
                        : new Date(ev.dataGeracao).toLocaleString('pt-BR')}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full">
                        Transmitido
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right space-x-2">
                      <button
                        type="button"
                        onClick={() => handleVisualizarXml(ev)}
                        className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold"
                      >
                        Visualizar
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDownloadXml(ev)}
                        className="text-xs text-slate-600 hover:text-slate-900 font-semibold"
                      >
                        Baixar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL DE VISUALIZAÇÃO DE XML */}
      {/* ========================================================================= */}
      {modalXml && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCode2 className="w-5 h-5 text-indigo-400" />
                <h4 className="font-bold text-sm">{modalXml.titulo}</h4>
              </div>
              <button
                type="button"
                onClick={() => setModalXml(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 bg-slate-950 flex-1 overflow-auto">
              <pre className="text-xs font-mono text-emerald-400 leading-relaxed whitespace-pre-wrap">
                {modalXml.xml}
              </pre>
            </div>

            <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Arquivo estruturado em conformidade com W3C XML Schema e XSD oficial do eSocial.
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(modalXml.xml);
                    alert('XML copiado para a área de transferência!');
                  }}
                  className="px-3 py-1.5 bg-white border border-slate-300 text-slate-700 text-xs font-bold rounded-lg hover:bg-slate-50 flex items-center gap-1.5"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copiar XML</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const blob = new Blob([modalXml.xml], { type: 'application/xml' });
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `evento_${modalXml.eventoId}.xml`;
                    a.click();
                  }}
                  className="px-3 py-1.5 bg-indigo-600 text-white text-xs font-bold rounded-lg hover:bg-indigo-700 flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Baixar Arquivo</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL DE DETALHAMENTO DE INCONSISTÊNCIAS */}
      {/* ========================================================================= */}
      {modalInconsistencia && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-4 bg-rose-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-rose-300" />
                <h4 className="font-bold text-sm">
                  Inconsistências do eSocial • {modalInconsistencia.colaborador || 'Geral'}
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setModalInconsistencia(null)}
                className="text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-auto space-y-3">
              {modalInconsistencia.inconsistencias.map((inc, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-xl border text-sm ${
                    inc.tipo === 'erro'
                      ? 'bg-rose-50 border-rose-200 text-rose-900'
                      : 'bg-amber-50 border-amber-200 text-amber-900'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono font-bold text-xs uppercase px-2 py-0.5 bg-white rounded border">
                      {inc.codigoRegra}
                    </span>
                    <span
                      className={`text-[11px] font-bold uppercase ${
                        inc.tipo === 'erro' ? 'text-rose-700' : 'text-amber-700'
                      }`}
                    >
                      {inc.tipo === 'erro' ? 'Erro Bloqueante' : 'Advertência'}
                    </span>
                  </div>
                  <p className="font-semibold text-sm mt-1">{inc.descricao}</p>
                  <p className="text-xs mt-1 text-slate-700 bg-white/70 p-2 rounded border border-slate-200">
                    <strong>Como corrigir:</strong> {inc.sugestaoCorrecao}
                  </p>
                </div>
              ))}
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 text-right">
              <button
                type="button"
                onClick={() => setModalInconsistencia(null)}
                className="px-4 py-2 bg-slate-800 text-white text-xs font-bold rounded-lg hover:bg-slate-900"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
