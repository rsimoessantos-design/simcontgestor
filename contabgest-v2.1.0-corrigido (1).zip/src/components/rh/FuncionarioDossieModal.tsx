import React from 'react';
import {
  X,
  User,
  Building,
  CreditCard,
  HeartHandshake,
  Calendar,
  FileText,
  Printer,
  ShieldCheck,
  CheckCircle,
  MapPin,
  Mail,
  Phone,
} from 'lucide-react';
import { Funcionario, Empresa } from '../../types';

interface FuncionarioDossieModalProps {
  isOpen: boolean;
  onClose: () => void;
  funcionario: Funcionario | null;
  empresa: Empresa | null;
  onAbrirHolerite: () => void;
  onAbrirFerias: () => void;
}

export const FuncionarioDossieModal: React.FC<FuncionarioDossieModalProps> = ({
  isOpen,
  onClose,
  funcionario,
  empresa,
  onAbrirHolerite,
  onAbrirFerias,
}) => {
  if (!isOpen || !funcionario) return null;

  const statusColors = {
    ativo: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    ferias: 'bg-amber-100 text-amber-800 border-amber-200',
    afastado: 'bg-rose-100 text-rose-800 border-rose-200',
    desligado: 'bg-slate-100 text-slate-800 border-slate-200',
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-100 overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-6">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white font-bold text-lg flex items-center justify-center shadow-md">
              {funcionario.nomeCompleto.substring(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">{funcionario.nomeCompleto}</h3>
                <span
                  className={`px-2 py-0.5 text-[11px] font-bold rounded-full border uppercase ${
                    statusColors[funcionario.status]
                  }`}
                >
                  {funcionario.status}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                {funcionario.cargoNome} • Matrícula {funcionario.matricula} • {empresa?.razaoSocial || 'Empresa'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onAbrirHolerite}
              className="px-3 py-1.5 text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <FileText className="w-4 h-4" />
              <span>Ver Holerite</span>
            </button>
            <button
              onClick={onAbrirFerias}
              className="px-3 py-1.5 text-xs font-semibold text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Calendar className="w-4 h-4" />
              <span>Férias</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* Card 1: Informações Contratuais */}
          <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Building className="w-4 h-4 text-indigo-600" />
              Dados do Contrato de Trabalho
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="text-slate-500 block">Cargo / Função:</span>
                <span className="font-semibold text-slate-900">{funcionario.cargoNome}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Código CBO:</span>
                <span className="font-semibold text-slate-900">{funcionario.cbo || '---'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Departamento:</span>
                <span className="font-semibold text-slate-900">{funcionario.departamento}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Tipo Contrato:</span>
                <span className="font-semibold text-slate-900">{funcionario.tipoContrato}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Data de Admissão:</span>
                <span className="font-semibold text-slate-900">
                  {funcionario.dataAdmissao ? new Date(funcionario.dataAdmissao).toLocaleDateString('pt-BR') : '---'}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Regime de Trabalho:</span>
                <span className="font-semibold text-slate-900 capitalize">{funcionario.regimeTrabalho}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Salário Base Mensal:</span>
                <span className="font-bold text-emerald-600 text-sm">
                  {funcionario.salarioBase.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Adicionais Salariais:</span>
                <span className="font-semibold text-slate-800">
                  {(funcionario.adicionaisTotal || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </span>
              </div>
            </div>
          </div>

          {/* Card 2: Documentos & Identificação */}
          <div className="border border-slate-200 rounded-xl p-4 bg-white">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-indigo-600" />
              Documentos & Dados Civis
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="text-slate-500 block">CPF:</span>
                <span className="font-mono font-bold text-slate-900">{funcionario.cpf}</span>
              </div>
              <div>
                <span className="text-slate-500 block">RG:</span>
                <span className="font-semibold text-slate-900">
                  {funcionario.rg || '---'} ({funcionario.rgOrgaoEmissor || 'SSP'})
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">PIS / PASEP / NIT:</span>
                <span className="font-mono font-semibold text-slate-900">{funcionario.pisPasep || '---'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">CTPS:</span>
                <span className="font-semibold text-slate-900">
                  {funcionario.ctpsNumero ? `${funcionario.ctpsNumero} / ${funcionario.ctpsSerie} - ${funcionario.ctpsUf}` : 'Digital'}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Nascimento:</span>
                <span className="font-semibold text-slate-900">
                  {funcionario.dataNascimento ? new Date(funcionario.dataNascimento).toLocaleDateString('pt-BR') : '---'}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Estado Civil:</span>
                <span className="font-semibold text-slate-900">{funcionario.estadoCivil || '---'}</span>
              </div>
              <div className="md:col-span-2">
                <span className="text-slate-500 block">Filiação (Mãe):</span>
                <span className="font-semibold text-slate-900">{funcionario.nomeMae || '---'}</span>
              </div>
            </div>
          </div>

          {/* Card 3: Contato & Endereço */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-slate-200 rounded-xl p-4 bg-white">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Mail className="w-4 h-4 text-indigo-600" />
                Canais de Contato
              </h4>
              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <span className="text-slate-800">{funcionario.email || 'Não informado'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span className="text-slate-800">{funcionario.whatsapp || funcionario.telefone || 'Não informado'}</span>
                </div>
              </div>
            </div>

            <div className="border border-slate-200 rounded-xl p-4 bg-white">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-indigo-600" />
                Endereço Residencial
              </h4>
              <p className="text-xs text-slate-800">
                {funcionario.logradouro ? (
                  <>
                    {funcionario.logradouro}, {funcionario.numero} {funcionario.complemento && `(${funcionario.complemento})`}
                    <br />
                    {funcionario.bairro} - {funcionario.cidade}/{funcionario.uf} - CEP {funcionario.cep}
                  </>
                ) : (
                  <span className="text-slate-400">Endereço não cadastrado</span>
                )}
              </p>
            </div>
          </div>

          {/* Card 4: Dados Bancários & Benefícios */}
          <div className="border border-slate-200 rounded-xl p-4 bg-white">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <CreditCard className="w-4 h-4 text-indigo-600" />
              Remuneração, Benefícios & Dados Bancários
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
              <div>
                <span className="text-slate-500 block">Banco:</span>
                <span className="font-semibold text-slate-900">{funcionario.bancoNome || 'Não informado'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Agência / Conta:</span>
                <span className="font-semibold text-slate-900">
                  Ag: {funcionario.bancoAgencia || '-'} / CC: {funcionario.bancoConta || '-'}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Chave Pix:</span>
                <span className="font-mono font-semibold text-indigo-600">{funcionario.chavePix || '---'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Vale Transporte:</span>
                <span className="font-semibold text-slate-900">{funcionario.valeTransporte ? 'Sim (6% desc)' : 'Não'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Auxílio VR/VA:</span>
                <span className="font-semibold text-slate-900">
                  {(funcionario.valorVrVaMensal || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Plano de Saúde:</span>
                <span className="font-semibold text-slate-900">{funcionario.planoSaude ? 'Ativo' : 'Não'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Saldo Férias:</span>
                <span className="font-bold text-amber-600">{funcionario.diasFeriasSaldo ?? 30} dias</span>
              </div>
              <div>
                <span className="text-slate-500 block">Validade ASO:</span>
                <span className="font-semibold text-slate-900">
                  {funcionario.dataValidadeAso
                    ? new Date(funcionario.dataValidadeAso).toLocaleDateString('pt-BR')
                    : 'Pendente'}
                </span>
              </div>
            </div>
          </div>

          {/* Card 5: Dependentes Cadastrados */}
          {funcionario.dependentes && funcionario.dependentes.length > 0 && (
            <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <HeartHandshake className="w-4 h-4 text-indigo-600" />
                Dependentes Cadastrados ({funcionario.dependentes.length})
              </h4>
              <div className="space-y-2">
                {funcionario.dependentes.map((dep, idx) => (
                  <div key={idx} className="flex justify-between items-center text-xs p-2 bg-white rounded-lg border border-slate-200">
                    <div>
                      <span className="font-semibold text-slate-800">{dep.nome}</span>
                      <span className="text-slate-500 ml-2">({dep.parentesco})</span>
                    </div>
                    <div className="text-slate-600 font-mono">
                      {dep.cpf ? `CPF: ${dep.cpf}` : 'Sem CPF'} • {dep.deducaoIrrf ? 'Dedução IRRF' : ''}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {funcionario.observacoes && (
            <div className="border border-slate-200 rounded-xl p-3 bg-slate-50 text-xs text-slate-600">
              <span className="font-bold text-slate-700 block mb-1">Anotações Gerais:</span>
              <p>{funcionario.observacoes}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
