import React, { useState, useEffect } from 'react';
import {
  FileText,
  Download,
  Printer,
  Calendar,
  User,
  Clock,
  Building2,
  AlertCircle,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  DollarSign,
  X,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';
import { Funcionario, EspelhoPontoMensal } from '../../types';
import { api } from '../../services/api';
import {
  gerarEspelhoPontoPdf,
  formatMinutosParaHorasExtenso,
  formatMoedaReal,
  formatDataPtBr,
} from '../../utils/espelhoPontoPdf';

interface EspelhoPontoModalProps {
  funcionarioId: string;
  funcionarios: Funcionario[];
  initialCompetencia?: string; // MM/YYYY
  onClose?: () => void;
  isEmbedded?: boolean; // Se true, renderiza inline como aba; se false, como modal
}

export const EspelhoPontoModal: React.FC<EspelhoPontoModalProps> = ({
  funcionarioId,
  funcionarios,
  initialCompetencia = '09/2026',
  onClose,
  isEmbedded = false,
}) => {
  const [selectedFuncId, setSelectedFuncId] = useState<string>(funcionarioId);
  const [competencia, setCompetencia] = useState<string>(initialCompetencia);
  const [espelhoData, setEspelhoData] = useState<EspelhoPontoMensal | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [erro, setErro] = useState<string | null>(null);
  const [gerandoPdf, setGerandoPdf] = useState<boolean>(false);
  const [sucessoPdf, setSucessoPdf] = useState<boolean>(false);

  // Colaborador atual selecionado
  const currentFunc = funcionarios.find((f) => f.id === selectedFuncId) || funcionarios[0];

  useEffect(() => {
    if (funcionarioId) {
      setSelectedFuncId(funcionarioId);
    }
  }, [funcionarioId]);

  const carregarEspelho = async () => {
    if (!selectedFuncId) return;
    setLoading(true);
    setErro(null);
    try {
      const data = await api.getEspelhoPonto(selectedFuncId, competencia);
      if (data) {
        setEspelhoData(data);
      } else {
        setErro('Não foi possível carregar o espelho de ponto.');
      }
    } catch (err: any) {
      setErro(err?.message || 'Erro ao consultar espelho de ponto no servidor.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    carregarEspelho();
  }, [selectedFuncId, competencia]);

  // Navegação de competência (Mês anterior / próximo mês)
  const alterarMes = (delta: number) => {
    const [mesStr, anoStr] = competencia.split('/');
    let mes = parseInt(mesStr, 10);
    let ano = parseInt(anoStr, 10);

    mes += delta;
    if (mes > 12) {
      mes = 1;
      ano += 1;
    } else if (mes < 1) {
      mes = 12;
      ano -= 1;
    }

    setCompetencia(`${String(mes).padStart(2, '0')}/${ano}`);
  };

  const handleBaixarPdf = () => {
    if (!espelhoData) return;
    setGerandoPdf(true);
    try {
      gerarEspelhoPontoPdf(espelhoData, { autoDownload: true });
      setSucessoPdf(true);
      setTimeout(() => setSucessoPdf(false), 3500);
    } catch (err: any) {
      console.error('Erro ao gerar PDF do espelho:', err);
      alert('Erro ao gerar arquivo PDF. Verifique os dados e tente novamente.');
    } finally {
      setGerandoPdf(false);
    }
  };

  const handleImprimir = () => {
    window.print();
  };

  const totalNegativoMinutos =
    (espelhoData?.totalAtrasosMinutos || 0) + (espelhoData?.totalFaltasMinutos || 0);

  const containerContent = (
    <div className="space-y-6">
      {/* Barra Superior de Controle & Parâmetros */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Seleção de Colaborador e Mês */}
        <div className="flex flex-wrap items-center gap-3 sm:gap-4">
          <div className="min-w-[240px]">
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 flex items-center gap-1">
              <User className="w-3 h-3 text-slate-400" />
              Colaborador (REP-P)
            </label>
            <select
              id="select_colaborador_espelho_modal"
              value={selectedFuncId}
              onChange={(e) => setSelectedFuncId(e.target.value)}
              className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
            >
              {funcionarios.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.nomeCompleto} ({f.matricula}) • {f.cargoNome}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 flex items-center gap-1">
              <Calendar className="w-3 h-3 text-slate-400" />
              Competência (Mês/Ano)
            </label>
            <div className="flex items-center space-x-1">
              <button
                type="button"
                onClick={() => alterarMes(-1)}
                title="Mês anterior"
                className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-300 transition-colors"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <input
                id="input_competencia_espelho_modal"
                type="text"
                value={competencia}
                onChange={(e) => setCompetencia(e.target.value)}
                placeholder="MM/AAAA"
                className="w-24 px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none text-center font-mono"
              />
              <button
                type="button"
                onClick={() => alterarMes(1)}
                title="Próximo mês"
                className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-300 transition-colors"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <button
            type="button"
            onClick={carregarEspelho}
            disabled={loading}
            title="Atualizar dados do REP-P"
            className="self-end p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg border border-slate-300 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Botões de Ação: Baixar PDF e Imprimir */}
        <div className="flex items-center space-x-2.5">
          <button
            id="btn_baixar_espelho_pdf"
            type="button"
            onClick={handleBaixarPdf}
            disabled={loading || !espelhoData || gerandoPdf}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors shadow-sm disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{gerandoPdf ? 'Gerando PDF...' : 'Baixar PDF Oficial'}</span>
          </button>

          <button
            id="btn_imprimir_espelho_modal"
            type="button"
            onClick={handleImprimir}
            disabled={loading || !espelhoData}
            className="flex items-center space-x-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-semibold transition-colors shadow-2xs disabled:opacity-50"
          >
            <Printer className="w-4 h-4" />
            <span>Imprimir</span>
          </button>

          {!isEmbedded && onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {sucessoPdf && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-xl flex items-center space-x-3 text-xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>
            <strong>PDF emitido com sucesso!</strong> O documento oficial em conformidade com a Portaria MTP nº 671/2021 foi baixado.
          </span>
        </div>
      )}

      {erro && (
        <div className="bg-rose-50 border border-rose-200 text-rose-800 px-4 py-3 rounded-xl flex items-center space-x-3 text-xs">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{erro}</span>
        </div>
      )}

      {/* Cartão de Espelho de Ponto Oficial */}
      {loading ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500">
          <RefreshCw className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-3" />
          <p className="font-semibold text-sm">Consolidando marcações do REP-P e calculando horas extras...</p>
          <p className="text-xs text-slate-400 mt-1">Processando regras da CLT, DSR (Lei 605/49) e fechamento do período.</p>
        </div>
      ) : espelhoData ? (
        <div
          id="cartao_espelho_ponto_a4"
          className="bg-white rounded-2xl border border-slate-300 p-6 sm:p-8 shadow-sm space-y-6"
        >
          {/* Cabeçalho Oficial do Espelho */}
          <div className="border-b border-slate-200 pb-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 uppercase tracking-wide mb-1.5">
                  <ShieldCheck className="w-3 h-3" />
                  <span>Portaria MTP nº 671/2021 • Art. 84</span>
                </div>
                <h2 className="text-lg sm:text-xl font-black text-slate-900 uppercase tracking-tight">
                  ESPELHO DE PONTO ELETRÔNICO INDIVIDUAL
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Relatório Consolidado de Frequência, Horas Extras, Faltas e DSR • Competência: {espelhoData.competencia}
                </p>
              </div>

              <div className="text-left sm:text-right text-xs">
                <span className="font-bold text-slate-800 block text-sm">
                  {espelhoData.empresa?.razaoSocial || currentFunc?.empresaNome}
                </span>
                <span className="text-slate-500 block font-mono text-[11px]">
                  CNPJ: {espelhoData.empresa?.cnpj || '12.345.678/0001-90'}
                </span>
                <span className="text-slate-400 text-[11px] block mt-0.5">
                  Sistema Homologado: REP-P ContabGest • Dispositivo Oficial
                </span>
              </div>
            </div>

            {/* Ficha do Trabalhador */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t border-slate-100 text-xs bg-slate-50/70 p-3 rounded-xl">
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold block">Nome do Empregado</span>
                <span className="font-extrabold text-slate-900">{espelhoData.funcionario?.nome}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold block">CPF / PIS-PASEP</span>
                <span className="font-mono text-slate-800">
                  {espelhoData.funcionario?.cpf} • {espelhoData.funcionario?.pisPasep}
                </span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold block">Cargo / Departamento</span>
                <span className="text-slate-800 font-medium">
                  {espelhoData.funcionario?.cargo} ({espelhoData.funcionario?.departamento})
                </span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold block">Matrícula / Admissão</span>
                <span className="font-mono text-slate-800">
                  {espelhoData.funcionario?.matricula} • {formatDataPtBr(espelhoData.funcionario?.dataAdmissao)}
                </span>
              </div>
            </div>
          </div>

          {/* Cards de KPIs e Cálculos Consolidados */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {/* Horas Previstas */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block flex items-center gap-1">
                <Clock className="w-3 h-3 text-slate-400" />
                Previstas
              </span>
              <span className="text-base font-bold text-slate-800 font-mono mt-1 block">
                {formatMinutosParaHorasExtenso(espelhoData.totalHorasPrevistasMinutos)}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                {espelhoData.totalDiasUteis || 0} dias úteis
              </span>
            </div>

            {/* Horas Trabalhadas */}
            <div className="bg-blue-50/60 p-3 rounded-xl border border-blue-200">
              <span className="text-[10px] font-bold text-blue-800 uppercase tracking-wider block flex items-center gap-1">
                <Clock className="w-3 h-3 text-blue-500" />
                Trabalhadas
              </span>
              <span className="text-base font-bold text-blue-900 font-mono mt-1 block">
                {formatMinutosParaHorasExtenso(espelhoData.totalHorasTrabalhadasMinutos)}
              </span>
              <span className="text-[10px] text-blue-700 block mt-0.5">
                {espelhoData.totalDiasTrabalhados} dias cumpridos
              </span>
            </div>

            {/* H.E. 50% */}
            <div className="bg-emerald-50/70 p-3 rounded-xl border border-emerald-200">
              <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block flex items-center gap-1">
                <TrendingUp className="w-3 h-3 text-emerald-600" />
                H.E. 50%
              </span>
              <span className="text-base font-bold text-emerald-700 font-mono mt-1 block">
                +{formatMinutosParaHorasExtenso(espelhoData.totalHorasExtras50Minutos || 0)}
              </span>
              <span className="text-[10px] text-emerald-700 font-semibold block mt-0.5">
                {formatMoedaReal(espelhoData.valorHorasExtras50)}
              </span>
            </div>

            {/* H.E. 100% */}
            <div className="bg-teal-50/70 p-3 rounded-xl border border-teal-200">
              <span className="text-[10px] font-bold text-teal-800 uppercase tracking-wider block flex items-center gap-1">
                <TrendingUp className="w-3 h-3 text-teal-600" />
                H.E. 100%
              </span>
              <span className="text-base font-bold text-teal-700 font-mono mt-1 block">
                +{formatMinutosParaHorasExtenso(espelhoData.totalHorasExtras100Minutos || 0)}
              </span>
              <span className="text-[10px] text-teal-700 font-semibold block mt-0.5">
                {formatMoedaReal(espelhoData.valorHorasExtras100)}
              </span>
            </div>

            {/* Faltas & Atrasos */}
            <div className="bg-rose-50/70 p-3 rounded-xl border border-rose-200">
              <span className="text-[10px] font-bold text-rose-800 uppercase tracking-wider block flex items-center gap-1">
                <TrendingDown className="w-3 h-3 text-rose-600" />
                Faltas / Atrasos
              </span>
              <span className="text-base font-bold text-rose-700 font-mono mt-1 block">
                -{formatMinutosParaHorasExtenso(totalNegativoMinutos)}
              </span>
              <span className="text-[10px] text-rose-700 font-semibold block mt-0.5">
                -{formatMoedaReal(espelhoData.valorTotalDescontosPonto)}
              </span>
            </div>

            {/* Saldo Banco de Horas */}
            <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xs">
              <span className="text-[10px] font-bold text-slate-300 uppercase tracking-wider block">
                Saldo Banco Horas
              </span>
              <span
                className={`text-base font-black font-mono mt-1 block ${
                  (espelhoData.saldoHorasMinutos || 0) >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {(espelhoData.saldoHorasMinutos || 0) >= 0 ? '+' : ''}
                {formatMinutosParaHorasExtenso(espelhoData.saldoHorasMinutos)}
              </span>
              <span className="text-[10px] text-slate-300 block mt-0.5">
                Reflexo: {formatMoedaReal(espelhoData.saldoFinanceiroLiquido)}
              </span>
            </div>
          </div>

          {/* Destaque do Reflexo de DSR (Lei 605/49) */}
          <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center space-x-2.5">
              <DollarSign className="w-4 h-4 text-amber-700 shrink-0" />
              <div>
                <span className="font-bold text-amber-900">
                  Reflexo de DSR sobre Horas Extras (Lei nº 605/1949 & Súmula 172 TST):
                </span>{' '}
                <span className="text-amber-800">
                  +{formatMinutosParaHorasExtenso(espelhoData.totalDsrSobreHorasExtrasMinutos || 0)} equivalentes a{' '}
                  <strong>{formatMoedaReal(espelhoData.valorDsrHorasExtras)}</strong> adicionados aos proventos.
                </span>
              </div>
            </div>
            <div className="text-[11px] text-amber-900 font-mono shrink-0 bg-white/70 px-2.5 py-1 rounded-md border border-amber-200">
              Hora Base: {formatMoedaReal(espelhoData.valorHoraNormal)} (Divisor 220)
            </div>
          </div>

          {/* Tabela Diária Consolidada (REP-P) */}
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div className="bg-slate-100 px-4 py-2.5 border-b border-slate-200 flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Grade de Marcações Diárias & Apuração Legal
              </span>
              <span className="text-[11px] text-slate-500 font-medium">
                {espelhoData.dias.length} dias registrados no mês
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-600 font-semibold uppercase tracking-wider text-[10px]">
                    <th className="py-2.5 px-3">Data</th>
                    <th className="py-2.5 px-2">Dia</th>
                    <th className="py-2.5 px-2 text-center">1ª Ent</th>
                    <th className="py-2.5 px-2 text-center">1ª Saí</th>
                    <th className="py-2.5 px-2 text-center">2ª Ent</th>
                    <th className="py-2.5 px-2 text-center">2ª Saí</th>
                    <th className="py-2.5 px-2 text-center">Trabalhado</th>
                    <th className="py-2.5 px-2 text-center">Previsto</th>
                    <th className="py-2.5 px-2 text-center">H.E. 50%</th>
                    <th className="py-2.5 px-2 text-center">H.E. 100%</th>
                    <th className="py-2.5 px-2 text-center">Falta/Atr</th>
                    <th className="py-2.5 px-3">Status / Ocorrência</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {espelhoData.dias.map((d) => {
                    const isFalta = d.isFaltaIntegral;
                    const isDsr = d.tipoDia === 'dsr';
                    const isFeriado = d.tipoDia === 'feriado';
                    const isFerias = d.tipoDia === 'ferias';
                    const isSabado = d.tipoDia === 'sabado_compensado';
                    const isAjustado = d.statusAuditoria === 'ajustado';

                    return (
                      <tr
                        key={d.id}
                        className={`hover:bg-slate-50/80 transition-colors ${
                          isFalta
                            ? 'bg-rose-50/30'
                            : isDsr || isSabado
                            ? 'bg-slate-50/50'
                            : isFeriado
                            ? 'bg-amber-50/30'
                            : isFerias
                            ? 'bg-blue-50/20'
                            : ''
                        }`}
                      >
                        <td className="py-2 px-3 font-mono font-bold text-slate-900 whitespace-nowrap">
                          {d.data.split('-').reverse().join('/')}
                        </td>
                        <td className="py-2 px-2 text-slate-600 font-medium whitespace-nowrap">
                          {d.diaSemana}
                        </td>
                        <td className="py-2 px-2 text-center font-mono font-medium text-slate-800">
                          {d.entrada1 || '--:--'}
                        </td>
                        <td className="py-2 px-2 text-center font-mono font-medium text-slate-800">
                          {d.saidaIntervalo || '--:--'}
                        </td>
                        <td className="py-2 px-2 text-center font-mono font-medium text-slate-800">
                          {d.retornoIntervalo || '--:--'}
                        </td>
                        <td className="py-2 px-2 text-center font-mono font-medium text-slate-800">
                          {d.saida2 || '--:--'}
                        </td>

                        {/* Horas Trabalhadas */}
                        <td className="py-2 px-2 text-center font-mono font-bold text-slate-900">
                          {d.horasTrabalhadasMinutos > 0
                            ? formatMinutosParaHorasExtenso(d.horasTrabalhadasMinutos)
                            : '-'}
                        </td>

                        {/* Horas Previstas */}
                        <td className="py-2 px-2 text-center font-mono text-slate-500">
                          {d.horasPrevistasMinutos > 0
                            ? formatMinutosParaHorasExtenso(d.horasPrevistasMinutos)
                            : '-'}
                        </td>

                        {/* H.E. 50% */}
                        <td className="py-2 px-2 text-center font-mono font-bold text-emerald-600">
                          {(d.horasExtras50Minutos || 0) > 0
                            ? `+${formatMinutosParaHorasExtenso(d.horasExtras50Minutos)}`
                            : '-'}
                        </td>

                        {/* H.E. 100% */}
                        <td className="py-2 px-2 text-center font-mono font-bold text-teal-700">
                          {(d.horasExtras100Minutos || 0) > 0
                            ? `+${formatMinutosParaHorasExtenso(d.horasExtras100Minutos)}`
                            : '-'}
                        </td>

                        {/* Faltas / Atrasos */}
                        <td className="py-2 px-2 text-center font-mono font-bold text-rose-600">
                          {(d.horasNegativasMinutos || 0) > 0
                            ? `-${formatMinutosParaHorasExtenso(d.horasNegativasMinutos)}`
                            : '-'}
                        </td>

                        {/* Ocorrência */}
                        <td className="py-2 px-3 text-[11px]">
                          {isAjustado && (
                            <span className="inline-block mr-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-blue-100 text-blue-800">
                              Ajuste RH
                            </span>
                          )}

                          {isFalta ? (
                            <span className="text-rose-700 font-bold">Falta Não Justificada</span>
                          ) : isFerias ? (
                            <span className="text-blue-700 font-semibold">Férias CLT Art. 129</span>
                          ) : isFeriado ? (
                            <span className="text-amber-800 font-semibold">{d.ocorrenciaDescricao || 'Feriado'}</span>
                          ) : isDsr ? (
                            <span className="text-slate-500">DSR</span>
                          ) : isSabado ? (
                            <span className="text-slate-500">Sábado Compensado</span>
                          ) : d.inconsistencias && d.inconsistencias.length > 0 ? (
                            <span className="text-amber-700 font-medium">{d.inconsistencias[0]}</span>
                          ) : (d.horasExtrasMinutos || 0) > 0 ? (
                            <span className="text-emerald-700 font-medium">Hora Extra Computada</span>
                          ) : (d.horasNegativasMinutos || 0) > 0 ? (
                            <span className="text-rose-600 font-medium">Atraso / Saída Antecipada</span>
                          ) : (
                            <span className="text-slate-400">Jornada Regular</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-slate-300 bg-slate-100/90 font-bold text-slate-900 text-xs">
                    <td colSpan={6} className="py-2.5 px-3 uppercase text-[10px] tracking-wider text-slate-700">
                      TOTAIS CONSOLIDADOS DO PERÍODO
                    </td>
                    <td className="py-2.5 px-2 text-center font-mono">
                      {formatMinutosParaHorasExtenso(espelhoData.totalHorasTrabalhadasMinutos)}
                    </td>
                    <td className="py-2.5 px-2 text-center font-mono text-slate-600">
                      {formatMinutosParaHorasExtenso(espelhoData.totalHorasPrevistasMinutos)}
                    </td>
                    <td className="py-2.5 px-2 text-center font-mono text-emerald-700">
                      +{formatMinutosParaHorasExtenso(espelhoData.totalHorasExtras50Minutos || 0)}
                    </td>
                    <td className="py-2.5 px-2 text-center font-mono text-teal-700">
                      +{formatMinutosParaHorasExtenso(espelhoData.totalHorasExtras100Minutos || 0)}
                    </td>
                    <td className="py-2.5 px-2 text-center font-mono text-rose-700">
                      -{formatMinutosParaHorasExtenso(totalNegativoMinutos)}
                    </td>
                    <td className="py-2.5 px-3 font-mono font-extrabold text-slate-900">
                      Saldo: {formatMinutosParaHorasExtenso(espelhoData.saldoHorasMinutos)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Autenticação Digital & Assinaturas Oficiais (Portaria 671 MTP) */}
          <div className="pt-6 border-t border-slate-300 space-y-6">
            <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl text-xs text-slate-600 space-y-1.5">
              <p className="font-semibold text-slate-800">Declaração de Conformidade & Ciência do Trabalhador:</p>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Reconheço a integridade e exatidão de todas as marcações de horário de entrada, saídas para intervalo,
                retornos e término de expediente aqui apuradas pelo Registrador Eletrônico de Ponto via Programa (REP-P),
                para fins de apuração de folha de pagamento nos termos da Portaria MTP nº 671/2021 e do Art. 74 da CLT.
              </p>
              <p className="font-mono text-[10px] text-slate-400 pt-1">
                Hash SHA-256 de Autenticação: {espelhoData.hashAutenticidade || 'E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 text-xs text-slate-700 pt-4">
              <div className="text-center pt-8 border-t border-slate-400">
                <p className="font-bold text-slate-900">{espelhoData.funcionario?.nome}</p>
                <p className="text-[11px] text-slate-500">Assinatura do Empregado (CPF: {espelhoData.funcionario?.cpf})</p>
              </div>

              <div className="text-center pt-8 border-t border-slate-400">
                <p className="font-bold text-slate-900">{espelhoData.empresa?.razaoSocial}</p>
                <p className="text-[11px] text-slate-500">Departamento de Recursos Humanos / Empregador</p>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );

  if (isEmbedded) {
    return containerContent;
  }

  // Se modal flutuante:
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-slate-100 rounded-3xl shadow-2xl border border-slate-300 w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Top Header do Modal */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2.5">
            <FileText className="w-5 h-5 text-blue-400" />
            <div>
              <h3 className="text-sm font-bold tracking-tight">Gerador de Espelho de Ponto Individual (PDF)</h3>
              <p className="text-[11px] text-slate-400">
                REP-P • Portaria MTP nº 671/2021 • Apuração Automática de Horas Extras e Faltas
              </p>
            </div>
          </div>
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Corpo do Modal com Scroll */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1">{containerContent}</div>
      </div>
    </div>
  );
};
