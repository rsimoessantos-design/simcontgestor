import React, { useState } from 'react';
import {
  X,
  Printer,
  Copy,
  Check,
  ShieldCheck,
  Clock,
  Building2,
  User,
  QrCode,
  Download,
} from 'lucide-react';
import { ComprovantePontoEmitido } from '../../types';

interface ComprovantePontoModalProps {
  isOpen: boolean;
  onClose: () => void;
  comprovante: ComprovantePontoEmitido | null;
}

export const ComprovantePontoModal: React.FC<ComprovantePontoModalProps> = ({
  isOpen,
  onClose,
  comprovante,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !comprovante) return null;

  const handleCopyHash = () => {
    navigator.clipboard.writeText(comprovante.hashRegistro);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  // Format date and time
  const dataDate = new Date(comprovante.dataHora);
  const dataFormatada = dataDate.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
  const horaFormatada = dataDate.toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  return (
    <div
      id="modal_comprovante_ponto_backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto"
    >
      <div
        id="modal_comprovante_ponto_content"
        className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden flex flex-col my-8 animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Modal Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold">Comprovante de Ponto Oficial</h3>
              <p className="text-xs text-slate-300">Conformidade Portaria MTE nº 671/2021 (REP-P)</p>
            </div>
          </div>
          <button
            id="btn_fechar_comprovante_top"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body / Recibo Térmico */}
        <div className="p-6 bg-slate-50 flex-1 overflow-y-auto">
          <div
            id="comprovante_papel_recibo"
            className="bg-white p-6 rounded-xl border border-slate-300 shadow-sm font-mono text-xs text-slate-800 space-y-4 relative"
          >
            {/* Marca d'água de autenticidade */}
            <div className="text-center pb-3 border-b border-dashed border-slate-300">
              <p className="font-bold text-sm tracking-wider uppercase text-slate-900">
                COMPROVANTE DE REGISTRO DE PONTO DO TRABALHADOR
              </p>
              <p className="text-[10px] text-slate-700 mt-0.5">
                PROGRAMA DE TRATAMENTO DE REGISTRO DE PONTO ELETRÔNICO (REP-P)
              </p>
            </div>

            {/* Dados Empregador */}
            <div className="space-y-1 pb-3 border-b border-dashed border-slate-300">
              <p className="text-[10px] uppercase font-bold text-slate-700">Empregador:</p>
              <p className="font-bold text-slate-900">{comprovante.empresa.razaoSocial}</p>
              <p className="text-slate-700">CNPJ: {comprovante.empresa.cnpj}</p>
              {comprovante.empresa.endereco && (
                <p className="text-slate-700 text-[11px] truncate">{comprovante.empresa.endereco}</p>
              )}
            </div>

            {/* Dados Trabalhador */}
            <div className="space-y-1 pb-3 border-b border-dashed border-slate-300">
              <p className="text-[10px] uppercase font-bold text-slate-700">Trabalhador:</p>
              <p className="font-bold text-slate-900">{comprovante.funcionario.nome}</p>
              <div className="grid grid-cols-2 gap-2 text-slate-700">
                <p>CPF: {comprovante.funcionario.cpf}</p>
                <p>PIS/PASEP: {comprovante.funcionario.pisPasep || 'Não informado'}</p>
                <p>Matrícula: {comprovante.funcionario.matricula}</p>
                <p>Cargo: {comprovante.funcionario.cargo || 'Não informado'}</p>
              </div>
            </div>

            {/* Dados da Marcação */}
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-2">
              <div className="flex items-center justify-between text-slate-900">
                <span className="font-bold uppercase text-[11px]">NSR (Nº Seq. Registro):</span>
                <span className="font-bold text-sm text-blue-800">#{comprovante.nsr}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-700">Data da Batida:</span>
                <span className="font-bold text-slate-900">{dataFormatada}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-700">Horário Oficial:</span>
                <span className="font-bold text-base text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-300">
                  {horaFormatada}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-700">Tipo de Marcação:</span>
                <span className="font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded text-[11px]">
                  {comprovante.tipoDescricao}
                </span>
              </div>
            </div>

            {/* Geolocalização / Dispositivo */}
            <div className="text-[11px] text-slate-700 space-y-1 pb-2 border-b border-dashed border-slate-300">
              <p>
                <span className="font-bold text-slate-800">Terminal Homologado:</span> {comprovante.dispositivo}
              </p>
              <p>
                <span className="font-bold text-slate-800">Localização Capturada:</span>{' '}
                {comprovante.geolocalizacao || 'Coordenadas via GPS'}
              </p>
            </div>

            {/* Chave Criptográfica SHA-256 */}
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold text-slate-700">
                  Assinatura Digital SHA-256 (MTE):
                </span>
                <button
                  id="btn_copiar_hash_comprovante"
                  onClick={handleCopyHash}
                  className="text-xs text-blue-800 hover:text-blue-900 flex items-center space-x-1 font-sans font-medium"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-700" />
                      <span className="text-emerald-700 text-[11px]">Copiado</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span className="text-[11px]">Copiar</span>
                    </>
                  )}
                </button>
              </div>
              <div className="p-2 bg-slate-100 rounded text-[9px] break-all leading-tight text-slate-700 border border-slate-200 select-all">
                {comprovante.hashRegistro}
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="bg-white px-6 py-4 border-t border-slate-200 flex items-center justify-between">
          <button
            id="btn_imprimir_comprovante"
            onClick={handlePrint}
            className="flex items-center space-x-2 px-4 py-2 bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-lg text-sm font-medium transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Imprimir Recibo</span>
          </button>
          <button
            id="btn_fechar_comprovante_bottom"
            onClick={onClose}
            className="px-5 py-2 bg-blue-600 text-white hover:bg-blue-700 rounded-lg text-sm font-medium shadow-sm transition-colors"
          >
            Concluir
          </button>
        </div>
      </div>
    </div>
  );
};
