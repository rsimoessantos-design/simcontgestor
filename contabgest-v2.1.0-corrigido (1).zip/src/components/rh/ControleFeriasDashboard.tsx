import React, { useState, useEffect, useMemo } from 'react';
import {
  Umbrella,
  Calendar,
  AlertTriangle,
  Clock,
  CheckCircle2,
  FileText,
  DollarSign,
  Plus,
  RefreshCw,
  Search,
  Filter,
  Eye,
  Trash2,
  Printer,
  ChevronRight,
  TrendingDown,
  Sparkles,
  Info,
  Building2,
  Users,
  Briefcase,
  Layers,
  Calculator,
  ShieldAlert,
} from 'lucide-react';
import {
  Funcionario,
  Empresa,
  PeriodoGozoFerias,
  PainelAvisosFeriasResponse,
  AlertaFeriasItem,
  PeriodoAquisitivoHistorico,
  DocumentoAvisoReciboFerias,
  StatusPeriodoFerias,
} from '../../types';
import { api } from '../../services/api';
import { FeriasAfastamentoModal, FeriasRegistrationData } from './FeriasAfastamentoModal';
import { DocumentoFeriasModal } from './DocumentoFeriasModal';

interface ControleFeriasDashboardProps {
  funcionarios: Funcionario[];
  empresas: Empresa[];
  selectedEmpresa: Empresa | null;
  onRefreshRH: () => Promise<void>;
}

export const ControleFeriasDashboard: React.FC<ControleFeriasDashboardProps> = ({
  funcionarios,
  empresas,
  selectedEmpresa,
  onRefreshRH,
}) => {
  // Sub-abas do controle de férias
  const [subTab, setSubTab] = useState<'painel' | 'periodos' | 'extrato' | 'simulador'>('painel');

  // Estado dos dados da API
  const [loading, setLoading] = useState(false);
  const [painelAvisos, setPainelAvisos] = useState<PainelAvisosFeriasResponse | null>(null);
  const [periodosGozo, setPeriodosGozo] = useState<PeriodoGozoFerias[]>([]);

  // Filtros de listagem
  const [filtroStatus, setFiltroStatus] = useState<string>('todos');
  const [filtroFuncionario, setFiltroFuncionario] = useState<string>('todos');
  const [filtroAno, setFiltroAno] = useState<string>('2026');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Modals
  const [isModalFeriasOpen, setIsModalFeriasOpen] = useState(false);
  const [selectedFuncionarioParaFerias, setSelectedFuncionarioParaFerias] = useState<Funcionario | null>(null);
  const [sugestaoDataInicio, setSugestaoDataInicio] = useState<string | undefined>(undefined);

  const [isDocModalOpen, setIsDocModalOpen] = useState(false);
  const [docSelecionado, setDocSelecionado] = useState<DocumentoAvisoReciboFerias | null>(null);
  const [loadingDoc, setLoadingDoc] = useState(false);

  // Extrato do Colaborador selecionado
  const [selectedFuncionarioExtratoId, setSelectedFuncionarioExtratoId] = useState<string>('');
  const [extratoColaborador, setExtratoColaborador] = useState<{
    funcionario: Funcionario;
    periodos: PeriodoAquisitivoHistorico[];
    saldoTotalDisponivel: number;
    avisos: AlertaFeriasItem[];
  } | null>(null);
  const [loadingExtrato, setLoadingExtrato] = useState(false);

  // Simulador de Férias State
  const [simSalario, setSimSalario] = useState<number>(4500);
  const [simDiasGozo, setSimDiasGozo] = useState<number>(30);
  const [simAbono, setSimAbono] = useState<boolean>(false);
  const [simAdiant13, setSimAdiant13] = useState<boolean>(false);
  const [simDependentes, setSimDependentes] = useState<number>(0);
  const [simResultado, setSimResultado] = useState<any | null>(null);

  // Carregar dados de férias
  const loadFeriasData = async () => {
    try {
      setLoading(true);
      const empId = selectedEmpresa ? selectedEmpresa.id : 'todas';

      const [painel, periodos] = await Promise.all([
        api.getPainelAvisosFerias(empId),
        api.getPeriodosFerias({
          empresaId: empId,
          ano: filtroAno && filtroAno !== 'todos' ? Number(filtroAno) : undefined,
        }),
      ]);

      setPainelAvisos(painel);
      setPeriodosGozo(periodos);

      // Se nenhum funcionário estiver selecionado para extrato, selecionar o primeiro
      if (!selectedFuncionarioExtratoId && funcionarios.length > 0) {
        setSelectedFuncionarioExtratoId(funcionarios[0].id);
      }
    } catch (err) {
      console.error('Erro ao carregar controle de férias:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadFeriasData();
  }, [selectedEmpresa, filtroAno]);

  // Carregar extrato do funcionário quando a seleção mudar
  useEffect(() => {
    if (!selectedFuncionarioExtratoId) return;

    const fetchExtrato = async () => {
      try {
        setLoadingExtrato(true);
        const data = await api.getCalculoSaldosPeriodosFuncionario(selectedFuncionarioExtratoId);
        setExtratoColaborador(data);
      } catch (err) {
        console.error('Erro ao buscar extrato do funcionário:', err);
      } finally {
        setLoadingExtrato(false);
      }
    };

    fetchExtrato();
  }, [selectedFuncionarioExtratoId]);

  // Executar simulação
  useEffect(() => {
    const runSimulacao = async () => {
      try {
        const res = await api.simularCalculoFerias({
          salarioBase: Number(simSalario),
          diasGozo: Number(simDiasGozo),
          abonoPecuniario: simAbono,
          diasAbono: simAbono ? 10 : 0,
          adiantamentoDecimoTerceiro: simAdiant13,
          dependentesIrrf: Number(simDependentes),
        });
        setSimResultado(res);
      } catch (err) {
        console.error('Erro ao simular:', err);
      }
    };
    runSimulacao();
  }, [simSalario, simDiasGozo, simAbono, simAdiant13, simDependentes]);

  // Ação: Abrir modal para agendar férias de colaborador
  const handleAgendarFerias = (func: Funcionario, dataSugerida?: string) => {
    setSelectedFuncionarioParaFerias(func);
    setSugestaoDataInicio(dataSugerida);
    setIsModalFeriasOpen(true);
  };

  // Ação: Gravação de férias avançada
  const handleSaveFeriasAvancado = async (dados: FeriasRegistrationData) => {
    await api.registrarPeriodoGozo(dados);
    await loadFeriasData();
    await onRefreshRH();
  };

  // Ação: Cancelar período de férias
  const handleCancelarPeriodo = async (periodoId: string) => {
    if (!confirm('Deseja realmente cancelar este período de férias? O saldo de dias será restituído ao colaborador.')) {
      return;
    }
    try {
      await api.cancelarPeriodoGozo(periodoId);
      await loadFeriasData();
      await onRefreshRH();
    } catch (err: any) {
      alert(err.message || 'Erro ao cancelar período');
    }
  };

  // Ação: Visualizar documento oficial (Aviso e Recibo CLT)
  const handleVisualizarDocumento = async (periodoId: string) => {
    try {
      setIsDocModalOpen(true);
      setLoadingDoc(true);
      const doc = await api.getDocumentoAvisoRecibo(periodoId);
      setDocSelecionado(doc);
    } catch (err: any) {
      alert(err.message || 'Erro ao emitir documento de férias');
      setIsDocModalOpen(false);
    } finally {
      setLoadingDoc(false);
    }
  };

  // Helpers de formatação
  const formatMoney = (val?: number) => {
    return (val || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '---';
    const [ano, mes, dia] = dateStr.split('-');
    if (ano && mes && dia) return `${dia}/${mes}/${ano}`;
    return new Date(dateStr).toLocaleDateString('pt-BR');
  };

  // Filtros aplicados na lista de períodos
  const periodosFiltrados = useMemo(() => {
    return periodosGozo.filter((p) => {
      if (filtroStatus !== 'todos' && p.status !== filtroStatus) return false;
      if (filtroFuncionario !== 'todos' && p.funcionarioId !== filtroFuncionario) return false;
      if (searchTerm) {
        const termo = searchTerm.toLowerCase();
        const matchNome = p.funcionarioNome.toLowerCase().includes(termo);
        const matchCargo = p.funcionarioCargo.toLowerCase().includes(termo);
        const matchObs = p.observacoes ? p.observacoes.toLowerCase().includes(termo) : false;
        if (!matchNome && !matchCargo && !matchObs) return false;
      }
      return true;
    });
  }, [periodosGozo, filtroStatus, filtroFuncionario, searchTerm]);

  // Badges de Status do Período
  const statusPeriodoBadges: Record<StatusPeriodoFerias, { label: string; class: string }> = {
    planejado: { label: 'Planejado', class: 'bg-slate-100 text-slate-700 border-slate-200' },
    aprovado: { label: 'Aprovado', class: 'bg-blue-50 text-blue-700 border-blue-200' },
    em_gozo: { label: 'Em Gozo Atualmente', class: 'bg-amber-100 text-amber-900 border-amber-300 font-bold' },
    concluido: { label: 'Concluído', class: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
    cancelado: { label: 'Cancelado', class: 'bg-rose-50 text-rose-700 border-rose-200' },
  };

  return (
    <div className="space-y-6">
      {/* Top Banner de Avisos & Indicadores CLT */}
      {painelAvisos && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Card 1: Monitoramento */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
            <span className="text-xs font-semibold text-slate-500 flex items-center gap-1.5">
              <Users className="w-4 h-4 text-indigo-600" />
              Monitorados
            </span>
            <div className="mt-2">
              <span className="text-2xl font-black text-slate-900">{painelAvisos.totalFuncionarios}</span>
              <p className="text-[11px] text-slate-400">colaboradores ativos</p>
            </div>
          </div>

          {/* Card 2: Em Gozo Hoje */}
          <div className="bg-amber-50/70 p-4 rounded-xl border border-amber-200 shadow-sm flex flex-col justify-between">
            <span className="text-xs font-semibold text-amber-800 flex items-center gap-1.5">
              <Umbrella className="w-4 h-4 text-amber-600" />
              Em Férias Hoje
            </span>
            <div className="mt-2">
              <span className="text-2xl font-black text-amber-900">{painelAvisos.emGozoHoje}</span>
              <p className="text-[11px] text-amber-700">ausências ativas</p>
            </div>
          </div>

          {/* Card 3: Vencidas em Dobro (Art. 137 CLT) */}
          <div className="bg-rose-50/80 p-4 rounded-xl border border-rose-300 shadow-sm flex flex-col justify-between">
            <span className="text-xs font-bold text-rose-800 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              Vencidas (Dobro)
            </span>
            <div className="mt-2">
              <div className="flex items-baseline gap-1.5">
                <span className="text-2xl font-black text-rose-700">{painelAvisos.vencidasEmDobro}</span>
                {painelAvisos.riscoFinanceiroDobroTotal > 0 && (
                  <span className="text-[11px] text-rose-600 font-bold">
                    ({formatMoney(painelAvisos.riscoFinanceiroDobroTotal)})
                  </span>
                )}
              </div>
              <p className="text-[11px] text-rose-700 font-medium">Art. 137 CLT - Risco</p>
            </div>
          </div>

          {/* Card 4: Vencendo em 30d */}
          <div className="bg-orange-50/70 p-4 rounded-xl border border-orange-200 shadow-sm flex flex-col justify-between">
            <span className="text-xs font-semibold text-orange-800 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-orange-600" />
              Vencendo em 30d
            </span>
            <div className="mt-2">
              <span className="text-2xl font-black text-orange-900">{painelAvisos.vencendoEm30Dias}</span>
              <p className="text-[11px] text-orange-700">ação imediata</p>
            </div>
          </div>

          {/* Card 5: Vencendo em 60d */}
          <div className="bg-blue-50/70 p-4 rounded-xl border border-blue-200 shadow-sm flex flex-col justify-between">
            <span className="text-xs font-semibold text-blue-800 flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-blue-600" />
              Vencendo em 60d
            </span>
            <div className="mt-2">
              <span className="text-2xl font-black text-blue-900">{painelAvisos.vencendoEm60Dias}</span>
              <p className="text-[11px] text-blue-700">aviso prévio (30d)</p>
            </div>
          </div>

          {/* Card 6: Saldo Total em Dias */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between">
            <span className="text-xs font-semibold text-slate-500 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-indigo-600" />
              Saldo Acumulado
            </span>
            <div className="mt-2">
              <span className="text-2xl font-black text-slate-900">{painelAvisos.saldoTotalDiasEmpresa}</span>
              <p className="text-[11px] text-slate-400">dias de direito</p>
            </div>
          </div>
        </div>
      )}

      {/* Navegação de Sub-abas */}
      <div className="flex items-center justify-between border-b border-slate-200 bg-white px-4 rounded-xl shadow-sm">
        <div className="flex items-center gap-2 overflow-x-auto">
          {[
            { id: 'painel', label: 'Alertas & Compliance CLT', icon: AlertTriangle, count: painelAvisos?.avisos.length },
            { id: 'periodos', label: 'Programação de Gozo', icon: Calendar, count: periodosGozo.length },
            { id: 'extrato', label: 'Extrato por Colaborador', icon: FileText },
            { id: 'simulador', label: 'Simulador Financeiro', icon: Calculator },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = subTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setSubTab(tab.id as any)}
                className={`py-3 px-4 text-sm font-semibold border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
                  active
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {tab.count !== undefined && tab.count > 0 && (
                  <span
                    className={`px-2 py-0.5 text-xs rounded-full font-bold ${
                      tab.id === 'painel' && (painelAvisos?.vencidasEmDobro || 0) > 0
                        ? 'bg-rose-100 text-rose-700'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2 py-2">
          <button
            onClick={loadFeriasData}
            disabled={loading}
            className="p-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
            title="Atualizar dados de férias"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-indigo-600' : ''}`} />
          </button>
          <button
            onClick={() => {
              if (funcionarios.length > 0) {
                handleAgendarFerias(funcionarios[0]);
              }
            }}
            className="px-3.5 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Agendar Férias</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SUB-ABA 1: PAINEL DE AVISOS & COMPLIANCE CLT */}
      {/* ========================================================================= */}
      {subTab === 'painel' && (
        <div className="space-y-4">
          {/* Card Explicativo das Regras Legais CLT */}
          <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white p-5 rounded-2xl shadow-sm space-y-2">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-400" />
              <h3 className="font-bold text-sm tracking-tight">
                Regras Fundamentais do Regime de Férias CLT (Decreto-Lei nº 5.452/1943)
              </h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-slate-300 pt-1">
              <div className="bg-white/10 p-2.5 rounded-xl border border-white/10">
                <span className="font-bold text-white block mb-0.5">Art. 135 — Comunicação Prévia:</span>
                O empregador deve avisar o empregado com no mínimo <strong>30 dias de antecedência</strong> por escrito.
              </div>
              <div className="bg-white/10 p-2.5 rounded-xl border border-white/10">
                <span className="font-bold text-white block mb-0.5">Art. 145 — Prazo de Pagamento:</span>
                A remuneração das férias e o 1/3 constitucional devem ser pagos <strong>até 2 dias antes</strong> do início do gozo.
              </div>
              <div className="bg-white/10 p-2.5 rounded-xl border border-white/10">
                <span className="font-bold text-rose-300 block mb-0.5">Art. 137 — Dobra Salarial:</span>
                Férias concedidas após o limite concessivo geram <strong>pagamento em dobro</strong> de todo o período vencido.
              </div>
            </div>
          </div>

          {/* Lista de Alertas Ativos */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
            <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Alertas Automáticos de Vencimento de Período Concessivo
                </h3>
                <p className="text-xs text-slate-500">
                  Notificações preventivas para evitar multas trabalhistas e pagamento em dobro
                </p>
              </div>
              <span className="text-xs font-semibold text-slate-500">
                {painelAvisos?.avisos.length || 0} colaboradores com avisos
              </span>
            </div>

            {!painelAvisos || painelAvisos.avisos.length === 0 ? (
              <div className="p-12 text-center text-slate-400">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-2 opacity-80" />
                <p className="text-sm font-bold text-slate-700">Todos os períodos em conformidade!</p>
                <p className="text-xs text-slate-400">
                  Nenhum colaborador possui férias vencidas ou com vencimento próximo nos próximos 60 dias.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {painelAvisos.avisos.map((aviso) => {
                  const func = funcionarios.find((f) => f.id === aviso.funcionarioId);
                  const isVencido = aviso.tipo === 'vencido_dobro';
                  const isUrgente = aviso.tipo === 'urgente_30';

                  return (
                    <div
                      key={`${aviso.funcionarioId}-${aviso.periodoAquisitivoFim}`}
                      className={`p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-colors ${
                        isVencido
                          ? 'bg-rose-50/40 hover:bg-rose-50/80 border-l-4 border-l-rose-600'
                          : isUrgente
                          ? 'bg-orange-50/30 hover:bg-orange-50/60 border-l-4 border-l-orange-500'
                          : 'hover:bg-slate-50 border-l-4 border-l-blue-400'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-sm text-slate-900">{aviso.funcionarioNome}</span>
                          <span className="text-xs text-slate-500">• {aviso.funcionarioCargo}</span>
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                              isVencido
                                ? 'bg-rose-100 text-rose-800'
                                : isUrgente
                                ? 'bg-orange-100 text-orange-800'
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {isVencido ? 'Vencido em Dobro' : isUrgente ? 'Urgente (30d)' : 'Atenção (60d)'}
                          </span>
                        </div>

                        <p className="text-xs text-slate-700 font-medium">{aviso.mensagem}</p>

                        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 pt-0.5">
                          <span>
                            Aquisitivo: <strong>{formatDate(aviso.periodoAquisitivoInicio)} a {formatDate(aviso.periodoAquisitivoFim)}</strong>
                          </span>
                          <span>•</span>
                          <span>
                            Limite Concessivo: <strong>{formatDate(aviso.limiteConcessivo)}</strong>
                          </span>
                          <span>•</span>
                          <span className="text-amber-700 font-bold">
                            Saldo: {aviso.saldoDias} dias
                          </span>
                          {aviso.riscoFinanceiroDobro && (
                            <>
                              <span>•</span>
                              <span className="text-rose-700 font-bold">
                                Custo da Dobra Estimado: {formatMoney(aviso.riscoFinanceiroDobro)}
                              </span>
                            </>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => {
                            setSelectedFuncionarioExtratoId(aviso.funcionarioId);
                            setSubTab('extrato');
                          }}
                          className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-sm transition-colors"
                        >
                          Ver Extrato
                        </button>
                        {func && (
                          <button
                            onClick={() => handleAgendarFerias(func, aviso.sugestaoInicioGozo)}
                            className={`px-3.5 py-1.5 text-xs font-bold rounded-lg shadow-sm flex items-center gap-1.5 transition-colors ${
                              isVencido
                                ? 'bg-rose-600 hover:bg-rose-700 text-white'
                                : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                            }`}
                          >
                            <Umbrella className="w-3.5 h-3.5" />
                            <span>Agendar Imediatamente</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-ABA 2: PROGRAMAÇÃO E HISTÓRICO DE GOZO */}
      {/* ========================================================================= */}
      {subTab === 'periodos' && (
        <div className="space-y-4">
          {/* Barra de Filtros */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
              <div className="relative w-full md:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Buscar colaborador ou cargo..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <select
                value={filtroStatus}
                onChange={(e) => setFiltroStatus(e.target.value)}
                className="px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
              >
                <option value="todos">Todos os Status</option>
                <option value="em_gozo">Em Gozo Atualmente</option>
                <option value="planejado">Planejados</option>
                <option value="aprovado">Aprovados</option>
                <option value="concluido">Concluídos</option>
                <option value="cancelado">Cancelados</option>
              </select>

              <select
                value={filtroAno}
                onChange={(e) => setFiltroAno(e.target.value)}
                className="px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
              >
                <option value="todos">Todos os Anos</option>
                <option value="2026">Ano 2026</option>
                <option value="2025">Ano 2025</option>
                <option value="2024">Ano 2024</option>
              </select>
            </div>

            <span className="text-xs text-slate-500 whitespace-nowrap">
              Mostrando <strong>{periodosFiltrados.length}</strong> de {periodosGozo.length} períodos
            </span>
          </div>

          {/* Tabela de Períodos de Gozo */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                    <th className="py-3 px-4">Colaborador</th>
                    <th className="py-3 px-4">Período de Gozo</th>
                    <th className="py-3 px-4 text-center">Dias / Fracionamento</th>
                    <th className="py-3 px-4">Aquisitivo Ref.</th>
                    <th className="py-3 px-4">Abono / 13º</th>
                    <th className="py-3 px-4 text-right">Valor Líquido</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Ações CLT</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {periodosFiltrados.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-400">
                        Nenhum período de férias encontrado com os filtros selecionados.
                      </td>
                    </tr>
                  ) : (
                    periodosFiltrados.map((p) => {
                      const badge = statusPeriodoBadges[p.status] || {
                        label: p.status,
                        class: 'bg-slate-100 text-slate-700',
                      };

                      return (
                        <tr key={p.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="py-3.5 px-4">
                            <span className="font-bold text-slate-900 block">{p.funcionarioNome}</span>
                            <span className="text-slate-500 text-[11px]">{p.funcionarioCargo}</span>
                          </td>
                          <td className="py-3.5 px-4 font-medium text-slate-800">
                            {formatDate(p.dataInicio)} até {formatDate(p.dataFim)}
                            <span className="text-slate-400 block text-[11px]">
                              Retorno: {formatDate(p.dataRetornoTrabalho)}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <span className="font-black text-amber-700 text-sm block">{p.diasGozo} dias</span>
                            <span className="text-[10px] text-slate-500 uppercase">
                              {p.fracionamentoNumero}º período
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-slate-600 text-[11px]">
                            {formatDate(p.periodoAquisitivoInicio)} a {formatDate(p.periodoAquisitivoFim)}
                            <span className="text-slate-400 block">
                              Limite: {formatDate(p.limiteConcessivo)}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-[11px] text-slate-600">
                            {p.abonoPecuniario ? (
                              <span className="px-1.5 py-0.5 bg-amber-50 text-amber-800 rounded font-semibold block w-fit mb-0.5">
                                Abono: {p.diasAbono}d
                              </span>
                            ) : (
                              <span className="text-slate-400 block">Sem abono</span>
                            )}
                            {p.adiantamentoDecimoTerceiro && (
                              <span className="px-1.5 py-0.5 bg-indigo-50 text-indigo-800 rounded font-semibold block w-fit">
                                + 1ª Parc 13º
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-700">
                            {formatMoney(p.valorTotalLiquido)}
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <span className={`px-2 py-0.5 rounded-full text-[11px] border ${badge.class}`}>
                              {badge.label}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => handleVisualizarDocumento(p.id)}
                                title="Emitir Aviso Prévio e Recibo Oficial CLT"
                                className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg border border-slate-200 transition-colors"
                              >
                                <FileText className="w-4 h-4" />
                              </button>
                              {p.status !== 'cancelado' && p.status !== 'concluido' && (
                                <button
                                  onClick={() => handleCancelarPeriodo(p.id)}
                                  title="Cancelar Férias e Restituir Saldo"
                                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg border border-slate-200 transition-colors"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-ABA 3: EXTRATO COMPLETO POR COLABORADOR */}
      {/* ========================================================================= */}
      {subTab === 'extrato' && (
        <div className="space-y-4">
          {/* Seletor de Colaborador */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <label className="text-xs font-bold text-slate-700 whitespace-nowrap">
                Selecione o Colaborador:
              </label>
              <select
                value={selectedFuncionarioExtratoId}
                onChange={(e) => setSelectedFuncionarioExtratoId(e.target.value)}
                className="px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:outline-none min-w-[280px]"
              >
                {funcionarios.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.nomeCompleto} ({f.cargoNome}) - Saldo: {f.diasFeriasSaldo ?? 30}d
                  </option>
                ))}
              </select>
            </div>

            {extratoColaborador && (
              <button
                onClick={() => handleAgendarFerias(extratoColaborador.funcionario)}
                className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-sm flex items-center gap-1.5 transition-colors self-start sm:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>Registrar Férias para {extratoColaborador.funcionario.nomeCompleto.split(' ')[0]}</span>
              </button>
            )}
          </div>

          {loadingExtrato ? (
            <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center text-slate-500">
              <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
              <p className="text-xs">Calculando linha do tempo e períodos aquisitivos CLT...</p>
            </div>
          ) : !extratoColaborador ? (
            <div className="bg-white p-12 rounded-2xl border border-slate-200 text-center text-slate-400 text-xs">
              Selecione um colaborador para carregar o extrato detalhado de férias.
            </div>
          ) : (
            <div className="space-y-4">
              {/* Card Resumo do Funcionário */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <span className="text-xs text-slate-400 block font-medium">Colaborador(a)</span>
                  <span className="font-bold text-slate-900 text-base block">
                    {extratoColaborador.funcionario.nomeCompleto}
                  </span>
                  <span className="text-xs text-slate-500">
                    {extratoColaborador.funcionario.cargoNome} • Adm: {formatDate(extratoColaborador.funcionario.dataAdmissao)}
                  </span>
                </div>

                <div>
                  <span className="text-xs text-slate-400 block font-medium">Salário Base Contratual</span>
                  <span className="font-bold text-slate-900 text-base block">
                    {formatMoney(extratoColaborador.funcionario.salarioBase)}
                  </span>
                  <span className="text-xs text-slate-500">
                    Diária de férias: {formatMoney((extratoColaborador.funcionario.salarioBase || 0) / 30)}
                  </span>
                </div>

                <div>
                  <span className="text-xs text-slate-400 block font-medium">Saldo Total Disponível</span>
                  <span className="font-black text-amber-600 text-2xl block">
                    {extratoColaborador.saldoTotalDisponivel} dias
                  </span>
                  <span className="text-xs text-slate-500">
                    Direito acumulado atual
                  </span>
                </div>

                <div>
                  <span className="text-xs text-slate-400 block font-medium">Status no Módulo RH</span>
                  <span
                    className={`inline-block px-3 py-1 rounded-full text-xs font-bold mt-1 ${
                      extratoColaborador.funcionario.status === 'ferias'
                        ? 'bg-amber-100 text-amber-900 border border-amber-300'
                        : extratoColaborador.funcionario.status === 'afastado'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {extratoColaborador.funcionario.status === 'ferias'
                      ? 'Em Férias Atualmente'
                      : extratoColaborador.funcionario.status === 'afastado'
                      ? 'Afastado INSS'
                      : 'Ativo / Trabalhando'}
                  </span>
                </div>
              </div>

              {/* Tabela de Linha do Tempo dos Períodos Aquisitivos */}
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
                <div className="px-6 py-4 border-b border-slate-200 bg-slate-50">
                  <h4 className="font-bold text-sm text-slate-900">
                    Histórico de Períodos Aquisitivos e Limites Concessivos (CLT)
                  </h4>
                  <p className="text-xs text-slate-500">
                    Controle de ciclos anuais de aquisição (12 meses trabalhados) e concessão (12 meses seguintes)
                  </p>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 font-bold text-slate-600 uppercase text-[11px]">
                        <th className="py-3 px-4">Período Aquisitivo</th>
                        <th className="py-3 px-4">Limite Concessivo</th>
                        <th className="py-3 px-4 text-center">Dias Adquiridos</th>
                        <th className="py-3 px-4 text-center">Gozados / Vendidos</th>
                        <th className="py-3 px-4 text-center">Saldo</th>
                        <th className="py-3 px-4 text-center">Situação Legal</th>
                        <th className="py-3 px-4 text-right">Ação</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {extratoColaborador.periodos.map((p) => {
                        const isVencido = p.status === 'vencido_dobro';
                        const isConcessao = p.status === 'em_concessao';
                        const isQuitado = p.status === 'quitado';

                        return (
                          <tr
                            key={`${p.inicioAquisitivo}-${p.fimAquisitivo}`}
                            className={`hover:bg-slate-50/80 transition-colors ${
                              isVencido ? 'bg-rose-50/30' : ''
                            }`}
                          >
                            <td className="py-3.5 px-4 font-semibold text-slate-900">
                              {formatDate(p.inicioAquisitivo)} a {formatDate(p.fimAquisitivo)}
                            </td>
                            <td className="py-3.5 px-4 font-medium text-slate-800">
                              {formatDate(p.limiteConcessivo)}
                              {isVencido && (
                                <span className="text-rose-600 font-bold block text-[11px]">
                                  Expirou o prazo legal!
                                </span>
                              )}
                            </td>
                            <td className="py-3.5 px-4 text-center font-bold text-slate-800">
                              {p.diasAdquiridos}d
                            </td>
                            <td className="py-3.5 px-4 text-center text-slate-600">
                              {p.diasGozados}d gozados
                              {p.diasAbonoVendidos > 0 && ` + ${p.diasAbonoVendidos}d abono`}
                            </td>
                            <td className="py-3.5 px-4 text-center font-black text-sm text-amber-700">
                              {p.saldoRemanescente}d
                            </td>
                            <td className="py-3.5 px-4 text-center">
                              <span
                                className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                                  isVencido
                                    ? 'bg-rose-100 text-rose-800'
                                    : isConcessao
                                    ? 'bg-amber-100 text-amber-900'
                                    : isQuitado
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-blue-50 text-blue-800'
                                }`}
                              >
                                {isVencido
                                  ? 'Vencido em Dobro'
                                  : isConcessao
                                  ? 'Em Concessão'
                                  : isQuitado
                                  ? 'Quitado / Usufruído'
                                  : 'Em Aquisição'}
                              </span>
                            </td>
                            <td className="py-3.5 px-4 text-right">
                              {p.saldoRemanescente > 0 && (
                                <button
                                  onClick={() => handleAgendarFerias(extratoColaborador.funcionario)}
                                  className="px-3 py-1 text-xs font-bold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors"
                                >
                                  Agendar
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-ABA 4: SIMULADOR DE FÉRIAS E ENCARGOS */}
      {/* ========================================================================= */}
      {subTab === 'simulador' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Coluna 1: Parâmetros */}
          <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
              <Calculator className="w-5 h-5 text-indigo-600" />
              <h3 className="font-bold text-sm text-slate-900">
                Parâmetros da Simulação de Férias
              </h3>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Salário Base Mensal (R$)
              </label>
              <input
                type="number"
                step="50"
                min="1000"
                value={simSalario}
                onChange={(e) => setSimSalario(Number(e.target.value))}
                className="w-full px-3 py-2.5 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Dias de Gozo Efetivo
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[30, 20, 15, 14].map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setSimDiasGozo(d)}
                    className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                      simDiasGozo === d
                        ? 'bg-indigo-600 text-white border-indigo-700 shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {d} dias
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-100">
              <label className="flex items-start gap-2.5 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={simAbono}
                  onChange={(e) => {
                    setSimAbono(e.target.checked);
                    if (e.target.checked && simDiasGozo > 20) setSimDiasGozo(20);
                  }}
                  className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                />
                <div className="text-xs">
                  <span className="font-bold text-slate-900 block">
                    Venda de 10 dias de Abono Pecuniário (Art. 143)
                  </span>
                  <span className="text-slate-500">
                    O abono e seu 1/3 são isentos de INSS e IRRF.
                  </span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={simAdiant13}
                  onChange={(e) => setSimAdiant13(e.target.checked)}
                  className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                />
                <div className="text-xs">
                  <span className="font-bold text-slate-900 block">
                    Adiantar 1ª Parcela do 13º Salário (50%)
                  </span>
                  <span className="text-slate-500">
                    Metade do salário base sem descontos de INSS/IRRF no adiantamento.
                  </span>
                </div>
              </label>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Dependentes para Dedução do IRRF (R$ 189,59 cada)
              </label>
              <input
                type="number"
                min="0"
                max="10"
                value={simDependentes}
                onChange={(e) => setSimDependentes(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl"
              />
            </div>
          </div>

          {/* Coluna 2: Demonstrativo Calculado */}
          <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-sm text-slate-900">
                Demonstrativo de Proventos e Descontos Legais
              </h3>
              <span className="text-xs font-semibold text-slate-500">Tabela 2026 CLT</span>
            </div>

            {simResultado && (
              <div className="space-y-4">
                <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                        <th className="py-2.5 px-4">Rubrica</th>
                        <th className="py-2.5 px-4 text-right">Proventos (R$)</th>
                        <th className="py-2.5 px-4 text-right">Descontos (R$)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      <tr>
                        <td className="py-2 px-4 font-semibold text-slate-800">
                          Férias Proporcionais ({simDiasGozo} dias)
                        </td>
                        <td className="py-2 px-4 text-right font-mono text-slate-800 font-medium">
                          {formatMoney(simResultado.valorFeriasBruto)}
                        </td>
                        <td className="py-2 px-4 text-right text-slate-400">-</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-4 font-semibold text-slate-800">
                          1/3 Constitucional sobre Férias (Art. 7º, XVII CF/88)
                        </td>
                        <td className="py-2 px-4 text-right font-mono text-slate-800 font-medium">
                          {formatMoney(simResultado.tercoConstitucional)}
                        </td>
                        <td className="py-2 px-4 text-right text-slate-400">-</td>
                      </tr>
                      {simAbono && (
                        <>
                          <tr>
                            <td className="py-2 px-4 font-semibold text-slate-800">
                              Abono Pecuniário (10 dias de venda) - Isento
                            </td>
                            <td className="py-2 px-4 text-right font-mono text-slate-800 font-medium">
                              {formatMoney(simResultado.valorAbono)}
                            </td>
                            <td className="py-2 px-4 text-right text-slate-400">-</td>
                          </tr>
                          <tr>
                            <td className="py-2 px-4 font-semibold text-slate-800">
                              1/3 Constitucional sobre Abono Pecuniário - Isento
                            </td>
                            <td className="py-2 px-4 text-right font-mono text-slate-800 font-medium">
                              {formatMoney(simResultado.tercoAbono)}
                            </td>
                            <td className="py-2 px-4 text-right text-slate-400">-</td>
                          </tr>
                        </>
                      )}
                      {simAdiant13 && (
                        <tr>
                          <td className="py-2 px-4 font-semibold text-slate-800">
                            Adiantamento 1ª Parcela 13º Salário (50%)
                          </td>
                          <td className="py-2 px-4 text-right font-mono text-slate-800 font-medium">
                            {formatMoney(simResultado.adiantamento13)}
                          </td>
                          <td className="py-2 px-4 text-right text-slate-400">-</td>
                        </tr>
                      )}
                      <tr>
                        <td className="py-2 px-4 text-rose-700 font-medium">
                          Contribuição Previdenciária (INSS sobre Férias)
                        </td>
                        <td className="py-2 px-4 text-right text-slate-400">-</td>
                        <td className="py-2 px-4 text-right font-mono text-rose-700 font-medium">
                          {formatMoney(simResultado.inssFerias)}
                        </td>
                      </tr>
                      <tr>
                        <td className="py-2 px-4 text-rose-700 font-medium">
                          Imposto de Renda Retido na Fonte (IRRF Férias)
                        </td>
                        <td className="py-2 px-4 text-right text-slate-400">-</td>
                        <td className="py-2 px-4 text-right font-mono text-rose-700 font-medium">
                          {formatMoney(simResultado.irrfFerias)}
                        </td>
                      </tr>
                    </tbody>
                    <tfoot>
                      <tr className="bg-slate-50 border-t border-slate-200 font-bold">
                        <td className="py-2.5 px-4 text-slate-800">Totalizadores:</td>
                        <td className="py-2.5 px-4 text-right font-mono text-emerald-700">
                          {formatMoney(
                            simResultado.valorFeriasBruto +
                              simResultado.tercoConstitucional +
                              simResultado.valorAbono +
                              simResultado.tercoAbono +
                              simResultado.adiantamento13
                          )}
                        </td>
                        <td className="py-2.5 px-4 text-right font-mono text-rose-700">
                          {formatMoney(simResultado.inssFerias + simResultado.irrfFerias)}
                        </td>
                      </tr>
                      <tr className="bg-emerald-50 text-emerald-950 font-black border-t-2 border-emerald-300">
                        <td className="py-3 px-4 text-xs uppercase">Valor Líquido Creditado:</td>
                        <td colSpan={2} className="py-3 px-4 text-right font-mono text-lg text-emerald-800">
                          {formatMoney(simResultado.totalLiquido)}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                {/* Caixa informativa de FGTS */}
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1 text-slate-600">
                  <span className="font-bold text-slate-800 block">
                    Encargos Sociais do Empregador (FGTS 8%):
                  </span>
                  <p>
                    O depósito de FGTS referente às férias (base: Férias + 1/3 = {formatMoney(simResultado.valorFeriasBruto + simResultado.tercoConstitucional)}) 
                    será de <strong>{formatMoney((simResultado.valorFeriasBruto + simResultado.tercoConstitucional) * 0.08)}</strong> na guia FGTS Digital.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal de Registro de Férias */}
      {isModalFeriasOpen && selectedFuncionarioParaFerias && (
        <FeriasAfastamentoModal
          isOpen={isModalFeriasOpen}
          onClose={() => {
            setIsModalFeriasOpen(false);
            setSelectedFuncionarioParaFerias(null);
          }}
          funcionario={selectedFuncionarioParaFerias}
          mode="ferias"
          initialDataInicio={sugestaoDataInicio}
          onSaveFerias={async (id, dias, dtIni, dtFim) => {
            await api.registrarPeriodoGozo({
              funcionarioId: id,
              periodoAquisitivoInicio: selectedFuncionarioParaFerias.periodoAquisitivoInicio || '2024-01-01',
              periodoAquisitivoFim: selectedFuncionarioParaFerias.periodoAquisitivoFim || '2024-12-31',
              limiteConcessivo: selectedFuncionarioParaFerias.limiteConcessivoFerias || '2025-11-30',
              fracionamentoNumero: 1,
              dataInicio: dtIni,
              dataFim: dtFim,
              diasGozo: dias,
              abonoPecuniario: false,
              diasAbono: 0,
              adiantamentoDecimoTerceiro: false,
            });
            await loadFeriasData();
            await onRefreshRH();
          }}
          onSaveFeriasAvancado={handleSaveFeriasAvancado}
          onSaveAfastamento={async () => {}}
        />
      )}

      {/* Modal de Impressão do Documento Oficial (Aviso e Recibo CLT) */}
      <DocumentoFeriasModal
        isOpen={isDocModalOpen}
        onClose={() => {
          setIsDocModalOpen(false);
          setDocSelecionado(null);
        }}
        documento={docSelecionado}
        loading={loadingDoc}
      />
    </div>
  );
};
