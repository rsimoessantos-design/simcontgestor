import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Calendar,
  AlertCircle,
  Check,
  Umbrella,
  ShieldAlert,
  DollarSign,
  Calculator,
  Info,
  Clock,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';
import { Funcionario } from '../../types';
import { api } from '../../services/api';

export interface FeriasRegistrationData {
  funcionarioId: string;
  periodoAquisitivoInicio: string;
  periodoAquisitivoFim: string;
  limiteConcessivo: string;
  fracionamentoNumero: 1 | 2 | 3;
  dataInicio: string;
  dataFim: string;
  diasGozo: number;
  abonoPecuniario: boolean;
  diasAbono: number;
  adiantamentoDecimoTerceiro: boolean;
  dataAvisoFerias?: string;
  dataLimitePagamento?: string;
  observacoes?: string;
}

interface FeriasAfastamentoModalProps {
  isOpen: boolean;
  onClose: () => void;
  funcionario: Funcionario | null;
  mode: 'ferias' | 'afastamento';
  initialDataInicio?: string;
  onSaveFerias: (id: string, dias: number, dataInicio: string, dataFim: string) => Promise<void>;
  onSaveFeriasAvancado?: (dados: FeriasRegistrationData) => Promise<void>;
  onSaveAfastamento: (id: string, motivo: string) => Promise<void>;
}

export const FeriasAfastamentoModal: React.FC<FeriasAfastamentoModalProps> = ({
  isOpen,
  onClose,
  funcionario,
  mode,
  initialDataInicio,
  onSaveFerias,
  onSaveFeriasAvancado,
  onSaveAfastamento,
}) => {
  // Configuração padrão de datas
  const hoje = '2026-09-13';

  // State de Férias
  const [diasGozo, setDiasGozo] = useState<number>(30);
  const [fracionamentoNumero, setFracionamentoNumero] = useState<1 | 2 | 3>(1);
  const [abonoPecuniario, setAbonoPecuniario] = useState<boolean>(false);
  const [diasAbono, setDiasAbono] = useState<number>(10);
  const [adiantamento13, setAdiantamento13] = useState<boolean>(false);
  const [observacoes, setObservacoes] = useState<string>('');

  // Datas
  const [dataInicio, setDataInicio] = useState<string>('');
  const [dataFim, setDataFim] = useState<string>('');

  // Período aquisitivo e limite concessivo
  const [periodoAquisitivoInicio, setPeriodoAquisitivoInicio] = useState<string>('');
  const [periodoAquisitivoFim, setPeriodoAquisitivoFim] = useState<string>('');
  const [limiteConcessivo, setLimiteConcessivo] = useState<string>('');

  // State de Afastamento
  const [motivoAfastamento, setMotivoAfastamento] = useState('Licença Médica / Auxílio-Doença (INSS)');

  // Estado geral
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Simulação financeira
  const [simulacao, setSimulacao] = useState<{
    salarioBase: number;
    valorFeriasBruto: number;
    tercoConstitucional: number;
    valorAbono: number;
    tercoAbono: number;
    adiantamento13: number;
    inssFerias: number;
    irrfFerias: number;
    totalLiquido: number;
  } | null>(null);

  // Inicializar dados ao abrir modal
  useEffect(() => {
    if (isOpen && funcionario) {
      setError(null);
      const saldo = funcionario.diasFeriasSaldo ?? 30;

      // Definir período aquisitivo padrão do funcionário
      const paIni = funcionario.periodoAquisitivoInicio || '2024-01-01';
      const paFim = funcionario.periodoAquisitivoFim || '2024-12-31';
      const limConc = funcionario.limiteConcessivoFerias || '2025-11-30';

      setPeriodoAquisitivoInicio(paIni);
      setPeriodoAquisitivoFim(paFim);
      setLimiteConcessivo(limConc);

      // Data de início: se veio sugerida ou calcular para daqui a 30 dias (segunda-feira)
      let dataIni = initialDataInicio;
      if (!dataIni) {
        const dt = new Date('2026-10-15'); // 32 dias à frente, permitindo aviso prévio
        dataIni = dt.toISOString().split('T')[0];
      }
      setDataInicio(dataIni);

      // Dias sugeridos
      const diasIniciais = saldo >= 30 ? 30 : saldo > 0 ? saldo : 30;
      setDiasGozo(diasIniciais);
      setAbonoPecuniario(false);
      setDiasAbono(10);
      setAdiantamento13(false);
      setObservacoes('');

      // Calcular data fim
      const dtFim = new Date(dataIni);
      dtFim.setDate(dtFim.getDate() + diasIniciais - 1);
      setDataFim(dtFim.toISOString().split('T')[0]);
    }
  }, [isOpen, funcionario, initialDataInicio]);

  // Atualizar data de término das férias automaticamente com base nos dias
  const handleDataInicioChange = (inicio: string, dias: number) => {
    setDataInicio(inicio);
    if (inicio && dias > 0) {
      const dt = new Date(inicio);
      dt.setDate(dt.getDate() + dias - 1);
      setDataFim(dt.toISOString().split('T')[0]);
    }
  };

  const handleDiasChange = (dias: number) => {
    setDiasGozo(dias);
    if (dataInicio && dias > 0) {
      const dt = new Date(dataInicio);
      dt.setDate(dt.getDate() + dias - 1);
      setDataFim(dt.toISOString().split('T')[0]);
    }
  };

  // Calcular datas legais da CLT
  const datasLegais = useMemo(() => {
    if (!dataInicio) return null;
    const dtIni = new Date(dataInicio);

    // Aviso prévio (Art. 135 CLT): 30 dias antes
    const dtAviso = new Date(dtIni);
    dtAviso.setDate(dtAviso.getDate() - 30);

    // Limite de pagamento (Art. 145 CLT): 2 dias antes
    const dtPagamento = new Date(dtIni);
    dtPagamento.setDate(dtPagamento.getDate() - 2);

    // Validação dia da semana de início (Art. 134 §3º CLT)
    // 0 = Domingo, 1 = Segunda, 4 = Quinta, 5 = Sexta, 6 = Sábado
    const diaSemana = dtIni.getDay();
    const avisoDiaProibido = diaSemana === 5 || diaSemana === 6; // Sexta ou Sábado

    return {
      avisoPrevio: dtAviso.toISOString().split('T')[0],
      limitePagamento: dtPagamento.toISOString().split('T')[0],
      diaSemana,
      avisoDiaProibido,
    };
  }, [dataInicio]);

  // Atualizar simulação em tempo real
  useEffect(() => {
    if (!funcionario || mode !== 'ferias') return;

    const salario = funcionario.salarioBase || 0;
    const dias = diasGozo || 0;
    const abono = abonoPecuniario ? diasAbono : 0;

    // Férias Brutas
    const valorFeriasBruto = (salario / 30) * dias;
    const tercoConstitucional = valorFeriasBruto / 3;

    // Abono Pecuniário
    const valorAbono = abonoPecuniario ? (salario / 30) * abono : 0;
    const tercoAbono = valorAbono / 3;

    // 13º Salário Adiantamento (50%)
    const adiant13 = adiantamento13 ? salario * 0.5 : 0;

    // Base tributável (férias + terço de gozo)
    const baseTributavel = valorFeriasBruto + tercoConstitucional;

    // INSS aproximado 2026
    let inss = 0;
    if (baseTributavel <= 1412.0) {
      inss = baseTributavel * 0.075;
    } else if (baseTributavel <= 2666.68) {
      inss = 1412.0 * 0.075 + (baseTributavel - 1412.0) * 0.09;
    } else if (baseTributavel <= 4000.03) {
      inss = 1412.0 * 0.075 + (2666.68 - 1412.0) * 0.09 + (baseTributavel - 2666.68) * 0.12;
    } else {
      inss =
        1412.0 * 0.075 +
        (2666.68 - 1412.0) * 0.09 +
        (4000.03 - 2666.68) * 0.12 +
        Math.min(baseTributavel - 4000.03, 3787.21) * 0.14;
    }
    inss = Math.round(inss * 100) / 100;

    // IRRF aproximado 2026
    const deducaoDep = (funcionario.dependentesIrrf || 0) * 189.59;
    const baseIrrf = Math.max(0, baseTributavel - inss - deducaoDep);
    let irrf = 0;
    if (baseIrrf <= 2259.2) {
      irrf = 0;
    } else if (baseIrrf <= 2826.65) {
      irrf = baseIrrf * 0.075 - 169.44;
    } else if (baseIrrf <= 3751.05) {
      irrf = baseIrrf * 0.15 - 381.44;
    } else if (baseIrrf <= 4664.68) {
      irrf = baseIrrf * 0.225 - 662.77;
    } else {
      irrf = baseIrrf * 0.275 - 896.0;
    }
    irrf = Math.max(0, Math.round(irrf * 100) / 100);

    const totalLiquido =
      valorFeriasBruto +
      tercoConstitucional +
      valorAbono +
      tercoAbono +
      adiant13 -
      inss -
      irrf;

    setSimulacao({
      salarioBase: salario,
      valorFeriasBruto,
      tercoConstitucional,
      valorAbono,
      tercoAbono,
      adiantamento13: adiant13,
      inssFerias: inss,
      irrfFerias: irrf,
      totalLiquido: Math.round(totalLiquido * 100) / 100,
    });
  }, [funcionario, mode, diasGozo, abonoPecuniario, diasAbono, adiantamento13]);

  if (!isOpen || !funcionario) return null;

  const saldoAtual = funcionario.diasFeriasSaldo ?? 30;
  const totalDiasRequeridos = diasGozo + (abonoPecuniario ? diasAbono : 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      setSaving(true);
      if (mode === 'ferias') {
        if (!dataInicio || !dataFim) {
          setError('Informe o período completo de gozo das férias.');
          return;
        }

        if (diasGozo <= 0) {
          setError('A quantidade de dias de gozo deve ser maior que zero.');
          return;
        }

        // Validação fracionamento CLT Art. 134 §1º
        if (fracionamentoNumero > 1 && diasGozo < 5) {
          setError('Art. 134 §1º da CLT: Nenhum período de férias fracionadas pode ser inferior a 5 (cinco) dias.');
          return;
        }

        // Se tem função avançada registrada
        if (onSaveFeriasAvancado) {
          await onSaveFeriasAvancado({
            funcionarioId: funcionario.id,
            periodoAquisitivoInicio,
            periodoAquisitivoFim,
            limiteConcessivo,
            fracionamentoNumero,
            dataInicio,
            dataFim,
            diasGozo: Number(diasGozo),
            abonoPecuniario,
            diasAbono: abonoPecuniario ? Number(diasAbono) : 0,
            adiantamentoDecimoTerceiro: adiantamento13,
            dataAvisoFerias: datasLegais?.avisoPrevio,
            dataLimitePagamento: datasLegais?.limitePagamento,
            observacoes: observacoes.trim(),
          });
        } else {
          await onSaveFerias(funcionario.id, Number(diasGozo), dataInicio, dataFim);
        }
      } else {
        if (!motivoAfastamento.trim()) {
          setError('Informe o motivo do afastamento.');
          return;
        }
        await onSaveAfastamento(funcionario.id, motivoAfastamento.trim());
      }
      onClose();
    } catch (err: any) {
      setError(err.message || 'Erro ao registrar evento no módulo de RH');
    } finally {
      setSaving(false);
    }
  };

  const formatMoney = (val?: number) => {
    return (val || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '---';
    const [ano, mes, dia] = dateStr.split('-');
    if (ano && mes && dia) return `${dia}/${mes}/${ano}`;
    return new Date(dateStr).toLocaleDateString('pt-BR');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                mode === 'ferias'
                  ? 'bg-amber-50 text-amber-600 border border-amber-200'
                  : 'bg-rose-50 text-rose-600 border border-rose-200'
              }`}
            >
              {mode === 'ferias' ? <Umbrella className="w-5 h-5" /> : <ShieldAlert className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                {mode === 'ferias' ? 'Registrar Período de Férias CLT' : 'Registrar Afastamento Ocupacional'}
              </h3>
              <p className="text-xs text-slate-500">
                {funcionario.nomeCompleto} • {funcionario.cargoNome} (Salário Base: {formatMoney(funcionario.salarioBase)})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 flex-1">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-rose-800 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {mode === 'ferias' ? (
            <>
              {/* Box de Saldo & Período Aquisitivo */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl text-xs">
                <div>
                  <span className="text-amber-800 font-medium">Saldo Disponível no Sistema:</span>
                  <div className="flex items-baseline gap-2 mt-0.5">
                    <span className="text-lg font-black text-amber-900">{saldoAtual} dias</span>
                    <span className="text-[11px] text-amber-700">
                      (Solicitando {totalDiasRequeridos} dias)
                    </span>
                  </div>
                  {totalDiasRequeridos > saldoAtual && (
                    <p className="text-rose-600 font-bold text-[11px] mt-1 flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      Atenção: A soma dos dias ultrapassa o saldo disponível!
                    </p>
                  )}
                </div>

                <div className="border-t sm:border-t-0 sm:border-l border-amber-200/80 sm:pl-3 pt-2 sm:pt-0 space-y-0.5">
                  <span className="text-amber-800 font-medium">Período Concessivo Limite (Art. 134):</span>
                  <p className="font-bold text-slate-900">
                    {formatDate(limiteConcessivo)}
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Aquisitivo: {formatDate(periodoAquisitivoInicio)} a {formatDate(periodoAquisitivoFim)}
                  </p>
                </div>
              </div>

              {/* Opções de Fracionamento & Pré-definições de Dias */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Divisão de Período & Fracionamento (Art. 134 §1º CLT)</span>
                  </label>
                  <span className="text-[11px] text-slate-500">
                    Permitido em até 3 períodos
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {[
                    { num: 1, label: '1º Período (Integral ou Maior)' },
                    { num: 2, label: '2º Período (Fracionado)' },
                    { num: 3, label: '3º Período (Fracionado)' },
                  ].map((frac) => (
                    <button
                      key={frac.num}
                      type="button"
                      onClick={() => setFracionamentoNumero(frac.num as 1 | 2 | 3)}
                      className={`p-2.5 text-xs font-semibold rounded-xl border text-center transition-all ${
                        fracionamentoNumero === frac.num
                          ? 'bg-indigo-600 text-white border-indigo-700 shadow-sm'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {frac.label}
                    </button>
                  ))}
                </div>

                {/* Botões rápidos de dias de gozo */}
                <div className="flex items-center gap-2 pt-1">
                  <span className="text-xs text-slate-500 font-medium">Atalhos de dias:</span>
                  {[30, 20, 15, 14, 10, 5].map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => handleDiasChange(d)}
                      className={`px-2.5 py-1 text-xs font-bold rounded-lg border transition-all ${
                        diasGozo === d
                          ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                          : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                      }`}
                    >
                      {d}d
                    </button>
                  ))}
                </div>
              </div>

              {/* Datas de Gozo */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Dias de Gozo Efetivo
                  </label>
                  <input
                    type="number"
                    min="5"
                    max="30"
                    value={diasGozo}
                    onChange={(e) => handleDiasChange(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Data de Início do Gozo
                  </label>
                  <input
                    type="date"
                    value={dataInicio}
                    onChange={(e) => handleDataInicioChange(e.target.value, diasGozo)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Data de Término (Último dia)
                  </label>
                  <input
                    type="date"
                    value={dataFim}
                    onChange={(e) => setDataFim(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    required
                  />
                </div>
              </div>

              {/* Alerta Legal de Dia de Início (Art. 134 §3º) */}
              {datasLegais?.avisoDiaProibido && (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Atenção ao Art. 134 §3º da CLT:</span>
                    <p className="mt-0.5">
                      É vedado o início das férias no período de dois dias que antecede feriado ou repouso semanal remunerado (sexta-feira ou sábado). Recomenda-se agendar para a segunda-feira anterior ou posterior.
                    </p>
                  </div>
                </div>
              )}

              {/* Opções Financeiras: Abono Pecuniário & 13º */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <label className="flex items-start gap-2.5 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                  <input
                    type="checkbox"
                    checked={abonoPecuniario}
                    onChange={(e) => {
                      const check = e.target.checked;
                      setAbonoPecuniario(check);
                      if (check && diasGozo > 20) {
                        handleDiasChange(20);
                      }
                    }}
                    className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-slate-900 block">
                      Abono Pecuniário (Art. 143 CLT)
                    </span>
                    <span className="text-slate-500">
                      Vender 10 dias de férias em dinheiro (+1/3 proporcional e isenção de encargos).
                    </span>
                  </div>
                </label>

                <label className="flex items-start gap-2.5 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition-colors">
                  <input
                    type="checkbox"
                    checked={adiantamento13}
                    onChange={(e) => setAdiantamento13(e.target.checked)}
                    className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-slate-900 block">
                      Adiantar 1ª Parcela do 13º Salário
                    </span>
                    <span className="text-slate-500">
                      Adiantamento de 50% do salário contratual (conforme Lei 4.749/65).
                    </span>
                  </div>
                </label>
              </div>

              {/* Datas Legais Calculadas */}
              {datasLegais && (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-700">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-indigo-600 shrink-0" />
                    <div>
                      <span className="text-slate-500 block text-[11px]">Aviso Prévio (Mínimo 30 dias):</span>
                      <strong className="text-slate-900">{formatDate(datasLegais.avisoPrevio)}</strong>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <span className="text-slate-500 block text-[11px]">Data Limite de Pagamento (Art. 145):</span>
                      <strong className="text-emerald-700">{formatDate(datasLegais.limitePagamento)}</strong>
                    </div>
                  </div>
                </div>
              )}

              {/* Simulador Financeiro em Tempo Real */}
              {simulacao && (
                <div className="p-4 bg-indigo-50/70 border border-indigo-200 rounded-xl space-y-2">
                  <div className="flex items-center justify-between border-b border-indigo-200 pb-2">
                    <div className="flex items-center gap-1.5 text-indigo-900 font-bold text-xs">
                      <Calculator className="w-4 h-4 text-indigo-600" />
                      <span>Simulador Financeiro de Férias CLT</span>
                    </div>
                    <span className="text-xs font-bold text-indigo-700">
                      Líquido a Pagar: {formatMoney(simulacao.totalLiquido)}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs pt-1">
                    <div>
                      <span className="text-slate-500 text-[11px] block">Férias ({diasGozo}d):</span>
                      <span className="font-semibold text-slate-800">{formatMoney(simulacao.valorFeriasBruto)}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[11px] block">1/3 Constitucional:</span>
                      <span className="font-semibold text-slate-800">{formatMoney(simulacao.tercoConstitucional)}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[11px] block">Desconto INSS:</span>
                      <span className="font-semibold text-rose-600">-{formatMoney(simulacao.inssFerias)}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[11px] block">Desconto IRRF:</span>
                      <span className="font-semibold text-rose-600">-{formatMoney(simulacao.irrfFerias)}</span>
                    </div>
                  </div>

                  {(simulacao.valorAbono > 0 || simulacao.adiantamento13 > 0) && (
                    <div className="flex items-center gap-4 text-xs pt-1 border-t border-indigo-100 text-indigo-900">
                      {simulacao.valorAbono > 0 && (
                        <span>Abono + 1/3: <strong>{formatMoney(simulacao.valorAbono + simulacao.tercoAbono)}</strong> (Isento)</span>
                      )}
                      {simulacao.adiantamento13 > 0 && (
                        <span>1ª Parc 13º: <strong>{formatMoney(simulacao.adiantamento13)}</strong></span>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Observações */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Observações Internas / Justificativa
                </label>
                <input
                  type="text"
                  value={observacoes}
                  onChange={(e) => setObservacoes(e.target.value)}
                  placeholder="Ex: Alinhado com a gerência do setor de operações."
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </>
          ) : (
            <>
              {/* Formulário de Afastamento */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Motivo / Categoria do Afastamento Ocupacional
                </label>
                <select
                  value={motivoAfastamento}
                  onChange={(e) => setMotivoAfastamento(e.target.value)}
                  className="w-full px-3 py-2.5 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none font-medium"
                >
                  <option value="Licença Médica / Auxílio-Doença (INSS - Acima de 15 dias)">
                    Licença Médica / Auxílio-Doença (INSS - Acima de 15 dias)
                  </option>
                  <option value="Acidente de Trabalho (CAT / eSocial S-2210)">
                    Acidente de Trabalho (CAT / eSocial S-2210)
                  </option>
                  <option value="Licença Maternidade (120 dias)">Licença Maternidade (120 dias)</option>
                  <option value="Licença Paternidade (5 a 20 dias)">Licença Paternidade (5 a 20 dias)</option>
                  <option value="Serviço Militar Obrigatório">Serviço Militar Obrigatório</option>
                  <option value="Licença Não Remunerada">Licença Não Remunerada</option>
                </select>
              </div>

              <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-900 space-y-1">
                <p className="font-bold flex items-center gap-1.5 text-rose-800">
                  <ShieldCheck className="w-4 h-4 text-rose-600" />
                  Transmissão Direta para o eSocial (Evento S-2230):
                </p>
                <p className="text-slate-700 leading-relaxed">
                  Ao registrar o afastamento, o colaborador terá seu status alterado para <strong>afastado</strong>, 
                  congelando a contagem de faltas e gerando automaticamente os dados para o evento de afastamento temporário.
                </p>
              </div>
            </>
          )}

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-xl transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-sm flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>{saving ? 'Gravando...' : mode === 'ferias' ? 'Confirmar Agendamento de Férias' : 'Confirmar Afastamento'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
