import React, { useState, useEffect, useMemo } from 'react';
import {
  Calculator,
  FileText,
  FileCheck,
  Building2,
  User,
  Calendar,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Printer,
  ShieldAlert,
  ArrowRight,
  Info,
  ChevronDown,
  ChevronUp,
  Trash2,
  Send,
  HelpCircle,
  PlusCircle,
  RefreshCw,
} from 'lucide-react';
import {
  Funcionario,
  Empresa,
  CalculoRescisaoResultado,
  DocumentoTRCT,
  RescisaoContratualRegistro,
  TipoMotivoRescisao,
  TipoAvisoPrevioRescisao,
} from '../../types';
import { api } from '../../services/api';
import {
  calcularRescisaoCompleta,
  gerarDocumentoTRCTOficial,
  MOTIVOS_RESCISAO_CONFIG,
  TABELA_AVISO_PREVIO_LEI_12506,
} from '../../utils/rescisaoCalculator';
import { TRCTDocumentViewer } from './TRCTDocumentViewer';

interface RescisaoModuleProps {
  empresas: Empresa[];
  empresaSelecionada: string;
  onEmpresaChange?: (empresaId: string) => void;
}

export const RescisaoModule: React.FC<RescisaoModuleProps> = ({
  empresas,
  empresaSelecionada,
}) => {
  const [activeTab, setActiveTab] = useState<'calculadora' | 'historico' | 'legislacao'>('calculadora');
  const [funcionarios, setFuncionarios] = useState<Funcionario[]>([]);
  const [selectedFuncionarioId, setSelectedFuncionarioId] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Formulário de Parâmetros
  const [motivoRescisao, setMotivoRescisao] = useState<TipoMotivoRescisao>('sem_justa_causa');
  const [tipoAvisoPrevio, setTipoAvisoPrevio] = useState<TipoAvisoPrevioRescisao>('indenizado');
  const [dataDesligamento, setDataDesligamento] = useState<string>(
    () => new Date().toISOString().split('T')[0]
  );
  const [dataAvisoPrevio, setDataAvisoPrevio] = useState<string>(
    () => new Date().toISOString().split('T')[0]
  );
  const [saldoFgtsManual, setSaldoFgtsManual] = useState<string>('');
  const [horasExtras, setHorasExtras] = useState<string>('0');
  const [outrosAdicionais, setOutrosAdicionais] = useState<string>('0');
  const [faltasDsr, setFaltasDsr] = useState<string>('0');
  const [outrosDescontos, setOutrosDescontos] = useState<string>('0');
  const [diasFeriasVencidasManual, setDiasFeriasVencidasManual] = useState<string>('');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showMemoria, setShowMemoria] = useState(false);

  // Estado do TRCT
  const [activeTRCT, setActiveTRCT] = useState<DocumentoTRCT | null>(null);
  const [showTRCTViewer, setShowTRCTViewer] = useState(false);

  // Histórico de Rescisões
  const [rescisoes, setRescisoes] = useState<RescisaoContratualRegistro[]>([]);
  const [filtroStatus, setFiltroStatus] = useState<string>('todos');
  const [filtroBusca, setFiltroBusca] = useState<string>('');

  // Carrega Funcionários da empresa
  useEffect(() => {
    const fetchFuncs = async () => {
      try {
        setLoading(true);
        const data = await api.getFuncionarios(empresaSelecionada);
        setFuncionarios(data || []);
        if (data && data.length > 0) {
          // Seleciona o primeiro ou mantém se ainda existir na lista
          if (!selectedFuncionarioId || !data.some((f) => f.id === selectedFuncionarioId)) {
            setSelectedFuncionarioId(data[0].id);
          }
        } else {
          setSelectedFuncionarioId('');
        }
      } catch (err) {
        console.error('Erro ao carregar funcionários:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchFuncs();
  }, [empresaSelecionada]);

  // Carrega Histórico de Rescisões
  const carregarHistorico = async () => {
    try {
      setLoadingHistory(true);
      const data = await api.getRescisoes(empresaSelecionada);
      setRescisoes(data || []);
    } catch (err) {
      console.error('Erro ao carregar rescisões:', err);
    } finally {
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    carregarHistorico();
  }, [empresaSelecionada]);

  // Funcionário selecionado
  const funcionarioAtual = useMemo(() => {
    return funcionarios.find((f) => f.id === selectedFuncionarioId) || null;
  }, [funcionarios, selectedFuncionarioId]);

  // Empresa selecionada
  const empresaAtual = useMemo(() => {
    return (
      empresas.find((e) => e.id === empresaSelecionada) || {
        id: 'emp_1',
        razaoSocial: 'Empresa Demo Ltda',
        cnpj: '12.345.678/0001-90',
        cidade: 'São Paulo',
        uf: 'SP',
      } as Empresa
    );
  }, [empresas, empresaSelecionada]);

  // Atualiza regras padrão ao mudar o motivo da rescisão
  const handleMotivoChange = (novoMotivo: TipoMotivoRescisao) => {
    setMotivoRescisao(novoMotivo);
    if (novoMotivo === 'pedido_demissao') {
      setTipoAvisoPrevio('trabalhado');
    } else if (novoMotivo === 'justa_causa' || novoMotivo === 'termino_experiencia') {
      setTipoAvisoPrevio('nao_aplicavel');
    } else if (novoMotivo === 'sem_justa_causa' || novoMotivo === 'rescisao_indireta') {
      setTipoAvisoPrevio('indenizado');
    } else if (novoMotivo === 'acordo_mutuo') {
      setTipoAvisoPrevio('indenizado');
    }
  };

  // Preenche saldo de férias do funcionário quando ele muda
  useEffect(() => {
    if (funcionarioAtual) {
      if (funcionarioAtual.feriasVencidasDias && funcionarioAtual.feriasVencidasDias > 0) {
        setDiasFeriasVencidasManual(String(funcionarioAtual.feriasVencidasDias));
      } else {
        setDiasFeriasVencidasManual('0');
      }
    }
  }, [funcionarioAtual]);

  // Real-time calculation
  const calculoResultado = useMemo<CalculoRescisaoResultado | null>(() => {
    if (!funcionarioAtual) return null;
    try {
      return calcularRescisaoCompleta({
        funcionario: funcionarioAtual,
        empresa: empresaAtual,
        motivoRescisao,
        tipoAvisoPrevio,
        dataDesligamento,
        dataAvisoPrevio,
        saldoFgtsInformado: saldoFgtsManual ? Number(saldoFgtsManual) : undefined,
        horasExtrasValor: Number(horasExtras) || 0,
        outrosAdicionaisValor: Number(outrosAdicionais) || 0,
        faltasDsrValor: Number(faltasDsr) || 0,
        outrosDescontosValor: Number(outrosDescontos) || 0,
        diasFeriasVencidasManual: diasFeriasVencidasManual ? Number(diasFeriasVencidasManual) : undefined,
      });
    } catch (err) {
      console.error('Erro no cálculo rescisório:', err);
      return null;
    }
  }, [
    funcionarioAtual,
    empresaAtual,
    motivoRescisao,
    tipoAvisoPrevio,
    dataDesligamento,
    dataAvisoPrevio,
    saldoFgtsManual,
    horasExtras,
    outrosAdicionais,
    faltasDsr,
    outrosDescontos,
    diasFeriasVencidasManual,
  ]);

  // Formatações
  const formatCurrency = (val?: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '-';
    if (dateStr.includes('/')) return dateStr;
    const parts = dateStr.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
    return dateStr;
  };

  // Abrir Visualização do TRCT
  const handleVisualizarTRCT = () => {
    if (!calculoResultado || !funcionarioAtual) return;
    const trctGerado = gerarDocumentoTRCTOficial(calculoResultado, funcionarioAtual, empresaAtual);
    setActiveTRCT(trctGerado);
    setShowTRCTViewer(true);
  };

  // Salvar Rescisão no Banco de Dados
  const handleSalvarRescisao = async (atualizarStatus: boolean = false) => {
    if (!calculoResultado || !funcionarioAtual) return;
    try {
      setSaving(true);
      setMessage(null);

      const trctGerado = gerarDocumentoTRCTOficial(calculoResultado, funcionarioAtual, empresaAtual);

      const registro = await api.salvarRescisao({
        funcionarioId: funcionarioAtual.id,
        funcionarioNome: funcionarioAtual.nomeCompleto,
        funcionarioCpf: funcionarioAtual.cpf,
        funcionarioCargo: funcionarioAtual.cargoNome,
        empresaId: funcionarioAtual.empresaId,
        empresaNome: empresaAtual.razaoSocial,
        motivoRescisao,
        tipoAvisoPrevio,
        dataAdmissao: funcionarioAtual.dataAdmissao,
        dataAfastamento: dataDesligamento,
        dataAvisoPrevio,
        dataLimitePagamento: calculoResultado.dataLimitePagamento,
        totalBruto: calculoResultado.totalBruto,
        totalDescontos: calculoResultado.totalDescontos,
        totalLiquido: calculoResultado.totalLiquido,
        saldoFgts: calculoResultado.fgts.saldoBaseCalculo,
        multaFgtsValor: calculoResultado.fgts.multaRescisoriaValor,
        status: 'calculada',
        calculo: calculoResultado,
        trct: trctGerado,
        atualizarStatusFuncionario: atualizarStatus,
      });

      setMessage({
        type: 'success',
        text: `Rescisão de ${funcionarioAtual.nomeCompleto} calculada e salva com sucesso! Nº TRCT: ${trctGerado.numeroTermo}${atualizarStatus ? ' (Status do colaborador alterado para Desligado)' : ''}`,
      });

      await carregarHistorico();
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Erro ao salvar rescisão' });
    } finally {
      setSaving(false);
    }
  };

  // Homologar do Histórico
  const handleHomologar = async (id: string, nome: string) => {
    if (!confirm(`Deseja homologar formalmente a rescisão de ${nome}? O funcionário será classificado como "Desligado".`)) {
      return;
    }
    try {
      await api.homologarRescisao(id);
      setMessage({
        type: 'success',
        text: `Rescisão de ${nome} homologada com sucesso. Colaborador desligado.`,
      });
      await carregarHistorico();
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Erro ao homologar rescisão' });
    }
  };

  // Excluir do Histórico
  const handleExcluir = async (id: string) => {
    if (!confirm('Tem certeza de que deseja excluir este registro rescisório?')) return;
    try {
      await api.deleteRescisao(id);
      setMessage({ type: 'success', text: 'Registro rescisório excluído com sucesso.' });
      await carregarHistorico();
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Erro ao excluir' });
    }
  };

  // Histórico Filtrado
  const historicoFiltrado = useMemo(() => {
    return rescisoes.filter((r) => {
      const matchStatus = filtroStatus === 'todos' || r.status === filtroStatus;
      const matchBusca =
        !filtroBusca ||
        (r.funcionarioNome || '').toLowerCase().includes(filtroBusca.toLowerCase()) ||
        (r.funcionarioCpf || '').includes(filtroBusca) ||
        (r.trct?.numeroTermo || '').toLowerCase().includes(filtroBusca.toLowerCase());
      return matchStatus && matchBusca;
    });
  }, [rescisoes, filtroStatus, filtroBusca]);

  // Se o usuário estiver vendo o TRCT em tela cheia
  if (showTRCTViewer && activeTRCT) {
    return (
      <div className="p-4 sm:p-6 max-w-6xl mx-auto">
        <TRCTDocumentViewer trct={activeTRCT} onClose={() => setShowTRCTViewer(false)} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Banner / Header com Identidade Visual & Tabs */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-400/30">
                  CLT & Portaria MTE 1.057/2012
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                  eSocial S-2299 Compliant
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2.5">
                <Calculator className="w-6 h-6 text-blue-400" />
                Cálculo de Rescisão Contratual & TRCT Oficial
              </h2>
              <p className="text-sm text-slate-300 mt-1 max-w-3xl">
                Automatização completa de verbas rescisórias: saldo de salário, aviso prévio proporcional (Lei 12.506/11), 13º salário, férias proporcionais e vencidas com 1/3 constitucional, multa rescisória FGTS e geração imediata do Termo de Homologação (TRCT).
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={carregarHistorico}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white/90 bg-white/10 hover:bg-white/20 rounded-lg transition-colors"
                title="Recarregar dados"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loadingHistory ? 'animate-spin' : ''}`} />
                Atualizar
              </button>
            </div>
          </div>
        </div>

        {/* Mensagens de Feedback */}
        {message && (
          <div
            className={`p-4 border-b flex items-center justify-between text-sm ${
              message.type === 'success'
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                : 'bg-rose-50 text-rose-900 border-rose-200'
            }`}
          >
            <div className="flex items-center gap-2">
              {message.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-rose-600 flex-shrink-0" />
              )}
              <span>{message.text}</span>
            </div>
            <button
              onClick={() => setMessage(null)}
              className="text-xs font-bold uppercase tracking-wider hover:opacity-75"
            >
              Fechar
            </button>
          </div>
        )}

        {/* Navegação por Abas */}
        <div className="border-b border-slate-200 bg-slate-50 px-6 flex items-center gap-3">
          <button
            onClick={() => setActiveTab('calculadora')}
            className={`py-3.5 px-4 text-sm font-semibold border-b-2 -mb-px flex items-center gap-2 transition-colors ${
              activeTab === 'calculadora'
                ? 'border-blue-600 text-blue-700 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-100/60'
            }`}
          >
            <Calculator className="w-4 h-4" />
            Simulador & Cálculo Rescisório
          </button>

          <button
            onClick={() => setActiveTab('historico')}
            className={`py-3.5 px-4 text-sm font-semibold border-b-2 -mb-px flex items-center gap-2 transition-colors ${
              activeTab === 'historico'
                ? 'border-blue-600 text-blue-700 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-100/60'
            }`}
          >
            <FileText className="w-4 h-4" />
            Histórico de Rescisões & TRCTs ({rescisoes.length})
          </button>

          <button
            onClick={() => setActiveTab('legislacao')}
            className={`py-3.5 px-4 text-sm font-semibold border-b-2 -mb-px flex items-center gap-2 transition-colors ${
              activeTab === 'legislacao'
                ? 'border-blue-600 text-blue-700 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-100/60'
            }`}
          >
            <Info className="w-4 h-4" />
            Guia CLT & Direitos Rescisórios
          </button>
        </div>
      </div>

      {/* ABA 1: CALCULADORA & SIMULADOR */}
      {activeTab === 'calculadora' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Coluna da Esquerda: Formulário de Parâmetros (5 colunas) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-5">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <User className="w-4 h-4 text-blue-600" />
                  1. Seleção do Colaborador
                </h3>
                <span className="text-xs text-slate-500 font-medium">
                  {funcionarios.length} cadastrados
                </span>
              </div>

              {/* Seletor de Funcionário */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Colaborador
                </label>
                <select
                  value={selectedFuncionarioId}
                  onChange={(e) => setSelectedFuncionarioId(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  disabled={loading || funcionarios.length === 0}
                >
                  {funcionarios.length === 0 && (
                    <option value="">Nenhum colaborador encontrado</option>
                  )}
                  {funcionarios.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.nomeCompleto} — {f.cargoNome} ({f.status})
                    </option>
                  ))}
                </select>
              </div>

              {/* Card Resumo do Funcionário Selecionado */}
              {funcionarioAtual && (
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs space-y-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-bold text-slate-900 text-sm">
                        {funcionarioAtual.nomeCompleto}
                      </div>
                      <div className="text-slate-600">
                        {funcionarioAtual.cargoNome} • Matrícula: {funcionarioAtual.matricula}
                      </div>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        funcionarioAtual.status === 'ativo'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {funcionarioAtual.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-200 text-slate-700">
                    <div>
                      <span className="text-slate-500">Admissão:</span>{' '}
                      <strong>{formatDate(funcionarioAtual.dataAdmissao)}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500">Salário Base:</span>{' '}
                      <strong className="text-slate-900 font-mono">
                        {formatCurrency(funcionarioAtual.salarioBase)}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-500">CPF:</span>{' '}
                      <span className="font-mono">{funcionarioAtual.cpf}</span>
                    </div>
                    <div>
                      <span className="text-slate-500">PIS/PASEP:</span>{' '}
                      <span className="font-mono">{funcionarioAtual.pisPasep}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* 2. Motivo do Desligamento & Aviso Prévio */}
              <div className="pt-2 border-t border-slate-100 space-y-4">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-blue-600" />
                  2. Motivo & Aviso Prévio
                </h3>

                {/* Motivo */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Motivo da Rescisão Contratual
                  </label>
                  <select
                    value={motivoRescisao}
                    onChange={(e) => handleMotivoChange(e.target.value as TipoMotivoRescisao)}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none font-medium"
                  >
                    <option value="sem_justa_causa">
                      Demissão Sem Justa Causa pelo Empregador (Multa 40% + Saque FGTS + Seguro)
                    </option>
                    <option value="pedido_demissao">
                      Pedido de Demissão pelo Empregado (Sem Multa, Sem Saque FGTS)
                    </option>
                    <option value="acordo_mutuo_484a">
                      Acordo Mútuo entre as Partes (Art. 484-A CLT - Multa 20% + 80% FGTS)
                    </option>
                    <option value="com_justa_causa">
                      Demissão Com Justa Causa pelo Empregador (Art. 482 CLT - Somente Saldo e Vencidas)
                    </option>
                    <option value="termino_contrato_experiencia">
                      Término do Contrato de Experiência / Prazo Determinado
                    </option>
                    <option value="rescisao_antecipada_empregador">
                      Rescisão Antecipada de Experiência pelo Empregador (Art. 479 CLT)
                    </option>
                    <option value="rescisao_indireta">
                      Rescisão Indireta do Empregador (Art. 483 CLT - Falta Grave do Patrão)
                    </option>
                  </select>
                </div>

                {/* Tipo de Aviso Prévio */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Modalidade do Aviso Prévio
                  </label>
                  <select
                    value={tipoAvisoPrevio}
                    onChange={(e) => setTipoAvisoPrevio(e.target.value as TipoAvisoPrevioRescisao)}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  >
                    <option value="indenizado">
                      Aviso Prévio Indenizado pelo Empregador (Lei 12.506/11)
                    </option>
                    <option value="trabalhado">
                      Aviso Prévio Trabalhado (Redução de 2h/dia ou 7 dias)
                    </option>
                    <option value="descontado">
                      Aviso Prévio Descontado do Empregado (Não cumprido no pedido)
                    </option>
                    <option value="dispensado">
                      Aviso Prévio Dispensado pelo Empregador (Sem ônus)
                    </option>
                    <option value="nao_aplicavel">
                      Não Aplicável (Justa Causa / Término de Prazo)
                    </option>
                  </select>
                </div>

                {/* Datas de Afastamento e Aviso */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Data do Afastamento
                    </label>
                    <input
                      type="date"
                      value={dataDesligamento}
                      onChange={(e) => setDataDesligamento(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none font-medium"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Data da Comunicação
                    </label>
                    <input
                      type="date"
                      value={dataAvisoPrevio}
                      onChange={(e) => setDataAvisoPrevio(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none font-medium"
                    />
                  </div>
                </div>

                {/* Banner de Lei 12.506/2011 se indenizado */}
                {calculoResultado && (
                  <div className="bg-blue-50 p-3 rounded-lg border border-blue-200 text-xs text-blue-900 space-y-1">
                    <div className="font-bold flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-blue-700" />
                      Aviso Prévio Proporcional: {calculoResultado.diasAvisoPrevio} dias
                    </div>
                    <p className="text-blue-800 text-[11px] leading-relaxed">
                      {calculoResultado.anosCompletosServico > 0
                        ? `30 dias regulares + ${calculoResultado.anosCompletosServico * 3} dias adicionais (${calculoResultado.anosCompletosServico} anos de serviço). Projeção final em ${formatDate(calculoResultado.dataProjetadaAviso)}.`
                        : 'Menos de 1 ano completo de empresa: 30 dias integrais de aviso.'}
                    </p>
                  </div>
                )}
              </div>

              {/* 3. Ajustes Adicionais & FGTS (Accordion) */}
              <div className="pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAdvanced(!showAdvanced)}
                  className="w-full flex items-center justify-between text-xs font-bold text-slate-700 uppercase tracking-wider hover:text-slate-900 py-1"
                >
                  <span className="flex items-center gap-1.5">
                    <DollarSign className="w-4 h-4 text-emerald-600" />
                    3. Ajustes Financeiros & Saldo FGTS Caixa
                  </span>
                  {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                {showAdvanced && (
                  <div className="mt-3 space-y-3 bg-slate-50 p-3.5 rounded-lg border border-slate-200 text-xs">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Saldo FGTS da Conta Vinculada (Caixa Econômica Federal)
                      </label>
                      <input
                        type="number"
                        placeholder="Deixe em branco para calcular automaticamente (8%/mês)"
                        value={saldoFgtsManual}
                        onChange={(e) => setSaldoFgtsManual(e.target.value)}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white font-mono text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      />
                      <span className="text-[10px] text-slate-500">
                        Base utilizada para o cálculo da multa rescisória (40% ou 20%).
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">
                          Horas Extras e DSR (R$)
                        </label>
                        <input
                          type="number"
                          value={horasExtras}
                          onChange={(e) => setHorasExtras(e.target.value)}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white font-mono text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">
                          Outros Adicionais (R$)
                        </label>
                        <input
                          type="number"
                          value={outrosAdicionais}
                          onChange={(e) => setOutrosAdicionais(e.target.value)}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white font-mono text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">
                          Faltas e DSR Descontar (R$)
                        </label>
                        <input
                          type="number"
                          value={faltasDsr}
                          onChange={(e) => setFaltasDsr(e.target.value)}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white font-mono text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">
                          Outros Descontos / Danos (R$)
                        </label>
                        <input
                          type="number"
                          value={outrosDescontos}
                          onChange={(e) => setOutrosDescontos(e.target.value)}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white font-mono text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Dias de Férias Vencidas (se houver período em aberto)
                      </label>
                      <input
                        type="number"
                        placeholder="Ex: 30"
                        value={diasFeriasVencidasManual}
                        onChange={(e) => setDiasFeriasVencidasManual(e.target.value)}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded bg-white font-mono text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Coluna da Direita: Resultado Rescisório em Tempo Real (7 colunas) */}
          <div className="lg:col-span-7 space-y-6">
            {calculoResultado ? (
              <>
                {/* 4 Cards de Métricas Principais */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                      Total Bruto (99)
                    </span>
                    <span className="text-lg font-black font-mono text-slate-900 block mt-1">
                      {formatCurrency(calculoResultado.totalBruto)}
                    </span>
                    <span className="text-[10px] text-emerald-600 font-medium">
                      Verbas Proporcionais
                    </span>
                  </div>

                  <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                      Deduções (115)
                    </span>
                    <span className="text-lg font-black font-mono text-rose-600 block mt-1">
                      - {formatCurrency(calculoResultado.totalDescontos)}
                    </span>
                    <span className="text-[10px] text-slate-500 font-medium">
                      INSS, IRRF & Outros
                    </span>
                  </div>

                  <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-300 shadow-sm">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 block">
                      Líquido Rescisório (116)
                    </span>
                    <span className="text-lg font-black font-mono text-emerald-700 block mt-1">
                      {formatCurrency(calculoResultado.totalLiquido)}
                    </span>
                    <span className="text-[10px] text-emerald-700 font-medium">
                      Prazo: {formatDate(calculoResultado.dataLimitePagamento)}
                    </span>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-xl border border-blue-200 shadow-sm">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-blue-800 block">
                      Multa FGTS ({calculoResultado.fgts.aliquotaMulta}%)
                    </span>
                    <span className="text-lg font-black font-mono text-blue-700 block mt-1">
                      {formatCurrency(calculoResultado.fgts.multaRescisoriaValor)}
                    </span>
                    <span className="text-[10px] text-blue-600 font-medium">
                      Cód. {calculoResultado.fgts.codigoSaque}
                    </span>
                  </div>
                </div>

                {/* Alerta de Conformidade Legal CLT Art. 477 § 6º */}
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
                  <ShieldAlert className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-xs text-amber-900 space-y-1">
                    <div className="font-bold flex items-center gap-2">
                      <span>Prazo Impreterível de Pagamento (Art. 477, § 6º da CLT):</span>
                      <span className="px-2 py-0.5 rounded bg-amber-200 text-amber-950 font-black font-mono text-xs">
                        {formatDate(calculoResultado.dataLimitePagamento)}
                      </span>
                    </div>
                    <p className="text-amber-800 leading-relaxed text-[11px]">
                      O pagamento das verbas rescisórias deve ser efetuado em até <strong>10 (dez) dias corridos</strong> contados a partir do término do contrato. A inobservância deste prazo sujeita o empregador à multa de 1 salário em favor do empregado (Art. 477, § 8º).
                    </p>
                  </div>
                </div>

                {/* Tabela de Verbas Rescisórias Discriminadas */}
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">
                        Demonstrativo de Rubricas & Verbas Rescisórias
                      </h4>
                      <span className="text-[11px] text-slate-500">
                        Classificação oficial da Portaria MTE nº 1.057/2012
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowMemoria(!showMemoria)}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-800"
                    >
                      {showMemoria ? 'Ocultar Memória' : 'Ver Memória de Cálculo'}
                      {showMemoria ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-slate-100/70 text-slate-600 font-bold uppercase text-[10px] border-b border-slate-200">
                        <tr>
                          <th className="p-2.5 pl-4">Rubrica</th>
                          <th className="p-2.5">Descrição</th>
                          <th className="p-2.5">Referência / Avos</th>
                          <th className="p-2.5">Tipo</th>
                          <th className="p-2.5 pr-4 text-right">Valor (R$)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {calculoResultado.rubricas.map((item, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                            <td className="p-2.5 pl-4 font-mono font-bold text-slate-700">
                              [{item.codigo}]
                            </td>
                            <td className="p-2.5 font-medium text-slate-900">
                              {item.descricao}
                            </td>
                            <td className="p-2.5 font-mono text-slate-600">
                              {item.referencia}
                            </td>
                            <td className="p-2.5">
                              <span
                                className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                                  item.tipo === 'provento'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-rose-100 text-rose-800'
                                }`}
                              >
                                {item.tipo}
                              </span>
                            </td>
                            <td
                              className={`p-2.5 pr-4 text-right font-mono font-bold ${
                                item.tipo === 'provento' ? 'text-slate-900' : 'text-rose-600'
                              }`}
                            >
                              {item.tipo === 'desconto' ? '- ' : ''}
                              {formatCurrency(item.valor)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot className="bg-slate-50 font-bold text-xs border-t-2 border-slate-200">
                        <tr>
                          <td colSpan={4} className="p-2.5 pl-4 uppercase">
                            Total Líquido Rescisório (116):
                          </td>
                          <td className="p-2.5 pr-4 text-right font-mono text-sm text-emerald-700">
                            {formatCurrency(calculoResultado.totalLiquido)}
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>

                  {/* Memória de Cálculo Expansível */}
                  {showMemoria && (
                    <div className="p-4 bg-slate-900 text-slate-200 text-xs space-y-3 font-mono border-t border-slate-800">
                      <div className="text-emerald-400 font-bold text-[11px] uppercase tracking-wider">
                        MEMÓRIA ANALÍTICA DE CÁLCULO (AUDITORIA FISCAL)
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[11px]">
                        <div className="space-y-1">
                          <div className="text-slate-400 font-bold">1. Saldo de Salário:</div>
                          <div>
                            {calculoResultado.diasSaldoSalario} dias × (R$ {calculoResultado.salarioBase.toFixed(2)} / 30) = R$ {calculoResultado.valorSaldoSalario.toFixed(2)}
                          </div>
                        </div>
                        <div className="space-y-1">
                          <div className="text-slate-400 font-bold">2. 13º Proporcional:</div>
                          <div>
                            {calculoResultado.avos13o} avos normais + {calculoResultado.avos13oIndenizado} avo indenizado = R$ {(calculoResultado.valor13oProporcional + calculoResultado.valor13oIndenizado).toFixed(2)}
                          </div>
                        </div>
                        <div className="space-y-1">
                          <div className="text-slate-400 font-bold">3. Férias & 1/3 Constitucional:</div>
                          <div>
                            Prop: {calculoResultado.avosFerias} avos (+ {calculoResultado.avosFeriasIndenizado} avo indenizado) = R$ {(calculoResultado.valorFeriasProporcionais + calculoResultado.valorFeriasIndenizadas).toFixed(2)}
                          </div>
                          <div>
                            1/3 Constitucional: R$ {(calculoResultado.tercoFeriasProporcionais + calculoResultado.tercoFeriasIndenizadas).toFixed(2)}
                          </div>
                          {calculoResultado.valorFeriasVencidas > 0 && (
                            <div>
                              Férias Vencidas: R$ {calculoResultado.valorFeriasVencidas.toFixed(2)} (+ 1/3: R$ {calculoResultado.tercoFeriasVencidas.toFixed(2)})
                            </div>
                          )}
                        </div>
                        <div className="space-y-1">
                          <div className="text-slate-400 font-bold">4. Retenções Tributárias:</div>
                          <div>INSS s/ Saldo: R$ {calculoResultado.inssSaldoSalario.toFixed(2)}</div>
                          <div>INSS s/ 13º: R$ {calculoResultado.inss13o.toFixed(2)}</div>
                          <div>IRRF s/ Saldo: R$ {calculoResultado.irrfSaldoSalario.toFixed(2)}</div>
                          <div>IRRF s/ 13º: R$ {calculoResultado.irrf13o.toFixed(2)}</div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Barra de Ações: Visualizar TRCT / Salvar / Homologar */}
                <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleVisualizarTRCT}
                      className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-colors"
                    >
                      <Printer className="w-4 h-4" />
                      Visualizar & Imprimir TRCT Oficial
                    </button>

                    <button
                      onClick={() => handleSalvarRescisao(false)}
                      disabled={saving}
                      className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors disabled:opacity-50"
                    >
                      <FileCheck className="w-4 h-4 text-slate-600" />
                      {saving ? 'Gravando...' : 'Salvar no Histórico'}
                    </button>
                  </div>

                  <div>
                    <button
                      onClick={() => handleSalvarRescisao(true)}
                      disabled={saving}
                      className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-emerald-700 bg-emerald-100 hover:bg-emerald-200 rounded-lg transition-colors disabled:opacity-50"
                      title="Salva a rescisão e altera o status cadastral do funcionário para 'desligado'"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Salvar & Efetivar Desligamento
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <div className="bg-white rounded-xl border border-slate-200 p-12 text-center text-slate-400 space-y-3">
                <Calculator className="w-10 h-10 mx-auto text-slate-300" />
                <div className="text-base font-medium text-slate-600">
                  Nenhum funcionário selecionado para o cálculo rescisório.
                </div>
                <p className="text-xs max-w-sm mx-auto">
                  Selecione um colaborador ativo na lista ao lado para simular automaticamente as verbas rescisórias conforme a CLT.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ABA 2: HISTÓRICO DE RESCISÕES GERADAS */}
      {activeTab === 'historico' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden space-y-4">
          <div className="p-6 border-b border-slate-200 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Histórico de Rescisões Contratuais & TRCTs Emitidos
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Contratos rescindidos nesta empresa, valores apurados e controle de homologação.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <input
                type="text"
                placeholder="Buscar por colaborador, CPF ou termo..."
                value={filtroBusca}
                onChange={(e) => setFiltroBusca(e.target.value)}
                className="px-3 py-1.5 text-xs border border-slate-300 rounded-lg w-64 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />

              <select
                value={filtroStatus}
                onChange={(e) => setFiltroStatus(e.target.value)}
                className="px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none font-medium"
              >
                <option value="todos">Todos os Status</option>
                <option value="calculada">Calculadas</option>
                <option value="homologada">Homologadas</option>
                <option value="paga">Pagas</option>
                <option value="transmitida_esocial">Transmitidas eSocial</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-[10px] border-b border-slate-200">
                <tr>
                  <th className="p-3 pl-6">Nº Termo / TRCT</th>
                  <th className="p-3">Colaborador / Cargo</th>
                  <th className="p-3">Motivo / Aviso</th>
                  <th className="p-3">Afastamento</th>
                  <th className="p-3">Limite Pgto</th>
                  <th className="p-3 text-right">Valor Líquido</th>
                  <th className="p-3 text-center">Status</th>
                  <th className="p-3 pr-6 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {historicoFiltrado.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-400">
                      Nenhuma rescisão contratual encontrada para os filtros selecionados.
                    </td>
                  </tr>
                ) : (
                  historicoFiltrado.map((resc) => (
                    <tr key={resc.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 pl-6 font-mono font-bold text-blue-700">
                        {resc.trct?.numeroTermo || resc.id}
                      </td>
                      <td className="p-3">
                        <div className="font-bold text-slate-900">{resc.funcionarioNome}</div>
                        <div className="text-[11px] text-slate-500">
                          {resc.funcionarioCargo} • CPF: {resc.funcionarioCpf}
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="font-semibold text-slate-800">
                          {MOTIVOS_RESCISAO_CONFIG[resc.motivoRescisao]?.nome || resc.motivoRescisao}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          Aviso: {resc.tipoAvisoPrevio}
                        </div>
                      </td>
                      <td className="p-3 font-medium text-slate-700">
                        {formatDate(resc.dataAfastamento)}
                      </td>
                      <td className="p-3 font-bold font-mono text-slate-900">
                        {formatDate(resc.dataLimitePagamento)}
                      </td>
                      <td className="p-3 text-right font-mono font-bold text-emerald-700">
                        {formatCurrency(resc.totalLiquido)}
                      </td>
                      <td className="p-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            resc.status === 'homologada'
                              ? 'bg-emerald-100 text-emerald-800'
                              : resc.status === 'paga'
                              ? 'bg-blue-100 text-blue-800'
                              : resc.status === 'transmitida_esocial'
                              ? 'bg-purple-100 text-purple-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {resc.status}
                        </span>
                      </td>
                      <td className="p-3 pr-6 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {resc.trct && (
                            <button
                              onClick={() => {
                                setActiveTRCT(resc.trct!);
                                setShowTRCTViewer(true);
                              }}
                              className="px-2.5 py-1 text-[11px] font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded transition-colors inline-flex items-center gap-1"
                              title="Visualizar e Imprimir TRCT"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              TRCT
                            </button>
                          )}

                          {resc.status === 'calculada' && (
                            <button
                              onClick={() => handleHomologar(resc.id, resc.funcionarioNome)}
                              className="px-2.5 py-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded transition-colors"
                              title="Homologar Rescisão e Desligar Colaborador"
                            >
                              Homologar
                            </button>
                          )}

                          <button
                            onClick={() => handleExcluir(resc.id)}
                            className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                            title="Excluir Registro"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ABA 3: GUIA CLT & DIREITOS RESCISÓRIOS */}
      {activeTab === 'legislacao' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Card 1: Comparativo de Direitos */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-blue-600" />
              Direitos Trabalhistas por Modalidade de Rescisão
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Consolidação das verbas devidas ao trabalhador de acordo com o motivo do encerramento do contrato de trabalho (CLT):
            </p>

            <div className="overflow-x-auto text-[11px]">
              <table className="w-full text-left border border-slate-200">
                <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="p-2 border-b border-slate-200">Direito CLT</th>
                    <th className="p-2 border-b border-slate-200 text-center">Sem Justa Causa</th>
                    <th className="p-2 border-b border-slate-200 text-center">Pedido Demissão</th>
                    <th className="p-2 border-b border-slate-200 text-center">Com Justa Causa</th>
                    <th className="p-2 border-b border-slate-200 text-center">Acordo 484-A</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  <tr>
                    <td className="p-2 font-medium">Saldo de Salário</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">Aviso Prévio</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim (Integral)</td>
                    <td className="p-2 text-center text-rose-600 font-bold">Trabalha ou Paga</td>
                    <td className="p-2 text-center text-rose-600 font-bold">Não</td>
                    <td className="p-2 text-center text-blue-700 font-bold">50% Indenizado</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">13º Salário Proporcional</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                    <td className="p-2 text-center text-rose-600 font-bold">Não</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">Férias Proporcionais + 1/3</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                    <td className="p-2 text-center text-rose-600 font-bold">Não</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">Férias Vencidas + 1/3</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">Saque do FGTS</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim (100%)</td>
                    <td className="p-2 text-center text-rose-600 font-bold">Não</td>
                    <td className="p-2 text-center text-rose-600 font-bold">Não</td>
                    <td className="p-2 text-center text-blue-700 font-bold">Sim (80%)</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">Multa Rescisória FGTS</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">40%</td>
                    <td className="p-2 text-center text-rose-600 font-bold">Não</td>
                    <td className="p-2 text-center text-rose-600 font-bold">Não</td>
                    <td className="p-2 text-center text-blue-700 font-bold">20%</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">Seguro-Desemprego</td>
                    <td className="p-2 text-center text-emerald-700 font-bold">Sim</td>
                    <td className="p-2 text-center text-rose-600 font-bold">Não</td>
                    <td className="p-2 text-center text-rose-600 font-bold">Não</td>
                    <td className="p-2 text-center text-rose-600 font-bold">Não</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Card 2: Escala de Dias da Lei 12.506/2011 */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-600" />
              Aviso Prévio Proporcional (Lei nº 12.506/2011)
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Aos 30 dias regulares são acrescidos <strong>3 dias por cada ano completo</strong> de serviço prestado na mesma empresa, até o limite máximo de 90 dias (Art. 1º, parágrafo único):
            </p>

            <div className="overflow-x-auto text-[11px] max-h-96 overflow-y-auto border border-slate-200 rounded">
              <table className="w-full text-left">
                <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] sticky top-0">
                  <tr>
                    <th className="p-2 border-b border-slate-200">Tempo de Serviço na Empresa</th>
                    <th className="p-2 border-b border-slate-200">Dias de Aviso</th>
                    <th className="p-2 border-b border-slate-200">Adicional de 3 dias</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {TABELA_AVISO_PREVIO_LEI_12506.map((item) => (
                    <tr key={item.anosCompletos} className="hover:bg-slate-50">
                      <td className="p-2 font-medium">
                        {item.anosCompletos === 0
                          ? 'Menos de 1 ano completo'
                          : `${item.anosCompletos} ano${item.anosCompletos > 1 ? 's' : ''} completo${item.anosCompletos > 1 ? 's' : ''}`}
                      </td>
                      <td className="p-2 font-bold font-mono text-blue-700">
                        {item.diasAviso} dias
                      </td>
                      <td className="p-2 text-slate-500 font-mono">
                        {item.diasAdicionais > 0 ? `+ ${item.diasAdicionais} dias` : 'Padrão (30)'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
