import React, { useState, useMemo } from 'react';
import {
  X,
  Download,
  FileSpreadsheet,
  FileCode,
  CheckCircle2,
  Package,
  Layers,
  TrendingDown,
  DollarSign,
  Building,
  Shield,
} from 'lucide-react';
import { BemPatrimonial, Empresa, CentroCusto } from '../types';
import {
  gerarOfxPatrimonio,
  gerarCsvPatrimonio,
  baixarArquivo,
} from '../utils/exportContabilUtils';

interface ModalExportacaoPatrimonioProps {
  isOpen: boolean;
  onClose: () => void;
  bensTotais: BemPatrimonial[];
  bensFiltrados: BemPatrimonial[];
  bensSelecionadosIds: string[];
  empresas: Empresa[];
  centrosCusto: CentroCusto[];
  onFeedback?: (msg: string) => void;
}

export const ModalExportacaoPatrimonio: React.FC<ModalExportacaoPatrimonioProps> = ({
  isOpen,
  onClose,
  bensTotais,
  bensFiltrados,
  bensSelecionadosIds,
  empresas,
  centrosCusto,
  onFeedback,
}) => {
  const [formato, setFormato] = useState<'csv' | 'ofx'>('csv');
  const [delimitadorCsv, setDelimitadorCsv] = useState<';' | ','>(';');
  const [escopo, setEscopo] = useState<'selecionados' | 'filtrados' | 'todos'>(
    bensSelecionadosIds.length > 0 ? 'selecionados' : 'filtrados'
  );
  const [filtroStatusModal, setFiltroStatusModal] = useState<string>('todos');

  // Determina os itens base pelo escopo
  const bensBase = useMemo(() => {
    if (escopo === 'selecionados') {
      const setIds = new Set(bensSelecionadosIds);
      return bensTotais.filter((b) => setIds.has(b.id));
    }
    if (escopo === 'filtrados') {
      return bensFiltrados;
    }
    return bensTotais;
  }, [escopo, bensSelecionadosIds, bensFiltrados, bensTotais]);

  // Aplica filtro de status adicional
  const bensFinais = useMemo(() => {
    if (filtroStatusModal === 'todos') return bensBase;
    return bensBase.filter((b) => b.status === filtroStatusModal);
  }, [bensBase, filtroStatusModal]);

  // Métricas do lote a ser exportado
  const metricas = useMemo(() => {
    const totalQtd = bensFinais.length;
    const valorOriginal = bensFinais.reduce((acc, b) => acc + (b.valorAquisicao || 0), 0);
    const deprecAcumulada = bensFinais.reduce((acc, b) => acc + (b.depreciacaoAcumulada || 0), 0);
    const valorLiquido = bensFinais.reduce((acc, b) => acc + (b.valorContabilLiquido || 0), 0);
    const comSeguro = bensFinais.filter((b) => b.temSeguro).length;

    return {
      totalQtd,
      valorOriginal,
      deprecAcumulada,
      valorLiquido,
      comSeguro,
    };
  }, [bensFinais]);

  if (!isOpen) return null;

  const handleExportar = () => {
    if (bensFinais.length === 0) {
      if (onFeedback) onFeedback('Nenhum bem selecionado para exportação.');
      return;
    }

    const dataHoje = new Date().toISOString().slice(0, 10);

    if (formato === 'ofx') {
      const conteudo = gerarOfxPatrimonio(bensFinais, empresas, centrosCusto, {
        nomeOrganizacao: 'ContabGest Ativo Imobilizado',
        identificadorConta: 'PATRIMONIO-IMOBILIZADO',
      });
      const nomeArquivo = `Ativo_Imobilizado_${dataHoje}_${bensFinais.length}bens.ofx`;
      baixarArquivo(conteudo, nomeArquivo, 'application/x-ofx');
      if (onFeedback) {
        onFeedback(`Arquivo OFX gerado com sucesso (${bensFinais.length} lançamentos contábeis)!`);
      }
    } else {
      const conteudo = gerarCsvPatrimonio(bensFinais, empresas, centrosCusto, {
        delimitador: delimitadorCsv,
      });
      const nomeArquivo = `Inventario_Patrimonial_${dataHoje}_${bensFinais.length}bens.csv`;
      baixarArquivo(conteudo, nomeArquivo, 'text/csv');
      if (onFeedback) {
        onFeedback(`Arquivo CSV exportado com sucesso (${bensFinais.length} bens patrimoniais)!`);
      }
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        id="modal-exportacao-patrimonio"
        className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Cabeçalho */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center text-blue-700">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                Exportação em Lote do Ativo Imobilizado
              </h2>
              <p className="text-xs text-slate-500">
                Gere arquivos OFX ou CSV estruturados para importação em sistemas contábeis (Domínio, ContaAzul, Omie, etc.)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-6">
          {/* 1. Escolha do Formato */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5">
              1. Selecione o Formato do Arquivo
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setFormato('csv')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer relative ${
                  formato === 'csv'
                    ? 'border-blue-600 bg-blue-50/50 ring-2 ring-blue-500/20 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className={`p-2 rounded-lg ${formato === 'csv' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                      <FileSpreadsheet className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-sm font-bold text-slate-900 block">Arquivo CSV (Inventário)</span>
                      <span className="text-[11px] text-slate-500">Excel, ERPs Contábeis, Auditoria</span>
                    </div>
                  </div>
                  {formato === 'csv' && <CheckCircle2 className="w-5 h-5 text-blue-600" />}
                </div>
                <p className="text-xs text-slate-600 mt-2.5">
                  Exporta todas as 48 colunas: tombamento, NF, fornecedor, contas contábeis, cálculo CPC 27, taxas, seguros e baixas.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setFormato('ofx')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer relative ${
                  formato === 'ofx'
                    ? 'border-blue-600 bg-blue-50/50 ring-2 ring-blue-500/20 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className={`p-2 rounded-lg ${formato === 'ofx' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                      <FileCode className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-sm font-bold text-slate-900 block">Arquivo OFX (Financeiro)</span>
                      <span className="text-[11px] text-slate-500">Lançamentos & Conciliação</span>
                    </div>
                  </div>
                  {formato === 'ofx' && <CheckCircle2 className="w-5 h-5 text-blue-600" />}
                </div>
                <p className="text-xs text-slate-600 mt-2.5">
                  Gera partidas de aquisição (DEBIT) e cotas de depreciação (CREDIT) para importação em extratos de sistemas ERP.
                </p>
              </button>
            </div>

            {/* Delimitador para CSV */}
            {formato === 'csv' && (
              <div className="mt-3.5 bg-slate-50 p-3 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                <span className="font-semibold text-slate-700">Delimitador do CSV:</span>
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-1.5 cursor-pointer text-slate-700">
                    <input
                      type="radio"
                      name="delimPatrimonio"
                      checked={delimitadorCsv === ';'}
                      onChange={() => setDelimitadorCsv(';')}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span>Ponto e vírgula ( ; ) <span className="text-[10px] text-blue-700 font-semibold bg-blue-100 px-1 rounded">Padrão Brasil / Excel</span></span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer text-slate-700">
                    <input
                      type="radio"
                      name="delimPatrimonio"
                      checked={delimitadorCsv === ','}
                      onChange={() => setDelimitadorCsv(',')}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                    <span>Vírgula ( , )</span>
                  </label>
                </div>
              </div>
            )}
          </div>

          {/* 2. Escopo dos Bens */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2.5">
              2. Defina o Escopo do Lote
            </label>
            <div className="space-y-2">
              <label
                className={`flex items-start gap-3 p-3 rounded-xl border transition-all cursor-pointer ${
                  escopo === 'selecionados'
                    ? 'border-blue-500 bg-blue-50/40 text-slate-900'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700'
                } ${bensSelecionadosIds.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <input
                  type="radio"
                  name="escopoPatrimonio"
                  value="selecionados"
                  disabled={bensSelecionadosIds.length === 0}
                  checked={escopo === 'selecionados'}
                  onChange={() => setEscopo('selecionados')}
                  className="mt-1 text-blue-600 focus:ring-blue-500"
                />
                <div>
                  <span className="text-sm font-semibold block">
                    Apenas bens marcados na tabela ({bensSelecionadosIds.length} selecionados)
                  </span>
                  <span className="text-xs text-slate-500">
                    Exporta somente os ativos marcados individualmente com caixas de seleção.
                  </span>
                </div>
              </label>

              <label
                className={`flex items-start gap-3 p-3 rounded-xl border transition-all cursor-pointer ${
                  escopo === 'filtrados'
                    ? 'border-blue-500 bg-blue-50/40 text-slate-900'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="escopoPatrimonio"
                  value="filtrados"
                  checked={escopo === 'filtrados'}
                  onChange={() => setEscopo('filtrados')}
                  className="mt-1 text-blue-600 focus:ring-blue-500"
                />
                <div>
                  <span className="text-sm font-semibold block">
                    Bens exibidos com os filtros ativos na tela ({bensFiltrados.length} bens)
                  </span>
                  <span className="text-xs text-slate-500">
                    Respeita os filtros de empresa, classificação contábil, status e seguro vigentes.
                  </span>
                </div>
              </label>

              <label
                className={`flex items-start gap-3 p-3 rounded-xl border transition-all cursor-pointer ${
                  escopo === 'todos'
                    ? 'border-blue-500 bg-blue-50/40 text-slate-900'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="escopoPatrimonio"
                  value="todos"
                  checked={escopo === 'todos'}
                  onChange={() => setEscopo('todos')}
                  className="mt-1 text-blue-600 focus:ring-blue-500"
                />
                <div>
                  <span className="text-sm font-semibold block">
                    Todo o acervo patrimonial cadastrado ({bensTotais.length} bens)
                  </span>
                  <span className="text-xs text-slate-500">
                    Exporta a totalidade de bens de todas as empresas e centros de custos.
                  </span>
                </div>
              </label>
            </div>
          </div>

          {/* 3. Filtro Opcional de Status */}
          <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200">
            <span className="text-xs font-semibold text-slate-700">Filtrar por Status no Lote:</span>
            <select
              value={filtroStatusModal}
              onChange={(e) => setFiltroStatusModal(e.target.value)}
              className="text-xs border border-slate-300 rounded-lg px-2.5 py-1.5 bg-white text-slate-800 font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none"
            >
              <option value="todos">Todos os Status</option>
              <option value="ativo">Apenas Ativos em Operação</option>
              <option value="manutencao">Apenas em Manutenção</option>
              <option value="depreciado">Apenas Totalmente Depreciados</option>
              <option value="baixado">Apenas Baixados / Alienados</option>
            </select>
          </div>

          {/* Resumo do Lote */}
          <div className="bg-slate-900 text-white rounded-xl p-4">
            <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2.5">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                Resumo do Lote Patrimonial
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full font-mono uppercase bg-blue-500/20 text-blue-400 font-semibold">
                Formato .{formato.toUpperCase()}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="bg-slate-800/60 p-2.5 rounded-lg">
                <span className="text-[11px] text-slate-400 block">Total de Bens</span>
                <span className="text-lg font-bold text-white">{metricas.totalQtd}</span>
              </div>
              <div className="bg-slate-800/60 p-2.5 rounded-lg">
                <span className="text-[11px] text-slate-400 block">Custo Histórico</span>
                <span className="text-sm font-bold text-slate-200">
                  {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(metricas.valorOriginal)}
                </span>
              </div>
              <div className="bg-slate-800/60 p-2.5 rounded-lg">
                <span className="text-[11px] text-slate-400 block">Depreciação Acum.</span>
                <span className="text-sm font-bold text-amber-400">
                  -{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(metricas.deprecAcumulada)}
                </span>
              </div>
              <div className="bg-slate-800/60 p-2.5 rounded-lg">
                <span className="text-[11px] text-slate-400 block">Valor Líquido</span>
                <span className="text-sm font-bold text-emerald-400">
                  {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(metricas.valorLiquido)}
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 mt-3 text-center">
              {formato === 'ofx'
                ? 'Estrutura Open Financial Exchange para conciliação de ativos e depreciações contábeis.'
                : 'Planilha com codificação UTF-8 BOM e 48 colunas técnicas conforme as normas CPC 27 / NBC TG 27.'}
            </p>
          </div>
        </div>

        {/* Rodapé com Ações */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
          >
            Cancelar
          </button>

          <button
            type="button"
            id="btn-confirmar-exportacao-patrimonio"
            onClick={handleExportar}
            disabled={bensFinais.length === 0}
            className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white shadow-sm transition-all cursor-pointer ${
              bensFinais.length > 0
                ? 'bg-blue-600 hover:bg-blue-700'
                : 'bg-slate-300 cursor-not-allowed'
            }`}
          >
            <Download className="w-4 h-4" />
            Baixar Arquivo .{formato.toUpperCase()} ({bensFinais.length} bens)
          </button>
        </div>
      </div>
    </div>
  );
};
