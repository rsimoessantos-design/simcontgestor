import React, { useState, useEffect, useCallback } from 'react';
import {
  User,
  Empresa,
  Cliente,
  Socio,
  Obrigacao,
  Documento,
  Certidao,
  Tarefa,
  ContaPagar,
  ContaReceber,
  CategoriaFinanceira,
  DashboardMetrics,
  NavSection,
  NotaFiscal,
  CertificadoDigital,
  PendenciaEcac,
  AlvaraLicenca,
} from './types';
import { api } from './services/api';
import { LoginScreen } from './components/LoginScreen';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { EmpresasView } from './components/EmpresasView';
import { ClientesView } from './components/ClientesView';
import { NotasFiscaisView } from './components/NotasFiscaisView';
import { CertificadosView } from './components/CertificadosView';
import { AlvarasView } from './components/AlvarasView';
import { EcacPendenciasView } from './components/EcacPendenciasView';
import { ControleEntregasView } from './components/ControleEntregasView';
import { ObrigacoesView } from './components/ObrigacoesView';
import { DocumentosView } from './components/DocumentosView';
import { CertidoesView } from './components/CertidoesView';
import { TarefasView } from './components/TarefasView';
import { FinanceiroView } from './components/FinanceiroView';
import { RHView } from './components/RHView';
import { AgendaView, RelatoriosView, ConfiguracoesView } from './components/OtherViews';
import { DatabaseManagerView } from './components/DatabaseManagerView';
import { SimuladorTributarioView } from './components/SimuladorTributarioView';
import { SimplesNacionalView } from './components/SimplesNacionalView';
import { MeiView } from './components/MeiView';
import { ConformidadeFiscalView } from './components/ConformidadeFiscalView';
import { PainelCobrancasView } from './components/PainelCobrancasView';
import { ControlePatrimonialView } from './components/ControlePatrimonialView';
import { ContabilidadeAnalisesView } from './components/ContabilidadeAnalisesView';
import { FooterNotificationToast } from './components/FooterNotificationToast';

export default function App() {
  // User Authentication State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authChecked, setAuthChecked] = useState(false);

  // App Navigation & Tenant State
  const [currentSection, setCurrentSection] = useState<NavSection>('dashboard');
  const [selectedEmpresaId, setSelectedEmpresaId] = useState<string>('todas');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Data Store
  const [empresas, setEmpresas] = useState<Empresa[]>([]);
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [allClientes, setAllClientes] = useState<Cliente[]>([]);
  const [socios, setSocios] = useState<Socio[]>([]);
  const [obrigacoes, setObrigacoes] = useState<Obrigacao[]>([]);
  const [documentos, setDocumentos] = useState<Documento[]>([]);
  const [allDocumentos, setAllDocumentos] = useState<Documento[]>([]);
  const [certidoes, setCertidoes] = useState<Certidao[]>([]);
  const [tarefas, setTarefas] = useState<Tarefa[]>([]);
  const [contasPagar, setContasPagar] = useState<ContaPagar[]>([]);
  const [contasReceber, setContasReceber] = useState<ContaReceber[]>([]);
  const [categorias, setCategorias] = useState<CategoriaFinanceira[]>([]);
  const [notasFiscais, setNotasFiscais] = useState<NotaFiscal[]>([]);
  const [certificados, setCertificados] = useState<CertificadoDigital[]>([]);
  const [pendenciasEcac, setPendenciasEcac] = useState<PendenciaEcac[]>([]);
  const [alvaras, setAlvaras] = useState<AlvaraLicenca[]>([]);
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [loadingData, setLoadingData] = useState(false);

  // Initialize Session / Auth
  useEffect(() => {
    const savedUser = localStorage.getItem('contabgest_user') || sessionStorage.getItem('contabgest_user');
    const token = localStorage.getItem('contabgest_token') || sessionStorage.getItem('contabgest_token');
    if (!savedUser || !token) {
      localStorage.removeItem('contabgest_user');
      localStorage.removeItem('contabgest_token');
      sessionStorage.removeItem('contabgest_user');
      sessionStorage.removeItem('contabgest_token');
      setAuthChecked(true);
      return;
    }
    api.getCurrentUser()
      .then((user) => {
        setCurrentUser(user);
        localStorage.setItem('contabgest_user', JSON.stringify(user));
      })
      .catch(() => {
        localStorage.removeItem('contabgest_user');
        localStorage.removeItem('contabgest_token');
        setCurrentUser(null);
      })
      .finally(() => setAuthChecked(true));
  }, []);

  // Fetch all entities based on active company selection
  const loadData = useCallback(async (empresaId: string) => {
    setLoadingData(true);
    try {
      const [
        empresasData,
        clientesData,
        sociosData,
        obrigacoesData,
        documentosData,
        certidoesData,
        tarefasData,
        contasPagarData,
        contasReceberData,
        categoriasData,
        notasData,
        certData,
        ecacData,
        alvarasData,
        metricsData,
      ] = await Promise.all([
        api.getEmpresas(),
        api.getClientes(empresaId),
        api.getSocios(empresaId),
        api.getObrigacoes(empresaId),
        api.getDocumentos(empresaId),
        api.getCertidoes(empresaId),
        api.getTarefas(empresaId),
        api.getContasPagar(empresaId),
        api.getContasReceber(empresaId),
        api.getCategoriasFinanceiras(),
        api.getNotasFiscais(empresaId),
        api.getCertificados(empresaId),
        api.getPendenciasEcac(empresaId),
        api.getAlvaras(empresaId),
        api.getDashboardMetrics(empresaId),
      ]);

      setEmpresas(empresasData);
      setClientes(clientesData);
      setSocios(sociosData);
      setObrigacoes(obrigacoesData);
      setDocumentos(documentosData);
      setCertidoes(certidoesData);
      setTarefas(tarefasData);
      setContasPagar(contasPagarData);
      setContasReceber(contasReceberData);
      setCategorias(categoriasData);
      setNotasFiscais(notasData);
      setCertificados(certData);
      setPendenciasEcac(ecacData);
      setAlvaras(alvarasData);
      setMetrics(metricsData);

      if (empresaId === 'todas') {
        setAllClientes(clientesData);
        setAllDocumentos(documentosData);
      }
    } catch (err) {
      console.error('Erro ao carregar dados do ContabGest:', err);
    } finally {
      setLoadingData(false);
    }
  }, []);

  useEffect(() => {
    if (currentUser) {
      loadData(selectedEmpresaId);
      // Pre-load global items for cross-tenant search if not already loaded
      api.getClientes('todas').then(setAllClientes).catch(console.error);
      api.getDocumentos('todas').then(setAllDocumentos).catch(console.error);
    }
  }, [currentUser, selectedEmpresaId, loadData]);

  // Auth Handlers
  const handleLoginSuccess = (user: User, token: string, rememberMe: boolean) => {
    setCurrentUser(user);
    if (rememberMe) {
      localStorage.setItem('contabgest_user', JSON.stringify(user));
      localStorage.setItem('contabgest_token', token);
    } else {
      sessionStorage.setItem('contabgest_user', JSON.stringify(user));
      sessionStorage.setItem('contabgest_token', token);
    }
  };

  const handleLogout = async () => {
    await api.logout();
    sessionStorage.removeItem('contabgest_user');
    sessionStorage.removeItem('contabgest_token');
    setCurrentUser(null);
  };

  // Obligation Status Update Handler
  const handleUpdateObligationStatus = async (id: string, status: Obrigacao['status']) => {
    try {
      const updated = await api.updateObrigacaoStatus(id, status);
      setObrigacoes((prev) => prev.map((o) => (o.id === id ? updated : o)));
      // Refresh metrics to keep cards in sync
      const freshMetrics = await api.getDashboardMetrics(selectedEmpresaId);
      setMetrics(freshMetrics);
    } catch (err) {
      console.error('Erro ao atualizar obrigação:', err);
    }
  };

  // Task Status Update Handler
  const handleUpdateTaskStatus = async (id: string, status: Tarefa['status']) => {
    try {
      const updated = await api.updateTarefaStatus(id, status);
      setTarefas((prev) => prev.map((t) => (t.id === id ? updated : t)));
    } catch (err) {
      console.error('Erro ao atualizar tarefa:', err);
    }
  };

  // Add Document Handler
  const handleAddDocument = async (doc: Omit<Documento, 'id'>) => {
    try {
      const newDoc = await api.addDocumento(doc);
      setDocumentos((prev) => [newDoc, ...prev]);
      const freshMetrics = await api.getDashboardMetrics(selectedEmpresaId);
      setMetrics(freshMetrics);
    } catch (err) {
      console.error('Erro ao adicionar documento:', err);
    }
  };

  if (!authChecked) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center text-white">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-3 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
          <span className="text-xs text-slate-400 font-medium">Carregando ContabGest SaaS...</span>
        </div>
      </div>
    );
  }

  // Not logged in -> Display Login Screen
  if (!currentUser) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  const activeEmpresa = empresas.find((e) => e.id === selectedEmpresaId);
  const pendingObligationsCount = obrigacoes.filter(
    (o) => o.status === 'pendente' || o.status === 'atrasada' || o.status === 'vencendo'
  ).length;
  const pendingTasksCount = tarefas.filter((t) => t.status !== 'concluida').length;

  const handleNavigateWithEmpresa = (section: NavSection, empresaId?: string) => {
    if (empresaId) {
      setSelectedEmpresaId(empresaId);
    }
    setCurrentSection(section);
  };

  return (
    <div id="app-root-layout" className="min-h-screen bg-slate-100/70 flex flex-col antialiased">
      <div className="flex flex-1 w-full relative">
        {/* Responsive Sidebar */}
        <Sidebar
          currentSection={currentSection}
          onSelectSection={setCurrentSection}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          mobileOpen={mobileSidebarOpen}
          onCloseMobile={() => setMobileSidebarOpen(false)}
          user={currentUser}
          pendingObligationsCount={pendingObligationsCount}
          pendingTasksCount={pendingTasksCount}
        />

        {/* Main Application Area */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Header */}
          <Header
            user={currentUser}
            empresas={empresas}
            clientes={allClientes.length ? allClientes : clientes}
            documentos={allDocumentos.length ? allDocumentos : documentos}
            selectedEmpresaId={selectedEmpresaId}
            onSelectEmpresa={setSelectedEmpresaId}
            onNavigate={setCurrentSection}
            onOpenMobileMenu={() => setMobileSidebarOpen(true)}
            onLogout={handleLogout}
          />

          {/* Body Section Content */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
            {loadingData && !metrics ? (
              <div className="h-64 flex items-center justify-center">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-8 h-8 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin"></div>
                  <span className="text-xs text-slate-500 font-medium">
                    Sincronizando dados contábeis...
                  </span>
                </div>
              </div>
            ) : (
              <>
                {currentSection === 'dashboard' && metrics && (
                  <DashboardView
                    metrics={metrics}
                    selectedEmpresa={activeEmpresa}
                    obrigacoes={obrigacoes}
                    tarefas={tarefas}
                    onNavigate={setCurrentSection}
                    onRefresh={() => loadData(selectedEmpresaId)}
                  />
                )}

                {currentSection === 'conformidade_fiscal' && (
                  <ConformidadeFiscalView
                    empresas={empresas}
                    selectedEmpresa={activeEmpresa}
                    onNavigate={handleNavigateWithEmpresa}
                    onRefresh={() => loadData(selectedEmpresaId)}
                  />
                )}

                {currentSection === 'empresas' && (
                  <EmpresasView
                    empresas={empresas}
                    socios={socios}
                    certificados={certificados}
                    onSelectEmpresa={setSelectedEmpresaId}
                    selectedEmpresaId={selectedEmpresaId}
                    onRefresh={() => loadData(selectedEmpresaId)}
                  />
                )}

                {currentSection === 'clientes' && (
                  <ClientesView
                    clientes={clientes}
                    empresas={empresas}
                    selectedEmpresa={activeEmpresa}
                  />
                )}

                {currentSection === 'simulador_tributario' && (
                  <SimuladorTributarioView
                    empresas={empresas}
                    selectedEmpresa={activeEmpresa}
                    currentUser={currentUser}
                  />
                )}

                {currentSection === 'notas_fiscais' && (
                  <NotasFiscaisView
                    selectedEmpresa={activeEmpresa}
                    empresas={empresas}
                    clientes={clientes}
                    notasFiscais={notasFiscais}
                    onRefresh={() => loadData(selectedEmpresaId)}
                    initialTab="emitidas"
                  />
                )}

                {currentSection === 'simples_nacional' && (
                  <SimplesNacionalView
                    selectedEmpresa={activeEmpresa}
                    empresas={empresas}
                    notasFiscais={notasFiscais}
                    currentUser={currentUser || undefined}
                    onRefresh={() => loadData(selectedEmpresaId)}
                  />
                )}

                {currentSection === 'mei' && (
                  <MeiView
                    selectedEmpresa={activeEmpresa}
                    empresas={empresas}
                    notasFiscais={notasFiscais}
                    currentUser={currentUser || undefined}
                    onRefresh={() => loadData(selectedEmpresaId)}
                  />
                )}

                {currentSection === 'captura_sefaz' && (
                  <NotasFiscaisView
                    selectedEmpresa={activeEmpresa}
                    empresas={empresas}
                    clientes={clientes}
                    notasFiscais={notasFiscais}
                    onRefresh={() => loadData(selectedEmpresaId)}
                    initialTab="entradas_sefaz"
                  />
                )}

                {currentSection === 'certificados_digitais' && (
                  <CertificadosView
                    selectedEmpresa={activeEmpresa}
                    empresas={empresas}
                    certificados={certificados}
                    onRefresh={() => loadData(selectedEmpresaId)}
                  />
                )}

                {currentSection === 'alvaras_licencas' && (
                  <AlvarasView
                    selectedEmpresa={activeEmpresa}
                    empresas={empresas}
                    alvaras={alvaras}
                    onRefresh={() => loadData(selectedEmpresaId)}
                  />
                )}

                {currentSection === 'ecac_pendencias' && (
                  <EcacPendenciasView
                    selectedEmpresa={activeEmpresa}
                    empresas={empresas}
                    pendencias={pendenciasEcac}
                    onRefresh={() => loadData(selectedEmpresaId)}
                  />
                )}

                {currentSection === 'controle_entregas' && (
                  <ControleEntregasView
                    selectedEmpresa={activeEmpresa}
                    empresas={empresas}
                    obrigacoes={obrigacoes}
                    tarefas={tarefas}
                    onRefresh={() => loadData(selectedEmpresaId)}
                  />
                )}

                {currentSection === 'obrigacoes' && (
                  <ObrigacoesView
                    obrigacoes={obrigacoes}
                    empresas={empresas}
                    selectedEmpresa={activeEmpresa}
                    onUpdateStatus={handleUpdateObligationStatus}
                  />
                )}

                {currentSection === 'documentos' && (
                  <DocumentosView
                    documentos={documentos}
                    empresas={empresas}
                    selectedEmpresa={activeEmpresa}
                    onAddDocument={handleAddDocument}
                  />
                )}

                {currentSection === 'certidoes' && (
                  <CertidoesView
                    certidoes={certidoes}
                    empresas={empresas}
                    selectedEmpresa={activeEmpresa}
                  />
                )}

                {currentSection === 'tarefas' && (
                  <TarefasView
                    tarefas={tarefas}
                    empresas={empresas}
                    selectedEmpresa={activeEmpresa}
                    onUpdateStatus={handleUpdateTaskStatus}
                  />
                )}

                {currentSection === 'agenda' && <AgendaView selectedEmpresa={activeEmpresa} />}

                {currentSection === 'financeiro' && (
                  <FinanceiroView
                    contasPagar={contasPagar}
                    contasReceber={contasReceber}
                    categorias={categorias}
                    empresas={empresas}
                    selectedEmpresa={activeEmpresa}
                  />
                )}

                {currentSection === 'cobrancas' && (
                  <PainelCobrancasView
                    empresas={empresas}
                    selectedEmpresa={activeEmpresa}
                    onRefresh={() => loadData(selectedEmpresaId)}
                  />
                )}

                {currentSection === 'patrimonio' && (
                  <ControlePatrimonialView
                    empresas={empresas}
                    selectedEmpresa={activeEmpresa}
                    onRefresh={() => loadData(selectedEmpresaId)}
                    onNavigateToContabilidade={() => setCurrentSection('contabilidade')}
                  />
                )}

                {currentSection === 'contabilidade' && (
                  <ContabilidadeAnalisesView
                    empresas={empresas}
                    selectedEmpresa={activeEmpresa}
                    onNavigateToPatrimonio={() => setCurrentSection('patrimonio')}
                  />
                )}

                {currentSection === 'rh' && (
                  <RHView
                    selectedEmpresa={activeEmpresa}
                    empresas={empresas}
                    onRefresh={() => loadData(selectedEmpresaId)}
                  />
                )}

                {currentSection === 'relatorios' && (
                  <RelatoriosView selectedEmpresa={activeEmpresa} />
                )}

                {currentSection === 'configuracoes' && (
                  <ConfiguracoesView onNavigate={setCurrentSection} />
                )}

                {currentSection === 'banco_dados' && (
                  <DatabaseManagerView
                    currentUser={currentUser}
                    onDatabaseAltered={() => {
                      loadData(selectedEmpresaId);
                      api.getClientes('todas').then(setAllClientes).catch(console.error);
                      api.getDocumentos('todas').then(setAllDocumentos).catch(console.error);
                    }}
                  />
                )}
              </>
            )}
          </main>

          {/* Rodapé do Layout com Status dos Monitores Fiscais */}
          <footer className="border-t border-slate-200/80 bg-white/80 backdrop-blur-xs py-3 px-4 sm:px-6 lg:px-8 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2.5">
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-1.5 text-slate-700 font-medium">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>Monitor e-CAC / RFB: <strong>Conectado</strong></span>
              </div>
              <span className="text-slate-300 hidden sm:inline">•</span>
              <div className="flex items-center gap-1 text-slate-600">
                <span>Alerta 48h: <strong>Ativo</strong></span>
              </div>
              <span className="text-slate-300 hidden sm:inline">•</span>
              <span className="text-slate-500">
                Competência Vigente: <strong>09/2026</strong>
              </span>
            </div>

            <div className="flex items-center gap-4 text-[11px] text-slate-400">
              <span>ContabGest SaaS Enterprise © 2026</span>
              <span>Todos os direitos reservados</span>
            </div>
          </footer>
        </div>
      </div>

      {/* Sistema de Notificações Push & Alertas Toast no Rodapé */}
      <FooterNotificationToast
        obrigacoes={obrigacoes}
        pendenciasEcac={pendenciasEcac}
        empresas={empresas}
        onNavigate={setCurrentSection}
      />
    </div>
  );
}
