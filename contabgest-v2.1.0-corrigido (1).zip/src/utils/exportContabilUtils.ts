/**
 * Utilitários para Exportação Contábil e Financeira em Lote
 * Suporta formatos:
 * - OFX (Open Financial Exchange 1.02 / SGML/XML) compatível com Domínio Sistemas, Alterdata, ContaAzul, Omie, Fortes, Questor, Totvs, etc.
 * - CSV (Valores Separados por Vírgula / Ponto e Vírgula) com UTF-8 BOM e cabeçalhos normatizados para ERPs contábeis e Excel.
 */

import { MensalidadeHonorario, ContratoHonorario, BemPatrimonial, Empresa, CentroCusto } from '../types';

export interface OpcoesExportacaoCsv {
  delimitador?: ';' | ',';
  incluirCabecalho?: boolean;
}

export interface OpcoesExportacaoOfx {
  nomeOrganizacao?: string;
  identificadorConta?: string;
  moeda?: string;
}

/**
 * Função auxiliar para escapar campos CSV conforme RFC 4180
 */
function escaparCsv(valor: any, delimitador: string): string {
  if (valor === null || valor === undefined) return '';
  let str = String(valor).trim();
  // Se contiver delimitador, quebras de linha ou aspas duplas, envolve em aspas duplas
  if (str.includes(delimitador) || str.includes('"') || str.includes('\n') || str.includes('\r')) {
    str = `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * Formata data ISO (YYYY-MM-DD) para padrão OFX (YYYYMMDDHHMMSS[-3:BRT])
 */
function formatarDataOfx(dataIso?: string): string {
  if (!dataIso) {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    return `${y}${m}${d}120000[-03:EST]`;
  }
  const limpa = dataIso.replace(/[^0-9]/g, '').slice(0, 8);
  if (limpa.length === 8) {
    return `${limpa}120000[-03:EST]`;
  }
  return `${new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 14)}[-03:EST]`;
}

/**
 * Limpa e sanitiza textos para tags SGML/OFX (remove <, >, &, etc)
 */
function sanitizarOfx(texto: string, maxLen = 95): string {
  if (!texto) return '';
  return texto
    .replace(/[<>&]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLen);
}

// ============================================================================
// 1. EXPORTAÇÃO PAINEL DE COBRANÇAS / HONORÁRIOS
// ============================================================================

/**
 * Gera arquivo OFX a partir de uma lista de Mensalidades de Honorários
 */
export function gerarOfxCobrancas(
  mensalidades: MensalidadeHonorario[],
  contratos: ContratoHonorario[],
  empresas: Empresa[],
  opcoes?: OpcoesExportacaoOfx
): string {
  const org = opcoes?.nomeOrganizacao || 'ContabGest Assessoria Contabil';
  const acct = opcoes?.identificadorConta || '0001-998877';
  const cur = opcoes?.moeda || 'BRL';

  const nowStr = formatarDataOfx();
  let menorData = '99999999120000';
  let maiorData = '00000000120000';
  let saldoTotal = 0;

  const transacoesOfx = mensalidades.map((m) => {
    const emp = empresas.find((e) => e.id === m.empresaId);
    const contrato = contratos.find((c) => c.id === m.contratoId);

    const nomeCliente = emp?.razaoSocial || emp?.nomeFantasia || 'Cliente Contábil';
    const cnpjCliente = emp?.cnpj || '00.000.000/0001-00';
    const numContrato = contrato?.numeroContrato || 'CONT-PADRAO';

    const dataTransacao = m.status === 'pago' && m.dataPagamento
      ? formatarDataOfx(m.dataPagamento)
      : formatarDataOfx(m.dataVencimento);

    if (dataTransacao < menorData) menorData = dataTransacao;
    if (dataTransacao > maiorData) maiorData = dataTransacao;

    const valorNumerico = m.status === 'pago' ? (m.valorPago || m.valor) : m.valor;
    saldoTotal += valorNumerico;

    // Tipo de transação: CREDIT para recebimentos/faturamento
    const trnType = m.status === 'pago' ? 'CREDIT' : 'OTHER';
    const fitid = `COB-${m.id.replace(/[^a-zA-Z0-9]/g, '')}-${dataTransacao.slice(0, 8)}`;
    const checknum = m.reciboNumero || numContrato;

    const memo = sanitizarOfx(
      `Honorarios ${m.competencia} - ${nomeCliente} (CNPJ: ${cnpjCliente}) [${m.status.toUpperCase()}]`
    );

    return `          <STMTTRN>
            <TRNTYPE>${trnType}</TRNTYPE>
            <DTPOSTED>${dataTransacao}</DTPOSTED>
            <TRNAMT>${valorNumerico.toFixed(2)}</TRNAMT>
            <FITID>${fitid}</FITID>
            <CHECKNUM>${checknum}</CHECKNUM>
            <MEMO>${memo}</MEMO>
          </STMTTRN>`;
  });

  if (menorData === '99999999120000') menorData = nowStr;
  if (maiorData === '00000000120000') maiorData = nowStr;

  return `OFXHEADER:100
DATA:OFXSGML
VERSION:102
SECURITY:NONE
ENCODING:UTF-8
CHARSET:NONE
COMPRESSION:NONE
OLDAUTH:NONE
NEWAUTH:NONE

<OFX>
  <SIGNONMSGSRSV1>
    <SONRS>
      <STATUS>
        <CODE>0</CODE>
        <SEVERITY>INFO</SEVERITY>
      </STATUS>
      <DTSERVER>${nowStr}</DTSERVER>
      <LANGUAGE>POR</LANGUAGE>
      <FI>
        <ORG>${sanitizarOfx(org, 32)}</ORG>
        <FID>999</FID>
      </FI>
    </SONRS>
  </SIGNONMSGSRSV1>
  <BANKMSGSRSV1>
    <STMTTRNRS>
      <TRNUID>1001</TRNUID>
      <STATUS>
        <CODE>0</CODE>
        <SEVERITY>INFO</SEVERITY>
      </STATUS>
      <STMTRS>
        <CURDEF>${cur}</CURDEF>
        <BANKACCTFROM>
          <BANKID>999</BANKID>
          <BRANCHID>0001</BRANCHID>
          <ACCTID>${sanitizarOfx(acct, 20)}</ACCTID>
          <ACCTTYPE>CHECKING</ACCTTYPE>
        </BANKACCTFROM>
        <BANKTRANLIST>
          <DTSTART>${menorData}</DTSTART>
          <DTEND>${maiorData}</DTEND>
${transacoesOfx.join('\n')}
        </BANKTRANLIST>
        <LEDGERBAL>
          <BALAMT>${saldoTotal.toFixed(2)}</BALAMT>
          <DTASOF>${nowStr}</DTASOF>
        </LEDGERBAL>
      </STMTRS>
    </STMTTRNRS>
  </BANKMSGSRSV1>
</OFX>`;
}

/**
 * Gera arquivo CSV a partir de uma lista de Mensalidades de Honorários
 */
export function gerarCsvCobrancas(
  mensalidades: MensalidadeHonorario[],
  contratos: ContratoHonorario[],
  empresas: Empresa[],
  opcoes?: OpcoesExportacaoCsv
): string {
  const delim = opcoes?.delimitador || ';';

  const cabecalhos = [
    'ID_COBRANCA',
    'COMPETENCIA',
    'RAZAO_SOCIAL_CLIENTE',
    'NOME_FANTASIA_CLIENTE',
    'CNPJ_CPF_CLIENTE',
    'NUMERO_CONTRATO',
    'DATA_VENCIMENTO',
    'DATA_PAGAMENTO',
    'STATUS_COBRANCA',
    'FORMA_PAGAMENTO',
    'VALOR_TOTAL_BRUTA',
    'VALOR_PRINCIPAL',
    'HONORARIOS_ADICIONAIS',
    'VALOR_LIQUIDADO',
    'NUMERO_RECIBO_CRC',
    'CODIGO_BARRAS_BOLETO',
    'CHAVE_PIX',
    'SERVICOS_CONTRATADOS',
    'OBSERVACOES',
  ];

  const linhas = mensalidades.map((m) => {
    const emp = empresas.find((e) => e.id === m.empresaId);
    const contrato = contratos.find((c) => c.id === m.contratoId);

    const servicos = contrato?.servicosContratadosNomes?.join(' | ') || 'Honorários Padrão';
    const valorPago = m.status === 'pago' ? (m.valorPago || m.valor) : 0;

    const row = [
      m.id,
      m.competencia,
      emp?.razaoSocial || 'Cliente Contábil',
      emp?.nomeFantasia || emp?.razaoSocial || 'Cliente Contábil',
      emp?.cnpj || '',
      contrato?.numeroContrato || 'S/N',
      m.dataVencimento,
      m.dataPagamento || '',
      m.status.toUpperCase(),
      m.formaPagamento ? m.formaPagamento.toUpperCase() : (m.status === 'pago' ? 'PIX' : ''),
      m.valor.toFixed(2).replace('.', ','),
      m.valor.toFixed(2).replace('.', ','),
      '0,00',
      valorPago > 0 ? valorPago.toFixed(2).replace('.', ',') : '0,00',
      m.reciboNumero || '',
      m.codigoBarras || '',
      m.pixCopiaECola || '',
      servicos,
      m.observacao || '',
    ];

    return row.map((campo) => escaparCsv(campo, delim)).join(delim);
  });

  // Prefixo UTF-8 BOM (\uFEFF) para garantir abertura correta no Microsoft Excel
  return '\uFEFF' + [cabecalhos.join(delim), ...linhas].join('\r\n');
}

// ============================================================================
// 2. EXPORTAÇÃO CONTROLE PATRIMONIAL (ATIVO IMOBILIZADO)
// ============================================================================

/**
 * Gera arquivo OFX a partir do acervo de Bens Patrimoniais
 * Representa os lançamentos financeiros de aquisição (DEBIT) e depreciação acumulada (CREDIT)
 */
export function gerarOfxPatrimonio(
  bens: BemPatrimonial[],
  empresas: Empresa[],
  centrosCusto: CentroCusto[],
  opcoes?: OpcoesExportacaoOfx
): string {
  const org = opcoes?.nomeOrganizacao || 'ContabGest Gestao Patrimonial';
  const acct = opcoes?.identificadorConta || 'ATIVO-IMOBILIZADO';
  const cur = opcoes?.moeda || 'BRL';

  const nowStr = formatarDataOfx();
  let menorData = '99999999120000';
  let maiorData = '00000000120000';
  let valorLiquidoTotal = 0;

  const transacoes: string[] = [];

  bens.forEach((b) => {
    const emp = empresas.find((e) => e.id === b.empresaId);
    const cc = centrosCusto.find((c) => c.id === b.centroCustoId);
    const empNome = emp?.razaoSocial || emp?.nomeFantasia || 'Empresa';
    const ccNome = cc ? `${cc.codigo}-${cc.nome}` : 'Geral';

    const dtAquisicao = formatarDataOfx(b.dataAquisicao);
    if (dtAquisicao < menorData) menorData = dtAquisicao;
    if (dtAquisicao > maiorData) maiorData = dtAquisicao;

    valorLiquidoTotal += b.valorContabilLiquido;

    // 1. Transação de Aquisição Histórica do Bem (Saída/Investimento - DEBIT)
    const fitidAquisicao = `AQ-${b.id.replace(/[^a-zA-Z0-9]/g, '')}-${dtAquisicao.slice(0, 8)}`;
    const memoAquisicao = sanitizarOfx(
      `AQUISICAO BEM [${b.numeroPatrimonio}] ${b.descricao} (NF ${b.numeroNotaFiscal}) [CC: ${ccNome}] - ${empNome}`
    );

    transacoes.push(`          <STMTTRN>
            <TRNTYPE>DEBIT</TRNTYPE>
            <DTPOSTED>${dtAquisicao}</DTPOSTED>
            <TRNAMT>-${b.valorAquisicao.toFixed(2)}</TRNAMT>
            <FITID>${fitidAquisicao}</FITID>
            <CHECKNUM>${b.placaIdentificacao || b.numeroPatrimonio}</CHECKNUM>
            <MEMO>${memoAquisicao}</MEMO>
          </STMTTRN>`);

    // 2. Se houver depreciação acumulada, gera lançamento contábil de quota de amortização (CREDIT)
    if (b.depreciacaoAcumulada > 0) {
      const dtDeprec = formatarDataOfx(); // data de conciliação atual
      const fitidDeprec = `DP-${b.id.replace(/[^a-zA-Z0-9]/g, '')}-${dtDeprec.slice(0, 8)}`;
      const memoDeprec = sanitizarOfx(
        `DEPREC ACUMULADA [${b.numeroPatrimonio}] ${b.descricao} (Taxa: ${b.taxaDepreciacaoAnual}% a.a.)`
      );

      transacoes.push(`          <STMTTRN>
            <TRNTYPE>CREDIT</TRNTYPE>
            <DTPOSTED>${dtDeprec}</DTPOSTED>
            <TRNAMT>${b.depreciacaoAcumulada.toFixed(2)}</TRNAMT>
            <FITID>${fitidDeprec}</FITID>
            <CHECKNUM>${b.placaIdentificacao || b.numeroPatrimonio}</CHECKNUM>
            <MEMO>${memoDeprec}</MEMO>
          </STMTTRN>`);
    }

    // 3. Se estiver baixado, gera a movimentação de alienação
    if (b.status === 'baixado' && b.dataBaixa) {
      const dtBaixa = formatarDataOfx(b.dataBaixa);
      const valorVenda = b.valorVenda || 0;
      const fitidBaixa = `BX-${b.id.replace(/[^a-zA-Z0-9]/g, '')}-${dtBaixa.slice(0, 8)}`;
      const memoBaixa = sanitizarOfx(
        `BAIXA/ALIENACAO [${b.numeroPatrimonio}] ${b.descricao} (${b.motivoBaixa || 'Baixa Contábil'})`
      );

      transacoes.push(`          <STMTTRN>
            <TRNTYPE>OTHER</TRNTYPE>
            <DTPOSTED>${dtBaixa}</DTPOSTED>
            <TRNAMT>${valorVenda.toFixed(2)}</TRNAMT>
            <FITID>${fitidBaixa}</FITID>
            <CHECKNUM>${b.notaFiscalBaixa || b.numeroPatrimonio}</CHECKNUM>
            <MEMO>${memoBaixa}</MEMO>
          </STMTTRN>`);
    }
  });

  if (menorData === '99999999120000') menorData = nowStr;
  if (maiorData === '00000000120000') maiorData = nowStr;

  return `OFXHEADER:100
DATA:OFXSGML
VERSION:102
SECURITY:NONE
ENCODING:UTF-8
CHARSET:NONE
COMPRESSION:NONE
OLDAUTH:NONE
NEWAUTH:NONE

<OFX>
  <SIGNONMSGSRSV1>
    <SONRS>
      <STATUS>
        <CODE>0</CODE>
        <SEVERITY>INFO</SEVERITY>
      </STATUS>
      <DTSERVER>${nowStr}</DTSERVER>
      <LANGUAGE>POR</LANGUAGE>
      <FI>
        <ORG>${sanitizarOfx(org, 32)}</ORG>
        <FID>888</FID>
      </FI>
    </SONRS>
  </SIGNONMSGSRSV1>
  <BANKMSGSRSV1>
    <STMTTRNRS>
      <TRNUID>2002</TRNUID>
      <STATUS>
        <CODE>0</CODE>
        <SEVERITY>INFO</SEVERITY>
      </STATUS>
      <STMTRS>
        <CURDEF>${cur}</CURDEF>
        <BANKACCTFROM>
          <BANKID>888</BANKID>
          <BRANCHID>0001</BRANCHID>
          <ACCTID>${sanitizarOfx(acct, 20)}</ACCTID>
          <ACCTTYPE>SAVINGS</ACCTTYPE>
        </BANKACCTFROM>
        <BANKTRANLIST>
          <DTSTART>${menorData}</DTSTART>
          <DTEND>${maiorData}</DTEND>
${transacoes.join('\n')}
        </BANKTRANLIST>
        <LEDGERBAL>
          <BALAMT>${valorLiquidoTotal.toFixed(2)}</BALAMT>
          <DTASOF>${nowStr}</DTASOF>
        </LEDGERBAL>
      </STMTRS>
    </STMTTRNRS>
  </BANKMSGSRSV1>
</OFX>`;
}

/**
 * Gera arquivo CSV completo de Inventário e Ficha de Bens Patrimoniais
 */
export function gerarCsvPatrimonio(
  bens: BemPatrimonial[],
  empresas: Empresa[],
  centrosCusto: CentroCusto[],
  opcoes?: OpcoesExportacaoCsv
): string {
  const delim = opcoes?.delimitador || ';';

  const cabecalhos = [
    'NUMERO_PATRIMONIO',
    'PLACA_IDENTIFICACAO',
    'DESCRICAO_DO_BEM',
    'CLASSIFICACAO_CONTABIL',
    'EMPRESA_PROPRIETARIA',
    'CNPJ_EMPRESA',
    'MARCA',
    'MODELO',
    'NUMERO_SERIE',
    'LOCALIZACAO_FISICA',
    'CODIGO_CENTRO_CUSTO',
    'NOME_CENTRO_CUSTO',
    'RESPONSAVEL',
    'STATUS_OPERACIONAL',
    'DATA_AQUISICAO',
    'NUMERO_NOTA_FISCAL',
    'SERIE_NF',
    'CHAVE_ACESSO_NFE',
    'FORNECEDOR',
    'CNPJ_FORNECEDOR',
    'VALOR_AQUISICAO',
    'AGIO',
    'DESAGIO',
    'RESIDUAL_PERCENTUAL',
    'VALOR_RESIDUAL',
    'VALOR_DEPRECIAVEL',
    'VIDA_UTIL_ANOS',
    'VIDA_UTIL_MESES',
    'TAXA_DEPRECIACAO_ANUAL_PCT',
    'DEPRECIACAO_MENSAL',
    'MESES_DEPRECIADOS',
    'DEPRECIACAO_ACUMULADA',
    'VALOR_CONTABIL_LIQUIDO',
    'CONTA_CONTABIL_IMOBILIZADO',
    'CONTA_CONTABIL_DEPREC_ACUM',
    'CONTA_CONTABIL_DESPESA_DEPREC',
    'TEM_SEGURO',
    'SEGURADORA',
    'NUMERO_APOLICE',
    'VIGENCIA_SEGURO_INICIO',
    'VIGENCIA_SEGURO_FIM',
    'VALOR_SEGURADO',
    'STATUS_SEGURO',
    'DATA_BAIXA',
    'MOTIVO_BAIXA',
    'VALOR_VENDA_BAIXA',
    'NF_BAIXA',
    'OBSERVACOES',
  ];

  const linhas = bens.map((b) => {
    const emp = empresas.find((e) => e.id === b.empresaId);
    const cc = centrosCusto.find((c) => c.id === b.centroCustoId);

    const row = [
      b.numeroPatrimonio,
      b.placaIdentificacao,
      b.descricao,
      b.classificacao,
      emp?.razaoSocial || emp?.nomeFantasia || 'Empresa Cliente',
      emp?.cnpj || '',
      b.marca || '',
      b.modelo || '',
      b.numeroSerie || '',
      b.localizacao || '',
      cc?.codigo || '',
      cc?.nome || '',
      b.responsavel || '',
      b.status.toUpperCase(),
      b.dataAquisicao,
      b.numeroNotaFiscal,
      b.serieNotaFiscal || '1',
      b.chaveAcessoNfe || '',
      b.fornecedorNome,
      b.fornecedorCnpj || '',
      b.valorAquisicao.toFixed(2).replace('.', ','),
      (b.agio || 0).toFixed(2).replace('.', ','),
      (b.desagio || 0).toFixed(2).replace('.', ','),
      (b.valorResidualPercentual || 10).toFixed(1).replace('.', ','),
      (b.valorResidual || 0).toFixed(2).replace('.', ','),
      (b.valorDepreciavel || 0).toFixed(2).replace('.', ','),
      b.vidaUtilAnos,
      b.vidaUtilAnos * 12,
      b.taxaDepreciacaoAnual.toFixed(1).replace('.', ','),
      b.depreciacaoMensal.toFixed(2).replace('.', ','),
      b.mesesDepreciados,
      b.depreciacaoAcumulada.toFixed(2).replace('.', ','),
      b.valorContabilLiquido.toFixed(2).replace('.', ','),
      '1.2.3.01',
      '1.2.3.09',
      '3.1.2.05',
      b.temSeguro ? 'SIM' : 'NAO',
      b.seguradora || '',
      b.numeroApolice || '',
      b.seguroDataInicio || '',
      b.seguroDataFim || '',
      (b.valorSegurado || 0).toFixed(2).replace('.', ','),
      b.seguroStatus ? b.seguroStatus.toUpperCase() : (b.temSeguro ? 'VIGENTE' : 'SEM_SEGURO'),
      b.dataBaixa || '',
      b.motivoBaixa || '',
      (b.valorVenda || 0).toFixed(2).replace('.', ','),
      b.notaFiscalBaixa || '',
      b.observacoes || '',
    ];

    return row.map((campo) => escaparCsv(campo, delim)).join(delim);
  });

  return '\uFEFF' + [cabecalhos.join(delim), ...linhas].join('\r\n');
}

/**
 * Dispara o download de um arquivo gerado no navegador do usuário
 */
export function baixarArquivo(conteudo: string, nomeArquivo: string, tipoMime: string) {
  const blob = new Blob([conteudo], { type: `${tipoMime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = nomeArquivo;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
