import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { EspelhoPontoMensal, RegistroPontoDia } from '../types';

export function formatMinutosParaHorasExtenso(minutos?: number): string {
  if (minutos === undefined || minutos === null) return '00:00';
  const sinal = minutos < 0 ? '-' : '';
  const abs = Math.abs(minutos);
  const h = Math.floor(abs / 60);
  const m = abs % 60;
  return `${sinal}${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

export function formatMoedaReal(valor?: number): string {
  if (valor === undefined || valor === null) return 'R$ 0,00';
  return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

export function formatDataPtBr(dataIso?: string): string {
  if (!dataIso) return '-';
  const partes = dataIso.split('-');
  if (partes.length === 3) {
    return `${partes[2]}/${partes[1]}/${partes[0]}`;
  }
  return dataIso;
}

export interface GerarPdfOptions {
  autoDownload?: boolean;
  nomeArquivo?: string;
}

/**
 * Gera o Espelho de Ponto Eletrônico Individual em formato PDF
 * em total conformidade com o Artigo 84 da Portaria MTP nº 671/2021.
 */
export function gerarEspelhoPontoPdf(
  espelho: EspelhoPontoMensal,
  options: GerarPdfOptions = { autoDownload: true }
): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const marginX = 12;
  const contentWidth = pageWidth - marginX * 2; // 186mm

  // =========================================================================
  // 1. CABEÇALHO DO DOCUMENTO
  // =========================================================================
  // Faixa superior com identidade corporativa
  doc.setFillColor(30, 41, 59); // slate-800
  doc.rect(marginX, 10, contentWidth, 18, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('ESPELHO DE PONTO ELETRÔNICO INDIVIDUAL', marginX + 4, 17);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(203, 213, 225); // slate-300
  doc.text('REP-P Homologado • Portaria MTP nº 671/2021, Art. 84 • Programa ContabGest RH', marginX + 4, 23);

  // Competência e Emissão à direita
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.text(`COMPETÊNCIA: ${espelho.competencia}`, pageWidth - marginX - 4, 17, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(226, 232, 240);
  const dataHoje = new Date().toLocaleDateString('pt-BR');
  doc.text(`Emissão: ${dataHoje}`, pageWidth - marginX - 4, 23, { align: 'right' });

  // =========================================================================
  // 2. DADOS DA EMPRESA E DO EMPREGADO
  // =========================================================================
  let currentY = 31;

  // Bloco Empregador & Empregado
  doc.setDrawColor(203, 213, 225); // slate-300
  doc.setFillColor(248, 250, 252); // slate-50
  doc.roundedRect(marginX, currentY, contentWidth, 26, 1.5, 1.5, 'FD');

  // Linha divisória vertical
  const colMeio = marginX + contentWidth / 2;
  doc.setDrawColor(226, 232, 240);
  doc.line(colMeio, currentY + 2, colMeio, currentY + 24);

  // Coluna Esquerda: EMPREGADOR
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  doc.text('IDENTIFICAÇÃO DO EMPREGADOR:', marginX + 3, currentY + 5);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text(espelho.empresa?.razaoSocial || 'EMPRESA EMPREGADORA LTDA', marginX + 3, currentY + 10);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(51, 65, 85);
  doc.text(`CNPJ: ${espelho.empresa?.cnpj || 'Não informado'}`, marginX + 3, currentY + 15);
  doc.text(`Endereço: ${espelho.empresa?.endereco || 'Sede Principal'}`, marginX + 3, currentY + 19.5);
  doc.text(`Cidade/UF: ${espelho.empresa?.cidadeUf || 'São Paulo/SP'}`, marginX + 3, currentY + 24);

  // Coluna Direita: EMPREGADO
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  doc.text('IDENTIFICAÇÃO DO EMPREGADO:', colMeio + 3, currentY + 5);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text(espelho.funcionario?.nome || 'COLABORADOR', colMeio + 3, currentY + 10);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(51, 65, 85);
  doc.text(
    `CPF: ${espelho.funcionario?.cpf || '-'}  •  PIS: ${espelho.funcionario?.pisPasep || '-'}  •  Matrícula: ${espelho.funcionario?.matricula || '-'}`,
    colMeio + 3,
    currentY + 15
  );
  doc.text(
    `Cargo: ${espelho.funcionario?.cargo || '-'}  •  Depto: ${espelho.funcionario?.departamento || '-'}`,
    colMeio + 3,
    currentY + 19.5
  );
  doc.text(
    `Admissão: ${formatDataPtBr(espelho.funcionario?.dataAdmissao)}  •  Jornada: 44h sem (08:00-17:00 c/ 1h int.)`,
    colMeio + 3,
    currentY + 24
  );

  currentY += 29;

  // =========================================================================
  // 3. TABELA DE MARCAÇÕES DIÁRIAS (PORTARIA 671/2021)
  // =========================================================================
  const tableRows = espelho.dias.map((d: RegistroPontoDia) => {
    const diaNum = d.data.split('-')[2] || '';
    const diaSem = d.diaSemana ? d.diaSemana.substring(0, 3) : '';

    const ent1 = d.entrada1 || '-';
    const sai1 = d.saidaIntervalo || '-';
    const ent2 = d.retornoIntervalo || '-';
    const sai2 = d.saida2 || '-';

    const trab = d.horasTrabalhadasMinutos > 0 ? formatMinutosParaHorasExtenso(d.horasTrabalhadasMinutos) : '-';
    const prev = d.horasPrevistasMinutos > 0 ? formatMinutosParaHorasExtenso(d.horasPrevistasMinutos) : '-';

    const he50 = (d.horasExtras50Minutos || 0) > 0 ? `+${formatMinutosParaHorasExtenso(d.horasExtras50Minutos)}` : '-';
    const he100 = (d.horasExtras100Minutos || 0) > 0 ? `+${formatMinutosParaHorasExtenso(d.horasExtras100Minutos)}` : '-';
    const atraso = (d.horasNegativasMinutos || 0) > 0 ? `-${formatMinutosParaHorasExtenso(d.horasNegativasMinutos)}` : '-';

    let ocorrencia = d.ocorrenciaDescricao || '';
    if (!ocorrencia) {
      if (d.tipoDia === 'dsr') ocorrencia = 'DSR';
      else if (d.tipoDia === 'sabado_compensado') ocorrencia = 'Sábado Compensado';
      else if (d.tipoDia === 'feriado') ocorrencia = 'Feriado Nacional';
      else if (d.tipoDia === 'ferias') ocorrencia = 'Férias';
      else if (d.isFaltaIntegral) ocorrencia = 'Falta Integral';
      else if (d.horasTrabalhadasMinutos > 0) ocorrencia = 'Normal';
    }

    // Se houve ajuste manual do RH
    if (d.statusAuditoria === 'ajustado') {
      ocorrencia += ' [Ajuste RH]';
    }

    return [
      diaNum,
      diaSem,
      ent1,
      sai1,
      ent2,
      sai2,
      trab,
      prev,
      he50,
      he100,
      atraso,
      ocorrencia,
    ];
  });

  // Linha de Totalização da Tabela
  const totalTrabStr = formatMinutosParaHorasExtenso(espelho.totalHorasTrabalhadasMinutos);
  const totalPrevStr = formatMinutosParaHorasExtenso(espelho.totalHorasPrevistasMinutos);
  const totalHe50Str = formatMinutosParaHorasExtenso(espelho.totalHorasExtras50Minutos || 0);
  const totalHe100Str = formatMinutosParaHorasExtenso(espelho.totalHorasExtras100Minutos || 0);
  const totalNegativoMinutos = (espelho.totalAtrasosMinutos || 0) + (espelho.totalFaltasMinutos || 0);
  const totalAtrasoStr = formatMinutosParaHorasExtenso(totalNegativoMinutos);

  tableRows.push([
    'TOTAL',
    '',
    '',
    '',
    '',
    '',
    totalTrabStr,
    totalPrevStr,
    `+${totalHe50Str}`,
    `+${totalHe100Str}`,
    `-${totalAtrasoStr}`,
    `Saldo: ${formatMinutosParaHorasExtenso(espelho.saldoHorasMinutos)}`,
  ]);

  autoTable(doc, {
    startY: currentY,
    head: [[
      'Dia',
      'Sem',
      '1ª Ent',
      '1ª Saí',
      '2ª Ent',
      '2ª Saí',
      'H. Trab',
      'H. Prev',
      'H.E. 50%',
      'H.E. 100%',
      'Faltas/Atr',
      'Ocorrência / Justificativa',
    ]],
    body: tableRows,
    theme: 'grid',
    margin: { left: marginX, right: marginX, bottom: 50 },
    styles: {
      fontSize: 6.8,
      cellPadding: 1.1,
      font: 'helvetica',
      textColor: [15, 23, 42],
      lineColor: [203, 213, 225],
      lineWidth: 0.15,
      halign: 'center',
      valign: 'middle',
    },
    headStyles: {
      fillColor: [51, 65, 85], // slate-700
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 6.8,
      halign: 'center',
    },
    columnStyles: {
      0: { cellWidth: 8, fontStyle: 'bold' },
      1: { cellWidth: 9 },
      2: { cellWidth: 12 },
      3: { cellWidth: 12 },
      4: { cellWidth: 12 },
      5: { cellWidth: 12 },
      6: { cellWidth: 13, fontStyle: 'bold' },
      7: { cellWidth: 13 },
      8: { cellWidth: 15, textColor: [16, 185, 129], fontStyle: 'bold' }, // verde
      9: { cellWidth: 15, textColor: [5, 150, 105], fontStyle: 'bold' }, // verde escuro
      10: { cellWidth: 15, textColor: [220, 38, 38], fontStyle: 'bold' }, // vermelho
      11: { cellWidth: 'auto', halign: 'left' },
    },
    didParseCell: (data) => {
      // Destaque da linha de totais
      if (data.row.index === tableRows.length - 1) {
        data.cell.styles.fillColor = [241, 245, 249];
        data.cell.styles.fontStyle = 'bold';
      }
    },
  });

  // =========================================================================
  // 4. QUADRO DE APURAÇÃO CONSOLIDADA E ESTIMATIVAS FINANCEIRAS
  // =========================================================================
  // Pega a posição logo após a tabela ou inicia nova página se necessário
  // @ts-ignore
  let finalTableY = (doc as any).lastAutoTable?.finalY || 185;

  // Se estiver muito próximo do fim da página, cria nova página
  if (finalTableY > 220) {
    doc.addPage();
    finalTableY = 15;
  } else {
    finalTableY += 4;
  }

  const boxHeight = 36;
  const boxWidthHalf = (contentWidth - 4) / 2;

  // Bloco 1: Consolidado de Horas
  doc.setDrawColor(203, 213, 225);
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(marginX, finalTableY, boxWidthHalf, boxHeight, 1.5, 1.5, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(30, 41, 59);
  doc.text('CONSOLIDAÇÃO DA JORNADA & HORAS:', marginX + 3, finalTableY + 5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.2);
  doc.setTextColor(71, 85, 105);

  doc.text(
    `Dias Úteis no Mês: ${espelho.totalDiasUteis || 0}   •   DSR / Feriados: ${espelho.totalDiasDsr || 0}   •   Dias Trab.: ${espelho.totalDiasTrabalhados || 0}`,
    marginX + 3,
    finalTableY + 10
  );
  doc.text(
    `Horas Previstas: ${formatMinutosParaHorasExtenso(espelho.totalHorasPrevistasMinutos)}   •   Horas Trabalhadas: ${formatMinutosParaHorasExtenso(espelho.totalHorasTrabalhadasMinutos)}`,
    marginX + 3,
    finalTableY + 14.5
  );
  doc.text(
    `Horas Extras 50%: +${formatMinutosParaHorasExtenso(espelho.totalHorasExtras50Minutos || 0)}   •   Horas Extras 100%: +${formatMinutosParaHorasExtenso(espelho.totalHorasExtras100Minutos || 0)}`,
    marginX + 3,
    finalTableY + 19
  );
  doc.text(
    `Reflexo DSR s/ H.E. (Lei 605/49): +${formatMinutosParaHorasExtenso(espelho.totalDsrSobreHorasExtrasMinutos || 0)}`,
    marginX + 3,
    finalTableY + 23.5
  );
  doc.text(
    `Atrasos: -${formatMinutosParaHorasExtenso(espelho.totalAtrasosMinutos || 0)}   •   Faltas Integrais: -${formatMinutosParaHorasExtenso(espelho.totalFaltasMinutos || 0)} (${espelho.totalFaltasDias || 0} dias)`,
    marginX + 3,
    finalTableY + 28
  );

  doc.setFont('helvetica', 'bold');
  const saldoSinal = (espelho.saldoHorasMinutos || 0) >= 0 ? '+' : '';
  const saldoCor: [number, number, number] = (espelho.saldoHorasMinutos || 0) >= 0 ? [16, 185, 129] : [220, 38, 38];
  doc.setTextColor(...saldoCor);
  doc.text(
    `SALDO DE BANCO DE HORAS: ${saldoSinal}${formatMinutosParaHorasExtenso(espelho.saldoHorasMinutos)}`,
    marginX + 3,
    finalTableY + 33
  );

  // Bloco 2: Reflexo Financeiro Estimado na Folha
  const box2X = marginX + boxWidthHalf + 4;
  doc.setDrawColor(203, 213, 225);
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(box2X, finalTableY, boxWidthHalf, boxHeight, 1.5, 1.5, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(30, 41, 59);
  doc.text('ESTIMATIVA DE PROVENTOS & DESCONTOS (R$):', box2X + 3, finalTableY + 5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.2);
  doc.setTextColor(71, 85, 105);

  doc.text(
    `Salário Base: ${formatMoedaReal(espelho.funcionario?.salarioBase)}   •   Valor Hora (div. 220): ${formatMoedaReal(espelho.valorHoraNormal)}`,
    box2X + 3,
    finalTableY + 10
  );
  doc.text(
    `Adicional H.E. 50% (+50%): ${formatMoedaReal(espelho.valorHorasExtras50)}`,
    box2X + 3,
    finalTableY + 14.5
  );
  doc.text(
    `Adicional H.E. 100% (+100%): ${formatMoedaReal(espelho.valorHorasExtras100)}`,
    box2X + 3,
    finalTableY + 19
  );
  doc.text(
    `Reflexo DSR sobre Horas Extras: ${formatMoedaReal(espelho.valorDsrHorasExtras)}`,
    box2X + 3,
    finalTableY + 23.5
  );
  doc.text(
    `Descontos Faltas e Atrasos: -${formatMoedaReal(espelho.valorTotalDescontosPonto)}`,
    box2X + 3,
    finalTableY + 28
  );

  doc.setFont('helvetica', 'bold');
  const saldoFinCor: [number, number, number] = (espelho.saldoFinanceiroLiquido || 0) >= 0 ? [5, 150, 105] : [185, 28, 28];
  doc.setTextColor(...saldoFinCor);
  doc.text(
    `IMPACTO LÍQUIDO NO HOLERITE: ${formatMoedaReal(espelho.saldoFinanceiroLiquido)}`,
    box2X + 3,
    finalTableY + 33
  );

  // =========================================================================
  // 5. TERMO DE CIÊNCIA E ASSINATURAS (PORTARIA 671 MTP)
  // =========================================================================
  let assinaturasY = finalTableY + boxHeight + 4;

  if (assinaturasY > 260) {
    doc.addPage();
    assinaturasY = 15;
  }

  // Declaração Legal
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  const declaracao =
    'Reconheço a exatidão das marcações de entrada, intervalos e saídas registradas neste espelho de ponto referente ao período indicado, nos termos do Art. 74 da CLT e Art. 84 da Portaria MTP nº 671/2021. Documento emitido por sistema REP-P devidamente cadastrado no MTE.';
  doc.text(declaracao, marginX, assinaturasY, { maxWidth: contentWidth });

  // Código Hash de Autenticidade
  doc.setFont('courier', 'normal');
  doc.setFontSize(6.2);
  doc.setTextColor(148, 163, 184);
  doc.text(
    `HASH SHA-256: ${espelho.hashAutenticidade || 'E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855'} • DATA DA APURAÇÃO: ${dataHoje}`,
    marginX,
    assinaturasY + 6
  );

  // Linhas de Assinatura
  const linhaY = assinaturasY + 18;
  const largAssinatura = 75;

  // Linha Empregado
  doc.setDrawColor(148, 163, 184);
  doc.setLineWidth(0.3);
  doc.line(marginX + 8, linhaY, marginX + 8 + largAssinatura, linhaY);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  doc.text(espelho.funcionario?.nome || 'Assinatura do Empregado', marginX + 8 + largAssinatura / 2, linhaY + 4, {
    align: 'center',
  });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.text(`CPF: ${espelho.funcionario?.cpf || '-'}`, marginX + 8 + largAssinatura / 2, linhaY + 7.5, {
    align: 'center',
  });

  // Linha Empregador
  const empLinhaX = pageWidth - marginX - 8 - largAssinatura;
  doc.line(empLinhaX, linhaY, empLinhaX + largAssinatura, linhaY);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(15, 23, 42);
  doc.text('Departamento de Recursos Humanos', empLinhaX + largAssinatura / 2, linhaY + 4, {
    align: 'center',
  });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(100, 116, 139);
  doc.text(espelho.empresa?.razaoSocial || 'Empregador', empLinhaX + largAssinatura / 2, linhaY + 7.5, {
    align: 'center',
  });

  // =========================================================================
  // SALVAMENTO / DOWNLOAD
  // =========================================================================
  if (options.autoDownload) {
    const nomeLimpo = (espelho.funcionario?.nome || 'colaborador')
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '_');
    const compLimpa = espelho.competencia.replace('/', '_');
    const fileName = options.nomeArquivo || `espelho_ponto_${nomeLimpo}_${compLimpa}.pdf`;
    doc.save(fileName);
  }

  return doc;
}
