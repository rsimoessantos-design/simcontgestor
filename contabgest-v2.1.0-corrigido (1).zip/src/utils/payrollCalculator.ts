/**
 * Motor de Cálculo Trabalhista e Previdenciário Brasileiro (CLT)
 * Atualizado com as tabelas vigentes de INSS Progressivo, IRRF Mensal com Dedução Simplificada,
 * FGTS Digital, Horas Extras, DSR, Insalubridade, Periculosidade e Benefícios.
 */

import { Funcionario, HoleriteCalculado, ItemHolerite } from '../types';

export const SALARIO_MINIMO_NACIONAL = 1412.0;
export const TETO_INSS = 7786.02;
export const TETO_VALOR_INSS = 908.86;
export const DEDUCAO_DEPENDENTE_IRRF = 189.59;
export const DESCONTO_SIMPLIFICADO_IRRF = 564.8; // 25% da 1ª faixa de isenção

export interface InssFaixaCalculo {
  faixaNumero: number;
  descricao: string;
  limiteInferior: number;
  limiteSuperior: number;
  aliquota: number;
  baseTributada: number;
  valorContribuicao: number;
}

export interface ResultadoINSS {
  valorTotal: number;
  aliquotaEfetiva: number;
  aliquotaEfetivaTexto: string;
  atingiuTeto: boolean;
  faixas: InssFaixaCalculo[];
}

export interface ResultadoIRRF {
  baseBrutaTributavel: number;
  totalDeducoesLegais: number;
  deducaoInss: number;
  deducaoDependentes: number;
  deducaoPensao: number;
  deducaoOutros: number;
  baseCalculoLegal: number;
  baseCalculoSimplificado: number;
  opcaoMaisVantajosa: 'legal' | 'simplificada';
  baseCalculoEfetiva: number;
  faixaNominal: string;
  aliquotaNominal: number;
  parcelaADeduzir: number;
  valorImposto: number;
  aliquotaEfetiva: number;
  isento: boolean;
}

export interface ParametrosCalculoFolha {
  funcionario?: Funcionario;
  competencia?: string;
  salarioBase: number;
  horasExtras50Horas?: number;
  horasExtras100Horas?: number;
  diasUteisMes?: number;
  domingosEFeriados?: number;
  adicionalNoturnoHoras?: number;
  grauInsalubridade?: 'nenhum' | 'minimo' | 'medio' | 'maximo';
  adicionalPericulosidade?: boolean;
  comissoesGratificacoes?: number;
  outrosProventos?: number;
  faltasDias?: number;
  atrasosHoras?: number;
  valeTransporteOptante?: boolean;
  valeTransporteCustoReal?: number;
  valeRefeicaoCoparticipacao?: number;
  planoSaudeCoparticipacao?: number;
  adiantamentoSalarial?: number;
  dependentesIrrf?: number;
  pensaoAlimenticia?: number;
  outrosDescontos?: number;
  tipoContrato?: string;
}

export interface EncargosEmpresa {
  inssPatronal: number; // 20%
  ratFap: number; // 1% a 3%
  terceirosSistemaS: number; // 5.8%
  fgts: number; // 8% ou 2%
  provisao13Salario: number; // 1/12
  provisaoFeriasTerco: number; // 1/12 + 1/3
  totalEncargosSociais: number;
  custoTotalColaborador: number;
}

/**
 * Cálculo progressivo do INSS conforme Emenda Constitucional 103/2019
 */
export function calcularInssProgressivo(baseCalculo: number): ResultadoINSS {
  const baseTributavel = Math.max(0, baseCalculo);

  const limitesFaixas = [
    { num: 1, min: 0, max: 1412.0, aliq: 0.075, label: '1ª Faixa (até R$ 1.412,00 - 7,5%)' },
    { num: 2, min: 1412.0, max: 2666.68, aliq: 0.09, label: '2ª Faixa (de R$ 1.412,01 até R$ 2.666,68 - 9%)' },
    { num: 3, min: 2666.68, max: 4000.03, aliq: 0.12, label: '3ª Faixa (de R$ 2.666,69 até R$ 4.000,03 - 12%)' },
    { num: 4, min: 4000.03, max: 7786.02, aliq: 0.14, label: '4ª Faixa (de R$ 4.000,04 até R$ 7.786,02 - 14%)' },
  ];

  let valorTotal = 0;
  const faixas: InssFaixaCalculo[] = [];

  for (const f of limitesFaixas) {
    if (baseTributavel > f.min) {
      const tetoFaixa = Math.min(baseTributavel, f.max);
      const baseNaFaixa = Math.max(0, tetoFaixa - f.min);
      const valorFaixa = Math.round(baseNaFaixa * f.aliq * 100) / 100;
      valorTotal += valorFaixa;

      faixas.push({
        faixaNumero: f.num,
        descricao: f.label,
        limiteInferior: f.min,
        limiteSuperior: f.max,
        aliquota: f.aliq,
        baseTributada: Math.round(baseNaFaixa * 100) / 100,
        valorContribuicao: valorFaixa,
      });
    } else {
      faixas.push({
        faixaNumero: f.num,
        descricao: f.label,
        limiteInferior: f.min,
        limiteSuperior: f.max,
        aliquota: f.aliq,
        baseTributada: 0,
        valorContribuicao: 0,
      });
    }
  }

  const atingiuTeto = baseTributavel >= TETO_INSS;
  if (atingiuTeto) {
    valorTotal = TETO_VALOR_INSS;
  } else {
    valorTotal = Math.min(TETO_VALOR_INSS, Math.round(valorTotal * 100) / 100);
  }

  const aliquotaEfetiva = baseTributavel > 0 ? (valorTotal / baseTributavel) * 100 : 0;
  const aliquotaEfetivaTexto = atingiuTeto
    ? `Teto Previdenciário (R$ ${TETO_VALOR_INSS.toFixed(2)})`
    : `${aliquotaEfetiva.toFixed(2)}% efetiva`;

  return {
    valorTotal: Math.round(valorTotal * 100) / 100,
    aliquotaEfetiva: Math.round(aliquotaEfetiva * 100) / 100,
    aliquotaEfetivaTexto,
    atingiuTeto,
    faixas,
  };
}

/**
 * Cálculo do IRRF na fonte com comparativo entre deduções legais e desconto simplificado
 */
export function calcularIrrf(
  baseBrutaTributavel: number,
  inssDescontado: number,
  dependentesQtd = 0,
  pensaoAlimenticia = 0,
  outrasDeducoes = 0
): ResultadoIRRF {
  const deducaoDependentes = dependentesQtd * DEDUCAO_DEPENDENTE_IRRF;
  const totalDeducoesLegais = inssDescontado + deducaoDependentes + pensaoAlimenticia + outrasDeducoes;

  const baseCalculoLegal = Math.max(0, baseBrutaTributavel - totalDeducoesLegais);
  const baseCalculoSimplificado = Math.max(0, baseBrutaTributavel - DESCONTO_SIMPLIFICADO_IRRF);

  // Calcula imposto pelo modelo de deduções legais
  const calcImpostoTabela = (base: number) => {
    if (base <= 2259.2) {
      return { aliquota: 0, parcela: 0, faixa: 'Isento (até R$ 2.259,20)', valor: 0 };
    } else if (base <= 2826.65) {
      const imp = base * 0.075 - 169.44;
      return { aliquota: 0.075, parcela: 169.44, faixa: '7,5% (de R$ 2.259,21 a R$ 2.826,65)', valor: Math.max(0, imp) };
    } else if (base <= 3751.05) {
      const imp = base * 0.15 - 381.44;
      return { aliquota: 0.15, parcela: 381.44, faixa: '15,0% (de R$ 2.826,66 a R$ 3.751,05)', valor: Math.max(0, imp) };
    } else if (base <= 4664.68) {
      const imp = base * 0.225 - 662.77;
      return { aliquota: 0.225, parcela: 662.77, faixa: '22,5% (de R$ 3.751,06 a R$ 4.664,68)', valor: Math.max(0, imp) };
    } else {
      const imp = base * 0.275 - 896.0;
      return { aliquota: 0.275, parcela: 896.0, faixa: '27,5% (acima de R$ 4.664,68)', valor: Math.max(0, imp) };
    }
  };

  const impostoLegal = calcImpostoTabela(baseCalculoLegal);
  const impostoSimplificado = calcImpostoTabela(baseCalculoSimplificado);

  // Aplica o mais benéfico ao colaborador (menor imposto)
  const usaSimplificado = impostoSimplificado.valor < impostoLegal.valor;
  const opcaoMaisVantajosa = usaSimplificado ? 'simplificada' : 'legal';
  const resultadoEscolhido = usaSimplificado ? impostoSimplificado : impostoLegal;
  const baseCalculoEfetiva = usaSimplificado ? baseCalculoSimplificado : baseCalculoLegal;

  const valorFinal = Math.round(resultadoEscolhido.valor * 100) / 100;
  const aliquotaEfetiva = baseBrutaTributavel > 0 ? (valorFinal / baseBrutaTributavel) * 100 : 0;

  return {
    baseBrutaTributavel,
    totalDeducoesLegais,
    deducaoInss: inssDescontado,
    deducaoDependentes,
    deducaoPensao: pensaoAlimenticia,
    deducaoOutros: outrasDeducoes,
    baseCalculoLegal: Math.round(baseCalculoLegal * 100) / 100,
    baseCalculoSimplificado: Math.round(baseCalculoSimplificado * 100) / 100,
    opcaoMaisVantajosa,
    baseCalculoEfetiva: Math.round(baseCalculoEfetiva * 100) / 100,
    faixaNominal: resultadoEscolhido.faixa,
    aliquotaNominal: resultadoEscolhido.aliquota * 100,
    parcelaADeduzir: resultadoEscolhido.parcela,
    valorImposto: valorFinal,
    aliquotaEfetiva: Math.round(aliquotaEfetiva * 100) / 100,
    isento: valorFinal === 0,
  };
}

/**
 * Realiza a apuração completa da folha de pagamento do colaborador
 */
export function calcularFolhaCompleta(params: ParametrosCalculoFolha): HoleriteCalculado & {
  memoriaInss: ResultadoINSS;
  memoriaIrrf: ResultadoIRRF;
  encargosEmpresa: EncargosEmpresa;
} {
  const salarioBase = Number(params.salarioBase) || 0;
  const cargaHoraria = 220; // Padrão 44h semanais CLT
  const valorHora = cargaHoraria > 0 ? salarioBase / cargaHoraria : 0;

  const itens: ItemHolerite[] = [];

  // 1. Salário Base
  itens.push({
    codigo: '001',
    descricao: 'Salário Base Contratual',
    referencia: '30D',
    tipo: 'provento',
    valor: Math.round(salarioBase * 100) / 100,
  });

  // 2. Horas Extras 50% e 100%
  const he50Qtd = Number(params.horasExtras50Horas) || 0;
  const valorHe50 = Math.round(he50Qtd * valorHora * 1.5 * 100) / 100;
  if (valorHe50 > 0) {
    itens.push({
      codigo: '010',
      descricao: 'Horas Extras 50%',
      referencia: `${he50Qtd}h`,
      tipo: 'provento',
      valor: valorHe50,
    });
  }

  const he100Qtd = Number(params.horasExtras100Horas) || 0;
  const valorHe100 = Math.round(he100Qtd * valorHora * 2.0 * 100) / 100;
  if (valorHe100 > 0) {
    itens.push({
      codigo: '011',
      descricao: 'Horas Extras 100% (Domingos/Feriados)',
      referencia: `${he100Qtd}h`,
      tipo: 'provento',
      valor: valorHe100,
    });
  }

  // DSR sobre Horas Extras (CLT Lei 605/49)
  let valorDsr = 0;
  const totalHorasExtras = valorHe50 + valorHe100;
  if (totalHorasExtras > 0) {
    const diasUteis = params.diasUteisMes || 25;
    const domingosEFeriados = params.domingosEFeriados || 5;
    valorDsr = Math.round((totalHorasExtras / diasUteis) * domingosEFeriados * 100) / 100;
    itens.push({
      codigo: '012',
      descricao: 'DSR s/ Horas Extras (Lei 605/49)',
      referencia: `${domingosEFeriados}D`,
      tipo: 'provento',
      valor: valorDsr,
    });
  }

  // 3. Adicional Noturno (20%)
  const horasNoturnas = Number(params.adicionalNoturnoHoras) || 0;
  const valorNoturno = Math.round(horasNoturnas * valorHora * 0.2 * 100) / 100;
  if (valorNoturno > 0) {
    itens.push({
      codigo: '013',
      descricao: 'Adicional Noturno 20% (Art. 73 CLT)',
      referencia: `${horasNoturnas}h`,
      tipo: 'provento',
      valor: valorNoturno,
    });
  }

  // 4. Insalubridade (calculada sobre Salário Mínimo R$ 1.412,00)
  let valorInsalubridade = 0;
  if (params.grauInsalubridade && params.grauInsalubridade !== 'nenhum') {
    const aliquota =
      params.grauInsalubridade === 'maximo' ? 0.4 : params.grauInsalubridade === 'medio' ? 0.2 : 0.1;
    valorInsalubridade = Math.round(SALARIO_MINIMO_NACIONAL * aliquota * 100) / 100;
    itens.push({
      codigo: '014',
      descricao: `Adicional de Insalubridade (${params.grauInsalubridade.toUpperCase()})`,
      referencia: `${aliquota * 100}%`,
      tipo: 'provento',
      valor: valorInsalubridade,
    });
  }

  // 5. Periculosidade (30% sobre o salário base sem acréscimos)
  let valorPericulosidade = 0;
  if (params.adicionalPericulosidade) {
    valorPericulosidade = Math.round(salarioBase * 0.3 * 100) / 100;
    itens.push({
      codigo: '015',
      descricao: 'Adicional de Periculosidade (Art. 193 CLT)',
      referencia: '30%',
      tipo: 'provento',
      valor: valorPericulosidade,
    });
  }

  // 6. Gratificações / Comissões
  const comissoes = Number(params.comissoesGratificacoes) || 0;
  if (comissoes > 0) {
    itens.push({
      codigo: '020',
      descricao: 'Comissões / Gratificações de Função',
      referencia: 'Variável',
      tipo: 'provento',
      valor: comissoes,
    });
  }

  const outrosProventos = Number(params.outrosProventos) || 0;
  if (outrosProventos > 0) {
    itens.push({
      codigo: '029',
      descricao: 'Outros Proventos / Bonificação',
      referencia: 'Avulso',
      tipo: 'provento',
      valor: outrosProventos,
    });
  }

  // Faltas e atrasos
  const diasFalta = Number(params.faltasDias) || 0;
  const horasAtraso = Number(params.atrasosHoras) || 0;
  let valorFaltas = 0;
  if (diasFalta > 0) {
    // 1 dia de falta + 1 dia de DSR descontado
    const valorDia = salarioBase / 30;
    valorFaltas = Math.round((diasFalta * valorDia + valorDia) * 100) / 100;
    itens.push({
      codigo: '108',
      descricao: 'Faltas Injustificadas e Perda de DSR',
      referencia: `${diasFalta}D+DSR`,
      tipo: 'desconto',
      valor: valorFaltas,
    });
  }

  let valorAtrasos = 0;
  if (horasAtraso > 0) {
    valorAtrasos = Math.round(horasAtraso * valorHora * 100) / 100;
    itens.push({
      codigo: '109',
      descricao: 'Atrasos / Saídas Antecipadas',
      referencia: `${horasAtraso}h`,
      tipo: 'desconto',
      valor: valorAtrasos,
    });
  }

  // Soma Total de Proventos Brutos
  const totalProventosSemDescontos =
    salarioBase +
    valorHe50 +
    valorHe100 +
    valorDsr +
    valorNoturno +
    valorInsalubridade +
    valorPericulosidade +
    comissoes +
    outrosProventos;

  const totalProventos = Math.round(totalProventosSemDescontos * 100) / 100;

  // Base de Cálculo INSS (salário + proventos tributáveis - faltas)
  const baseInss = Math.max(0, totalProventos - valorFaltas - valorAtrasos);
  const memoriaInss = calcularInssProgressivo(baseInss);

  // Adiciona item do INSS
  itens.push({
    codigo: '101',
    descricao: 'INSS - Previdência Social',
    referencia: memoriaInss.aliquotaEfetivaTexto,
    tipo: 'desconto',
    valor: memoriaInss.valorTotal,
  });

  // Desconto Vale Transporte (máximo 6% do salário base contratual)
  let valorVt = 0;
  if (params.valeTransporteOptante) {
    const descontoMaximo = Math.round(salarioBase * 0.06 * 100) / 100;
    const custoReal = Number(params.valeTransporteCustoReal) || descontoMaximo;
    valorVt = Math.min(descontoMaximo, custoReal);
    itens.push({
      codigo: '105',
      descricao: 'Vale Transporte (Lei 7.418/85)',
      referencia: '6,0%',
      tipo: 'desconto',
      valor: valorVt,
    });
  }

  // Dependentes e Pensão para IRRF
  const dependentes = Number(params.dependentesIrrf) || 0;
  const pensao = Number(params.pensaoAlimenticia) || 0;
  const memoriaIrrf = calcularIrrf(baseInss, memoriaInss.valorTotal, dependentes, pensao);

  if (memoriaIrrf.valorImposto > 0) {
    itens.push({
      codigo: '102',
      descricao: 'IRRF - Imposto de Renda Retido',
      referencia: `${memoriaIrrf.aliquotaNominal.toFixed(1)}% (${memoriaIrrf.opcaoMaisVantajosa === 'simplificada' ? 'Simplificado' : 'Legal'})`,
      tipo: 'desconto',
      valor: memoriaIrrf.valorImposto,
    });
  }

  // Coparticipação Benefícios
  const copartVr = Number(params.valeRefeicaoCoparticipacao) || 0;
  if (copartVr > 0) {
    itens.push({
      codigo: '106',
      descricao: 'Coparticipação Vale Refeição / Alimentação',
      referencia: 'PAT',
      tipo: 'desconto',
      valor: copartVr,
    });
  }

  const copartSaude = Number(params.planoSaudeCoparticipacao) || 0;
  if (copartSaude > 0) {
    itens.push({
      codigo: '107',
      descricao: 'Coparticipação Plano de Saúde / Odontológico',
      referencia: 'Convênio',
      tipo: 'desconto',
      valor: copartSaude,
    });
  }

  // Adiantamento Salarial (Vale)
  const adiantamento = Number(params.adiantamentoSalarial) || 0;
  if (adiantamento > 0) {
    itens.push({
      codigo: '110',
      descricao: 'Adiantamento Salarial (Vale Quinzenal)',
      referencia: 'Adiant.',
      tipo: 'desconto',
      valor: adiantamento,
    });
  }

  // Pensão Alimentícia
  if (pensao > 0) {
    itens.push({
      codigo: '111',
      descricao: 'Pensão Alimentícia Judicial',
      referencia: 'Ofício',
      tipo: 'desconto',
      valor: pensao,
    });
  }

  // Outros Descontos
  const outrosDescontos = Number(params.outrosDescontos) || 0;
  if (outrosDescontos > 0) {
    itens.push({
      codigo: '119',
      descricao: 'Outros Descontos Autorizados',
      referencia: 'Avulso',
      tipo: 'desconto',
      valor: outrosDescontos,
    });
  }

  // Totais
  const totalDescontos = itens
    .filter((i) => i.tipo === 'desconto')
    .reduce((acc, i) => acc + i.valor, 0);

  const salarioLiquido = Math.max(0, Math.round((totalProventos - totalDescontos) * 100) / 100);

  // FGTS (8% regular ou 2% aprendiz)
  const isAprendiz = params.tipoContrato === 'Menor Aprendiz' || params.tipoContrato === 'aprendiz';
  const aliqFgts = isAprendiz ? 0.02 : 0.08;
  const baseFgts = totalProventos;
  const valorFgts = Math.round(baseFgts * aliqFgts * 100) / 100;

  // Encargos da Empresa (Custo Empresa Real)
  const inssPatronal = Math.round(totalProventos * 0.2 * 100) / 100; // 20% CPP
  const ratFap = Math.round(totalProventos * 0.02 * 100) / 100; // 2% médio RAT
  const terceiros = Math.round(totalProventos * 0.058 * 100) / 100; // 5,8% Sistema S / terceiros
  const provisao13 = Math.round((totalProventos / 12) * 100) / 100; // 1/12 avos
  const provisaoFerias = Math.round(((totalProventos / 12) * 1.3333) * 100) / 100; // 1/12 + 1/3
  const totalEncargosSociais = Math.round((inssPatronal + ratFap + terceiros + valorFgts + provisao13 + provisaoFerias) * 100) / 100;
  const custoTotalColaborador = Math.round((totalProventos + inssPatronal + ratFap + terceiros + valorFgts) * 100) / 100;

  const encargosEmpresa: EncargosEmpresa = {
    inssPatronal,
    ratFap,
    terceirosSistemaS: terceiros,
    fgts: valorFgts,
    provisao13Salario: provisao13,
    provisaoFeriasTerco: provisaoFerias,
    totalEncargosSociais,
    custoTotalColaborador,
  };

  return {
    funcionarioId: params.funcionario?.id || 'simulacao',
    competencia: params.competencia || '09/2026',
    salarioBase,
    totalProventos,
    totalDescontos: Math.round(totalDescontos * 100) / 100,
    salarioLiquido,
    valorLiquido: salarioLiquido,
    baseInss,
    valorInss: memoriaInss.valorTotal,
    baseIrrf: memoriaIrrf.baseCalculoEfetiva,
    valorIrrf: memoriaIrrf.valorImposto,
    baseFgts,
    valorFgts,
    faixaInssAliquotaEfetiva: memoriaInss.aliquotaEfetivaTexto,
    faixaIrrfAliquota: `${memoriaIrrf.aliquotaNominal}%`,
    itens,
    bases: {
      salarioBase,
      baseInss,
      baseIrrf: memoriaIrrf.baseCalculoEfetiva,
      fgtsMes: valorFgts,
    },
    memoriaInss,
    memoriaIrrf,
    encargosEmpresa,
    memoriaCalculo: {
      inssFaixas: memoriaInss.faixas.map((f) => ({
        faixa: f.descricao,
        baseCalculada: f.baseTributada,
        aliquota: f.aliquota,
        valor: f.valorContribuicao,
      })),
      irrfDeducaoTipo: memoriaIrrf.opcaoMaisVantajosa,
      irrfDeducaoValor: memoriaIrrf.opcaoMaisVantajosa === 'simplificada' ? DESCONTO_SIMPLIFICADO_IRRF : memoriaIrrf.totalDeducoesLegais,
      dependentesQtd: dependentes,
      encargosPatronais: {
        inssPatronal,
        ratFap,
        terceiros,
        totalEncargos: inssPatronal + ratFap + terceiros,
      },
    },
  };
}
