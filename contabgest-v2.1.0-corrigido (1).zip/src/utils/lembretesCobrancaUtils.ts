import {
  Empresa,
  ContratoHonorario,
  MensalidadeHonorario,
  RegraLembreteCobranca,
  LogEnvioLembrete,
  LembreteFilaItem,
} from '../types';

export const REGRAS_LEMBRETES_PADRAO: RegraLembreteCobranca[] = [
  {
    id: 'regra-d-menos-3',
    nome: 'Lembrete Preventivo (3 dias antes)',
    tipo: 'preventivo',
    diasGatilho: -3,
    canalPadrao: 'whatsapp',
    ativo: true,
    horarioDisparo: '09:00',
    templateAssunto: 'Lembrete: Mensalidade de Honorários Contábeis ({COMPETENCIA}) vence em breve',
    templateMensagem: `Olá, *{CLIENTE}*! Tudo bem? 

Passando para lembrar que os honorários contábeis referentes à competência *{COMPETENCIA}* vencem em *{VENCIMENTO}* (daqui a 3 dias).

💰 *Valor:* R$ {VALOR}
🔑 *Chave Pix (Copie e Cole):*
\`{PIX}\`

📄 *Código de Barras:*
\`{CODIGO_BARRAS}\`

Caso o pagamento já tenha sido agendado ou realizado, por favor desconsidere esta mensagem.
Qualquer dúvida estamos à disposição!

Atenciosamente,
*{ESCRITORIO}*`,
  },
  {
    id: 'regra-d-menos-1',
    nome: 'Aviso de Vencimento Amanhã (1 dia antes)',
    tipo: 'preventivo',
    diasGatilho: -1,
    canalPadrao: 'whatsapp',
    ativo: true,
    horarioDisparo: '09:00',
    templateAssunto: 'Aviso: Sua mensalidade de honorários contábeis vence amanhã ({VENCIMENTO})',
    templateMensagem: `Olá, *{CLIENTE}*!

Lembramos que a mensalidade contábil da competência *{COMPETENCIA}* tem vencimento agendado para *amanhã, {VENCIMENTO}*.

💵 *Valor líquido:* R$ {VALOR}
⚡ *Pague via Pix instantâneo:*
\`{PIX}\`

Ou utilize a linha digitável do boleto:
\`{CODIGO_BARRAS}\`

Agradecemos pela parceria!
*{ESCRITORIO}*`,
  },
  {
    id: 'regra-d-zero',
    nome: 'Vencimento Hoje (Dia D)',
    tipo: 'vencimento',
    diasGatilho: 0,
    canalPadrao: 'ambos',
    ativo: true,
    horarioDisparo: '08:30',
    templateAssunto: 'Vencimento Hoje: Honorários Contábeis {COMPETENCIA} - {ESCRITORIO}',
    templateMensagem: `Prezado(a) *{CLIENTE}*, bom dia!

Informamos que a fatura de honorários contábeis referente a *{COMPETENCIA}* vence *HOJE ({VENCIMENTO})*.

💲 *Valor a liquidar:* R$ {VALOR}
📲 *Chave Pix Copia e Cola:*
\`{PIX}\`

Se preferir pagar via boleto bancário:
\`{CODIGO_BARRAS}\`

Assim que liquidado, seu recibo oficial de honorários com assinatura do contador responsável será disponibilizado automaticamente.

Tenha um excelente dia!
*{ESCRITORIO}*`,
  },
  {
    id: 'regra-d-mais-2',
    nome: 'Aviso Amigável de Atraso (2 dias)',
    tipo: 'atraso',
    diasGatilho: 2,
    canalPadrao: 'whatsapp',
    ativo: true,
    horarioDisparo: '10:00',
    templateAssunto: 'Aviso de Pendência: Honorários Contábeis em aberto ({COMPETENCIA})',
    templateMensagem: `Olá, *{CLIENTE}*. Tudo bem?

Constatamos em nosso sistema financeiro que a mensalidade de honorários da competência *{COMPETENCIA}*, com vencimento em *{VENCIMENTO}*, encontra-se com *{DIAS_ATRASO} dias em aberto*.

Gostaria de verificar se você teve algum problema para receber a fatura ou efetuar o pagamento.

💰 *Valor:* R$ {VALOR}
🔑 *Chave Pix para regularização imediata:*
\`{PIX}\`

Caso já tenha efetuado o pagamento nas últimas horas, por favor nos envie o comprovante para que possamos dar baixa.

Atenciosamente,
Setor Financeiro - *{ESCRITORIO}*`,
  },
  {
    id: 'regra-d-mais-7',
    nome: 'Cobrança Formal de Inadimplência (7 dias)',
    tipo: 'atraso',
    diasGatilho: 7,
    canalPadrao: 'ambos',
    ativo: true,
    horarioDisparo: '10:30',
    templateAssunto: 'URGENTE: Regularização de Honorários Contábeis em Atraso ({COMPETENCIA})',
    templateMensagem: `Prezado(a) *{CLIENTE}*,

Entramos em contato para solicitar a regularização urgente dos honorários contábeis de *{COMPETENCIA}*, vencidos desde *{VENCIMENTO}* (*{DIAS_ATRASO} dias de atraso*).

Conforme previsto na cláusula de inadimplência do nosso contrato de prestação de serviços contábeis, atrasos superiores podem acarretar a suspensão temporária do envio de guias e rotinas fiscais.

💳 *Valor Atualizado:* R$ {VALOR}
⚡ *Chave Pix:*
\`{PIX}\`

📄 *Linha Digitável:*
\`{CODIGO_BARRAS}\`

Pedimos a gentileza de regularizar ou responder a esta mensagem informando a previsão para liquidação.

Atenciosamente,
*{ESCRITORIO}* | Departamento Jurídico e Financeiro`,
  },
];

const ESCRITORIO_PADRAO = {
  nome: 'ContabGest Assessoria e Auditoria Contábil S/S',
  telefone: '(11) 98765-4321',
  email: 'financeiro@contabgest.com.br',
  pixChave: 'financeiro@contabgest.com.br',
};

/**
 * Calcula a diferença em dias entre a data de vencimento e a data de referência.
 * Retorno:
 * < 0: faltam dias para vencer (ex: -3 = faltam 3 dias)
 * = 0: vence hoje
 * > 0: está atrasado (ex: 5 = atrasado há 5 dias)
 */
export function calcularDiferencaDias(
  dataVencimentoIso: string,
  dataReferenciaIso: string = '2026-09-17'
): number {
  if (!dataVencimentoIso) return 0;

  const [aVenc, mVenc, dVenc] = dataVencimentoIso.split('-').map(Number);
  const [aRef, mRef, dRef] = dataReferenciaIso.split('-').map(Number);

  const dtVenc = new Date(aVenc, mVenc - 1, dVenc).getTime();
  const dtRef = new Date(aRef, mRef - 1, dRef).getTime();

  const msPorDia = 1000 * 60 * 60 * 24;
  return Math.round((dtRef - dtVenc) / msPorDia);
}

/**
 * Formata número de telefone brasileiro para padrão com 55 e apenas dígitos.
 */
export function sanitizarTelefone(telefone?: string): string {
  if (!telefone) return '5511999998888';
  const digitos = telefone.replace(/\D/g, '');
  if (digitos.startsWith('55') && digitos.length >= 12) {
    return digitos;
  }
  if (digitos.length === 10 || digitos.length === 11) {
    return `55${digitos}`;
  }
  return digitos;
}

/**
 * Substitui placeholders dinâmicos dentro do template de mensagem.
 */
export function compilarTemplateMensagem(
  template: string,
  dados: {
    cliente: string;
    valor: number;
    vencimento: string;
    competencia: string;
    pix: string;
    codigoBarras: string;
    diasAtraso: number;
    escritorio?: string;
  }
): string {
  const valorFormatado = dados.valor.toLocaleString('pt-BR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  const [ano, mes, dia] = dados.vencimento.split('-');
  const vencFormatado = dia && mes && ano ? `${dia}/${mes}/${ano}` : dados.vencimento;

  return template
    .replace(/{CLIENTE}/g, dados.cliente)
    .replace(/{VALOR}/g, valorFormatado)
    .replace(/{VENCIMENTO}/g, vencFormatado)
    .replace(/{COMPETENCIA}/g, dados.competencia)
    .replace(/{PIX}/g, dados.pix || ESCRITORIO_PADRAO.pixChave)
    .replace(/{CODIGO_BARRAS}/g, dados.codigoBarras || '34191.79001 01043.510047 91020.150008 7 98350000000000')
    .replace(/{DIAS_ATRASO}/g, String(Math.max(0, dados.diasAtraso)))
    .replace(/{ESCRITORIO}/g, dados.escritorio || ESCRITORIO_PADRAO.nome);
}

/**
 * Monta link direto do WhatsApp Web / Mobile com texto codificado.
 */
export function gerarUrlWhatsApp(telefone: string, mensagem: string): string {
  const telSanitizado = sanitizarTelefone(telefone);
  return `https://wa.me/${telSanitizado}?text=${encodeURIComponent(mensagem)}`;
}

/**
 * Monta link mailto com assunto e corpo codificados.
 */
export function gerarMailto(email: string, assunto: string, corpo: string): string {
  return `mailto:${email}?subject=${encodeURIComponent(assunto)}&body=${encodeURIComponent(corpo)}`;
}

/**
 * Avalia todas as mensalidades e descobre quais estão elegíveis para lembrete hoje.
 */
export function avaliarFilaLembretes(
  mensalidades: MensalidadeHonorario[],
  empresas: Empresa[],
  contratos: ContratoHonorario[],
  regras: RegraLembreteCobranca[],
  dataReferenciaIso: string = '2026-09-17'
): LembreteFilaItem[] {
  const regrasAtivas = regras.filter((r) => r.ativo);
  const fila: LembreteFilaItem[] = [];

  // Consideramos apenas mensalidades não pagas e não canceladas
  const faturasEmAberto = mensalidades.filter(
    (m) => m.status === 'pendente' || m.status === 'atrasado'
  );

  for (const mens of faturasEmAberto) {
    const empresa = empresas.find((e) => e.id === mens.empresaId);
    if (!empresa) continue;

    const contrato = contratos.find((c) => c.id === mens.contratoId);
    const difDias = calcularDiferencaDias(mens.dataVencimento, dataReferenciaIso);

    // Identificar a melhor regra aplicável
    // diasGatilho: negativo para preventivo (difDias < 0), zero para hoje (difDias === 0), positivo para atraso (difDias > 0)
    let regraEncontrada: RegraLembreteCobranca | undefined;

    if (difDias < 0) {
      // Preventivo: difDias é positivo para dias que faltam até o vencimento
      // ex: difDias = -3 (faltam 3 dias)
      regraEncontrada = regrasAtivas.find(
        (r) => r.tipo === 'preventivo' && r.diasGatilho === difDias
      );
      // Fallback: se estiver entre -5 e -1 e não houver regra exata, pega a regra preventiva mais próxima
      if (!regraEncontrada && difDias >= -5) {
        regraEncontrada = regrasAtivas.find((r) => r.tipo === 'preventivo');
      }
    } else if (difDias === 0) {
      // Vencimento hoje
      regraEncontrada = regrasAtivas.find((r) => r.tipo === 'vencimento' || r.diasGatilho === 0);
    } else {
      // Atraso: difDias > 0
      // Procura regra exata para os dias de atraso (ex: 2, 7, 15)
      regraEncontrada = regrasAtivas
        .filter((r) => r.tipo === 'atraso' && r.diasGatilho <= difDias)
        .sort((a, b) => b.diasGatilho - a.diasGatilho)[0];
    }

    if (!regraEncontrada) continue;

    // Verificar se já enviou lembrete hoje para não spamar
    const dataRefFormatada = dataReferenciaIso;
    const ultimoEnvio = mens.historicoEnvios?.[0];
    const jaEnviadoHoje = Boolean(
      mens.historicoEnvios?.some((h) => h.dataEnvio && h.dataEnvio.startsWith(dataRefFormatada))
    );

    const nomeCliente = empresa.nomeFantasia || empresa.razaoSocial;
    const msg = compilarTemplateMensagem(regraEncontrada.templateMensagem, {
      cliente: nomeCliente,
      valor: mens.valor,
      vencimento: mens.dataVencimento,
      competencia: mens.competencia,
      pix: mens.pixCopiaECola || ESCRITORIO_PADRAO.pixChave,
      codigoBarras: mens.codigoBarras || '',
      diasAtraso: difDias > 0 ? difDias : 0,
      escritorio: ESCRITORIO_PADRAO.nome,
    });

    const assunto = compilarTemplateMensagem(regraEncontrada.templateAssunto, {
      cliente: nomeCliente,
      valor: mens.valor,
      vencimento: mens.dataVencimento,
      competencia: mens.competencia,
      pix: mens.pixCopiaECola || '',
      codigoBarras: mens.codigoBarras || '',
      diasAtraso: difDias > 0 ? difDias : 0,
      escritorio: ESCRITORIO_PADRAO.nome,
    });

    fila.push({
      mensalidade: mens,
      empresa,
      contrato,
      tipo: regraEncontrada.tipo,
      diasDiferenca: difDias,
      regraAplicada: regraEncontrada,
      canalSugerido: regraEncontrada.canalPadrao,
      destinatarioWhatsApp: empresa.telefone || '(11) 98765-4321',
      destinatarioEmail: empresa.email || 'contato@cliente.com.br',
      mensagemFormatada: msg,
      assuntoFormatado: assunto,
      jaEnviadoHoje,
      ultimoEnvio,
    });
  }

  // Ordena por criticidade: atrasados há mais tempo primeiro, depois vencendo hoje, depois preventivos
  return fila.sort((a, b) => b.diasDiferenca - a.diasDiferenca);
}

const STORAGE_KEY_REGRAS = 'contabgest_regras_lembretes_v1';
const STORAGE_KEY_LOGS = 'contabgest_logs_lembretes_v1';

export function carregarRegrasStorage(): RegraLembreteCobranca[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_REGRAS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('Erro ao ler regras do localStorage', e);
  }
  return REGRAS_LEMBRETES_PADRAO;
}

export function salvarRegrasStorage(regras: RegraLembreteCobranca[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_REGRAS, JSON.stringify(regras));
  } catch (e) {
    console.error('Erro ao salvar regras no localStorage', e);
  }
}

export function carregarLogsStorage(): LogEnvioLembrete[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_LOGS);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.error('Erro ao ler logs do localStorage', e);
  }
  return [];
}

export function salvarLogStorage(log: LogEnvioLembrete): void {
  try {
    const logs = carregarLogsStorage();
    logs.unshift(log);
    // Limita a 100 logs
    const capped = logs.slice(0, 100);
    localStorage.setItem(STORAGE_KEY_LOGS, JSON.stringify(capped));
  } catch (e) {
    console.error('Erro ao salvar log no localStorage', e);
  }
}
