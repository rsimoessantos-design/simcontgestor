import {
  Empresa,
  GuiaDasMei,
  NotaFiscal,
  DeclaracaoAnualMei,
  ResumoFaturamentoMei,
  TipoAtividadeMei,
  SituacaoLimiteMei,
} from '../types';

export const SALARIO_MINIMO_VIGENTE = 1518; // 2025/2026 oficial
export const LIMITE_ANUAL_MEI_PADRAO = 81000;
export const LIMITE_MENSAL_MEI = 6750; // 81.000 / 12
export const LIMITE_EXCESSO_20_MEI = 97200; // 81.000 * 1.20
export const LIMITE_COMPRAS_PERCENTUAL = 0.8; // Máx 80% das receitas

export const VALOR_FIXO_ICMS = 1.0;
export const VALOR_FIXO_ISS = 5.0;

export const NOMES_MESES = [
  'Janeiro',
  'Fevereiro',
  'Março',
  'Abril',
  'Maio',
  'Junho',
  'Julho',
  'Agosto',
  'Setembro',
  'Outubro',
  'Novembro',
  'Dezembro',
];

/**
 * Calcula a composição do DAS-MEI mensal baseado na atividade
 */
export function calcularValoresGuiaMei(
  tipoAtividade: TipoAtividadeMei = 'servicos',
  salarioMinimo = SALARIO_MINIMO_VIGENTE
) {
  let valorInss = Math.round(salarioMinimo * 0.05 * 100) / 100; // 5% do salário mínimo
  if (tipoAtividade === 'transporte_caminhoneiro') {
    valorInss = Math.round(salarioMinimo * 0.12 * 100) / 100; // 12% para MEI Caminhoneiro
  }

  let valorIcms = 0;
  let valorIss = 0;

  if (tipoAtividade === 'comercio') {
    valorIcms = VALOR_FIXO_ICMS;
  } else if (tipoAtividade === 'servicos') {
    valorIss = VALOR_FIXO_ISS;
  } else if (tipoAtividade === 'comercio_e_servicos') {
    valorIcms = VALOR_FIXO_ICMS;
    valorIss = VALOR_FIXO_ISS;
  } else if (tipoAtividade === 'transporte_caminhoneiro') {
    valorIcms = VALOR_FIXO_ICMS;
    valorIss = VALOR_FIXO_ISS;
  }

  const valorTotal = Math.round((valorInss + valorIcms + valorIss) * 100) / 100;

  return {
    valorInss,
    valorIcms,
    valorIss,
    valorTotal,
  };
}

/**
 * Retorna a data de vencimento da competência (dia 20 do mês subsequente, postergando caso caia em sábado/domingo)
 */
export function getDataVencimentoDasMei(ano: number, mes: number): string {
  // Mês subsequente
  let mesVenc = mes + 1;
  let anoVenc = ano;
  if (mesVenc > 12) {
    mesVenc = 1;
    anoVenc += 1;
  }

  let dt = new Date(anoVenc, mesVenc - 1, 20);
  const diaSemana = dt.getDay(); // 0 = Domingo, 6 = Sábado
  if (diaSemana === 0) {
    // Domingo -> Segunda dia 21
    dt.setDate(21);
  } else if (diaSemana === 6) {
    // Sábado -> Segunda dia 22
    dt.setDate(22);
  }

  const a = dt.getFullYear();
  const m = String(dt.getMonth() + 1).padStart(2, '0');
  const d = String(dt.getDate()).padStart(2, '0');
  return `${a}-${m}-${d}`;
}

/**
 * Gera código de barras e linha digitável padrão arrecadação FEBRABAN para o DAS-MEI
 */
export function gerarCodigoBarrasDasMei(
  cnpj: string,
  competencia: string,
  valorTotal: number
): { codigoBarras: string; linhaDigitavel: string } {
  const cnpjClean = cnpj.replace(/\D/g, '').padEnd(14, '0').slice(0, 14);
  const compClean = competencia.replace(/\D/g, '').padEnd(6, '0').slice(0, 6);
  const centavos = Math.round(valorTotal * 100)
    .toString()
    .padStart(11, '0');

  // Código de barras arrecadação: 858 + moeda(8) + valor + órgão(0001) + CNPJ + competência
  const codigoBarras = `8588${centavos.slice(0, 11)}0001${cnpjClean.slice(0, 8)}${compClean}904128`;
  
  // Linha digitável formatada em 4 blocos de 12 dígitos (padrão arrecadação)
  const b1 = codigoBarras.slice(0, 11);
  const b2 = codigoBarras.slice(11, 22);
  const b3 = codigoBarras.slice(22, 33);
  const b4 = codigoBarras.slice(33, 44);

  const linhaDigitavel = `${b1}-8 ${b2}-4 ${b3}-1 ${b4}-9`;

  return { codigoBarras, linhaDigitavel };
}

/**
 * Gera payload Pix Copia e Cola padrão Banco Central do Brasil para arrecadação oficial do DAS-MEI
 */
export function gerarPixQrCodeDasMei(
  cnpj: string,
  competencia: string,
  valorTotal: number,
  numeroGuia: string
): string {
  const compClean = competencia.replace(/\D/g, '');
  const valorStr = valorTotal.toFixed(2);
  return (
    `00020126580014br.gov.bcb.pix0136arrecadacao-dasmei@receita.fazenda.gov.br` +
    `0218DAS-MEI ${compClean}520400005303986540${valorStr.length < 10 ? '0' + valorStr.length : valorStr.length}${valorStr}5802BR` +
    `5925RECEITA FEDERAL DO BRASIL6009BRASILIA62300526${numeroGuia.replace(/\D/g, '').slice(0, 16)}6304C108`
  );
}

/**
 * Gera a grade padrão de 12 guias do ano para o MEI
 */
export function gerarGradeGuiasAnoMei(
  empresa: Empresa,
  ano: number,
  guiasExistentes: GuiaDasMei[] = []
): GuiaDasMei[] {
  const tipoAtividade = empresa.tipoAtividadeMei || 'servicos';
  const { valorInss, valorIcms, valorIss, valorTotal } = calcularValoresGuiaMei(tipoAtividade);

  const guiasMap = new Map<string, GuiaDasMei>();
  guiasExistentes.forEach((g) => {
    if (g.ano === ano && g.empresaId === empresa.id) {
      guiasMap.set(g.competencia, g);
    }
  });

  const hoje = new Date();
  const anoAtual = hoje.getFullYear();
  const mesAtual = hoje.getMonth() + 1; // 1 a 12

  const guiasCompletas: GuiaDasMei[] = [];

  for (let m = 1; m <= 12; m++) {
    const compStr = `${String(m).padStart(2, '0')}/${ano}`;
    const existente = guiasMap.get(compStr);

    if (existente) {
      guiasCompletas.push(existente);
      continue;
    }

    const dataVencimento = getDataVencimentoDasMei(ano, m);
    const numeroDoc = `DASMEI-${ano}${String(m).padStart(2, '0')}-${empresa.cnpj.replace(/\D/g, '').slice(-4)}`;
    const { codigoBarras, linhaDigitavel } = gerarCodigoBarrasDasMei(empresa.cnpj, compStr, valorTotal);
    const pixQrCodePayload = gerarPixQrCodeDasMei(empresa.cnpj, compStr, valorTotal, numeroDoc);

    // Determina status inicial
    let status: 'pendente' | 'pago' | 'vencido' = 'pendente';
    let dataPagamento: string | undefined = undefined;

    // Se a competência já venceu no passado e é demo, podemos marcar meses mais antigos como pagos
    const dtVenc = new Date(dataVencimento);
    if (ano < anoAtual || (ano === anoAtual && m < mesAtual - 1)) {
      status = 'pago';
      dataPagamento = `${dataVencimento}T14:30:00Z`;
    } else if (ano === anoAtual && m === mesAtual - 1) {
      // Mês imediatamente anterior: pode estar pago ou pendente
      status = 'pago';
      dataPagamento = `${dataVencimento}T10:15:00Z`;
    } else if (dtVenc < hoje) {
      status = 'vencido';
    }

    guiasCompletas.push({
      id: `guia_dasmei_${empresa.id}_${ano}_${m}`,
      empresaId: empresa.id,
      ano,
      mes: m,
      competencia: compStr,
      dataVencimento,
      valorInss,
      valorIcms,
      valorIss,
      valorTotal,
      status,
      dataPagamento,
      codigoBarras,
      linhaDigitavel,
      pixQrCodePayload,
      numeroDocumento: numeroDoc,
      observacoes: `Guia PGMEI calculada conforme LC 123/2006. Atividade: ${tipoAtividade.toUpperCase()}`,
      isDemo: true,
    });
  }

  return guiasCompletas;
}

/**
 * Calcula o resumo consolidado de faturamento e limites do MEI no ano
 */
export function calcularResumoFaturamentoMei(params: {
  empresa: Empresa;
  ano: number;
  notasFiscais: NotaFiscal[];
  comprasEntradaValorTotal?: number;
}): ResumoFaturamentoMei {
  const { empresa, ano, notasFiscais, comprasEntradaValorTotal = 0 } = params;

  // Limite anual (padrão R$ 81.000 ou proporcional)
  let limiteAnual = LIMITE_ANUAL_MEI_PADRAO;
  if (empresa.limiteAnualCustomizado && empresa.limiteAnualCustomizado > 0) {
    limiteAnual = empresa.limiteAnualCustomizado;
  } else if (empresa.dataAberturaMei) {
    const dtAbertura = new Date(empresa.dataAberturaMei);
    if (dtAbertura.getFullYear() === ano) {
      const mesAbertura = dtAbertura.getMonth() + 1;
      const mesesAtividade = 12 - mesAbertura + 1;
      limiteAnual = mesesAtividade * LIMITE_MENSAL_MEI;
    }
  }

  const limiteMensalMedio = Math.round((limiteAnual / 12) * 100) / 100;

  // Filtrar notas de saída do ano da empresa
  const notasAno = notasFiscais.filter((nf) => {
    if (nf.empresaId !== empresa.id) return false;
    if (nf.status === 'cancelada' || nf.status === 'rejeitada') return false;
    const dt = new Date(nf.dataEmissao);
    return !isNaN(dt.getTime()) && dt.getFullYear() === ano;
  });

  // Inicializa mapa dos 12 meses
  const mesesMap: {
    [mes: number]: { comercio: number; servicos: number; total: number; qtd: number };
  } = {};

  for (let m = 1; m <= 12; m++) {
    mesesMap[m] = { comercio: 0, servicos: 0, total: 0, qtd: 0 };
  }

  // Preenche com as notas emitidas
  notasAno.forEach((nf) => {
    const dt = new Date(nf.dataEmissao);
    const m = dt.getMonth() + 1;
    const val = Number(nf.valorTotal) || 0;

    const isServico =
      nf.modeloDoc === 'NFSe' ||
      (nf.naturezaOperacao && nf.naturezaOperacao.toLowerCase().includes('serviço')) ||
      (nf.anexoSimples && (nf.anexoSimples === 'Anexo III' || nf.anexoSimples === 'Anexo IV' || nf.anexoSimples === 'Anexo V'));

    if (isServico) {
      mesesMap[m].servicos += val;
    } else {
      mesesMap[m].comercio += val;
    }
    mesesMap[m].total += val;
    mesesMap[m].qtd += 1;
  });

  // Se não houver notas suficientes (ex: empresa nova com faturamento mensal cadastrado na ficha),
  // podemos projetar com base no faturamento mensal informado na empresa
  const temNotas = notasAno.length > 0;
  if (!temNotas && empresa.faturamentoMensal && empresa.faturamentoMensal > 0) {
    const faturamentoBase = empresa.faturamentoMensal;
    const hoje = new Date();
    const mesesPassados = ano === hoje.getFullYear() ? hoje.getMonth() + 1 : 12;

    for (let m = 1; m <= mesesPassados; m++) {
      // Variação orgânica pequena (+- 8%)
      const fator = 0.95 + (m % 3) * 0.05;
      const val = Math.round(faturamentoBase * fator);

      if (empresa.tipoAtividadeMei === 'comercio') {
        mesesMap[m].comercio = val;
      } else {
        mesesMap[m].servicos = val;
      }
      mesesMap[m].total = val;
      mesesMap[m].qtd = 4;
    }
  }

  // Consolidação
  let faturamentoComercio = 0;
  let faturamentoServicos = 0;
  let mesesComFaturamento = 0;

  const mesesFaturamento = [];

  for (let m = 1; m <= 12; m++) {
    const c = Math.round(mesesMap[m].comercio * 100) / 100;
    const s = Math.round(mesesMap[m].servicos * 100) / 100;
    const tot = Math.round((c + s) * 100) / 100;

    faturamentoComercio += c;
    faturamentoServicos += s;
    if (tot > 0) mesesComFaturamento++;

    mesesFaturamento.push({
      mes: m,
      mesNome: NOMES_MESES[m - 1],
      valorComercio: c,
      valorServicos: s,
      valorTotal: tot,
      emitidasNfeQtd: mesesMap[m].qtd,
    });
  }

  const faturamentoAcumuladoAno = Math.round((faturamentoComercio + faturamentoServicos) * 100) / 100;
  const percentualUtilizado = Math.round((faturamentoAcumuladoAno / limiteAnual) * 1000) / 10; // ex: 65.4%
  const saldoRestante = Math.max(0, Math.round((limiteAnual - faturamentoAcumuladoAno) * 100) / 100);

  const divisorMeses = Math.max(1, mesesComFaturamento);
  const faturamentoMedioMensal = Math.round((faturamentoAcumuladoAno / divisorMeses) * 100) / 100;
  const projecaoAnual = Math.round(faturamentoMedioMensal * 12 * 100) / 100;

  let statusLimite: 'seguro' | 'atencao' | 'alerta_20' | 'estourado' = 'seguro';
  if (faturamentoAcumuladoAno > LIMITE_EXCESSO_20_MEI) {
    statusLimite = 'estourado';
  } else if (faturamentoAcumuladoAno > limiteAnual) {
    statusLimite = 'alerta_20';
  } else if (percentualUtilizado >= 80) {
    statusLimite = 'atencao';
  }

  // Alerta de compras de mercadorias (Lei: não pode comprar mercadorias > 80% das receitas)
  let alertaCompras = undefined;
  if (comprasEntradaValorTotal > 0 && faturamentoAcumuladoAno > 0) {
    const percentualSobreFaturamento = Math.round((comprasEntradaValorTotal / faturamentoAcumuladoAno) * 1000) / 10;
    alertaCompras = {
      totalCompras: comprasEntradaValorTotal,
      percentualSobreFaturamento,
      excedeuLimiteCompras: percentualSobreFaturamento > 80,
    };
  }

  return {
    empresaId: empresa.id,
    ano,
    limiteAnual,
    limiteMensalMedio,
    faturamentoAcumuladoAno,
    percentualUtilizado,
    saldoRestante,
    faturamentoMedioMensal,
    projecaoAnual,
    statusLimite,
    totalNotasFiscaisEmitidas: notasAno.length,
    faturamentoComercio: Math.round(faturamentoComercio * 100) / 100,
    faturamentoServicos: Math.round(faturamentoServicos * 100) / 100,
    mesesFaturamento,
    qtdeFuncionarios: empresa.qtdeFuncionarios || 0,
    funcionarioConforme: (empresa.qtdeFuncionarios || 0) <= 1,
    alertaCompras,
  };
}

/**
 * Apuração e cálculo da Declaração Anual do MEI (DASN-SIMEI)
 */
export function apurarDeclaracaoAnualMei(params: {
  empresa: Empresa;
  anoCalendario: number;
  receitaBrutaComercio: number;
  receitaBrutaServicos: number;
  possuiuEmpregado: boolean;
  tipoDeclaracao?: 'original' | 'retificadora' | 'extincao';
  usuarioTransmissao?: string;
}): DeclaracaoAnualMei {
  const {
    empresa,
    anoCalendario,
    receitaBrutaComercio,
    receitaBrutaServicos,
    possuiuEmpregado,
    tipoDeclaracao = 'original',
    usuarioTransmissao = 'Contador Responsável',
  } = params;

  const receitaBrutaTotal = Math.round((receitaBrutaComercio + receitaBrutaServicos) * 100) / 100;
  
  // Limite do ano
  let limiteAnual = LIMITE_ANUAL_MEI_PADRAO;
  if (empresa.limiteAnualCustomizado && empresa.limiteAnualCustomizado > 0) {
    limiteAnual = empresa.limiteAnualCustomizado;
  } else if (empresa.dataAberturaMei) {
    const dtAbertura = new Date(empresa.dataAberturaMei);
    if (dtAbertura.getFullYear() === anoCalendario) {
      const mesAbertura = dtAbertura.getMonth() + 1;
      const mesesAtividade = 12 - mesAbertura + 1;
      limiteAnual = mesesAtividade * LIMITE_MENSAL_MEI;
    }
  }

  const excedeuLimite = receitaBrutaTotal > limiteAnual;
  const valorExcedente = excedeuLimite ? Math.round((receitaBrutaTotal - limiteAnual) * 100) / 100 : 0;
  const percentualExcesso = excedeuLimite
    ? Math.round((valorExcedente / limiteAnual) * 1000) / 10
    : 0;

  let situacaoLimite: SituacaoLimiteMei = 'normal';
  let dasComplementarEstimado = 0;

  if (excedeuLimite) {
    const limiteCom20 = limiteAnual * 1.2;
    if (receitaBrutaTotal <= limiteCom20) {
      situacaoLimite = 'excesso_ate_20';
      // Alíquota média do Simples Nacional sobre o excedente (4% comércio ou 6% serviços)
      const aliquotaExcedente = empresa.tipoAtividadeMei === 'comercio' ? 0.04 : 0.06;
      dasComplementarEstimado = Math.round(valorExcedente * aliquotaExcedente * 100) / 100;
    } else {
      situacaoLimite = 'excesso_acima_20';
      // Desenquadramento retroativo: tributação pelo Simples Nacional sobre todo o faturamento
      const aliquotaSimplesIntegral = empresa.tipoAtividadeMei === 'comercio' ? 0.04 : 0.06;
      dasComplementarEstimado = Math.round(receitaBrutaTotal * aliquotaSimplesIntegral * 100) / 100;
    }
  }

  const agora = new Date();
  const timestamp = agora.toISOString();
  const protocoloTransmissao = `DASN-${anoCalendario}-${empresa.cnpj.replace(/\D/g, '').slice(-6)}-${Date.now().toString().slice(-6)}`;
  const reciboEntrega = `REC-SIMEI-${anoCalendario}-${Math.floor(10000000 + Math.random() * 90000000)}`;
  const hashAutenticidade = `SHA256-${anoCalendario}.${protocoloTransmissao}.${empresa.cnpj.replace(/\D/g, '')}.OK`.toUpperCase();

  return {
    id: `dasn_${empresa.id}_${anoCalendario}`,
    empresaId: empresa.id,
    anoCalendario,
    tipoDeclaracao,
    status: 'rascunho',
    receitaBrutaComercio,
    receitaBrutaServicos,
    receitaBrutaTotal,
    possuiuEmpregado,
    limiteAnual,
    excedeuLimite,
    valorExcedente,
    percentualExcesso,
    situacaoLimite,
    dasComplementarEstimado,
    protocoloTransmissao,
    reciboEntrega,
    hashAutenticidade,
    usuarioTransmissao,
    observacoes: `Declaração Anual DASN-SIMEI apurada para o ano-calendário ${anoCalendario}.`,
    isDemo: true,
  };
}

/**
 * Puxa as notas fiscais do ano e apura a Declaração Anual do MEI (DASN-SIMEI)
 */
export function calcularDasnSimei(
  empresa: Empresa,
  anoCalendario: number,
  notasFiscais: NotaFiscal[] = [],
  possuiuEmpregado: boolean = false,
  tipoDeclaracao: 'original' | 'retificadora' = 'original'
): DeclaracaoAnualMei {
  // Filtra notas autorizadas da empresa para o ano-calendário
  const notasDoAno = notasFiscais.filter((nf) => {
    if (nf.empresaId !== empresa.id) return false;
    if (nf.status !== 'autorizada') return false;
    const dt = new Date(nf.dataEmissao);
    return dt.getFullYear() === anoCalendario;
  });

  let recComercio = 0;
  let recServicos = 0;

  for (const nf of notasDoAno) {
    const valor = nf.valorTotal || nf.valorServicosOuProdutos || 0;
    if (nf.tipo === 'NFSe') {
      recServicos += valor;
    } else {
      recComercio += valor;
    }
  }

  return apurarDeclaracaoAnualMei({
    empresa,
    anoCalendario,
    receitaBrutaComercio: Math.round(recComercio * 100) / 100,
    receitaBrutaServicos: Math.round(recServicos * 100) / 100,
    possuiuEmpregado,
    tipoDeclaracao,
  });
}

