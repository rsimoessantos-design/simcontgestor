import {
  ParametrosSimulacaoTributaria,
  ResultadoCenarioSimulacao,
  DetalhamentoTributosRegime,
  AnoSimulacaoReforma,
  TipoAtividadeSimulador,
} from '../types';

// =========================================================================
// TABELAS DO SIMPLES NACIONAL (LEI COMPLEMENTAR 123/2006 ATUALIZADA)
// =========================================================================

interface FaixaSimples {
  limiteSuperior: number;
  aliquotaNominal: number;
  parcelaDeduzir: number;
}

const TABELA_ANEXO_I: FaixaSimples[] = [
  { limiteSuperior: 180000, aliquotaNominal: 0.04, parcelaDeduzir: 0 },
  { limiteSuperior: 360000, aliquotaNominal: 0.073, parcelaDeduzir: 5940 },
  { limiteSuperior: 720000, aliquotaNominal: 0.095, parcelaDeduzir: 13860 },
  { limiteSuperior: 1800000, aliquotaNominal: 0.107, parcelaDeduzir: 22500 },
  { limiteSuperior: 3600000, aliquotaNominal: 0.143, parcelaDeduzir: 87300 },
  { limiteSuperior: 4800000, aliquotaNominal: 0.19, parcelaDeduzir: 378000 },
];

const TABELA_ANEXO_II: FaixaSimples[] = [
  { limiteSuperior: 180000, aliquotaNominal: 0.045, parcelaDeduzir: 0 },
  { limiteSuperior: 360000, aliquotaNominal: 0.078, parcelaDeduzir: 5940 },
  { limiteSuperior: 720000, aliquotaNominal: 0.1, parcelaDeduzir: 13860 },
  { limiteSuperior: 1800000, aliquotaNominal: 0.112, parcelaDeduzir: 22500 },
  { limiteSuperior: 3600000, aliquotaNominal: 0.147, parcelaDeduzir: 85500 },
  { limiteSuperior: 4800000, aliquotaNominal: 0.3, parcelaDeduzir: 720000 },
];

const TABELA_ANEXO_III: FaixaSimples[] = [
  { limiteSuperior: 180000, aliquotaNominal: 0.06, parcelaDeduzir: 0 },
  { limiteSuperior: 360000, aliquotaNominal: 0.112, parcelaDeduzir: 9360 },
  { limiteSuperior: 720000, aliquotaNominal: 0.135, parcelaDeduzir: 17640 },
  { limiteSuperior: 1800000, aliquotaNominal: 0.16, parcelaDeduzir: 35640 },
  { limiteSuperior: 3600000, aliquotaNominal: 0.21, parcelaDeduzir: 125640 },
  { limiteSuperior: 4800000, aliquotaNominal: 0.33, parcelaDeduzir: 648000 },
];

const TABELA_ANEXO_IV: FaixaSimples[] = [
  { limiteSuperior: 180000, aliquotaNominal: 0.045, parcelaDeduzir: 0 },
  { limiteSuperior: 360000, aliquotaNominal: 0.09, parcelaDeduzir: 8100 },
  { limiteSuperior: 720000, aliquotaNominal: 0.102, parcelaDeduzir: 12420 },
  { limiteSuperior: 1800000, aliquotaNominal: 0.14, parcelaDeduzir: 39780 },
  { limiteSuperior: 3600000, aliquotaNominal: 0.22, parcelaDeduzir: 183780 },
  { limiteSuperior: 4800000, aliquotaNominal: 0.33, parcelaDeduzir: 828000 },
];

const TABELA_ANEXO_V: FaixaSimples[] = [
  { limiteSuperior: 180000, aliquotaNominal: 0.155, parcelaDeduzir: 0 },
  { limiteSuperior: 360000, aliquotaNominal: 0.18, parcelaDeduzir: 4500 },
  { limiteSuperior: 720000, aliquotaNominal: 0.195, parcelaDeduzir: 9900 },
  { limiteSuperior: 1800000, aliquotaNominal: 0.205, parcelaDeduzir: 17100 },
  { limiteSuperior: 3600000, aliquotaNominal: 0.23, parcelaDeduzir: 62100 },
  { limiteSuperior: 4800000, aliquotaNominal: 0.305, parcelaDeduzir: 540000 },
];

function calcularAliquotaEfetivaSimples(
  rbt12: number,
  tabela: FaixaSimples[]
): { aliquotaEfetiva: number; faixaIndex: number } {
  if (rbt12 <= 0) return { aliquotaEfetiva: 0, faixaIndex: 0 };
  const faixaIndex = tabela.findIndex((f) => rbt12 <= f.limiteSuperior);
  const faixa = faixaIndex !== -1 ? tabela[faixaIndex] : tabela[tabela.length - 1];
  const efetiva = (rbt12 * faixa.aliquotaNominal - faixa.parcelaDeduzir) / rbt12;
  return {
    aliquotaEfetiva: Math.max(0.04, Math.min(efetiva, 0.35)),
    faixaIndex: faixaIndex !== -1 ? faixaIndex : tabela.length - 1,
  };
}

// =========================================================================
// CRONOGRAMA DE TRANSIÇÃO DA REFORMA TRIBUTÁRIA (EC 132/2023 & LC 224/2025)
// =========================================================================

export interface ParametrosReformaAno {
  aliquotaCbsPadrao: number; // CBS federal estimada plena ~8.8%
  aliquotaIbsPadrao: number; // IBS estadual/municipal plena ~17.7%
  fatorTransicaoIbsIcms: number; // Proporção da transição ICMS/ISS -> IBS
  extinguePisCofins: boolean;
  aliquotaCbsEfetiva: number;
  aliquotaIbsEfetiva: number;
}

export function obterParametrosReformaPorAno(ano: AnoSimulacaoReforma): ParametrosReformaAno {
  switch (ano) {
    case 2026:
      // Ano teste: CBS 0,9% + IBS 0,1% compensáveis com PIS/COFINS
      return {
        aliquotaCbsPadrao: 0.009,
        aliquotaIbsPadrao: 0.001,
        fatorTransicaoIbsIcms: 0,
        extinguePisCofins: false,
        aliquotaCbsEfetiva: 0.009,
        aliquotaIbsEfetiva: 0.001,
      };
    case 2027:
    case 2028:
      // 2027: Extinção total de PIS e COFINS; CBS entra integralmente (~8,8%); IBS 0,1%
      return {
        aliquotaCbsPadrao: 0.088,
        aliquotaIbsPadrao: 0.001,
        fatorTransicaoIbsIcms: 0,
        extinguePisCofins: true,
        aliquotaCbsEfetiva: 0.088,
        aliquotaIbsEfetiva: 0.001,
      };
    case 2029:
      // Transição ICMS/ISS: 90% tributos antigos + 10% IBS (~1,77%)
      return {
        aliquotaCbsPadrao: 0.088,
        aliquotaIbsPadrao: 0.177,
        fatorTransicaoIbsIcms: 0.1,
        extinguePisCofins: true,
        aliquotaCbsEfetiva: 0.088,
        aliquotaIbsEfetiva: 0.177 * 0.1,
      };
    case 2030:
      // 80% tributos antigos + 20% IBS (~3,54%)
      return {
        aliquotaCbsPadrao: 0.088,
        aliquotaIbsPadrao: 0.177,
        fatorTransicaoIbsIcms: 0.2,
        extinguePisCofins: true,
        aliquotaCbsEfetiva: 0.088,
        aliquotaIbsEfetiva: 0.177 * 0.2,
      };
    case 2031:
      // 70% tributos antigos + 30% IBS (~5,31%)
      return {
        aliquotaCbsPadrao: 0.088,
        aliquotaIbsPadrao: 0.177,
        fatorTransicaoIbsIcms: 0.3,
        extinguePisCofins: true,
        aliquotaCbsEfetiva: 0.088,
        aliquotaIbsEfetiva: 0.177 * 0.3,
      };
    case 2032:
      // 60% tributos antigos + 40% IBS (~7,08%)
      return {
        aliquotaCbsPadrao: 0.088,
        aliquotaIbsPadrao: 0.177,
        fatorTransicaoIbsIcms: 0.4,
        extinguePisCofins: true,
        aliquotaCbsEfetiva: 0.088,
        aliquotaIbsEfetiva: 0.177 * 0.4,
      };
    case 2033:
    default:
      // Vigência Plena do IVA Dual: Extinção de ICMS e ISS; CBS 8,8% + IBS 17,7% = ~26,5%
      return {
        aliquotaCbsPadrao: 0.088,
        aliquotaIbsPadrao: 0.177,
        fatorTransicaoIbsIcms: 1.0,
        extinguePisCofins: true,
        aliquotaCbsEfetiva: 0.088,
        aliquotaIbsEfetiva: 0.177,
      };
  }
}

// =========================================================================
// MOTOR PRINCIPAL DE CÁLCULO TRIBUTÁRIO COMPARATIVO
// =========================================================================

export function calcularComparativoTributario(
  params: ParametrosSimulacaoTributaria
): {
  cenarios: ResultadoCenarioSimulacao[];
  melhorOpcao: ResultadoCenarioSimulacao;
  fatorRCalculado: number;
  fatorREnquadrado: boolean;
  resumoParecer: string;
} {
  const faturamento = Math.max(0, params.faturamentoAnual);
  const folha = Math.max(0, params.folhaAnual);
  const proLabore = Math.max(0, params.proLaboreAnual);
  const folhaTotal = folha + proLabore;
  const fatorR = faturamento > 0 ? folhaTotal / faturamento : 0;
  const fatorREnquadrado = fatorR >= 0.28;

  const reforma = obterParametrosReformaPorAno(params.anoAnalise);

  // -----------------------------------------------------------------------
  // 1. CÁLCULO: SIMPLES NACIONAL TRADICIONAL
  // -----------------------------------------------------------------------
  const simplesTradicional = calcularSimplesTradicional(
    params,
    faturamento,
    folha,
    proLabore,
    fatorR,
    fatorREnquadrado
  );

  // -----------------------------------------------------------------------
  // 2. CÁLCULO: SIMPLES NACIONAL HÍBRIDO (REFORMA TRIBUTÁRIA)
  // -----------------------------------------------------------------------
  const simplesHibrido = calcularSimplesHibrido(
    params,
    faturamento,
    folha,
    proLabore,
    fatorR,
    fatorREnquadrado,
    reforma
  );

  // -----------------------------------------------------------------------
  // 3. CÁLCULO: LUCRO PRESUMIDO
  // -----------------------------------------------------------------------
  const lucroPresumido = calcularLucroPresumido(
    params,
    faturamento,
    folha,
    proLabore,
    reforma
  );

  // -----------------------------------------------------------------------
  // 4. CÁLCULO: LUCRO REAL
  // -----------------------------------------------------------------------
  const lucroReal = calcularLucroReal(
    params,
    faturamento,
    folha,
    proLabore,
    reforma
  );

  const todosCenarios = [simplesTradicional, simplesHibrido, lucroPresumido, lucroReal];

  // Identificar melhor opção entre os elegíveis
  const elegiveis = todosCenarios.filter((c) => c.elegivel);
  let melhorCenario = elegiveis[0] || todosCenarios[0];

  for (const c of elegiveis) {
    if (c.tributos.custoLiquidoTributario < melhorCenario.tributos.custoLiquidoTributario) {
      melhorCenario = c;
    }
  }

  // Marcar a melhor opção e calcular diferenças e economia
  const menorCusto = melhorCenario.tributos.custoLiquidoTributario;

  todosCenarios.forEach((c) => {
    c.isMelhorOpcao = c.id === melhorCenario.id;
    c.diferencaAnualMelhorOpcao = Math.max(0, c.tributos.custoLiquidoTributario - menorCusto);
    c.percentualEconomia =
      c.tributos.custoLiquidoTributario > 0
        ? ((c.tributos.custoLiquidoTributario - menorCusto) / c.tributos.custoLiquidoTributario) * 100
        : 0;
  });

  // Gerar Resumo do Parecer Técnico
  const resumoParecer = gerarParecerTecnico(
    params,
    melhorCenario,
    todosCenarios,
    fatorR,
    fatorREnquadrado
  );

  return {
    cenarios: todosCenarios,
    melhorOpcao: melhorCenario,
    fatorRCalculado: fatorR,
    fatorREnquadrado,
    resumoParecer,
  };
}

// -------------------------------------------------------------------------
// Sub-rotina: Simples Tradicional
// -------------------------------------------------------------------------
function calcularSimplesTradicional(
  params: ParametrosSimulacaoTributaria,
  faturamento: number,
  folha: number,
  proLabore: number,
  fatorR: number,
  fatorREnquadrado: boolean
): ResultadoCenarioSimulacao {
  if (faturamento > 4800000) {
    return {
      id: 'simples_tradicional',
      titulo: 'Simples Nacional Tradicional',
      subtitulo: 'Regime Unificado DAS (LC 123/2006)',
      descricao: 'Apuração e recolhimento em documento único de arrecadação.',
      elegivel: false,
      motivoInelegibilidade: 'Faturamento superior ao teto do Simples Nacional (R$ 4.800.000,00 anuais).',
      fatorRCalculado: fatorR,
      fatorREnquadrado,
      tributos: criarDetalhamentoZerado(),
      diferencaAnualMelhorOpcao: 0,
      percentualEconomia: 0,
      isMelhorOpcao: false,
      pontosFortes: [],
      pontosAtencao: ['Excedeu limite legal do Simples Nacional.'],
    };
  }

  let tabela = TABELA_ANEXO_I;
  let anexoNome = 'Anexo I';
  let percentualIcmsOuIss = 0.34;
  let percentualPisCofins = 0.155;
  let percentualIrpjCsll = 0.09;
  let cppInclusa = true;

  if (params.atividade === 'comercio') {
    tabela = TABELA_ANEXO_I;
    anexoNome = 'Anexo I (Comércio)';
    percentualIcmsOuIss = 0.34; // ICMS
    percentualPisCofins = 0.155;
    percentualIrpjCsll = 0.09;
  } else if (params.atividade === 'industria') {
    tabela = TABELA_ANEXO_II;
    anexoNome = 'Anexo II (Indústria)';
    percentualIcmsOuIss = 0.32; // ICMS
    percentualPisCofins = 0.145;
    percentualIrpjCsll = 0.09;
  } else if (params.atividade === 'servicos_anexo3') {
    tabela = TABELA_ANEXO_III;
    anexoNome = 'Anexo III (Serviços em Geral)';
    percentualIcmsOuIss = 0.335; // ISS
    percentualPisCofins = 0.156;
    percentualIrpjCsll = 0.075;
  } else if (params.atividade === 'servicos_anexo4') {
    tabela = TABELA_ANEXO_IV;
    anexoNome = 'Anexo IV (Limpeza, Vigilância, Obras, Advocacia)';
    percentualIcmsOuIss = 0.44; // ISS
    percentualPisCofins = 0.20;
    percentualIrpjCsll = 0.36;
    cppInclusa = false; // Anexo IV não tem CPP no DAS!
  } else if (params.atividade === 'servicos_anexo5') {
    if (fatorREnquadrado) {
      tabela = TABELA_ANEXO_III;
      anexoNome = 'Anexo III (Beneficiado pelo Fator R ≥ 28%)';
      percentualIcmsOuIss = 0.335;
      percentualPisCofins = 0.156;
      percentualIrpjCsll = 0.075;
    } else {
      tabela = TABELA_ANEXO_V;
      anexoNome = 'Anexo V (Fator R < 28% - Alíquota Majorada)';
      percentualIcmsOuIss = 0.21;
      percentualPisCofins = 0.15;
      percentualIrpjCsll = 0.35;
    }
  }

  const { aliquotaEfetiva } = calcularAliquotaEfetivaSimples(faturamento, tabela);
  const valorDasAnual = faturamento * aliquotaEfetiva;

  // Repartição estimada do DAS
  const icmsIss = valorDasAnual * percentualIcmsOuIss;
  const pisCofins = valorDasAnual * percentualPisCofins;
  const irpjCsll = valorDasAnual * percentualIrpjCsll;
  const irpj = irpjCsll * 0.6;
  const csll = irpjCsll * 0.4;

  // Previdência Patronal:
  let inssPatronalFolha = 0;
  let inssProLabore = 0;

  if (!cppInclusa) {
    // Anexo IV: INSS Patronal 20% + RAT (ex: 2%) + Terceiros (5.8%) = 27.8%
    const aliqPatronal = 0.20 + (params.aliquotaRatFap || 0.02) + (params.aliquotaTerceiros || 0.058);
    inssPatronalFolha = folha * aliqPatronal;
    inssProLabore = proLabore * 0.20;
  }

  const totalTributosAnual = valorDasAnual + inssPatronalFolha + inssProLabore;

  // No Simples Tradicional, o crédito repassado no B2B é apenas o ICMS/ISS efetivo do DAS
  const percCreditoB2B = (icmsIss / (faturamento || 1));
  const faturamentoB2B = faturamento * ((params.percentualVendasB2B || 0) / 100);
  const creditoGeradoClientesB2B = faturamentoB2B * percCreditoB2B;

  return {
    id: 'simples_tradicional',
    titulo: 'Simples Nacional Tradicional',
    subtitulo: `Apuração Unificada via ${anexoNome}`,
    descricao: 'Recolhimento centralizado no DAS com menor burocracia contábil e obrigações acessórias simplificadas.',
    elegivel: true,
    anexoSimples: anexoNome,
    fatorRCalculado: fatorR,
    fatorREnquadrado,
    tributos: {
      irpj,
      csll,
      pisCofinsOuCbs: pisCofins,
      icmsIssOuIbs: icmsIss,
      inssPatronalFolha,
      inssProLabore,
      totalTributosAnual,
      totalTributosMensal: totalTributosAnual / 12,
      aliquotaEfetivaTotal: faturamento > 0 ? (totalTributosAnual / faturamento) * 100 : 0,
      creditoGeradoClientesB2B,
      creditoAproveitadoCompras: 0, // No Simples a empresa não toma crédito de compras
      custoLiquidoTributario: totalTributosAnual,
    },
    diferencaAnualMelhorOpcao: 0,
    percentualEconomia: 0,
    isMelhorOpcao: false,
    pontosFortes: [
      'Guia única mensal (DAS) de fácil quitação.',
      cppInclusa ? 'Isenção de CPP Patronal (20%) sobre salários e pró-labore.' : 'Alíquota DAS competitiva para atividades técnicas de advocacia/obras.',
      'Dispensa de ECD/ECF complexas e de obrigações pesadas de SPED.',
    ],
    pontosAtencao: [
      'Não permite transferir créditos integrais de PIS/COFINS (ou futura CBS) para clientes corporativos (B2B).',
      faturamento > 3600000 ? 'Atenção ao sublimite estadual de R$ 3,6M: ICMS/ISS deverá ser recolhido por fora.' : 'Alíquota cresce progressivamente conforme o faturamento dos últimos 12 meses.',
      params.atividade === 'servicos_anexo5' && !fatorREnquadrado ? 'Carga tributária elevada no Anexo V por possuir folha inferior a 28% do faturamento.' : 'Sem tomada de crédito nas aquisições de insumos e mercadorias.',
    ],
  };
}

// -------------------------------------------------------------------------
// Sub-rotina: Simples Nacional Híbrido (Reforma Tributária EC 132/2023)
// -------------------------------------------------------------------------
function calcularSimplesHibrido(
  params: ParametrosSimulacaoTributaria,
  faturamento: number,
  folha: number,
  proLabore: number,
  fatorR: number,
  fatorREnquadrado: boolean,
  reforma: ParametrosReformaAno
): ResultadoCenarioSimulacao {
  if (faturamento > 4800000) {
    return {
      id: 'simples_hibrido',
      titulo: 'Simples Nacional Híbrido (Reforma Tributária)',
      subtitulo: 'Regime Misto CBS/IBS + Simples Federal',
      descricao: 'Optante recolhe tributos de consumo fora do Simples gerando 100% de crédito para clientes.',
      elegivel: false,
      motivoInelegibilidade: 'Faturamento superior ao teto do Simples Nacional (R$ 4.800.000,00).',
      fatorRCalculado: fatorR,
      fatorREnquadrado,
      tributos: criarDetalhamentoZerado(),
      diferencaAnualMelhorOpcao: 0,
      percentualEconomia: 0,
      isMelhorOpcao: false,
      pontosFortes: [],
      pontosAtencao: ['Excedeu limite legal do Simples Nacional.'],
    };
  }

  // Base do Simples Federal (expurgando ICMS/ISS e PIS/COFINS do DAS)
  // No modelo híbrido, a empresa recolhe IRPJ, CSLL e CPP pelo Simples Nacional com desconto de ~45% a 55% da alíquota DAS
  const simplesBase = calcularSimplesTradicional(
    params,
    faturamento,
    folha,
    proLabore,
    fatorR,
    fatorREnquadrado
  );

  const dasReduzido = simplesBase.tributos.irpj + simplesBase.tributos.csll + (simplesBase.tributos.totalTributosAnual * 0.4);

  // E recolhe IBS e CBS no regime não-cumulativo amplo (com créditos sobre compras/insumos)
  const compras = Math.max(0, params.comprasInsumosAnual);
  const despesas = Math.max(0, params.despesasOperacionaisAnual);
  const baseCredito = compras + despesas;

  const aliqCbs = reforma.aliquotaCbsEfetiva;
  const aliqIbs = reforma.aliquotaIbsEfetiva;
  const aliqTotalConsumo = aliqCbs + aliqIbs;

  const debitoConsumo = faturamento * aliqTotalConsumo;
  const creditoConsumo = baseCredito * aliqTotalConsumo;
  const consumoLiquido = Math.max(0, debitoConsumo - creditoConsumo);

  const totalTributosAnual = dasReduzido + consumoLiquido + simplesBase.tributos.inssPatronalFolha + simplesBase.tributos.inssProLabore;

  // Crédito transferido ao cliente B2B é 100% do IBS e CBS destacados na venda!
  const faturamentoB2B = faturamento * ((params.percentualVendasB2B || 0) / 100);
  const creditoGeradoClientesB2B = faturamentoB2B * aliqTotalConsumo;

  const custoLiquidoTributario = totalTributosAnual;

  return {
    id: 'simples_hibrido',
    titulo: 'Simples Modelo Híbrido',
    subtitulo: `CBS/IBS Fora do DAS (${params.anoAnalise})`,
    descricao: 'Mantém IRPJ/CSLL/CPP no Simples e recolhe IBS/CBS no regime normal, transferindo 100% de crédito B2B.',
    elegivel: true,
    anexoSimples: simplesBase.anexoSimples,
    fatorRCalculado: fatorR,
    fatorREnquadrado,
    tributos: {
      irpj: simplesBase.tributos.irpj,
      csll: simplesBase.tributos.csll,
      pisCofinsOuCbs: Math.max(0, faturamento * aliqCbs - baseCredito * aliqCbs),
      icmsIssOuIbs: Math.max(0, faturamento * aliqIbs - baseCredito * aliqIbs),
      inssPatronalFolha: simplesBase.tributos.inssPatronalFolha,
      inssProLabore: simplesBase.tributos.inssProLabore,
      totalTributosAnual,
      totalTributosMensal: totalTributosAnual / 12,
      aliquotaEfetivaTotal: faturamento > 0 ? (totalTributosAnual / faturamento) * 100 : 0,
      creditoGeradoClientesB2B,
      creditoAproveitadoCompras: creditoConsumo,
      custoLiquidoTributario,
    },
    diferencaAnualMelhorOpcao: 0,
    percentualEconomia: 0,
    isMelhorOpcao: false,
    pontosFortes: [
      'Gera crédito integral de CBS e IBS aos clientes B2B, eliminando desvantagem comercial.',
      'Mantém a isenção de CPP patronal e tributação favorecida do IRPJ/CSLL no Simples.',
      'Aproveita créditos financeiros das compras de insumos, mercadorias e custos operacionais.',
    ],
    pontosAtencao: [
      'Exige apuração segregada de IBS/CBS fora do PG-DAS (maior complexidade contábil).',
      'Pode resultar em carga bruta maior se o percentual de compras/insumos com crédito for baixo.',
      'Recomendado fortemente quando a empresa atua no canal B2B e corre risco de perder contratos.',
    ],
  };
}

// -------------------------------------------------------------------------
// Sub-rotina: Lucro Presumido
// -------------------------------------------------------------------------
function calcularLucroPresumido(
  params: ParametrosSimulacaoTributaria,
  faturamento: number,
  folha: number,
  proLabore: number,
  reforma: ParametrosReformaAno
): ResultadoCenarioSimulacao {
  if (faturamento > 78000000) {
    return {
      id: 'lucro_presumido',
      titulo: 'Lucro Presumido',
      subtitulo: 'Presunção Legal de Margem',
      descricao: 'Tributação com base em percentuais fixados por lei sobre a receita.',
      elegivel: false,
      motivoInelegibilidade: 'Faturamento superior ao limite legal do Lucro Presumido (R$ 78.000.000,00 anuais).',
      tributos: criarDetalhamentoZerado(),
      diferencaAnualMelhorOpcao: 0,
      percentualEconomia: 0,
      isMelhorOpcao: false,
      pontosFortes: [],
      pontosAtencao: ['Obrigatório migrar para Lucro Real.'],
    };
  }

  // Presunções
  const isServico = params.atividade.startsWith('servicos');
  const presuncaoIrpj = isServico ? 0.32 : 0.08;
  const presuncaoCsll = isServico ? 0.32 : 0.12;

  const baseIrpj = faturamento * presuncaoIrpj;
  const baseCsll = faturamento * presuncaoCsll;

  // IRPJ: 15% + 10% adicional sobre excedente de 240k/ano (20k/mês)
  const irpjBasico = baseIrpj * 0.15;
  const adicionalIrpj = Math.max(0, (baseIrpj - 240000) * 0.10);
  const irpj = irpjBasico + adicionalIrpj;

  // CSLL: 9%
  const csll = baseCsll * 0.09;

  // Tributos sobre Consumo / Faturamento:
  let pisCofinsOuCbs = 0;
  let icmsIssOuIbs = 0;

  if (!reforma.extinguePisCofins) {
    // Regime Cumulativo clássico: PIS 0.65% + COFINS 3.00% = 3.65%
    pisCofinsOuCbs = faturamento * 0.0365;
  } else {
    // CBS da Reforma
    pisCofinsOuCbs = faturamento * reforma.aliquotaCbsEfetiva;
  }

  if (isServico) {
    const aliqIss = (params.aliquotaIssMunicipal || 3) / 100;
    const issTradicional = faturamento * aliqIss;
    if (reforma.fatorTransicaoIbsIcms === 0) {
      icmsIssOuIbs = issTradicional;
    } else {
      const parteIss = issTradicional * (1 - reforma.fatorTransicaoIbsIcms);
      const parteIbs = faturamento * reforma.aliquotaIbsEfetiva;
      icmsIssOuIbs = parteIss + parteIbs;
    }
  } else {
    // Comércio / Indústria: ICMS efetivo estimado líquido ~ 3.8%
    const aliqIcmsEfetiva = 0.038;
    const icmsTradicional = faturamento * aliqIcmsEfetiva;
    if (reforma.fatorTransicaoIbsIcms === 0) {
      icmsIssOuIbs = icmsTradicional;
    } else {
      const parteIcms = icmsTradicional * (1 - reforma.fatorTransicaoIbsIcms);
      const parteIbs = faturamento * reforma.aliquotaIbsEfetiva;
      icmsIssOuIbs = parteIcms + parteIbs;
    }
  }

  // Previdência Patronal:
  // 20% CPP + RAT/FAP (~2%) + Terceiros (5.8%) = 27.8% sobre folha
  // 20% CPP sobre pró-labore
  const aliqPatronalFolha = 0.20 + (params.aliquotaRatFap || 0.02) + (params.aliquotaTerceiros || 0.058);
  const inssPatronalFolha = folha * aliqPatronalFolha;
  const inssProLabore = proLabore * 0.20;

  const totalTributosAnual = irpj + csll + pisCofinsOuCbs + icmsIssOuIbs + inssPatronalFolha + inssProLabore;

  // Créditos B2B: No Lucro Presumido, transfere ICMS/ISS e CBS
  const faturamentoB2B = faturamento * ((params.percentualVendasB2B || 0) / 100);
  const aliqCreditoB2B = isServico ? 0.0365 + (params.aliquotaIssMunicipal || 3) / 100 : 0.0365 + 0.12;
  const creditoGeradoClientesB2B = faturamentoB2B * Math.min(0.18, aliqCreditoB2B);

  return {
    id: 'lucro_presumido',
    titulo: 'Lucro Presumido',
    subtitulo: isServico ? 'Presunção 32% (Serviços)' : 'Presunção 8% IRPJ / 12% CSLL',
    descricao: 'Recomendado para empresas com margem de lucro real superior à presunção legal e baixa despesa operacional.',
    elegivel: true,
    tributos: {
      irpj,
      csll,
      pisCofinsOuCbs,
      icmsIssOuIbs,
      inssPatronalFolha,
      inssProLabore,
      totalTributosAnual,
      totalTributosMensal: totalTributosAnual / 12,
      aliquotaEfetivaTotal: faturamento > 0 ? (totalTributosAnual / faturamento) * 100 : 0,
      creditoGeradoClientesB2B,
      creditoAproveitadoCompras: 0, // No cumulativo não se apropria de créditos gerais
      custoLiquidoTributario: totalTributosAnual,
    },
    diferencaAnualMelhorOpcao: 0,
    percentualEconomia: 0,
    isMelhorOpcao: false,
    pontosFortes: [
      'Excelente quando a margem líquida da empresa é alta (ex: 40% a 50%), pois só tributa a presunção legal.',
      'Cálculo objetivo e estável sem necessidade de comprovação minuciosa de cada despesa operacional.',
      'Gera créditos tributários atrativos para clientes em operações comerciais B2B.',
    ],
    pontosAtencao: [
      'Incidência pesada de INSS Patronal (~28% sobre folha de pagamento e 20% sobre pró-labore).',
      'Desfavorável se a empresa passar por períodos de prejuízo contábil (continua pagando sobre a presunção).',
      'Serviços possuem presunção elevada de 32% para IRPJ e CSLL.',
    ],
  };
}

// -------------------------------------------------------------------------
// Sub-rotina: Lucro Real
// -------------------------------------------------------------------------
function calcularLucroReal(
  params: ParametrosSimulacaoTributaria,
  faturamento: number,
  folha: number,
  proLabore: number,
  reforma: ParametrosReformaAno
): ResultadoCenarioSimulacao {
  const isServico = params.atividade.startsWith('servicos');
  const compras = Math.max(0, params.comprasInsumosAnual);
  const despesasOperacionais = Math.max(0, params.despesasOperacionaisAnual);
  const encargosPatronais = (folha * 0.278) + (proLabore * 0.20);

  // PIS / COFINS ou CBS no regime Não-Cumulativo:
  let aliqPisCofinsOuCbs = 0.0925; // PIS 1.65% + COFINS 7.60%
  if (reforma.extinguePisCofins) {
    aliqPisCofinsOuCbs = reforma.aliquotaCbsEfetiva;
  }

  const debitoPisCofins = faturamento * aliqPisCofinsOuCbs;
  const baseCreditoInsumos = compras + despesasOperacionais;
  const creditoPisCofins = baseCreditoInsumos * aliqPisCofinsOuCbs;
  const pisCofinsOuCbs = Math.max(0, debitoPisCofins - creditoPisCofins);

  // Tributo Local (ICMS / ISS / IBS):
  let icmsIssOuIbs = 0;
  if (isServico) {
    const aliqIss = (params.aliquotaIssMunicipal || 3) / 100;
    icmsIssOuIbs = faturamento * aliqIss;
  } else {
    // ICMS débitos e créditos reais
    const aliqIcms = (params.aliquotaIcmsInterno || 18) / 100;
    const debitoIcms = faturamento * aliqIcms;
    const creditoIcms = compras * aliqIcms;
    icmsIssOuIbs = Math.max(0, debitoIcms - creditoIcms);
  }

  // Previdência Patronal:
  const aliqPatronalFolha = 0.20 + (params.aliquotaRatFap || 0.02) + (params.aliquotaTerceiros || 0.058);
  const inssPatronalFolha = folha * aliqPatronalFolha;
  const inssProLabore = proLabore * 0.20;

  // Apuração do Lucro Real Efetivo (LAIR / LALUR):
  // Se o usuário informou margem de lucro estimada explicitamente:
  const margemPercentual = (params.margemLucroEstimada || 12) / 100;
  let lucroRealEstimado = faturamento * margemPercentual;

  // Se informou custos detalhados, calculamos analiticamente:
  if (compras > 0 || despesasOperacionais > 0) {
    lucroRealEstimado = Math.max(
      -faturamento * 0.1, // pode ter prejuízo fiscal de até 10%
      faturamento - compras - despesasOperacionais - folha - proLabore - encargosPatronais - pisCofinsOuCbs - icmsIssOuIbs
    );
  }

  let irpj = 0;
  let csll = 0;

  if (lucroRealEstimado > 0) {
    // IRPJ 15% + adicional 10% sobre o que exceder R$ 240k/ano
    const irpjBase = lucroRealEstimado * 0.15;
    const adicional = Math.max(0, (lucroRealEstimado - 240000) * 0.10);
    irpj = irpjBase + adicional;
    // CSLL 9%
    csll = lucroRealEstimado * 0.09;
  } else {
    // Prejuízo Fiscal: IRPJ e CSLL zerados!
    irpj = 0;
    csll = 0;
  }

  const totalTributosAnual = irpj + csll + pisCofinsOuCbs + icmsIssOuIbs + inssPatronalFolha + inssProLabore;

  // Crédito repassado ao cliente B2B: Pleno no Lucro Real
  const faturamentoB2B = faturamento * ((params.percentualVendasB2B || 0) / 100);
  const creditoGeradoClientesB2B = faturamentoB2B * (aliqPisCofinsOuCbs + (isServico ? 0.05 : 0.18));

  return {
    id: 'lucro_real',
    titulo: 'Lucro Real',
    subtitulo: lucroRealEstimado <= 0 ? 'Resultado com Prejuízo Fiscal' : `Margem Líquida Real Apurada (${((lucroRealEstimado / (faturamento || 1)) * 100).toFixed(1)}%)`,
    descricao: 'Tributação sobre o resultado contábil efetivo com aproveitamento integral de créditos fiscais.',
    elegivel: true,
    tributos: {
      irpj,
      csll,
      pisCofinsOuCbs,
      icmsIssOuIbs,
      inssPatronalFolha,
      inssProLabore,
      totalTributosAnual,
      totalTributosMensal: totalTributosAnual / 12,
      aliquotaEfetivaTotal: faturamento > 0 ? (totalTributosAnual / faturamento) * 100 : 0,
      creditoGeradoClientesB2B,
      creditoAproveitadoCompras: creditoPisCofins,
      custoLiquidoTributario: totalTributosAnual,
    },
    diferencaAnualMelhorOpcao: 0,
    percentualEconomia: 0,
    isMelhorOpcao: false,
    pontosFortes: [
      'Se a empresa tiver prejuízo fiscal ou margem muito baixa (< 6%), não paga IRPJ nem CSLL.',
      'Aproveitamento amplo de créditos de PIS/COFINS e IBS/CBS sobre insumos, aluguéis e compras.',
      'Transfere créditos tributários máximos para clientes PJ, fortalecendo a competitividade B2B.',
    ],
    pontosAtencao: [
      'Exige contabilidade rigorosa e escrituração digital no SPED (ECD, ECF, EFD-Contribuições).',
      'Alíquotas nominais mais altas no PIS/COFINS (9,25%) e CBS.',
      'Incidência integral de encargos de INSS patronal sobre a folha.',
    ],
  };
}

function criarDetalhamentoZerado(): DetalhamentoTributosRegime {
  return {
    irpj: 0,
    csll: 0,
    pisCofinsOuCbs: 0,
    icmsIssOuIbs: 0,
    inssPatronalFolha: 0,
    inssProLabore: 0,
    totalTributosAnual: 0,
    totalTributosMensal: 0,
    aliquotaEfetivaTotal: 0,
    creditoGeradoClientesB2B: 0,
    creditoAproveitadoCompras: 0,
    custoLiquidoTributario: 0,
  };
}

// -------------------------------------------------------------------------
// Geração de Parecer Técnico Orientativo
// -------------------------------------------------------------------------
function gerarParecerTecnico(
  params: ParametrosSimulacaoTributaria,
  melhor: ResultadoCenarioSimulacao,
  todos: ResultadoCenarioSimulacao[],
  fatorR: number,
  fatorREnquadrado: boolean
): string {
  const formatadorMoeda = (val: number) =>
    val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  // Comparar com o pior ou com o Simples Tradicional
  const simplesTrad = todos.find((c) => c.id === 'simples_tradicional');
  const lucroPresum = todos.find((c) => c.id === 'lucro_presumido');

  let mensagem = `Com base na receita anual de ${formatadorMoeda(params.faturamentoAnual)} e estrutura de custos informada, o regime tributário mais econômico para o exercício de ${params.anoAnalise} é o **${melhor.titulo}**. `;

  if (melhor.id === 'simples_tradicional') {
    mensagem += `Este modelo proporciona uma carga efetiva total de **${melhor.tributos.aliquotaEfetivaTotal.toFixed(2)}%**, simplificando os tributos federais, estaduais/municipais e dispensando encargos patronais de INSS sobre a folha. `;
    if (lucroPresum && lucroPresum.elegivel) {
      const economiaFrentePresumido = lucroPresum.tributos.custoLiquidoTributario - melhor.tributos.custoLiquidoTributario;
      if (economiaFrentePresumido > 0) {
        mensagem += `Em relação ao Lucro Presumido, a economia anual estimada é de **${formatadorMoeda(economiaFrentePresumido)}** (${((economiaFrentePresumido / lucroPresum.tributos.custoLiquidoTributario) * 100).toFixed(1)}%). `;
      }
    }
  } else if (melhor.id === 'simples_hibrido') {
    mensagem += `O modelo híbrido da Reforma Tributária se destaca principalmente porque a empresa possui expressivo volume de vendas corporativas B2B (${params.percentualVendasB2B}%). Ao recolher CBS/IBS fora do Simples, a empresa transfere **${formatadorMoeda(melhor.tributos.creditoGeradoClientesB2B)}** em créditos para seus clientes, mantendo ao mesmo tempo a tributação favorecida do IRPJ e CSLL dentro do Simples Nacional. `;
  } else if (melhor.id === 'lucro_presumido') {
    mensagem += `O Lucro Presumido se mostrou superior em função da alta margem contábil frente à alíquota progressiva que o Simples alcançaria nessa faixa de faturamento. `;
    if (simplesTrad && simplesTrad.elegivel) {
      const economia = simplesTrad.tributos.custoLiquidoTributario - melhor.tributos.custoLiquidoTributario;
      mensagem += `A economia estimada em relação ao Simples Nacional Tradicional é de **${formatadorMoeda(economia)}** ao ano. `;
    }
  } else if (melhor.id === 'lucro_real') {
    mensagem += `O Lucro Real é a alternativa mais eficiente devido ao alto volume de compras de insumos e despesas dedutíveis (${formatadorMoeda(params.comprasInsumosAnual + params.despesasOperacionaisAnual)}), permitindo expressiva tomada de créditos tributários e menor impacto de IRPJ/CSLL. `;
  }

  if (params.atividade === 'servicos_anexo5') {
    mensagem += `\n\n📌 **Análise do Fator R**: O índice apurado foi de **${(fatorR * 100).toFixed(1)}%**. Como ${
      fatorREnquadrado
        ? 'atingiu o limite de 28%, a empresa se beneficia do enquadramento no Anexo III, reduzindo substancialmente os tributos!'
        : 'ficou abaixo de 28%, a empresa é tributada pelo Anexo V caso opte pelo Simples Nacional, sofrendo alíquotas iniciais mais elevadas de 15,5%.'
    }`;
  }

  return mensagem;
}
