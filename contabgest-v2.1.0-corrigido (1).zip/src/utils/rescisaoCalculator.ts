import {
  Funcionario,
  Empresa,
  TipoMotivoRescisao,
  TipoAvisoPrevioRescisao,
  CalculoRescisaoResultado,
  RubricaRescisao,
  DocumentoTRCT,
} from '../types';

export interface ParametrosCalculoRescisao {
  funcionario: Funcionario;
  empresa?: Empresa | null;
  motivoRescisao: TipoMotivoRescisao;
  tipoAvisoPrevio: TipoAvisoPrevioRescisao;
  dataDesligamento: string; // YYYY-MM-DD
  dataAvisoPrevio?: string; // YYYY-MM-DD
  saldoFgtsInformado?: number; // Saldo da conta vinculada da Caixa
  diasSaldoSalarioManual?: number;
  horasExtrasValor?: number;
  outrosAdicionaisValor?: number;
  faltasDsrValor?: number;
  outrosDescontosValor?: number;
  diasFeriasVencidasManual?: number;
}

/**
 * Calcula anos completos entre duas datas
 */
export function calcularAnosCompletos(dataInicioStr: string, dataFimStr: string): number {
  const dInicio = new Date(dataInicioStr);
  const dFim = new Date(dataFimStr);
  let anos = dFim.getFullYear() - dInicio.getFullYear();
  const m = dFim.getMonth() - dInicio.getMonth();
  if (m < 0 || (m === 0 && dFim.getDate() < dInicio.getDate())) {
    anos--;
  }
  return Math.max(0, anos);
}

/**
 * Calcula total de meses trabalhados entre duas datas
 */
export function calcularMesesTrabalhados(dataInicioStr: string, dataFimStr: string): number {
  const dInicio = new Date(dataInicioStr);
  const dFim = new Date(dataFimStr);
  const anos = dFim.getFullYear() - dInicio.getFullYear();
  let meses = anos * 12 + (dFim.getMonth() - dInicio.getMonth());
  if (dFim.getDate() >= 15) {
    meses++;
  }
  return Math.max(1, meses);
}

/**
 * Tabela e configurações dos motivos de rescisão segundo a CLT
 */
export const MOTIVOS_RESCISAO_CONFIG: Record<
  TipoMotivoRescisao,
  {
    nome: string;
    codigoAfastamento: string;
    multaFgtsAliquota: number;
    permiteSaqueFgts: boolean;
    direitoSeguroDesemprego: boolean;
    artigoClt: string;
  }
> = {
  sem_justa_causa: {
    nome: 'Demissão Sem Justa Causa pelo Empregador',
    codigoAfastamento: 'SJ2',
    multaFgtsAliquota: 40,
    permiteSaqueFgts: true,
    direitoSeguroDesemprego: true,
    artigoClt: 'Art. 477 da CLT',
  },
  pedido_demissao: {
    nome: 'Pedido de Demissão pelo Empregado',
    codigoAfastamento: 'RA1',
    multaFgtsAliquota: 0,
    permiteSaqueFgts: false,
    direitoSeguroDesemprego: false,
    artigoClt: 'Art. 487 da CLT',
  },
  justa_causa: {
    nome: 'Demissão Com Justa Causa pelo Empregador',
    codigoAfastamento: 'JC1',
    multaFgtsAliquota: 0,
    permiteSaqueFgts: false,
    direitoSeguroDesemprego: false,
    artigoClt: 'Art. 482 da CLT',
  },
  acordo_mutuo: {
    nome: 'Demissão por Acordo Mútuo entre as Partes',
    codigoAfastamento: 'AM1',
    multaFgtsAliquota: 20,
    permiteSaqueFgts: true,
    direitoSeguroDesemprego: false,
    artigoClt: 'Art. 484-A da CLT (Reforma Trabalhista)',
  },
  termino_experiencia: {
    nome: 'Término do Contrato de Experiência / Prazo Determinado',
    codigoAfastamento: 'PD1',
    multaFgtsAliquota: 0,
    permiteSaqueFgts: true,
    direitoSeguroDesemprego: false,
    artigoClt: 'Art. 473 e 474 da CLT',
  },
  rescisao_antecipada_empregador: {
    nome: 'Rescisão Antecipada de Experiência pelo Empregador',
    codigoAfastamento: 'RA2',
    multaFgtsAliquota: 40,
    permiteSaqueFgts: true,
    direitoSeguroDesemprego: true,
    artigoClt: 'Art. 479 da CLT (Indenização de 50% dos dias restantes)',
  },
  rescisao_indireta: {
    nome: 'Rescisão Indireta por Falta Grave do Empregador',
    codigoAfastamento: 'RI1',
    multaFgtsAliquota: 40,
    permiteSaqueFgts: true,
    direitoSeguroDesemprego: true,
    artigoClt: 'Art. 483 da CLT',
  },
};

/**
 * Tabela escalonada de Aviso Prévio Proporcional (Lei 12.506/2011)
 */
export const TABELA_AVISO_PREVIO_LEI_12506: Array<{
  anosCompletos: number;
  diasAviso: number;
  diasAdicionais: number;
}> = Array.from({ length: 21 }, (_, i) => ({
  anosCompletos: i,
  diasAviso: Math.min(90, 30 + i * 3),
  diasAdicionais: Math.min(60, i * 3),
}));

/**
 * Calcula dias de aviso prévio proporcional conforme Lei 12.506/2011:
 * 30 dias base + 3 dias por ano completo de serviço prestado na empresa (até limite de 90 dias = 20 anos)
 */
export function calcularDiasAvisoLei12506(anosCompletos: number): number {
  const adicionais = anosCompletos * 3;
  return Math.min(90, 30 + adicionais);
}

/**
 * Tabela de INSS progressiva (vigente CLT)
 */
export function calcularInssProgressivo(baseCalculo: number): {
  valorTotal: number;
  faixas: Array<{ faixa: string; base: number; aliquota: number; valor: number }>;
} {
  const faixas = [
    { limite: 1412.0, aliq: 0.075, label: '7,5% (até R$ 1.412,00)' },
    { limite: 2666.68, aliq: 0.09, label: '9,0% (de R$ 1.412,01 a R$ 2.666,68)' },
    { limite: 4000.03, aliq: 0.12, label: '12,0% (de R$ 2.666,69 a R$ 4.000,03)' },
    { limite: 7786.02, aliq: 0.14, label: '14,0% (de R$ 4.000,04 a R$ 7.786,02)' },
  ];

  let valorTotal = 0;
  const detalheFaixas: Array<{ faixa: string; base: number; aliquota: number; valor: number }> = [];
  let baseRestante = Math.max(0, baseCalculo);
  let limiteAnterior = 0;

  for (const f of faixas) {
    if (baseRestante <= 0) break;
    const larguraFaixa = f.limite - limiteAnterior;
    const baseTributavelFaixa = Math.min(baseRestante, larguraFaixa);
    const valorFaixa = Math.round(baseTributavelFaixa * f.aliq * 100) / 100;

    detalheFaixas.push({
      faixa: f.label,
      base: baseTributavelFaixa,
      aliquota: f.aliq * 100,
      valor: valorFaixa,
    });

    valorTotal += valorFaixa;
    baseRestante -= baseTributavelFaixa;
    limiteAnterior = f.limite;
  }

  // Teto máximo do INSS
  const tetoInss = 908.86;
  if (valorTotal > tetoInss) {
    valorTotal = tetoInss;
  }

  return {
    valorTotal: Math.round(valorTotal * 100) / 100,
    faixas: detalheFaixas,
  };
}

/**
 * Tabela de IRRF progressiva com dedução por dependente
 */
export function calcularIrrf(
  baseBruta: number,
  deducaoInss: number,
  qtdDependentes: number
): {
  baseCalculo: number;
  valorIrrf: number;
  faixaAliquota: string;
  deducaoDependentes: number;
} {
  const deducaoDependentes = qtdDependentes * 189.59;
  const baseCalculo = Math.max(0, baseBruta - deducaoInss - deducaoDependentes);

  let valorIrrf = 0;
  let faixaAliquota = 'Isento';

  if (baseCalculo <= 2259.2) {
    valorIrrf = 0;
    faixaAliquota = 'Isento (até R$ 2.259,20)';
  } else if (baseCalculo <= 2826.65) {
    valorIrrf = baseCalculo * 0.075 - 169.44;
    faixaAliquota = '7,5%';
  } else if (baseCalculo <= 3751.05) {
    valorIrrf = baseCalculo * 0.15 - 381.44;
    faixaAliquota = '15,0%';
  } else if (baseCalculo <= 4664.68) {
    valorIrrf = baseCalculo * 0.225 - 662.77;
    faixaAliquota = '22,5%';
  } else {
    valorIrrf = baseCalculo * 0.275 - 896.0;
    faixaAliquota = '27,5%';
  }

  valorIrrf = Math.max(0, Math.round(valorIrrf * 100) / 100);

  return {
    baseCalculo: Math.round(baseCalculo * 100) / 100,
    valorIrrf,
    faixaAliquota,
    deducaoDependentes,
  };
}

/**
 * Calcula todos os valores rescisórios de acordo com a CLT e Lei 12.506/2011
 */
export function calcularRescisaoCompleta(params: ParametrosCalculoRescisao): CalculoRescisaoResultado {
  const {
    funcionario,
    motivoRescisao,
    tipoAvisoPrevio,
    dataDesligamento,
    dataAvisoPrevio = dataDesligamento,
    saldoFgtsInformado,
    diasSaldoSalarioManual,
    horasExtrasValor = 0,
    outrosAdicionaisValor = 0,
    faltasDsrValor = 0,
    outrosDescontosValor = 0,
    diasFeriasVencidasManual,
  } = params;

  const dataAdmissao = funcionario.dataAdmissao || '2023-01-01';
  const dAdmissao = new Date(dataAdmissao);
  const dDesligamento = new Date(dataDesligamento);

  const anosCompletos = calcularAnosCompletos(dataAdmissao, dataDesligamento);
  const mesesTotais = calcularMesesTrabalhados(dataAdmissao, dataDesligamento);
  const diasAvisoLei12506 = calcularDiasAvisoLei12506(anosCompletos);

  // Data de Projeção do Aviso Prévio (Art. 487 § 1º CLT)
  const dProjecao = new Date(dDesligamento);
  if (tipoAvisoPrevio === 'indenizado') {
    dProjecao.setDate(dProjecao.getDate() + diasAvisoLei12506);
  }
  const dataProjecaoAviso = dProjecao.toISOString().split('T')[0];

  // Data limite de pagamento (Art. 477 § 6º CLT: até 10 dias corridos do término)
  const dLimitePagto = new Date(dDesligamento);
  dLimitePagto.setDate(dLimitePagto.getDate() + 10);
  const dataLimitePagamento = dLimitePagto.toISOString().split('T')[0];

  // Remuneração base para rescisão
  const salarioBase = Number(funcionario.salarioBase) || 0;
  const adicionaisContratuais = Number(funcionario.adicionaisTotal) || 0;
  const remuneracaoBaseCalculo =
    salarioBase + adicionaisContratuais + horasExtrasValor + outrosAdicionaisValor;

  const valorDiaria = remuneracaoBaseCalculo / 30;

  // 1. Saldo de Salário
  // Dias trabalhados no mês do desligamento
  let diasSaldo = diasSaldoSalarioManual !== undefined ? diasSaldoSalarioManual : dDesligamento.getDate();
  if (diasSaldo > 30) diasSaldo = 30;
  if (diasSaldo < 0) diasSaldo = 0;

  let saldoSalario = Math.round(valorDiaria * diasSaldo * 100) / 100;

  // 2. Aviso Prévio Indenizado
  let avisoPrevioIndenizado = 0;
  let avisoPrevioDescontado = 0;

  if (tipoAvisoPrevio === 'indenizado') {
    if (motivoRescisao === 'sem_justa_causa' || motivoRescisao === 'rescisao_indireta') {
      // 100% dos dias de direito
      avisoPrevioIndenizado = Math.round(valorDiaria * diasAvisoLei12506 * 100) / 100;
    } else if (motivoRescisao === 'acordo_mutuo') {
      // Art. 484-A CLT: aviso prévio indenizado pago pela METADE (50%)
      avisoPrevioIndenizado = Math.round((valorDiaria * diasAvisoLei12506 * 0.5) * 100) / 100;
    }
  } else if (tipoAvisoPrevio === 'descontado') {
    if (motivoRescisao === 'pedido_demissao') {
      // Desconto de aviso prévio não cumprido pelo trabalhador (Art. 487 § 2º CLT - até 30 dias)
      avisoPrevioDescontado = Math.round(valorDiaria * 30 * 100) / 100;
    }
  }

  // 3. 13º Salário Proporcional
  // Contagem de avos no ano corrente (a partir de 1º de janeiro do ano de desligamento)
  const anoDesligamento = dDesligamento.getFullYear();
  let mesInicio13 = 0; // Janeiro
  if (dAdmissao.getFullYear() === anoDesligamento) {
    mesInicio13 = dAdmissao.getMonth();
    if (dAdmissao.getDate() > 15) {
      mesInicio13++;
    }
  }
  let mesFim13 = dDesligamento.getMonth();
  if (dDesligamento.getDate() >= 15) {
    mesFim13++;
  }
  let avos13Salario = Math.max(0, mesFim13 - mesInicio13);
  if (avos13Salario > 12) avos13Salario = 12;

  // Projeção do aviso prévio sobre 13º (se indenizado e fração >= 15 dias)
  let avos13Indenizado = 0;
  if (tipoAvisoPrevio === 'indenizado' && (motivoRescisao === 'sem_justa_causa' || motivoRescisao === 'acordo_mutuo' || motivoRescisao === 'rescisao_indireta')) {
    if (dProjecao.getMonth() !== dDesligamento.getMonth() || dProjecao.getDate() >= 15) {
      avos13Indenizado = 1;
    }
  }

  // Justa causa NÃO tem 13º proporcional
  if (motivoRescisao === 'justa_causa') {
    avos13Salario = 0;
    avos13Indenizado = 0;
  }

  const decimoTerceiroProporcional = Math.round((remuneracaoBaseCalculo / 12) * avos13Salario * 100) / 100;
  const decimoTerceiroAvisoIndenizado = Math.round((remuneracaoBaseCalculo / 12) * avos13Indenizado * 100) / 100;

  // 4. Férias Vencidas + 1/3 (Súmula 171 TST garante inclusive em justa causa se completou período aquisitivo)
  const diasFeriasVencidas = diasFeriasVencidasManual !== undefined
    ? diasFeriasVencidasManual
    : (funcionario.diasFeriasSaldo || 0);

  const feriasVencidas = Math.round(valorDiaria * diasFeriasVencidas * 100) / 100;
  const tercoFeriasVencidas = Math.round((feriasVencidas / 3) * 100) / 100;

  // 5. Férias Proporcionais + 1/3
  // Contagem de avos a partir do aniversário contratual mais recente
  let avosFeriasProporcionais = 0;
  let avosFeriasIndenizadas = 0;

  if (motivoRescisao !== 'justa_causa') {
    // Meses decorridos desde o último aniversário de admissão
    const mesesDesdeAdmissao = (dDesligamento.getFullYear() - dAdmissao.getFullYear()) * 12 + (dDesligamento.getMonth() - dAdmissao.getMonth());
    let avosCalculados = mesesDesdeAdmissao % 12;
    if (dDesligamento.getDate() >= dAdmissao.getDate() || dDesligamento.getDate() >= 15) {
      avosCalculados++;
    }
    if (avosCalculados === 0 && mesesTotais > 0) avosCalculados = 1;
    if (avosCalculados > 12) avosCalculados = 12;
    avosFeriasProporcionais = avosCalculados;

    if (tipoAvisoPrevio === 'indenizado' && (motivoRescisao === 'sem_justa_causa' || motivoRescisao === 'acordo_mutuo' || motivoRescisao === 'rescisao_indireta')) {
      avosFeriasIndenizadas = 1;
    }
  }

  const feriasProporcionais = Math.round((remuneracaoBaseCalculo / 12) * avosFeriasProporcionais * 100) / 100;
  const tercoFeriasProporcionais = Math.round((feriasProporcionais / 3) * 100) / 100;

  const feriasAvisoIndenizado = Math.round((remuneracaoBaseCalculo / 12) * avosFeriasIndenizadas * 100) / 100;
  const tercoFeriasAvisoIndenizado = Math.round((feriasAvisoIndenizado / 3) * 100) / 100;

  // 6. Indenização Art. 479 CLT (Rescisão antecipada de experiência pelo empregador)
  let indenizacaoArt479 = 0;
  if (motivoRescisao === 'rescisao_antecipada_empregador') {
    // 50% dos dias restantes até o término da experiência (estimado em 30 dias restantes)
    indenizacaoArt479 = Math.round(valorDiaria * 15 * 100) / 100;
  }

  // Total Proventos Brutos
  const totalBruto = Math.round(
    (saldoSalario +
      avisoPrevioIndenizado +
      decimoTerceiroProporcional +
      decimoTerceiroAvisoIndenizado +
      feriasVencidas +
      tercoFeriasVencidas +
      feriasProporcionais +
      tercoFeriasProporcionais +
      feriasAvisoIndenizado +
      tercoFeriasAvisoIndenizado +
      indenizacaoArt479) *
      100
  ) / 100;

  // 7. DESCONTOS:
  // INSS sobre Saldo de Salário
  const baseInssSaldo = Math.max(0, saldoSalario - faltasDsrValor);
  const inssSaldoResult = calcularInssProgressivo(baseInssSaldo);
  const inssSaldoSalario = inssSaldoResult.valorTotal;

  // INSS sobre 13º Salário Rescisório (Tributação exclusiva)
  const baseInss13 = decimoTerceiroProporcional + decimoTerceiroAvisoIndenizado;
  const inss13Result = calcularInssProgressivo(baseInss13);
  const inssDecimoTerceiro = inss13Result.valorTotal;

  // IRRF sobre Saldo de Salário
  const dependentesCount = (funcionario.dependentes || []).filter((d) => d.deducaoIrrf).length;
  const irrfSaldoResult = calcularIrrf(baseInssSaldo, inssSaldoSalario, dependentesCount);
  const irrfSaldoSalario = irrfSaldoResult.valorIrrf;

  // IRRF sobre 13º Salário (Tributação exclusiva)
  const irrf13Result = calcularIrrf(baseInss13, inssDecimoTerceiro, dependentesCount);
  const irrfDecimoTerceiro = irrf13Result.valorIrrf;

  const totalDescontos = Math.round(
    (inssSaldoSalario +
      inssDecimoTerceiro +
      irrfSaldoSalario +
      irrfDecimoTerceiro +
      avisoPrevioDescontado +
      faltasDsrValor +
      outrosDescontosValor) *
      100
  ) / 100;

  const totalLiquidoRescisao = Math.max(0, Math.round((totalBruto - totalDescontos) * 100) / 100);

  // 8. FGTS & MULTA RESCISÓRIA
  // Saldo FGTS estimado (8% de cada mês trabalhado mais rendimentos) se não informado
  const saldoFgtsBase = saldoFgtsInformado !== undefined
    ? saldoFgtsInformado
    : Math.round(salarioBase * 0.08 * mesesTotais * 1.05 * 100) / 100;

  // FGTS do mês da rescisão (8% s/ saldo de salário)
  const depositoMesRescisao = Math.round(baseInssSaldo * 0.08 * 100) / 100;

  // FGTS sobre 13º rescisório (8%)
  const deposito13Rescisorio = Math.round(baseInss13 * 0.08 * 100) / 100;

  // FGTS sobre aviso prévio indenizado (8% - Súmula 305 TST)
  const depositoAvisoIndenizado = Math.round(avisoPrevioIndenizado * 0.08 * 100) / 100;

  // Base total para fins rescisórios do FGTS
  const baseCalculoMultaFgts = Math.round(
    (saldoFgtsBase + depositoMesRescisao + deposito13Rescisorio + depositoAvisoIndenizado) * 100
  ) / 100;

  // Alíquota da multa rescisória e código de saque
  let aliquotaMultaFgts = 0;
  let codigoSaqueFgts = 'NÃO_PERMITIDO';
  let direitoSeguroDesemprego = false;

  if (motivoRescisao === 'sem_justa_causa' || motivoRescisao === 'rescisao_indireta') {
    aliquotaMultaFgts = 40;
    codigoSaqueFgts = '01 (Despedida Sem Justa Causa)';
    direitoSeguroDesemprego = true;
  } else if (motivoRescisao === 'acordo_mutuo') {
    aliquotaMultaFgts = 20;
    codigoSaqueFgts = '02 (Acordo Mútuo - Saque 80%)';
    direitoSeguroDesemprego = false;
  } else if (motivoRescisao === 'termino_experiencia') {
    aliquotaMultaFgts = 0;
    codigoSaqueFgts = '04 (Término Contrato Determinado)';
    direitoSeguroDesemprego = false;
  } else if (motivoRescisao === 'rescisao_antecipada_empregador') {
    aliquotaMultaFgts = 40;
    codigoSaqueFgts = '01 (Rescisão Antecipada Art. 479)';
    direitoSeguroDesemprego = true;
  } else if (motivoRescisao === 'pedido_demissao') {
    aliquotaMultaFgts = 0;
    codigoSaqueFgts = 'NÃO PERMITIDO (Pedido de Demissão)';
    direitoSeguroDesemprego = false;
  } else if (motivoRescisao === 'justa_causa') {
    aliquotaMultaFgts = 0;
    codigoSaqueFgts = 'NÃO PERMITIDO (Demissão c/ Justa Causa)';
    direitoSeguroDesemprego = false;
  }

  const valorMultaRescisoriaFgts = Math.round(baseCalculoMultaFgts * (aliquotaMultaFgts / 100) * 100) / 100;
  const totalRecolhimentoFgtsDigital = Math.round(
    (depositoMesRescisao + deposito13Rescisorio + depositoAvisoIndenizado + valorMultaRescisoriaFgts) * 100
  ) / 100;

  // Chave conectividade social fictícia/demo para o TRCT
  const chaveConectividadeSocial = `${funcionario.cpf.replace(/\D/g, '').slice(0, 8)}.${new Date().getFullYear()}.${Math.floor(100000 + Math.random() * 900000)}`;

  // 9. RUBRICAS OFICIAIS DO TRCT (Portaria MTE 1.057/2012)
  const rubricas: RubricaRescisao[] = [];

  if (saldoSalario > 0) {
    rubricas.push({
      codigo: '50',
      descricao: 'Saldo de Salário',
      referencia: `${diasSaldo} dia(s)`,
      tipo: 'provento',
      valor: saldoSalario,
      incideInss: true,
      incideIrrf: true,
      incideFgts: true,
    });
  }

  if (avisoPrevioIndenizado > 0) {
    rubricas.push({
      codigo: '69',
      descricao: 'Aviso Prévio Indenizado (Lei 12.506/2011)',
      referencia: `${diasAvisoLei12506} dia(s)${motivoRescisao === 'acordo_mutuo' ? ' (50%)' : ''}`,
      tipo: 'provento',
      valor: avisoPrevioIndenizado,
      incideInss: false,
      incideIrrf: false,
      incideFgts: true,
    });
  }

  if (decimoTerceiroProporcional > 0) {
    rubricas.push({
      codigo: '63',
      descricao: '13º Salário Proporcional',
      referencia: `${avos13Salario}/12 avos`,
      tipo: 'provento',
      valor: decimoTerceiroProporcional,
      incideInss: true,
      incideIrrf: true,
      incideFgts: true,
    });
  }

  if (decimoTerceiroAvisoIndenizado > 0) {
    rubricas.push({
      codigo: '70',
      descricao: '13º Salário s/ Aviso Prévio Indenizado',
      referencia: `${avos13Indenizado}/12 avo`,
      tipo: 'provento',
      valor: decimoTerceiroAvisoIndenizado,
      incideInss: true,
      incideIrrf: true,
      incideFgts: true,
    });
  }

  if (feriasVencidas > 0) {
    rubricas.push({
      codigo: '66',
      descricao: 'Férias Vencidas (Período Adquirido Integral)',
      referencia: `${diasFeriasVencidas} dia(s)`,
      tipo: 'provento',
      valor: feriasVencidas,
      incideInss: false,
      incideIrrf: false,
      incideFgts: false,
    });
    rubricas.push({
      codigo: '68',
      descricao: 'Terço Constitucional de Férias Vencidas (1/3)',
      referencia: '33,33%',
      tipo: 'provento',
      valor: tercoFeriasVencidas,
      incideInss: false,
      incideIrrf: false,
      incideFgts: false,
    });
  }

  if (feriasProporcionais > 0) {
    rubricas.push({
      codigo: '65',
      descricao: 'Férias Proporcionais',
      referencia: `${avosFeriasProporcionais}/12 avos`,
      tipo: 'provento',
      valor: feriasProporcionais,
      incideInss: false,
      incideIrrf: false,
      incideFgts: false,
    });
    rubricas.push({
      codigo: '68.1',
      descricao: 'Terço Constitucional de Férias Proporcionais (1/3)',
      referencia: '33,33%',
      tipo: 'provento',
      valor: tercoFeriasProporcionais,
      incideInss: false,
      incideIrrf: false,
      incideFgts: false,
    });
  }

  if (feriasAvisoIndenizado > 0) {
    rubricas.push({
      codigo: '71',
      descricao: 'Férias s/ Aviso Prévio Indenizado (Projeção)',
      referencia: `${avosFeriasIndenizadas}/12 avo`,
      tipo: 'provento',
      valor: feriasAvisoIndenizado,
      incideInss: false,
      incideIrrf: false,
      incideFgts: false,
    });
    rubricas.push({
      codigo: '71.1',
      descricao: 'Terço Constitucional s/ Férias do Aviso Indenizado',
      referencia: '33,33%',
      tipo: 'provento',
      valor: tercoFeriasAvisoIndenizado,
      incideInss: false,
      incideIrrf: false,
      incideFgts: false,
    });
  }

  if (indenizacaoArt479 > 0) {
    rubricas.push({
      codigo: '80',
      descricao: 'Indenização Rescisão Antecipada (Art. 479 CLT)',
      referencia: '50% dias faltantes',
      tipo: 'provento',
      valor: indenizacaoArt479,
      incideInss: false,
      incideIrrf: false,
      incideFgts: true,
    });
  }

  // DESCONTOS
  if (inssSaldoSalario > 0) {
    rubricas.push({
      codigo: '100',
      descricao: 'Previdência Social (INSS Saldo de Salário)',
      referencia: inssSaldoResult.faixas[0]?.faixa || 'Progressivo',
      tipo: 'desconto',
      valor: inssSaldoSalario,
    });
  }

  if (inssDecimoTerceiro > 0) {
    rubricas.push({
      codigo: '101',
      descricao: 'Previdência Social (INSS 13º Salário Rescisório)',
      referencia: inss13Result.faixas[0]?.faixa || 'Progressivo',
      tipo: 'desconto',
      valor: inssDecimoTerceiro,
    });
  }

  if (irrfSaldoSalario > 0) {
    rubricas.push({
      codigo: '102',
      descricao: 'IRRF sobre Saldo de Salário',
      referencia: irrfSaldoResult.faixaAliquota,
      tipo: 'desconto',
      valor: irrfSaldoSalario,
    });
  }

  if (irrfDecimoTerceiro > 0) {
    rubricas.push({
      codigo: '103',
      descricao: 'IRRF sobre 13º Salário Rescisório',
      referencia: irrf13Result.faixaAliquota,
      tipo: 'desconto',
      valor: irrfDecimoTerceiro,
    });
  }

  if (avisoPrevioDescontado > 0) {
    rubricas.push({
      codigo: '106',
      descricao: 'Desconto de Aviso Prévio Não Cumprido (Art. 487 § 2º CLT)',
      referencia: '30 dias',
      tipo: 'desconto',
      valor: avisoPrevioDescontado,
    });
  }

  if (faltasDsrValor > 0) {
    rubricas.push({
      codigo: '107',
      descricao: 'Faltas Injustificadas e DSR',
      referencia: 'Desconto',
      tipo: 'desconto',
      valor: faltasDsrValor,
    });
  }

  if (outrosDescontosValor > 0) {
    rubricas.push({
      codigo: '115',
      descricao: 'Outros Descontos / Adiantamentos Salariais',
      referencia: 'Ajuste',
      tipo: 'desconto',
      valor: outrosDescontosValor,
    });
  }

  return {
    funcionarioId: funcionario.id,
    empresaId: funcionario.empresaId,
    motivoRescisao,
    tipoAvisoPrevio,
    dataAdmissao,
    dataAvisoPrevio,
    dataDesligamento,
    dataProjecaoAviso,
    dataLimitePagamento,
    anosCompletosTrabalho: anosCompletos,
    mesesTrabalhadosTotal: mesesTotais,
    diasAvisoLei12506,
    diasSaldoSalario: diasSaldo,
    avos13Salario,
    avos13Indenizado,
    avosFeriasProporcionais,
    avosFeriasIndenizadas,
    diasFeriasVencidas,
    salarioBase,
    remuneracaoBaseCalculo,
    proventos: {
      saldoSalario,
      avisoPrevioIndenizado,
      decimoTerceiroProporcional,
      decimoTerceiroAvisoIndenizado,
      feriasVencidas,
      tercoFeriasVencidas,
      feriasProporcionais,
      tercoFeriasProporcionais,
      feriasAvisoIndenizado,
      tercoFeriasAvisoIndenizado,
      adicionalPericulosidadeInsalubridade: adicionaisContratuais + outrosAdicionaisValor,
      horasExtrasRescisorias: horasExtrasValor,
      indenizacaoArt479,
      totalBruto,
    },
    descontos: {
      inssSaldoSalario,
      inssDecimoTerceiro,
      irrfSaldoSalario,
      irrfDecimoTerceiro,
      avisoPrevioDescontado,
      faltasDsr: faltasDsrValor,
      adiantamentosOutros: outrosDescontosValor,
      totalDescontos,
    },
    totalLiquidoRescisao,
    fgts: {
      saldoParaFinsRescisorios: saldoFgtsBase,
      depositoMesRescisao,
      deposito13Rescisorio,
      depositoAvisoIndenizado,
      baseCalculoMultaFgts,
      aliquotaMultaFgts,
      valorMultaRescisoriaFgts,
      totalRecolhimentoFgtsDigital,
      codigoSaqueFgts,
      direitoSeguroDesemprego,
      chaveConectividadeSocial,
    },
    rubricas,
    memoriaCalculo: {
      inssFaixasSaldo: inssSaldoResult.faixas,
      inssFaixas13: inss13Result.faixas,
      deducaoDependentesIrrf: dependentesCount * 189.59,
      dependentesQtd: dependentesCount,
      diasProjetadosAviso: tipoAvisoPrevio === 'indenizado' ? diasAvisoLei12506 : 0,
      avisoExplicacao:
        tipoAvisoPrevio === 'indenizado'
          ? `Lei 12.506/2011: 30 dias + (${anosCompletos} ano(s) × 3 dias) = ${diasAvisoLei12506} dias de aviso prévio.`
          : 'Aviso prévio cumprido ou não aplicável para acréscimo indenizatório.',
    },
  };
}

/**
 * Gera os dados formatados do documento oficial TRCT (Portaria MTE 1.057/2012)
 */
export function gerarDocumentoTRCTOficial(
  calculo: CalculoRescisaoResultado,
  funcionario: Funcionario,
  empresa: Empresa
): DocumentoTRCT {
  const motivosNomes: Record<TipoMotivoRescisao, { desc: string; cod: string }> = {
    sem_justa_causa: {
      desc: 'Despedida sem justa causa, pelo empregador',
      cod: 'SJ2 - Rescisão sem Justa Causa',
    },
    pedido_demissao: {
      desc: 'Rescisão a pedido do empregado',
      cod: 'RA1 - Pedido de Demissão',
    },
    justa_causa: {
      desc: 'Despedida por justa causa, pelo empregador (Art. 482 CLT)',
      cod: 'JC1 - Rescisão com Justa Causa',
    },
    acordo_mutuo: {
      desc: 'Extinção do contrato de trabalho por acordo mútuo (Art. 484-A da CLT)',
      cod: 'AM1 - Acordo Empregado/Empregador',
    },
    termino_experiencia: {
      desc: 'Extinção normal do contrato de trabalho por prazo determinado',
      cod: 'PD1 - Término de Contrato',
    },
    rescisao_antecipada_empregador: {
      desc: 'Rescisão antecipada do contrato a termo pelo empregador (Art. 479 CLT)',
      cod: 'RA2 - Rescisão Antecipada Empregador',
    },
    rescisao_indireta: {
      desc: 'Rescisão indireta do contrato de trabalho (Art. 483 CLT)',
      cod: 'RI1 - Rescisão Indireta',
    },
  };

  const tipoAvisoNomes: Record<TipoAvisoPrevioRescisao, string> = {
    indenizado: 'Indenizado pelo Empregador',
    trabalhado: 'Trabalhado pelo Empregado',
    descontado: 'Descontado do Empregado (Não cumprido)',
    dispensado: 'Dispensado pelo Empregador',
    nao_aplicavel: 'Não Aplicável',
  };

  const numeroTermo = `TRCT-${empresa.cnpj.replace(/\D/g, '').slice(0, 8)}-${funcionario.matricula || funcionario.cpf.replace(/\D/g, '').slice(0, 6)}-${new Date().getFullYear()}`;

  return {
    numeroTermo,
    empresa: {
      razaoSocial: empresa.razaoSocial,
      cnpj: empresa.cnpj,
      endereco: `${empresa.cidade} - ${empresa.uf}`,
      cidadeUf: `${empresa.cidade}/${empresa.uf}`,
      cnae: '6201-5/01',
    },
    funcionario: {
      nome: funcionario.nomeCompleto,
      cpf: funcionario.cpf,
      pisPasep: funcionario.pisPasep || '123.45678.90-1',
      ctps: `${funcionario.ctpsNumero || '00000'} / ${funcionario.ctpsSerie || '001'} - ${funcionario.ctpsUf || empresa.uf}`,
      cargo: funcionario.cargoNome,
      cbo: funcionario.cbo || '2124-05',
      dataAdmissao: calculo.dataAdmissao,
      dataAviso: calculo.dataAvisoPrevio,
      dataAfastamento: calculo.dataDesligamento,
      dataNascimento: funcionario.dataNascimento,
      nomeMae: funcionario.nomeMae,
      endereco: `${funcionario.logradouro || ''}, ${funcionario.numero || ''} - ${funcionario.bairro || ''}, ${funcionario.cidade || empresa.cidade}/${funcionario.uf || empresa.uf}`,
      remuneracaoMesAnterior: funcionario.salarioBase,
    },
    dadosRescisao: {
      tipoContrato: funcionario.tipoContrato || 'CLT Indeterminado',
      motivoDescricao: motivosNomes[calculo.motivoRescisao]?.desc || 'Rescisão Contratual',
      codigoAfastamento: motivosNomes[calculo.motivoRescisao]?.cod || 'SJ2',
      tipoAvisoDescricao: tipoAvisoNomes[calculo.tipoAvisoPrevio] || 'Indenizado',
      dataLimitePagamento: calculo.dataLimitePagamento,
      pensaoAlimenticia: '0,00%',
      sindicatoNome: 'Sindicato dos Empregados no Comércio / Tecnologia e Serviços',
      codigoSindical: '000.123.456.78901-2',
    },
    rubricas: calculo.rubricas,
    totais: {
      totalBruto: calculo.proventos.totalBruto,
      totalDescontos: calculo.descontos.totalDescontos,
      totalLiquido: calculo.totalLiquidoRescisao,
    },
    dadosFgts: {
      saldoBaseFgts: calculo.fgts.saldoParaFinsRescisorios,
      multaRescisoria: calculo.fgts.valorMultaRescisoriaFgts,
      aliquotaMulta: calculo.fgts.aliquotaMultaFgts,
      codigoSaque: calculo.fgts.codigoSaqueFgts,
      direitoSeguroDesemprego: calculo.fgts.direitoSeguroDesemprego,
      chaveConectividade: calculo.fgts.chaveConectividadeSocial,
    },
    declaracaoQuitacao:
      'O empregado e o empregador dão por quitadas as parcelas discriminadas neste instrumento, na forma e para os efeitos do Artigo 477 da CLT.',
    dataEmissao: new Date().toLocaleDateString('pt-BR'),
  };
}
