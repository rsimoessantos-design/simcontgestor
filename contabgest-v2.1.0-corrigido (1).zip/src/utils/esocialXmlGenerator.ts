import {
  ESocialConfiguracao,
  EventoESocialRegistro,
  FechamentoFolhaESocialPainel,
  Funcionario,
  HoleriteCalculado,
  InconsistenciaValidacaoESocial,
} from '../types';

/**
 * Validação de regras e consistências dos eventos do eSocial (versão S-1.2/S-1.3)
 */
export function validarDadosColaboradorESocial(
  func: Funcionario,
  config: ESocialConfiguracao
): InconsistenciaValidacaoESocial[] {
  const erros: InconsistenciaValidacaoESocial[] = [];

  // Validação CPF
  const cleanCpf = (func.cpf || '').replace(/\D/g, '');
  if (!cleanCpf || cleanCpf.length !== 11) {
    erros.push({
      codigoRegra: 'REGRA_VALIDA_CPF',
      campo: 'cpf',
      descricao: 'CPF do colaborador inválido ou não informado.',
      tipo: 'erro',
      sugestaoCorrecao: 'Informe um CPF válido com 11 dígitos numéricos.',
    });
  }

  // Validação PIS/PASEP / NIS
  const cleanPis = (func.pisPasep || '').replace(/\D/g, '');
  if (!cleanPis && !func.matricula) {
    erros.push({
      codigoRegra: 'REGRA_NIS_MATRICULA',
      campo: 'pisPasep',
      descricao: 'PIS/PASEP ou Matrícula eSocial não cadastrada.',
      tipo: 'aviso',
      sugestaoCorrecao: 'Cadastre o PIS/PASEP do empregado para evitar pendências no FGTS Digital.',
    });
  }

  // Validação CBO
  if (!func.cbo || func.cbo.trim().length < 4) {
    erros.push({
      codigoRegra: 'REGRA_TAB_CBO',
      campo: 'cbo',
      descricao: 'Código Brasileiro de Ocupações (CBO) ausente ou inválido.',
      tipo: 'erro',
      sugestaoCorrecao: 'Vincule um CBO oficial de 6 dígitos no cadastro da função.',
    });
  }

  // Validação Data de Admissão
  if (!func.dataAdmissao) {
    erros.push({
      codigoRegra: 'REGRA_ADMISSAO_VALIDA',
      campo: 'dataAdmissao',
      descricao: 'Data de admissão não informada no cadastro.',
      tipo: 'erro',
      sugestaoCorrecao: 'Defina a data de admissão oficial do empregado.',
    });
  }

  // Validação Salário Base
  if (!func.salarioBase || func.salarioBase <= 0) {
    erros.push({
      codigoRegra: 'REGRA_REMUNERACAO_MINIMA',
      campo: 'salarioBase',
      descricao: 'Salário base contratual menor ou igual a zero.',
      tipo: 'erro',
      sugestaoCorrecao: 'O valor salarial deve respeitar o piso nacional ou da categoria.',
    });
  }

  // Validação Regime Tributário vs Classificação eSocial
  if (config.classificacaoTributaria === '01' || config.classificacaoTributaria === '02') {
    // Simples Nacional sem desoneração
  } else if (!config.aliquotaRat || config.aliquotaRat <= 0) {
    erros.push({
      codigoRegra: 'REGRA_RAT_FAP',
      campo: 'aliquotaRat',
      descricao: 'Alíquota RAT (Risco Ambiental do Trabalho) não configurada na empresa.',
      tipo: 'aviso',
      sugestaoCorrecao: 'Configure a alíquota RAT (1%, 2% ou 3%) nos parâmetros do eSocial.',
    });
  }

  return erros;
}

/**
 * Validação de Parâmetros e Fechamento da Folha (S-1299)
 */
export function validarParametrosFechamentoFolha(
  config: ESocialConfiguracao,
  competencia: string,
  eventosPeriodicos: EventoESocialRegistro[]
): InconsistenciaValidacaoESocial[] {
  const erros: InconsistenciaValidacaoESocial[] = [];

  // Verifica certificado digital
  if (!config.certificadoValidade) {
    erros.push({
      codigoRegra: 'REGRA_CERTIFICADO_DIGITAL',
      campo: 'certificadoDigitalId',
      descricao: 'Nenhum Certificado Digital e-CNPJ (A1/A3) associado para transmissão segura.',
      tipo: 'erro',
      sugestaoCorrecao: 'Vincule um Certificado Digital ICP-Brasil válido na aba de Parâmetros.',
    });
  } else {
    const validadeCert = new Date(config.certificadoValidade);
    if (validadeCert < new Date()) {
      erros.push({
        codigoRegra: 'REGRA_CERTIFICADO_EXPIRADO',
        campo: 'certificadoValidade',
        descricao: `Certificado digital expirou em ${validadeCert.toLocaleDateString('pt-BR')}.`,
        tipo: 'erro',
        sugestaoCorrecao: 'Renove o certificado e-CNPJ antes de efetuar o fechamento S-1299.',
      });
    }
  }

  // Validação de Classificação Tributária
  if (!config.classificacaoTributaria) {
    erros.push({
      codigoRegra: 'REGRA_TAB_CLASSTRIB',
      campo: 'classificacaoTributaria',
      descricao: 'Classificação tributária da empresa não configurada.',
      tipo: 'erro',
      sugestaoCorrecao: 'Defina a classificação conforme Tabela 08 do eSocial.',
    });
  }

  // Verifica eventos periódicos com rejeição
  const eventosComErro = eventosPeriodicos.filter((ev) => ev.status === 'rejeitado_erro');
  if (eventosComErro.length > 0) {
    erros.push({
      codigoRegra: 'REGRA_EVENTOS_COM_ERRO',
      campo: 'eventosPeriodicos',
      descricao: `Existem ${eventosComErro.length} evento(s) periódico(s) (S-1200 / S-1210) com erro de validação.`,
      tipo: 'erro',
      sugestaoCorrecao: 'Corrija os dados inconsistentes antes de assinar e enviar o fechamento S-1299.',
    });
  }

  return erros;
}

/**
 * Gerador de XML Oficial estruturado no padrão do eSocial S-1.2/S-1.3
 */
export function gerarXmlEventoESocial(
  tipo: string,
  dados: {
    config: ESocialConfiguracao;
    competencia?: string;
    funcionario?: Funcionario;
    holerite?: HoleriteCalculado;
    painel?: FechamentoFolhaESocialPainel;
  }
): string {
  const { config, competencia = '2026-09', funcionario, holerite, painel } = dados;
  const compFormatada = competencia.includes('/')
    ? `${competencia.split('/')[1]}-${competencia.split('/')[0]}`
    : competencia;
  const dataHoraIso = new Date().toISOString();
  const idEvento = `ID1${config.numeroInscricao.replace(/\D/g, '')}${dataHoraIso.replace(/[-:TZ.]/g, '').slice(0, 14)}00001`;

  if (tipo === 'S-1200') {
    // S-1200: Remuneração de Trabalhador vinculado ao Regime Geral de Previdência Social
    return `<?xml version="1.0" encoding="UTF-8"?>
<eSocial xmlns="http://www.esocial.gov.br/schema/evt/evtRemun/v_S_01_02_00">
  <evtRemun id="${idEvento}">
    <ideEvento>
      <indRetif>1</indRetif>
      <perApur>${compFormatada}</perApur>
      <tpAmb>${config.ambiente === 'producao' ? '1' : '2'}</tpAmb>
      <procEmi>1</procEmi>
      <verProc>${config.versaoManual}</verProc>
    </ideEvento>
    <ideEmpregador>
      <tpInsc>1</tpInsc>
      <nrInsc>${config.numeroInscricao.replace(/\D/g, '').slice(0, 8)}</nrInsc>
    </ideEmpregador>
    <ideTrabalhador>
      <cpfTrab>${(funcionario?.cpf || '00000000000').replace(/\D/g, '')}</cpfTrab>
      <infoComplem>
        <nmTrab>${funcionario?.nomeCompleto || 'Colaborador'}</nmTrab>
        <dtNascto>${funcionario?.dataNascimento || '1990-01-01'}</dtNascto>
      </infoComplem>
    </ideTrabalhador>
    <dmDev>
      <ideDmDev>DMDEV_${funcionario?.matricula || '001'}_${compFormatada.replace('-', '')}</ideDmDev>
      <codCateg>101</codCateg>
      <infoPerApur>
        <ideEstabLot>
          <tpInsc>1</tpInsc>
          <nrInsc>${config.numeroInscricao.replace(/\D/g, '')}</nrInsc>
          <codLotacao>LOT_PRINCIPAL_001</codLotacao>
          <remunPerApur>
            <matricula>${funcionario?.matricula || 'MAT001'}</matricula>
            <itensRemun>
              <codRubr>1000</codRubr>
              <ideTabRubr>TABRUB_01</ideTabRubr>
              <qtdRubr>30</qtdRubr>
              <vrRubr>${(holerite?.salarioBase || funcionario?.salarioBase || 0).toFixed(2)}</vrRubr>
              <indApurIR>0</indApurIR>
            </itensRemun>
            ${
              (holerite?.valorInss || 0) > 0
                ? `<itensRemun>
              <codRubr>9001</codRubr>
              <ideTabRubr>TABRUB_01</ideTabRubr>
              <vrRubr>${(holerite?.valorInss || 0).toFixed(2)}</vrRubr>
              <indApurIR>0</indApurIR>
            </itensRemun>`
                : ''
            }
            ${
              (holerite?.valorIrrf || 0) > 0
                ? `<itensRemun>
              <codRubr>9002</codRubr>
              <ideTabRubr>TABRUB_01</ideTabRubr>
              <vrRubr>${(holerite?.valorIrrf || 0).toFixed(2)}</vrRubr>
              <indApurIR>0</indApurIR>
            </itensRemun>`
                : ''
            }
          </remunPerApur>
        </ideEstabLot>
      </infoPerApur>
    </dmDev>
  </evtRemun>
</eSocial>`;
  }

  if (tipo === 'S-1210') {
    // S-1210: Pagamentos de Rendimentos do Trabalho
    return `<?xml version="1.0" encoding="UTF-8"?>
<eSocial xmlns="http://www.esocial.gov.br/schema/evt/evtPgtos/v_S_01_02_00">
  <evtPgtos id="${idEvento}">
    <ideEvento>
      <indRetif>1</indRetif>
      <perApur>${compFormatada}</perApur>
      <tpAmb>${config.ambiente === 'producao' ? '1' : '2'}</tpAmb>
      <procEmi>1</procEmi>
      <verProc>${config.versaoManual}</verProc>
    </ideEvento>
    <ideEmpregador>
      <tpInsc>1</tpInsc>
      <nrInsc>${config.numeroInscricao.replace(/\D/g, '').slice(0, 8)}</nrInsc>
    </ideEmpregador>
    <ideBenef>
      <cpfBenef>${(funcionario?.cpf || '00000000000').replace(/\D/g, '')}</cpfBenef>
      <infoPgto>
        <dtPgto>${compFormatada}-05</dtPgto>
        <tpPgto>1</tpPgto>
        <perRef>${compFormatada}</perRef>
        <ideDmDev>DMDEV_${funcionario?.matricula || '001'}_${compFormatada.replace('-', '')}</ideDmDev>
        <vrLiq>${(holerite?.salarioLiquido || holerite?.valorLiquido || 0).toFixed(2)}</vrLiq>
      </infoPgto>
    </ideBenef>
  </evtPgtos>
</eSocial>`;
  }

  if (tipo === 'S-1299') {
    // S-1299: Fechamento dos Eventos Periódicos
    return `<?xml version="1.0" encoding="UTF-8"?>
<eSocial xmlns="http://www.esocial.gov.br/schema/evt/evtFechaEvPer/v_S_01_02_00">
  <evtFechaEvPer id="${idEvento}">
    <ideEvento>
      <indApuracao>1</indApuracao>
      <perApur>${compFormatada}</perApur>
      <tpAmb>${config.ambiente === 'producao' ? '1' : '2'}</tpAmb>
      <procEmi>1</procEmi>
      <verProc>${config.versaoManual}</verProc>
    </ideEvento>
    <ideEmpregador>
      <tpInsc>1</tpInsc>
      <nrInsc>${config.numeroInscricao.replace(/\D/g, '').slice(0, 8)}</nrInsc>
    </ideEmpregador>
    <infoFech>
      <evtRemun>S</evtRemun>
      <evtPgtos>S</evtPgtos>
      <evtAqProd>N</evtAqProd>
      <evtComProd>N</evtComProd>
      <evtContratAvNP>N</evtContratAvNP>
      <evtInfoComplPer>N</evtInfoComplPer>
      <indExcApur1250>N</indExcApur1250>
      <transmReq>${config.transmissaoAutomatica ? 'S' : 'N'}</transmReq>
    </infoFech>
  </evtFechaEvPer>
  <Signature xmlns="http://www.w3.org/2000/09/xmldsig#">
    <SignedInfo>
      <CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
      <SignatureMethod Algorithm="http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"/>
      <Reference URI="#${idEvento}">
        <DigestMethod Algorithm="http://www.w3.org/2001/04/xmlenc#sha256"/>
        <DigestValue>${Buffer.from(idEvento).toString('base64')}</DigestValue>
      </Reference>
    </SignedInfo>
    <SignatureValue>MEQCIG...ASSINATURA_DIGITAL_ICP_BRASIL_A1_HOMOLOGADA...</SignatureValue>
  </Signature>
</eSocial>`;
  }

  // S-1000 padrão
  return `<?xml version="1.0" encoding="UTF-8"?>
<eSocial xmlns="http://www.esocial.gov.br/schema/evt/evtInfoEmpregador/v_S_01_02_00">
  <evtInfoEmpregador id="${idEvento}">
    <ideEvento>
      <tpAmb>${config.ambiente === 'producao' ? '1' : '2'}</tpAmb>
      <procEmi>1</procEmi>
      <verProc>${config.versaoManual}</verProc>
    </ideEvento>
    <ideEmpregador>
      <tpInsc>1</tpInsc>
      <nrInsc>${config.numeroInscricao.replace(/\D/g, '').slice(0, 8)}</nrInsc>
    </ideEmpregador>
    <infoEmpregador>
      <inclusao>
        <idePeriodo>
          <iniValid>2023-01</iniValid>
        </idePeriodo>
        <infoCadastro>
          <classTrib>${config.classificacaoTributaria}</classTrib>
          <indCoop>${config.indicativoCooperativa}</indCoop>
          <indConstr>${config.indicativoConstrutora}</indConstr>
          <indDesFolha>${config.indicativoDesoneracaoFolha}</indDesFolha>
          <indOptRegEletron>1</indOptRegEletron>
          <contato>
            <nmCtt>${config.contatoResponsavelNome}</nmCtt>
            <cpfCtt>${config.contatoResponsavelCpf.replace(/\D/g, '')}</cpfCtt>
            <foneFixo>${config.contatoResponsavelTelefone.replace(/\D/g, '')}</foneFixo>
            <email>${config.contatoResponsavelEmail}</email>
          </contato>
        </infoCadastro>
      </inclusao>
    </infoEmpregador>
  </evtInfoEmpregador>
</eSocial>`;
}
