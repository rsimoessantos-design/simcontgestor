import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { NotaFiscal, NotaFiscalEntrada, Empresa } from '../types';

export interface GerarDanfePdfOptions {
  autoDownload?: boolean;
  printDirectly?: boolean;
  nomeArquivo?: string;
}

// Formata chave de acesso em 11 grupos de 4 dígitos para legibilidade padrão SEFAZ
export function formatChaveAcesso(chave: string): string {
  const limpa = (chave || '').replace(/\D/g, '').padEnd(44, '0').slice(0, 44);
  return limpa.replace(/(\d{4})(?=\d)/g, '$1 ');
}

// Formata moeda Real BRL
export function formatMoedaDanfe(valor?: number): string {
  if (valor === undefined || valor === null || isNaN(valor)) return '0,00';
  return valor.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// Formata CNPJ ou CPF
export function formatCpfCnpjDanfe(valor?: string): string {
  if (!valor) return '-';
  const limpo = valor.replace(/\D/g, '');
  if (limpo.length === 14) {
    return limpo.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  }
  if (limpo.length === 11) {
    return limpo.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  }
  return valor;
}

// Formata Data ISO para formato dd/mm/aaaa
export function formatDataDanfe(dataIso?: string): string {
  if (!dataIso) return '-';
  try {
    const data = new Date(dataIso);
    if (isNaN(data.getTime())) {
      const partes = dataIso.split('T')[0].split('-');
      if (partes.length === 3) return `${partes[2]}/${partes[1]}/${partes[0]}`;
      return dataIso;
    }
    return data.toLocaleDateString('pt-BR');
  } catch {
    return dataIso;
  }
}

// Desenha código de barras 1D simulado de alta fidelidade
function desenharCodigoBarrasSimulado(
  doc: jsPDF,
  x: number,
  y: number,
  width: number,
  height: number,
  chave: string
) {
  doc.setFillColor(0, 0, 0);
  const totalBarras = 64;
  const barraLargura = width / (totalBarras * 1.5);
  let curX = x + 1;

  for (let i = 0; i < totalBarras; i++) {
    const charCode = chave.charCodeAt(i % chave.length) || 48;
    const isLarga = (charCode + i) % 3 === 0;
    const w = isLarga ? barraLargura * 1.8 : barraLargura * 0.9;
    const draw = (charCode + i) % 2 === 0 || i % 4 !== 0;

    if (draw && curX + w <= x + width - 1) {
      doc.rect(curX, y + 1, w, height - 2, 'F');
    }
    curX += w + (isLarga ? barraLargura * 0.8 : barraLargura * 0.5);
    if (curX >= x + width - 2) break;
  }
}

/**
 * Renderiza uma página completa do DANFE em formato A4
 */
export function desenharDanfeNaPagina(
  doc: jsPDF,
  nota: NotaFiscal,
  emitente?: Empresa | null,
  paginaAtual = 1,
  totalPaginas = 1
): void {
  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const marginX = 8;
  const contentWidth = pageWidth - marginX * 2; // 194mm
  let curY = 6;

  // Helper para desenhar caixas com títulos padronizados do DANFE
  const drawBox = (
    x: number,
    y: number,
    w: number,
    h: number,
    title?: string,
    value?: string,
    valFontSize = 8,
    align: 'left' | 'center' | 'right' = 'left',
    isBold = false
  ) => {
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.2);
    doc.rect(x, y, w, h);

    if (title) {
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(5.5);
      doc.setTextColor(60, 60, 60);
      doc.text(title.toUpperCase(), x + 1, y + 2.6);
    }

    if (value !== undefined) {
      doc.setFont('helvetica', isBold ? 'bold' : 'normal');
      doc.setFontSize(valFontSize);
      doc.setTextColor(0, 0, 0);
      const textY = y + h - 1.8;

      if (align === 'center') {
        doc.text(value, x + w / 2, textY, { align: 'center' });
      } else if (align === 'right') {
        doc.text(value, x + w - 1.5, textY, { align: 'right' });
      } else {
        doc.text(value, x + 1.2, textY);
      }
    }
  };

  // =========================================================================
  // 1. CANHOTO DE RECEBIMENTO (Recibo do Destinatário no topo da folha)
  // =========================================================================
  const canhotoH = 14;
  const emitenteNome = emitente?.razaoSocial || emitente?.nomeFantasia || 'EMPRESA EMITENTE LTDA';

  // Caixa principal do recibo
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.2);
  doc.rect(marginX, curY, contentWidth - 32, canhotoH);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6);
  doc.setTextColor(0, 0, 0);
  const reciboTexto = `RECEBEMOS DE ${emitenteNome.toUpperCase()} OS PRODUTOS / SERVIÇOS CONSTANTES DA NOTA FISCAL ELETRÔNICA INDICADA AO LADO.`;
  doc.text(reciboTexto, marginX + 1.5, curY + 3.2, { maxWidth: contentWidth - 36 });

  // Divisão inferior do canhoto: Data de Recebimento e Assinatura
  doc.line(marginX, curY + 6.5, marginX + contentWidth - 32, curY + 6.5);
  doc.line(marginX + 38, curY + 6.5, marginX + 38, curY + canhotoH);

  doc.setFontSize(5.5);
  doc.setTextColor(80, 80, 80);
  doc.text('DATA DE RECEBIMENTO', marginX + 1.5, curY + 9);
  doc.text('IDENTIFICAÇÃO E ASSINATURA DO RECEBEDOR', marginX + 40, curY + 9);

  // Caixa lateral direita do canhoto: NF-e Nº e Série
  doc.rect(marginX + contentWidth - 32, curY, 32, canhotoH);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(0, 0, 0);
  doc.text('NF-e', marginX + contentWidth - 16, curY + 4.5, { align: 'center' });
  doc.setFontSize(7.5);
  doc.text(`Nº ${String(nota.numero).padStart(9, '0')}`, marginX + contentWidth - 16, curY + 8.5, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.text(`Série ${nota.serie}`, marginX + contentWidth - 16, curY + 12, { align: 'center' });

  curY += canhotoH + 1.5;

  // Linha tracejada separadora de canhoto
  doc.setLineDashPattern([1.5, 1], 0);
  doc.line(marginX, curY, marginX + contentWidth, curY);
  doc.setLineDashPattern([], 0); // Restaura linha contínua

  curY += 2;

  // =========================================================================
  // 2. CABEÇALHO DO DANFE (Emitente, Dados, Tipo DANFE e Chave de Acesso)
  // =========================================================================
  const headerBoxH = 34;
  const col1W = 76;
  const col2W = 38;
  const col3W = contentWidth - col1W - col2W; // 80mm

  // 2.1 Coluna 1: Dados do Emitente
  doc.rect(marginX, curY, col1W, headerBoxH);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(0, 0, 0);
  doc.text(emitenteNome, marginX + 2, curY + 5, { maxWidth: col1W - 4 });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(50, 50, 50);
  const endEmitente = `Avenida Paulista, 1000 - Bela Vista`;
  const munEmitente = `${emitente?.cidade || 'São Paulo'} - ${emitente?.uf || 'SP'} - CEP 01310-100`;
  const foneEmitente = `Fone/Fax: ${emitente?.telefone || '(11) 3456-7890'}`;

  doc.text(endEmitente, marginX + 2, curY + 11);
  doc.text(munEmitente, marginX + 2, curY + 15);
  doc.text(foneEmitente, marginX + 2, curY + 19);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.5);
  doc.setTextColor(0, 0, 0);
  doc.text(`CNPJ: ${formatCpfCnpjDanfe(emitente?.cnpj || '12345678000190')}`, marginX + 2, curY + 24);
  doc.setFont('helvetica', 'normal');
  doc.text(`Inscrição Estadual: 110.234.567.119`, marginX + 2, curY + 28);
  doc.text(`Regime Tributário: ${emitente?.regimeTributario || 'Simples Nacional'}`, marginX + 2, curY + 31.5);

  // 2.2 Coluna 2: Identificação do DANFE
  doc.rect(marginX + col1W, curY, col2W, headerBoxH);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text('DANFE', marginX + col1W + col2W / 2, curY + 5, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(5.5);
  doc.text('DOCUMENTO AUXILIAR DA', marginX + col1W + col2W / 2, curY + 8, { align: 'center' });
  doc.text('NOTA FISCAL ELETRÔNICA', marginX + col1W + col2W / 2, curY + 10.5, { align: 'center' });

  // Entrada / Saída
  doc.setFontSize(6);
  doc.text('0 - ENTRADA', marginX + col1W + 6, curY + 15);
  doc.text('1 - SAÍDA', marginX + col1W + 23, curY + 15);

  // Quadrinho de seleção 1 (Saída)
  doc.rect(marginX + col1W + 16, curY + 12.5, 4, 3.5);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.text('1', marginX + col1W + 18, curY + 15.2, { align: 'center' });

  // Nº da Nota e Série em destaque
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text(`Nº ${String(nota.numero).padStart(9, '0')}`, marginX + col1W + col2W / 2, curY + 21, { align: 'center' });
  doc.text(`SÉRIE ${nota.serie}`, marginX + col1W + col2W / 2, curY + 25, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.text(`FOLHA ${paginaAtual} / ${totalPaginas}`, marginX + col1W + col2W / 2, curY + 29, { align: 'center' });

  // 2.3 Coluna 3: Código de Barras e Chave de Acesso
  doc.rect(marginX + col1W + col2W, curY, col3W, headerBoxH);

  // Código de barras simulado
  desenharCodigoBarrasSimulado(doc, marginX + col1W + col2W + 2, curY + 1.5, col3W - 4, 11, nota.chaveAcesso);

  // Chave de Acesso
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(5.5);
  doc.text('CHAVE DE ACESSO', marginX + col1W + col2W + 2, curY + 15.5);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6.5);
  const chaveFormatada = formatChaveAcesso(nota.chaveAcesso);
  doc.text(chaveFormatada, marginX + col1W + col2W + col3W / 2, curY + 19, { align: 'center' });

  // Consulta de autenticidade
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(5.5);
  doc.text(
    'Consulta de autenticidade no portal nacional da NF-e',
    marginX + col1W + col2W + col3W / 2,
    curY + 24,
    { align: 'center' }
  );
  doc.text(
    'www.nfe.fazenda.gov.br/portal ou no site da Sefaz Autorizadora',
    marginX + col1W + col2W + col3W / 2,
    curY + 26.5,
    { align: 'center' }
  );

  // Protocolo de autorização de uso
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(6);
  const protocolo = nota.protocoloAutorizacao || '135260049281729';
  const dataProtocolo = formatDataDanfe(nota.dataEmissao);
  doc.text(
    `PROTOCOLO DE AUTORIZAÇÃO DE USO: ${protocolo} - ${dataProtocolo}`,
    marginX + col1W + col2W + 2,
    curY + 31.5
  );

  curY += headerBoxH + 1;

  // =========================================================================
  // 3. QUADRO NATUREZA DA OPERAÇÃO E INSCRIÇÕES
  // =========================================================================
  const linhaNatH = 7.5;
  const colNat1 = 80;
  const colNat2 = 50;
  const colNat3 = contentWidth - colNat1 - colNat2;

  drawBox(marginX, curY, colNat1, linhaNatH, 'Natureza da Operação', nota.naturezaOperacao, 7.5, 'left', true);
  drawBox(
    marginX + colNat1,
    curY,
    colNat2,
    linhaNatH,
    'Protocolo de Autorização de Uso',
    `${protocolo} - ${dataProtocolo}`,
    6.5
  );
  drawBox(
    marginX + colNat1 + colNat2,
    curY,
    colNat3,
    linhaNatH,
    'CNPJ do Emitente',
    formatCpfCnpjDanfe(emitente?.cnpj || '12345678000190'),
    7,
    'left',
    true
  );

  curY += linhaNatH + 1.5;

  // =========================================================================
  // 4. QUADRO DESTINATÁRIO / REMETENTE
  // =========================================================================
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(0, 0, 0);
  doc.text('DESTINATÁRIO / REMETENTE', marginX, curY - 0.5);

  const destRowH = 7.5;
  const colD1 = 105;
  const colD2 = 54;
  const colD3 = contentWidth - colD1 - colD2;

  // Linha 1 Destinatário
  drawBox(marginX, curY, colD1, destRowH, 'Nome / Razão Social', nota.destinatarioNome, 7.5, 'left', true);
  drawBox(
    marginX + colD1,
    curY,
    colD2,
    destRowH,
    'CNPJ / CPF',
    formatCpfCnpjDanfe(nota.destinatarioCpfCnpj),
    7.5,
    'left',
    true
  );
  drawBox(
    marginX + colD1 + colD2,
    curY,
    colD3,
    destRowH,
    'Data da Emissão',
    formatDataDanfe(nota.dataEmissao),
    7.5,
    'center'
  );

  curY += destRowH;

  // Linha 2 Destinatário (Endereço, Bairro, CEP, Data Saída)
  const colD2_1 = 80;
  const colD2_2 = 45;
  const colD2_3 = 34;
  const colD2_4 = contentWidth - colD2_1 - colD2_2 - colD2_3;

  drawBox(marginX, curY, colD2_1, destRowH, 'Endereço', 'Rua das Indústrias, 450 - Sala 10', 7);
  drawBox(marginX + colD2_1, curY, colD2_2, destRowH, 'Bairro / Distrito', 'Distrito Industrial', 7);
  drawBox(marginX + colD2_1 + colD2_2, curY, colD2_3, destRowH, 'CEP', '04571-010', 7);
  drawBox(
    marginX + colD2_1 + colD2_2 + colD2_3,
    curY,
    colD2_4,
    destRowH,
    'Data Entrada / Saída',
    formatDataDanfe(nota.dataEmissao),
    7,
    'center'
  );

  curY += destRowH;

  // Linha 3 Destinatário (Município, Telefone, UF, Inscrição Estadual, Hora Saída)
  const colD3_1 = 65;
  const colD3_2 = 35;
  const colD3_3 = 12;
  const colD3_4 = 47;
  const colD3_5 = contentWidth - colD3_1 - colD3_2 - colD3_3 - colD3_4;

  drawBox(marginX, curY, colD3_1, destRowH, 'Município', 'São Paulo', 7);
  drawBox(marginX + colD3_1, curY, colD3_2, destRowH, 'Fone / Fax', '(11) 2999-8877', 7);
  drawBox(marginX + colD3_1 + colD3_2, curY, colD3_3, destRowH, 'UF', 'SP', 7, 'center');
  drawBox(marginX + colD3_1 + colD3_2 + colD3_3, curY, colD3_4, destRowH, 'Inscrição Estadual', 'ISENTO', 7);
  drawBox(
    marginX + colD3_1 + colD3_2 + colD3_3 + colD3_4,
    curY,
    colD3_5,
    destRowH,
    'Hora da Saída',
    '10:30:00',
    7,
    'center'
  );

  curY += destRowH + 1.5;

  // =========================================================================
  // 5. QUADRO CÁLCULO DO IMPOSTO
  // =========================================================================
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(0, 0, 0);
  doc.text('CÁLCULO DO IMPOSTO', marginX, curY - 0.5);

  const impRowH = 7.5;
  const colI5 = contentWidth / 5;

  // Linha 1 Impostos
  const baseIcms = (nota.impostos.icms || 0) > 0 ? formatMoedaDanfe(nota.valorTotal) : '0,00';
  const valIcms = formatMoedaDanfe(nota.impostos.icms || 0);
  const totalProdutos = formatMoedaDanfe(nota.valorServicosOuProdutos || nota.valorTotal);

  drawBox(marginX, curY, colI5, impRowH, 'Base de Cálculo do ICMS', baseIcms, 7.5, 'right');
  drawBox(marginX + colI5, curY, colI5, impRowH, 'Valor do ICMS', valIcms, 7.5, 'right');
  drawBox(marginX + colI5 * 2, curY, colI5, impRowH, 'Base de Cálculo ICMS ST', '0,00', 7.5, 'right');
  drawBox(marginX + colI5 * 3, curY, colI5, impRowH, 'Valor do ICMS Substituição', '0,00', 7.5, 'right');
  drawBox(marginX + colI5 * 4, curY, colI5, impRowH, 'Valor Total dos Produtos', totalProdutos, 7.5, 'right', true);

  curY += impRowH;

  // Linha 2 Impostos (Frete, Seguro, Desconto, Outras, IPI, Total da Nota)
  const colI6 = contentWidth / 6;
  drawBox(marginX, curY, colI6, impRowH, 'Valor do Frete', '0,00', 7, 'right');
  drawBox(marginX + colI6, curY, colI6, impRowH, 'Valor do Seguro', '0,00', 7, 'right');
  drawBox(marginX + colI6 * 2, curY, colI6, impRowH, 'Desconto', '0,00', 7, 'right');
  drawBox(marginX + colI6 * 3, curY, colI6, impRowH, 'Outras Despesas', '0,00', 7, 'right');
  drawBox(marginX + colI6 * 4, curY, colI6, impRowH, 'Valor do IPI', '0,00', 7, 'right');
  drawBox(
    marginX + colI6 * 5,
    curY,
    colI6,
    impRowH,
    'VALOR TOTAL DA NOTA',
    `R$ ${formatMoedaDanfe(nota.valorTotal)}`,
    8,
    'right',
    true
  );

  curY += impRowH + 1.5;

  // =========================================================================
  // 6. QUADRO TRANSPORTADOR / VOLUMES TRANSPORTADOS
  // =========================================================================
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(0, 0, 0);
  doc.text('TRANSPORTADOR / VOLUMES TRANSPORTADOS', marginX, curY - 0.5);

  const transRowH = 7;
  const colT1 = 70;
  const colT2 = 36;
  const colT3 = 24;
  const colT4 = 20;
  const colT5 = 10;
  const colT6 = contentWidth - colT1 - colT2 - colT3 - colT4 - colT5;

  drawBox(marginX, curY, colT1, transRowH, 'Razão Social', 'O PRÓPRIO / RETIRADA NO LOCAL', 7);
  drawBox(marginX + colT1, curY, colT2, transRowH, 'Frete por Conta', '9 - SEM FRETE', 7);
  drawBox(marginX + colT1 + colT2, curY, colT3, transRowH, 'Código ANTT', '-', 7, 'center');
  drawBox(marginX + colT1 + colT2 + colT3, curY, colT4, transRowH, 'Placa do Veículo', '-', 7, 'center');
  drawBox(marginX + colT1 + colT2 + colT3 + colT4, curY, colT5, transRowH, 'UF', '-', 7, 'center');
  drawBox(marginX + colT1 + colT2 + colT3 + colT4 + colT5, curY, colT6, transRowH, 'CNPJ / CPF', '-', 7);

  curY += transRowH + 1.5;

  // =========================================================================
  // 7. QUADRO DADOS DO PRODUTO / SERVIÇO (TABELA ESTRUTURADA)
  // =========================================================================
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(0, 0, 0);
  doc.text('DADOS DOS PRODUTOS / SERVIÇOS', marginX, curY - 0.5);

  const itensTableData = nota.itens.map((item, idx) => {
    const aliquotaIcms = (nota.impostos.icms || 0) > 0 ? '18,00' : '0,00';
    const valorIcmsItem = (nota.impostos.icms || 0) > 0 ? (item.valorTotal * 0.18).toFixed(2) : '0,00';

    return [
      String(idx + 1).padStart(3, '0'),
      item.descricao,
      '99000000', // NCM padrão
      '0102', // CSOSN Simples ou CST
      '5102', // CFOP padrão venda mercadorias
      'UN',
      String(item.quantidade),
      formatMoedaDanfe(item.valorUnitario),
      formatMoedaDanfe(item.valorTotal),
      formatMoedaDanfe(item.valorTotal),
      aliquotaIcms,
      valorIcmsItem,
    ];
  });

  autoTable(doc, {
    startY: curY,
    margin: { left: marginX, right: marginX },
    tableWidth: contentWidth,
    head: [
      [
        'CÓD.',
        'DESCRIÇÃO DO PRODUTO / SERVIÇO',
        'NCM/SH',
        'CST',
        'CFOP',
        'UN',
        'QTD',
        'V. UNIT.',
        'V. TOTAL',
        'BC ICMS',
        'ALÍQ.',
        'V. ICMS',
      ],
    ],
    body: itensTableData,
    theme: 'plain',
    styles: {
      fontSize: 6.5,
      cellPadding: 1.2,
      lineColor: [0, 0, 0],
      lineWidth: 0.15,
      textColor: [0, 0, 0],
      font: 'helvetica',
    },
    headStyles: {
      fontStyle: 'bold',
      fillColor: [240, 240, 240],
      textColor: [0, 0, 0],
      halign: 'center',
    },
    columnStyles: {
      0: { cellWidth: 10, halign: 'center' },
      1: { cellWidth: 62, halign: 'left' },
      2: { cellWidth: 15, halign: 'center' },
      3: { cellWidth: 10, halign: 'center' },
      4: { cellWidth: 10, halign: 'center' },
      5: { cellWidth: 8, halign: 'center' },
      6: { cellWidth: 10, halign: 'center' },
      7: { cellWidth: 17, halign: 'right' },
      8: { cellWidth: 18, halign: 'right', fontStyle: 'bold' },
      9: { cellWidth: 15, halign: 'right' },
      10: { cellWidth: 10, halign: 'center' },
      11: { cellWidth: 9, halign: 'right' },
    },
  });

  // Atualiza a posição vertical após a tabela
  curY = (doc as any).lastAutoTable.finalY + 2;

  // =========================================================================
  // 8. QUADRO DADOS ADICIONAIS / INFORMAÇÕES COMPLEMENTARES
  // =========================================================================
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7);
  doc.setTextColor(0, 0, 0);
  doc.text('DADOS ADICIONAIS', marginX, curY - 0.5);

  const dadosAdicH = 22;
  const colAdic1 = contentWidth * 0.72; // 140mm
  const colAdic2 = contentWidth - colAdic1; // 54mm

  // Caixa de Informações Complementares
  doc.rect(marginX, curY, colAdic1, dadosAdicH);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(5.5);
  doc.setTextColor(70, 70, 70);
  doc.text('INFORMAÇÕES COMPLEMENTARES', marginX + 1.5, curY + 3);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6);
  doc.setTextColor(0, 0, 0);
  const infoLegal = [
    `DOCUMENTO EMITIDO POR ME OU EPP OPTANTE PELO SIMPLES NACIONAL.`,
    `NÃO GERA DIREITO A CRÉDITO FISCAL DE IPI OU ICMS.`,
    `Tributos Totais Incidentes (Lei Federal nº 12.741/2012): R$ ${formatMoedaDanfe(
      (nota.impostos.icms || 0) + (nota.impostos.pis || 0) + (nota.impostos.cofins || 0) + (nota.impostos.iss || 0)
    )} (aprox. 14,25%).`,
    `Protocolo de Autorização SEFAZ: ${protocolo} transmitido em ambiente de produção.`,
    `Sistema Emissor ContabGest ERP Contábil - Chave: ${nota.chaveAcesso}`,
  ];
  doc.text(infoLegal, marginX + 1.5, curY + 6.5, { maxWidth: colAdic1 - 3, lineHeightFactor: 1.25 });

  // Caixa Reservado ao Fisco
  doc.rect(marginX + colAdic1, curY, colAdic2, dadosAdicH);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(5.5);
  doc.setTextColor(70, 70, 70);
  doc.text('RESERVADO AO FISCO', marginX + colAdic1 + 1.5, curY + 3);

  curY += dadosAdicH + 3;

  // =========================================================================
  // 9. MARCA D'ÁGUA OU TARJA DE CANCELAMENTO (SE A NOTA ESTIVER CANCELADA)
  // =========================================================================
  if (nota.status === 'cancelada') {
    doc.saveGraphicsState();
    doc.setTextColor(220, 38, 38); // rose-600
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(28);

    // Faixa diagonal no centro da página
    doc.text('*** NF-e CANCELADA NA SEFAZ ***', pageWidth / 2, 140, {
      align: 'center',
      angle: 35,
    });

    if (nota.motivoCancelamento) {
      doc.setFontSize(11);
      doc.text(`Motivo: ${nota.motivoCancelamento}`, pageWidth / 2, 150, {
        align: 'center',
        angle: 35,
      });
    }
    doc.restoreGraphicsState();
  }

  // Rodapé com carimbo de impressão contábil
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(5.5);
  doc.setTextColor(120, 120, 120);
  const dataHoraImpressao = new Date().toLocaleString('pt-BR');
  doc.text(
    `Impresso via ContabGest Cloud Fiscal em ${dataHoraImpressao} - Documento Auxiliar da NF-e Modelo 55`,
    marginX,
    290
  );
  doc.text(`Página ${paginaAtual} de ${totalPaginas}`, marginX + contentWidth, 290, { align: 'right' });
}

/**
 * Gera o DANFE (Documento Auxiliar da Nota Fiscal Eletrônica) em PDF A4
 * para uma nota fiscal individual.
 */
export function gerarDanfePdf(
  nota: NotaFiscal,
  emitente?: Empresa | null,
  options: GerarDanfePdfOptions = { autoDownload: true }
): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  desenharDanfeNaPagina(doc, nota, emitente, 1, 1);

  // Nome padrão do arquivo PDF
  const nomePdf =
    options.nomeArquivo ||
    `DANFE_NFe_${String(nota.numero).padStart(8, '0')}_Serie_${nota.serie}_${nota.destinatarioNome.replace(
      /[^a-zA-Z0-9]/g,
      '_'
    )}.pdf`;

  // Execução de Download ou Impressão Direta
  if (options.printDirectly) {
    try {
      doc.autoPrint();
      const blobUrl = doc.output('bloburl');
      const printWindow = window.open(blobUrl, '_blank');
      if (printWindow) {
        printWindow.focus();
      } else {
        doc.save(nomePdf);
      }
    } catch {
      doc.save(nomePdf);
    }
  } else if (options.autoDownload) {
    doc.save(nomePdf);
  }

  return doc;
}

/**
 * Gera um lote consolidado de DANFEs em um único arquivo PDF
 * (ideal para envio em massa para a impressora ou arquivamento contábil mensal).
 */
export function gerarLoteDanfePdf(
  notas: NotaFiscal[],
  getEmitente: (empresaId: string) => Empresa | undefined,
  options: GerarDanfePdfOptions = { autoDownload: true }
): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const total = notas.length;

  notas.forEach((nota, index) => {
    if (index > 0) {
      doc.addPage('a4', 'portrait');
    }
    const emit = getEmitente(nota.empresaId);
    desenharDanfeNaPagina(doc, nota, emit, index + 1, total);
  });

  const dataStr = new Date().toISOString().split('T')[0];
  const nomePdf = options.nomeArquivo || `Lote_DANFEs_NFe_${dataStr}_(${total}_notas).pdf`;

  if (options.printDirectly) {
    try {
      doc.autoPrint();
      const blobUrl = doc.output('bloburl');
      const printWindow = window.open(blobUrl, '_blank');
      if (printWindow) {
        printWindow.focus();
      } else {
        doc.save(nomePdf);
      }
    } catch {
      doc.save(nomePdf);
    }
  } else if (options.autoDownload) {
    doc.save(nomePdf);
  }

  return doc;
}

/**
 * Retorna o Blob do PDF do DANFE de uma nota (útil para empacotamento em ZIP)
 */
export function getDanfePdfBlob(nota: NotaFiscal, emitente?: Empresa | null): Blob {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });
  desenharDanfeNaPagina(doc, nota, emitente, 1, 1);
  return doc.output('blob');
}

/**
 * Converte NotaFiscalEntrada (capturada da SEFAZ) para o formato esperado pelo gerador de DANFE
 */
export function converterEntradaParaDanfe(notaEntrada: NotaFiscalEntrada): {
  notaAdaptada: NotaFiscal;
  fornecedorComoEmitente: Empresa;
} {
  const fornecedorComoEmitente: Empresa = {
    id: `forn_${notaEntrada.id}`,
    razaoSocial: notaEntrada.fornecedorNome,
    nomeFantasia: notaEntrada.fornecedorNome,
    cnpj: notaEntrada.fornecedorCnpj,
    cidade: notaEntrada.fornecedorMunicipio || 'São Paulo',
    uf: notaEntrada.fornecedorUf || 'SP',
    telefone: '(11) 3200-4000',
    regimeTributario: 'Lucro Presumido',
    status: 'ativa',
    isDemo: true,
    email: 'contato@fornecedor.com.br',
    faturamentoMensal: 150000,
    qtdeFuncionarios: 12,
    responsavelContabil: 'Setor Fiscal Fornecedor',
  };

  const notaAdaptada: NotaFiscal = {
    id: notaEntrada.id,
    empresaId: notaEntrada.empresaId,
    numero: notaEntrada.numero,
    serie: notaEntrada.serie,
    tipo: 'NFe',
    naturezaOperacao: notaEntrada.naturezaOperacao || 'Compra para Comercialização',
    destinatarioNome: notaEntrada.destinatarioNome,
    destinatarioCpfCnpj: notaEntrada.destinatarioCnpj,
    valorTotal: notaEntrada.valorTotal,
    valorServicosOuProdutos: notaEntrada.valorProdutos || notaEntrada.valorTotal,
    status: notaEntrada.statusSefaz === 'cancelada' ? 'cancelada' : 'autorizada',
    itens: (notaEntrada.itens || []).map((it) => ({
      descricao: it.descricao,
      quantidade: it.quantidade,
      valorUnitario: it.valorUnitario,
      valorTotal: it.valorTotal,
    })),
    impostos: {
      icms: notaEntrada.impostos?.icms,
      pis: notaEntrada.impostos?.pis,
      cofins: notaEntrada.impostos?.cofins,
    },
    dataEmissao: notaEntrada.dataEmissao,
    chaveAcesso: notaEntrada.chaveAcesso,
    protocoloAutorizacao: `1352600${notaEntrada.nsuSefaz?.slice(-8) || '81920394'}`,
    isDemo: notaEntrada.isDemo,
  };

  return { notaAdaptada, fornecedorComoEmitente };
}

/**
 * Gera e baixa o DANFE em PDF de uma Nota Fiscal de Entrada capturada da SEFAZ
 */
export function gerarDanfeEntradaPdf(
  notaEntrada: NotaFiscalEntrada,
  options: GerarDanfePdfOptions = { autoDownload: true }
): jsPDF {
  const { notaAdaptada, fornecedorComoEmitente } = converterEntradaParaDanfe(notaEntrada);
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  desenharDanfeNaPagina(doc, notaAdaptada, fornecedorComoEmitente, 1, 1);

  const chaveLimpa = (notaEntrada.chaveAcesso || '').replace(/\D/g, '');
  const nomePdf = options.nomeArquivo || `DANFE_Entrada_NFe_${String(notaEntrada.numero).padStart(9, '0')}_${chaveLimpa.slice(0, 14)}.pdf`;

  if (options.printDirectly) {
    try {
      doc.autoPrint();
      const blobUrl = doc.output('bloburl');
      const printWindow = window.open(blobUrl, '_blank');
      if (printWindow) {
        printWindow.focus();
      } else {
        doc.save(nomePdf);
      }
    } catch {
      doc.save(nomePdf);
    }
  } else if (options.autoDownload) {
    doc.save(nomePdf);
  }

  return doc;
}

/**
 * Gera o Blob do PDF do DANFE de uma Nota Fiscal de Entrada (para inclusão em ZIP de lote)
 */
export function getDanfeEntradaPdfBlob(notaEntrada: NotaFiscalEntrada): Blob {
  const { notaAdaptada, fornecedorComoEmitente } = converterEntradaParaDanfe(notaEntrada);
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });
  desenharDanfeNaPagina(doc, notaAdaptada, fornecedorComoEmitente, 1, 1);
  return doc.output('blob');
}

/**
 * Gera um lote de DANFEs em PDF para notas de entrada
 */
export function gerarLoteDanfeEntradasPdf(
  notas: NotaFiscalEntrada[],
  options: GerarDanfePdfOptions = { autoDownload: true }
): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const total = notas.length;

  notas.forEach((nota, index) => {
    if (index > 0) {
      doc.addPage('a4', 'portrait');
    }
    const { notaAdaptada, fornecedorComoEmitente } = converterEntradaParaDanfe(nota);
    desenharDanfeNaPagina(doc, notaAdaptada, fornecedorComoEmitente, index + 1, total);
  });

  const dataStr = new Date().toISOString().split('T')[0];
  const nomePdf = options.nomeArquivo || `Lote_DANFEs_Entrada_SEFAZ_${dataStr}_(${total}_notas).pdf`;

  if (options.printDirectly) {
    try {
      doc.autoPrint();
      const blobUrl = doc.output('bloburl');
      const printWindow = window.open(blobUrl, '_blank');
      if (printWindow) {
        printWindow.focus();
      } else {
        doc.save(nomePdf);
      }
    } catch {
      doc.save(nomePdf);
    }
  } else if (options.autoDownload) {
    doc.save(nomePdf);
  }

  return doc;
}

/**
 * Gera o conteúdo XML formatado e completo para a Nota Fiscal Eletrônica de Entrada
 * em conformidade com o padrão oficial SEFAZ NF-e Layout 4.00
 */
export function gerarXmlDanfeEntrada(nota: NotaFiscalEntrada): string {
  if (nota.xmlContent && nota.xmlContent.includes('<nfeProc')) {
    return nota.xmlContent;
  }

  const chaveLimpa = (nota.chaveAcesso || '').replace(/\D/g, '').padEnd(44, '0').slice(0, 44);
  const cnpjFornLimpo = (nota.fornecedorCnpj || '').replace(/\D/g, '');
  const cnpjDestLimpo = (nota.destinatarioCnpj || '').replace(/\D/g, '');
  const dataFormatada = (nota.dataEmissao || new Date().toISOString()).split('T')[0];
  const protocolo = `1352600${nota.nsuSefaz?.slice(-8) || '81920394'}`;

  const itensXml = (nota.itens || []).map((it, idx) => `
      <det nItem="${idx + 1}">
        <prod>
          <cProd>${it.codigo || `PROD-${idx + 1}`}</cProd>
          <cEAN>SEM GTIN</cEAN>
          <xProd>${it.descricao}</xProd>
          <NCM>${it.ncm || '84713012'}</NCM>
          <CFOP>${it.cfop || nota.cfopPrincipal.replace(/\D/g, '') || '5102'}</CFOP>
          <uCom>${it.unidade || 'UN'}</uCom>
          <qCom>${it.quantidade.toFixed(4)}</qCom>
          <vUnCom>${it.valorUnitario.toFixed(4)}</vUnCom>
          <vProd>${it.valorTotal.toFixed(2)}</vProd>
          <cEANTrib>SEM GTIN</cEANTrib>
          <uTrib>${it.unidade || 'UN'}</uTrib>
          <qTrib>${it.quantidade.toFixed(4)}</qTrib>
          <vUnTrib>${it.valorUnitario.toFixed(4)}</vUnTrib>
          <indTot>1</indTot>
        </prod>
        <imposto>
          <vTotTrib>${(it.valorTotal * 0.18).toFixed(2)}</vTotTrib>
          <ICMS>
            <ICMS00>
              <orig>0</orig>
              <CST>${it.cst || '00'}</CST>
              <modBC>3</modBC>
              <vBC>${it.valorTotal.toFixed(2)}</vBC>
              <pICMS>12.00</pICMS>
              <vICMS>${(it.valorTotal * 0.12).toFixed(2)}</vICMS>
            </ICMS00>
          </ICMS>
          <PIS>
            <PISAliq>
              <CST>01</CST>
              <vBC>${it.valorTotal.toFixed(2)}</vBC>
              <pPIS>0.65</pPIS>
              <vPIS>${(it.valorTotal * 0.0065).toFixed(2)}</vPIS>
            </PISAliq>
          </PIS>
          <COFINS>
            <COFINSAliq>
              <CST>01</CST>
              <vBC>${it.valorTotal.toFixed(2)}</vBC>
              <pCOFINS>3.00</pCOFINS>
              <vCOFINS>${(it.valorTotal * 0.03).toFixed(2)}</vCOFINS>
            </COFINSAliq>
          </COFINS>
        </imposto>
      </det>`).join('');

  return `<?xml version="1.0" encoding="UTF-8"?>
<nfeProc versao="4.00" xmlns="http://www.portalfiscal.inf.br/nfe">
  <NFe xmlns="http://www.portalfiscal.inf.br/nfe">
    <infNFe Id="NFe${chaveLimpa}" versao="4.00">
      <ide>
        <cUF>${chaveLimpa.slice(0, 2)}</cUF>
        <cNF>${chaveLimpa.slice(35, 43)}</cNF>
        <natOp>${nota.naturezaOperacao}</natOp>
        <mod>${nota.modelo}</mod>
        <serie>${nota.serie}</serie>
        <nNF>${nota.numero}</nNF>
        <dhEmi>${nota.dataEmissao}</dhEmi>
        <tpNF>1</tpNF>
        <idDest>1</idDest>
        <cMunFG>3550308</cMunFG>
        <tpImp>1</tpImp>
        <tpEmis>1</tpEmis>
        <cDV>${chaveLimpa.slice(43, 44)}</cDV>
        <tpAmb>1</tpAmb>
        <finNFe>1</finNFe>
        <indFinal>0</indFinal>
        <indPres>1</indPres>
        <procEmi>0</procEmi>
        <verProc>SEFAZ_DIST_DFE_v4.00</verProc>
      </ide>
      <emit>
        <CNPJ>${cnpjFornLimpo}</CNPJ>
        <xNome>${nota.fornecedorNome}</xNome>
        <enderEmit>
          <xLgr>Avenida Industrial dos Fornecedores</xLgr>
          <nro>500</nro>
          <xBairro>Distrito Industrial</xBairro>
          <cMun>3550308</cMun>
          <xMun>${nota.fornecedorMunicipio}</xMun>
          <UF>${nota.fornecedorUf}</UF>
          <CEP>04001000</CEP>
          <cPais>1058</cPais>
          <xPais>Brasil</xPais>
        </enderEmit>
        <IE>${nota.fornecedorIe?.replace(/\D/g, '') || '114829102910'}</IE>
        <CRT>3</CRT>
      </emit>
      <dest>
        <CNPJ>${cnpjDestLimpo}</CNPJ>
        <xNome>${nota.destinatarioNome}</xNome>
        <enderDest>
          <xLgr>Rua Empresarial Central</xLgr>
          <nro>1000</nro>
          <xBairro>Centro</xBairro>
          <cMun>3550308</cMun>
          <xMun>São Paulo</xMun>
          <UF>SP</UF>
          <CEP>01310100</CEP>
          <cPais>1058</cPais>
          <xPais>Brasil</xPais>
        </enderDest>
        <indIEDest>1</indIEDest>
        <IE>110234567119</IE>
      </dest>
      ${itensXml}
      <total>
        <ICMSTot>
          <vBC>${(nota.impostos?.baseCalculoIcms || nota.valorTotal).toFixed(2)}</vBC>
          <vICMS>${(nota.impostos?.icms || 0).toFixed(2)}</vICMS>
          <vICMSDeson>0.00</vICMSDeson>
          <vFCP>0.00</vFCP>
          <vBCST>0.00</vBCST>
          <vST>0.00</vST>
          <vFCPST>0.00</vFCPST>
          <vFCPSTRet>0.00</vFCPSTRet>
          <vProd>${(nota.valorProdutos || nota.valorTotal).toFixed(2)}</vProd>
          <vFrete>${(nota.valorFrete || 0).toFixed(2)}</vFrete>
          <vSeg>0.00</vSeg>
          <vDesc>${(nota.valorDesconto || 0).toFixed(2)}</vDesc>
          <vII>0.00</vII>
          <vIPI>${(nota.impostos?.ipi || 0).toFixed(2)}</vIPI>
          <vIPIDevol>0.00</vIPIDevol>
          <vPIS>${(nota.impostos?.pis || 0).toFixed(2)}</vPIS>
          <vCOFINS>${(nota.impostos?.cofins || 0).toFixed(2)}</vCOFINS>
          <vOutro>0.00</vOutro>
          <vNF>${nota.valorTotal.toFixed(2)}</vNF>
        </ICMSTot>
      </total>
      <transp>
        <modFrete>0</modFrete>
      </transp>
      <cobr>
        <fat>
          <nFat>${nota.numero}</nFat>
          <vOrig>${nota.valorTotal.toFixed(2)}</vOrig>
          <vDesc>0.00</vDesc>
          <vLiq>${nota.valorTotal.toFixed(2)}</vLiq>
        </fat>
      </cobr>
      <infAdic>
        <infCpl>${nota.observacoes || 'Documento emitido por contribuinte e capturado via Web Service Distribuição DF-e SEFAZ.'}</infCpl>
      </infAdic>
    </infNFe>
  </NFe>
  <protNFe versao="4.00">
    <infProt>
      <tpAmb>1</tpAmb>
      <verAplic>SVRS_2026.1</verAplic>
      <chNFe>${chaveLimpa}</chNFe>
      <dhRecbto>${nota.dataCapturaSefaz || nota.dataEmissao}</dhRecbto>
      <nProt>${protocolo}</nProt>
      <digVal>zFqA7v1x9P4o8K2L1m0N=</digVal>
      <cStat>100</cStat>
      <xMotivo>Autorizado o uso da NF-e</xMotivo>
    </infProt>
  </protNFe>
</nfeProc>`;
}

