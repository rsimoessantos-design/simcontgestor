import { DreData, BemPatrimonial } from '../types';

export interface MesEvolucaoFinanceira {
  id: string;
  mesAno: string; // Ex: 'Out/25'
  mesAnoCompleto: string; // Ex: 'Outubro/2025'
  ano: number;
  mes: number; // 1-12
  receitaLiquida: number;
  ebitda: number;
  margemEbitda: number; // %
  depreciacao: number;
  lucroLiquido: number;
  fluxoCaixaOperacional: number;
  fluxoCaixaLiquido: number; // Variação Líquida de Caixa
  saldoCaixaFinal: number;
  conversaoCaixaEbitda: number; // % conversão
  tendencia: 'alta' | 'estavel' | 'queda';
  destaque: string;
}

export interface ResumoLTM {
  ebitdaTotal: number;
  ebitdaMedioMensal: number;
  margemEbitdaMedia: number;
  fluxoCaixaLiquidoTotal: number;
  fluxoCaixaOperacionalTotal: number;
  conversaoCaixaEbitdaMedia: number;
  saldoCaixaAtual: number;
  melhorMesEbitda: MesEvolucaoFinanceira;
  menorMesEbitda: MesEvolucaoFinanceira;
  melhorMesCaixa: MesEvolucaoFinanceira;
  menorMesCaixa: MesEvolucaoFinanceira;
  crescimentoEbitdaMoM: number;
  tendenciaGeral: 'crescimento_forte' | 'crescimento_estavel' | 'atencao';
}

// Multiplicadores sazonais para calibrar os 12 meses históricos (Out/2025 a Set/2026)
const PERFIS_MENSAIS = [
  { mes: 10, ano: 2025, label: 'Out/25', nome: 'Outubro/2025', fatorRec: 0.94, fatorEbitda: 0.92, fatorCaixa: 0.88, destaque: 'Início do 4º trimestre e fortalecimento de contratos' },
  { mes: 11, ano: 2025, label: 'Nov/25', nome: 'Novembro/2025', fatorRec: 1.05, fatorEbitda: 1.02, fatorCaixa: 0.78, destaque: 'Campanhas promocionais e adiantamento de 13º salário' },
  { mes: 12, ano: 2025, label: 'Dez/25', nome: 'Dezembro/2025', fatorRec: 1.15, fatorEbitda: 1.14, fatorCaixa: 1.25, destaque: 'Pico sazonal de faturamento e quitação da 2ª parcela 13º' },
  { mes: 1,  ano: 2026, label: 'Jan/26', nome: 'Janeiro/2026',  fatorRec: 0.89, fatorEbitda: 0.86, fatorCaixa: 0.70, destaque: 'Ajuste anual, impostos municipais (IPTU/IPVA) e renovações' },
  { mes: 2,  ano: 2026, label: 'Fev/26', nome: 'Fevereiro/2026',fatorRec: 0.92, fatorEbitda: 0.90, fatorCaixa: 0.85, destaque: 'Mês útil reduzido e estabilização de custos operacionais' },
  { mes: 3,  ano: 2026, label: 'Mar/26', nome: 'Março/2026',    fatorRec: 1.02, fatorEbitda: 1.04, fatorCaixa: 1.10, destaque: 'Retomada de novos contratos comerciais e expansão' },
  { mes: 4,  ano: 2026, label: 'Abr/26', nome: 'Abril/2026',    fatorRec: 0.98, fatorEbitda: 1.00, fatorCaixa: 0.96, destaque: 'Fechamento do Q1 e pagamento de tributos trimestrais' },
  { mes: 5,  ano: 2026, label: 'Mai/26', nome: 'Maio/2026',     fatorRec: 1.04, fatorEbitda: 1.06, fatorCaixa: 1.08, destaque: 'Alta eficiência de conversão operacional em caixa' },
  { mes: 6,  ano: 2026, label: 'Jun/26', nome: 'Junho/2026',    fatorRec: 1.01, fatorEbitda: 1.02, fatorCaixa: 1.02, destaque: 'Encerramento de semestre e controle orçamentário' },
  { mes: 7,  ano: 2026, label: 'Jul/26', nome: 'Julho/2026',    fatorRec: 1.03, fatorEbitda: 1.05, fatorCaixa: 0.82, destaque: 'Aquisição de equipamentos de TI e investimentos' },
  { mes: 8,  ano: 2026, label: 'Ago/26', nome: 'Agosto/2026',   fatorRec: 1.08, fatorEbitda: 1.10, fatorCaixa: 1.18, destaque: 'Forte receita de serviços e recebimento em dia' },
  { mes: 9,  ano: 2026, label: 'Set/26', nome: 'Setembro/2026', fatorRec: 1.10, fatorEbitda: 1.12, fatorCaixa: 1.22, destaque: 'Fechamento do trimestre atual com recorde de geração operacional' },
];

/**
 * Gera a série histórica de 12 meses de EBITDA e Fluxo de Caixa calibrada
 * com base na DRE da empresa e bens patrimoniais ativos.
 */
export function gerarEvolucaoEbitdaFluxoCaixa12Meses(
  dre: DreData,
  bens: BemPatrimonial[],
  empresaId: string = '1'
): { dadosMensais: MesEvolucaoFinanceira[]; resumo: ResumoLTM } {
  // Base mensal de referência a partir da DRE 2026
  const baseReceitaMensal = (dre.receitaLiquida || 3070000) / 12;
  const baseEbitdaMensal = (dre.ebitda || 675000) / 12;
  const baseDeprecMensal = (dre.despesaDepreciacao || 86450) / 12;
  const baseLucroMensal = (dre.lucroLiquido || 391000) / 12;

  // Saldo inicial de caixa em 30/09/2025 (12 meses atrás)
  let saldoCaixaAcumulado = 215000;

  const dadosMensais: MesEvolucaoFinanceira[] = PERFIS_MENSAIS.map((perfil, index) => {
    // Aplica modulação sazonal
    const recLiq = Math.round(baseReceitaMensal * perfil.fatorRec);
    const ebitda = Math.round(baseEbitdaMensal * perfil.fatorEbitda);
    const deprec = Math.round(baseDeprecMensal * (0.95 + index * 0.01));
    const lucro = Math.round(baseLucroMensal * perfil.fatorEbitda * 0.98);

    // Fluxo de caixa operacional = EBITDA ajustado pela necessidade de capital de giro
    const ncgAjuste = index === 1 || index === 3 ? -14500 : index === 2 || index === 11 ? 16000 : 2000;
    const fluxoOperacional = Math.round(ebitda * 0.84 * perfil.fatorCaixa + ncgAjuste);

    // CAPEX / Investimentos pontuais (ex: em Julho e Dezembro)
    const capex = perfil.mes === 7 ? -35000 : perfil.mes === 12 ? -18000 : -6000;
    const amortizacaoDivida = -4100;
    
    // Fluxo de caixa líquido (Variação líquida do mês)
    const fluxoLiquido = fluxoOperacional + capex + amortizacaoDivida;

    // Atualiza saldo acumulado
    saldoCaixaAcumulado += fluxoLiquido;

    const margemEbitda = Number(((ebitda / recLiq) * 100).toFixed(1));
    const conversaoCaixa = Number(((fluxoOperacional / (ebitda || 1)) * 100).toFixed(1));

    // Determina tendência MoM
    const tendencia: 'alta' | 'estavel' | 'queda' =
      perfil.fatorEbitda >= 1.05 ? 'alta' : perfil.fatorEbitda < 0.95 ? 'queda' : 'estavel';

    return {
      id: `mes-${perfil.ano}-${perfil.mes}`,
      mesAno: perfil.label,
      mesAnoCompleto: perfil.nome,
      ano: perfil.ano,
      mes: perfil.mes,
      receitaLiquida: recLiq,
      ebitda,
      margemEbitda,
      depreciacao: deprec,
      lucroLiquido: lucro,
      fluxoCaixaOperacional: fluxoOperacional,
      fluxoCaixaLiquido: fluxoLiquido,
      saldoCaixaFinal: saldoCaixaAcumulado,
      conversaoCaixaEbitda: conversaoCaixa,
      tendencia,
      destaque: perfil.destaque,
    };
  });

  // Cálculos do Resumo LTM
  const ebitdaTotal = dadosMensais.reduce((acc, m) => acc + m.ebitda, 0);
  const ebitdaMedioMensal = Math.round(ebitdaTotal / dadosMensais.length);
  const margemEbitdaMedia = Number(
    (
      dadosMensais.reduce((acc, m) => acc + m.margemEbitda, 0) / dadosMensais.length
    ).toFixed(1)
  );

  const fluxoCaixaLiquidoTotal = dadosMensais.reduce((acc, m) => acc + m.fluxoCaixaLiquido, 0);
  const fluxoCaixaOperacionalTotal = dadosMensais.reduce(
    (acc, m) => acc + m.fluxoCaixaOperacional,
    0
  );
  const conversaoCaixaEbitdaMedia = Number(
    ((fluxoCaixaOperacionalTotal / ebitdaTotal) * 100).toFixed(1)
  );

  // Melhor e menor mês de EBITDA
  const ordenadoPorEbitda = [...dadosMensais].sort((a, b) => b.ebitda - a.ebitda);
  const melhorMesEbitda = ordenadoPorEbitda[0];
  const menorMesEbitda = ordenadoPorEbitda[ordenadoPorEbitda.length - 1];

  // Melhor e menor mês de Caixa
  const ordenadoPorCaixa = [...dadosMensais].sort(
    (a, b) => b.fluxoCaixaLiquido - a.fluxoCaixaLiquido
  );
  const melhorMesCaixa = ordenadoPorCaixa[0];
  const menorMesCaixa = ordenadoPorCaixa[ordenadoPorCaixa.length - 1];

  // Crescimento de Set/26 vs Out/25
  const primeiroMes = dadosMensais[0];
  const ultimoMes = dadosMensais[dadosMensais.length - 1];
  const crescimentoEbitdaMoM = Number(
    (((ultimoMes.ebitda - primeiroMes.ebitda) / primeiroMes.ebitda) * 100).toFixed(1)
  );

  const tendenciaGeral: 'crescimento_forte' | 'crescimento_estavel' | 'atencao' =
    crescimentoEbitdaMoM >= 10
      ? 'crescimento_forte'
      : crescimentoEbitdaMoM >= 0
      ? 'crescimento_estavel'
      : 'atencao';

  const resumo: ResumoLTM = {
    ebitdaTotal,
    ebitdaMedioMensal,
    margemEbitdaMedia,
    fluxoCaixaLiquidoTotal,
    fluxoCaixaOperacionalTotal,
    conversaoCaixaEbitdaMedia,
    saldoCaixaAtual: saldoCaixaAcumulado,
    melhorMesEbitda,
    menorMesEbitda,
    melhorMesCaixa,
    menorMesCaixa,
    crescimentoEbitdaMoM,
    tendenciaGeral,
  };

  return { dadosMensais, resumo };
}
