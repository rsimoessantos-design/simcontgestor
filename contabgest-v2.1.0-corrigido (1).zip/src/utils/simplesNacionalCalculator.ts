import {
  NotaFiscal,
  ApuracaoSimplesNacional,
  ItemApuracaoAnexo,
  TipoAnexoSimples,
  ReparticaoTributariaSimples,
  ResumoDocumentosPeriodo,
} from '../types';

// =========================================================================
// TABELAS OFICIAIS DO SIMPLES NACIONAL (LEI COMPLEMENTAR Nº 123/2006 & LC 155/2016)
// RESOLUÇÃO CGSN Nº 140/2018
// =========================================================================

export interface FaixaSimplesCompleta {
  faixa: number;
  descricao: string;
  limiteInferior: number;
  limiteSuperior: number;
  aliquotaNominal: number;
  parcelaDeduzir: number;
  // Percentual de repartição de cada tributo dentro da alíquota da faixa
  reparticao: {
    irpj: number;
    csll: number;
    cofins: number;
    pis: number;
    cpp: number;
    icms?: number;
    ipi?: number;
    iss?: number;
  };
}

export const TABELA_OFICIAL_ANEXO_I: FaixaSimplesCompleta[] = [
  {
    faixa: 1,
    descricao: '1ª Faixa (Até R$ 180.000,00)',
    limiteInferior: 0,
    limiteSuperior: 180000,
    aliquotaNominal: 0.04,
    parcelaDeduzir: 0,
    reparticao: { irpj: 0.055, csll: 0.035, cofins: 0.1274, pis: 0.0276, cpp: 0.415, icms: 0.34 },
  },
  {
    faixa: 2,
    descricao: '2ª Faixa (R$ 180.000,01 a R$ 360.000,00)',
    limiteInferior: 180000.01,
    limiteSuperior: 360000,
    aliquotaNominal: 0.073,
    parcelaDeduzir: 5940,
    reparticao: { irpj: 0.055, csll: 0.035, cofins: 0.1274, pis: 0.0276, cpp: 0.415, icms: 0.34 },
  },
  {
    faixa: 3,
    descricao: '3ª Faixa (R$ 360.000,01 a R$ 720.000,00)',
    limiteInferior: 360000.01,
    limiteSuperior: 720000,
    aliquotaNominal: 0.095,
    parcelaDeduzir: 13860,
    reparticao: { irpj: 0.055, csll: 0.035, cofins: 0.1274, pis: 0.0276, cpp: 0.42, icms: 0.335 },
  },
  {
    faixa: 4,
    descricao: '4ª Faixa (R$ 720.000,01 a R$ 1.800.000,00)',
    limiteInferior: 720000.01,
    limiteSuperior: 1800000,
    aliquotaNominal: 0.107,
    parcelaDeduzir: 22500,
    reparticao: { irpj: 0.055, csll: 0.035, cofins: 0.1274, pis: 0.0276, cpp: 0.42, icms: 0.335 },
  },
  {
    faixa: 5,
    descricao: '5ª Faixa (R$ 1.800.000,01 a R$ 3.600.000,00)',
    limiteInferior: 1800000.01,
    limiteSuperior: 3600000,
    aliquotaNominal: 0.143,
    parcelaDeduzir: 87300,
    reparticao: { irpj: 0.055, csll: 0.035, cofins: 0.1274, pis: 0.0276, cpp: 0.42, icms: 0.335 },
  },
  {
    faixa: 6,
    descricao: '6ª Faixa (R$ 3.600.000,01 a R$ 4.800.000,00)',
    limiteInferior: 3600000.01,
    limiteSuperior: 4800000,
    aliquotaNominal: 0.19,
    parcelaDeduzir: 378000,
    reparticao: { irpj: 0.135, csll: 0.1, cofins: 0.2827, pis: 0.0613, cpp: 0.421, icms: 0 },
  },
];

export const TABELA_OFICIAL_ANEXO_II: FaixaSimplesCompleta[] = [
  {
    faixa: 1,
    descricao: '1ª Faixa (Até R$ 180.000,00)',
    limiteInferior: 0,
    limiteSuperior: 180000,
    aliquotaNominal: 0.045,
    parcelaDeduzir: 0,
    reparticao: { irpj: 0.055, csll: 0.035, cofins: 0.1151, pis: 0.0249, cpp: 0.375, ipi: 0.075, icms: 0.32 },
  },
  {
    faixa: 2,
    descricao: '2ª Faixa (R$ 180.000,01 a R$ 360.000,00)',
    limiteInferior: 180000.01,
    limiteSuperior: 360000,
    aliquotaNominal: 0.078,
    parcelaDeduzir: 5940,
    reparticao: { irpj: 0.055, csll: 0.035, cofins: 0.1151, pis: 0.0249, cpp: 0.375, ipi: 0.075, icms: 0.32 },
  },
  {
    faixa: 3,
    descricao: '3ª Faixa (R$ 360.000,01 a R$ 720.000,00)',
    limiteInferior: 360000.01,
    limiteSuperior: 720000,
    aliquotaNominal: 0.1,
    parcelaDeduzir: 13860,
    reparticao: { irpj: 0.055, csll: 0.035, cofins: 0.1151, pis: 0.0249, cpp: 0.375, ipi: 0.075, icms: 0.32 },
  },
  {
    faixa: 4,
    descricao: '4ª Faixa (R$ 720.000,01 a R$ 1.800.000,00)',
    limiteInferior: 720000.01,
    limiteSuperior: 1800000,
    aliquotaNominal: 0.112,
    parcelaDeduzir: 22500,
    reparticao: { irpj: 0.055, csll: 0.035, cofins: 0.1151, pis: 0.0249, cpp: 0.375, ipi: 0.075, icms: 0.32 },
  },
  {
    faixa: 5,
    descricao: '5ª Faixa (R$ 1.800.000,01 a R$ 3.600.000,00)',
    limiteInferior: 1800000.01,
    limiteSuperior: 3600000,
    aliquotaNominal: 0.147,
    parcelaDeduzir: 85500,
    reparticao: { irpj: 0.055, csll: 0.035, cofins: 0.1151, pis: 0.0249, cpp: 0.375, ipi: 0.075, icms: 0.32 },
  },
  {
    faixa: 6,
    descricao: '6ª Faixa (R$ 3.600.000,01 a R$ 4.800.000,00)',
    limiteInferior: 3600000.01,
    limiteSuperior: 4800000,
    aliquotaNominal: 0.3,
    parcelaDeduzir: 720000,
    reparticao: { irpj: 0.085, csll: 0.075, cofins: 0.2096, pis: 0.0454, cpp: 0.235, ipi: 0.35, icms: 0 },
  },
];

export const TABELA_OFICIAL_ANEXO_III: FaixaSimplesCompleta[] = [
  {
    faixa: 1,
    descricao: '1ª Faixa (Até R$ 180.000,00)',
    limiteInferior: 0,
    limiteSuperior: 180000,
    aliquotaNominal: 0.06,
    parcelaDeduzir: 0,
    reparticao: { irpj: 0.04, csll: 0.035, cofins: 0.1282, pis: 0.0278, cpp: 0.434, iss: 0.335 },
  },
  {
    faixa: 2,
    descricao: '2ª Faixa (R$ 180.000,01 a R$ 360.000,00)',
    limiteInferior: 180000.01,
    limiteSuperior: 360000,
    aliquotaNominal: 0.112,
    parcelaDeduzir: 9360,
    reparticao: { irpj: 0.04, csll: 0.035, cofins: 0.1282, pis: 0.0278, cpp: 0.434, iss: 0.335 },
  },
  {
    faixa: 3,
    descricao: '3ª Faixa (R$ 360.000,01 a R$ 720.000,00)',
    limiteInferior: 360000.01,
    limiteSuperior: 720000,
    aliquotaNominal: 0.135,
    parcelaDeduzir: 17640,
    reparticao: { irpj: 0.04, csll: 0.035, cofins: 0.1282, pis: 0.0278, cpp: 0.434, iss: 0.335 },
  },
  {
    faixa: 4,
    descricao: '4ª Faixa (R$ 720.000,01 a R$ 1.800.000,00)',
    limiteInferior: 720000.01,
    limiteSuperior: 1800000,
    aliquotaNominal: 0.16,
    parcelaDeduzir: 35640,
    reparticao: { irpj: 0.04, csll: 0.035, cofins: 0.1282, pis: 0.0278, cpp: 0.434, iss: 0.335 },
  },
  {
    faixa: 5,
    descricao: '5ª Faixa (R$ 1.800.000,01 a R$ 3.600.000,00)',
    limiteInferior: 1800000.01,
    limiteSuperior: 3600000,
    aliquotaNominal: 0.21,
    parcelaDeduzir: 125640,
    reparticao: { irpj: 0.04, csll: 0.035, cofins: 0.1282, pis: 0.0278, cpp: 0.434, iss: 0.335 },
  },
  {
    faixa: 6,
    descricao: '6ª Faixa (R$ 3.600.000,01 a R$ 4.800.000,00)',
    limiteInferior: 3600000.01,
    limiteSuperior: 4800000,
    aliquotaNominal: 0.33,
    parcelaDeduzir: 648000,
    reparticao: { irpj: 0.35, csll: 0.15, cofins: 0.1603, pis: 0.0347, cpp: 0.305, iss: 0 },
  },
];

export const TABELA_OFICIAL_ANEXO_IV: FaixaSimplesCompleta[] = [
  {
    faixa: 1,
    descricao: '1ª Faixa (Até R$ 180.000,00)',
    limiteInferior: 0,
    limiteSuperior: 180000,
    aliquotaNominal: 0.045,
    parcelaDeduzir: 0,
    reparticao: { irpj: 0.188, csll: 0.152, cofins: 0.1767, pis: 0.0383, cpp: 0, iss: 0.445 },
  },
  {
    faixa: 2,
    descricao: '2ª Faixa (R$ 180.000,01 a R$ 360.000,00)',
    limiteInferior: 180000.01,
    limiteSuperior: 360000,
    aliquotaNominal: 0.09,
    parcelaDeduzir: 8100,
    reparticao: { irpj: 0.198, csll: 0.152, cofins: 0.2054, pis: 0.0446, cpp: 0, iss: 0.4 },
  },
  {
    faixa: 3,
    descricao: '3ª Faixa (R$ 360.000,01 a R$ 720.000,00)',
    limiteInferior: 360000.01,
    limiteSuperior: 720000,
    aliquotaNominal: 0.102,
    parcelaDeduzir: 12420,
    reparticao: { irpj: 0.208, csll: 0.152, cofins: 0.1973, pis: 0.0427, cpp: 0, iss: 0.4 },
  },
  {
    faixa: 4,
    descricao: '4ª Faixa (R$ 720.000,01 a R$ 1.800.000,00)',
    limiteInferior: 720000.01,
    limiteSuperior: 1800000,
    aliquotaNominal: 0.14,
    parcelaDeduzir: 39780,
    reparticao: { irpj: 0.178, csll: 0.192, cofins: 0.189, pis: 0.041, cpp: 0, iss: 0.4 },
  },
  {
    faixa: 5,
    descricao: '5ª Faixa (R$ 1.800.000,01 a R$ 3.600.000,00)',
    limiteInferior: 1800000.01,
    limiteSuperior: 3600000,
    aliquotaNominal: 0.22,
    parcelaDeduzir: 183780,
    reparticao: { irpj: 0.188, csll: 0.192, cofins: 0.1808, pis: 0.0392, cpp: 0, iss: 0.4 },
  },
  {
    faixa: 6,
    descricao: '6ª Faixa (R$ 3.600.000,01 a R$ 4.800.000,00)',
    limiteInferior: 3600000.01,
    limiteSuperior: 4800000,
    aliquotaNominal: 0.33,
    parcelaDeduzir: 828000,
    reparticao: { irpj: 0.535, csll: 0.215, cofins: 0.2055, pis: 0.0445, cpp: 0, iss: 0 },
  },
];

export const TABELA_OFICIAL_ANEXO_V: FaixaSimplesCompleta[] = [
  {
    faixa: 1,
    descricao: '1ª Faixa (Até R$ 180.000,00)',
    limiteInferior: 0,
    limiteSuperior: 180000,
    aliquotaNominal: 0.155,
    parcelaDeduzir: 0,
    reparticao: { irpj: 0.25, csll: 0.15, cofins: 0.141, pis: 0.0305, cpp: 0.2885, iss: 0.14 },
  },
  {
    faixa: 2,
    descricao: '2ª Faixa (R$ 180.000,01 a R$ 360.000,00)',
    limiteInferior: 180000.01,
    limiteSuperior: 360000,
    aliquotaNominal: 0.18,
    parcelaDeduzir: 4500,
    reparticao: { irpj: 0.23, csll: 0.15, cofins: 0.141, pis: 0.0305, cpp: 0.2785, iss: 0.17 },
  },
  {
    faixa: 3,
    descricao: '3ª Faixa (R$ 360.000,01 a R$ 720.000,00)',
    limiteInferior: 360000.01,
    limiteSuperior: 720000,
    aliquotaNominal: 0.195,
    parcelaDeduzir: 9900,
    reparticao: { irpj: 0.24, csll: 0.15, cofins: 0.1492, pis: 0.0323, cpp: 0.2385, iss: 0.19 },
  },
  {
    faixa: 4,
    descricao: '4ª Faixa (R$ 720.000,01 a R$ 1.800.000,00)',
    limiteInferior: 720000.01,
    limiteSuperior: 1800000,
    aliquotaNominal: 0.205,
    parcelaDeduzir: 17100,
    reparticao: { irpj: 0.21, csll: 0.15, cofins: 0.1574, pis: 0.0341, cpp: 0.2385, iss: 0.21 },
  },
  {
    faixa: 5,
    descricao: '5ª Faixa (R$ 1.800.000,01 a R$ 3.600.000,00)',
    limiteInferior: 1800000.01,
    limiteSuperior: 3600000,
    aliquotaNominal: 0.23,
    parcelaDeduzir: 62100,
    reparticao: { irpj: 0.23, csll: 0.125, cofins: 0.141, pis: 0.0305, cpp: 0.2385, iss: 0.235 },
  },
  {
    faixa: 6,
    descricao: '6ª Faixa (R$ 3.600.000,01 a R$ 4.800.000,00)',
    limiteInferior: 3600000.01,
    limiteSuperior: 4800000,
    aliquotaNominal: 0.305,
    parcelaDeduzir: 540000,
    reparticao: { irpj: 0.35, csll: 0.155, cofins: 0.1644, pis: 0.0356, cpp: 0.295, iss: 0 },
  },
];

export function obterTabelaOficialPorAnexo(anexo: TipoAnexoSimples): FaixaSimplesCompleta[] {
  switch (anexo) {
    case 'Anexo I':
      return TABELA_OFICIAL_ANEXO_I;
    case 'Anexo II':
      return TABELA_OFICIAL_ANEXO_II;
    case 'Anexo III':
      return TABELA_OFICIAL_ANEXO_III;
    case 'Anexo IV':
      return TABELA_OFICIAL_ANEXO_IV;
    case 'Anexo V':
      return TABELA_OFICIAL_ANEXO_V;
    default:
      return TABELA_OFICIAL_ANEXO_I;
  }
}

/**
 * Calcula a Alíquota Efetiva segundo a Lei Complementar 123/2006:
 * Alíquota Efetiva = (RBT12 × AlíquotaNominal - ParcelaDeduzir) / RBT12
 */
export function calcularAliquotaEfetivaSimples(
  rbt12: number,
  tabela: FaixaSimplesCompleta[]
): {
  faixaIndex: number;
  faixa: FaixaSimplesCompleta;
  aliquotaNominal: number;
  parcelaDeduzir: number;
  aliquotaEfetiva: number;
} {
  // Para empresas em início de atividade ou com RBT12 = 0, aplica-se a 1ª faixa diretamente
  if (rbt12 <= 0) {
    const primeira = tabela[0];
    return {
      faixaIndex: 0,
      faixa: primeira,
      aliquotaNominal: primeira.aliquotaNominal,
      parcelaDeduzir: 0,
      aliquotaEfetiva: primeira.aliquotaNominal,
    };
  }

  const faixaIndex = tabela.findIndex((f) => rbt12 <= f.limiteSuperior);
  const faixa = faixaIndex !== -1 ? tabela[faixaIndex] : tabela[tabela.length - 1];
  const idx = faixaIndex !== -1 ? faixaIndex : tabela.length - 1;

  const efetiva = (rbt12 * faixa.aliquotaNominal - faixa.parcelaDeduzir) / rbt12;
  const aliquotaEfetivaAjustada = Math.max(0.02, Math.min(efetiva, 0.40));

  return {
    faixaIndex: idx,
    faixa,
    aliquotaNominal: faixa.aliquotaNominal,
    parcelaDeduzir: faixa.parcelaDeduzir,
    aliquotaEfetiva: aliquotaEfetivaAjustada,
  };
}

/**
 * Calcula a repartição exata de cada tributo em reais para o anexo e faixa
 */
export function calcularReparticaoTributaria(
  valorDevido: number,
  faixa: FaixaSimplesCompleta,
  isSemIcms: boolean = false,
  isSemPisCofins: boolean = false
): ReparticaoTributariaSimples {
  const rep = faixa.reparticao;

  const percIrpj = rep.irpj;
  const percCsll = rep.csll;
  const percCpp = rep.cpp;
  const percIpi = rep.ipi || 0;
  const percIss = rep.iss || 0;
  const percIcms = isSemIcms ? 0 : rep.icms || 0;
  const percPis = isSemPisCofins ? 0 : rep.pis;
  const percCofins = isSemPisCofins ? 0 : rep.cofins;

  // Soma dos percentuais ativos para normalizar proporção caso tenha segregação
  const somaAtivos = percIrpj + percCsll + percCpp + percIpi + percIss + percIcms + percPis + percCofins;
  const fatorNorm = somaAtivos > 0 ? 1 / somaAtivos : 1;

  return {
    irpj: Number((valorDevido * (percIrpj * fatorNorm)).toFixed(2)),
    csll: Number((valorDevido * (percCsll * fatorNorm)).toFixed(2)),
    cofins: Number((valorDevido * (percCofins * fatorNorm)).toFixed(2)),
    pis: Number((valorDevido * (percPis * fatorNorm)).toFixed(2)),
    cpp: Number((valorDevido * (percCpp * fatorNorm)).toFixed(2)),
    icms: Number((valorDevido * (percIcms * fatorNorm)).toFixed(2)),
    ipi: Number((valorDevido * (percIpi * fatorNorm)).toFixed(2)),
    iss: Number((valorDevido * (percIss * fatorNorm)).toFixed(2)),
  };
}

/**
 * Identifica o anexo e a segregação recomendada de uma Nota Fiscal ou Cupom Fiscal
 * com base no tipo de documento, natureza da operação, CFOP e descrição dos itens.
 */
export function classificarDocumentoFiscalParaSimples(nota: NotaFiscal): {
  anexo: TipoAnexoSimples;
  modelo: '55' | '65' | 'NFSe';
  segregacao:
    | 'tributacao_integral'
    | 'substituicao_tributaria_icms'
    | 'pis_cofins_monofasico'
    | 'icms_st_e_monofasico'
    | 'exportacao'
    | 'isento_imune';
  motivoClassificacao: string;
} {
  // Modelo
  let modelo: '55' | '65' | 'NFSe' = '55';
  if (nota.tipo === 'NFCe' || (nota as any).modeloDoc === '65') {
    modelo = '65';
  } else if (nota.tipo === 'NFSe' || (nota as any).modeloDoc === 'NFSe') {
    modelo = 'NFSe';
  }

  // Se a nota já possuir classificação explícita salva:
  if (nota.anexoSimples && nota.segregacaoTributaria) {
    return {
      anexo: nota.anexoSimples,
      modelo,
      segregacao: nota.segregacaoTributaria,
      motivoClassificacao: 'Definido no cadastro do documento fiscal',
    };
  }

  const natureza = (nota.naturezaOperacao || '').toLowerCase();
  const cfop = (nota.cfopPrincipal || (nota.itens?.[0]?.cfop) || '').replace(/\D/g, '');

  // 1. Prestação de Serviços (NFSe ou CFOP de serviços)
  if (modelo === 'NFSe' || natureza.includes('serviço') || natureza.includes('suporte') || natureza.includes('consultoria') || natureza.includes('projeto')) {
    // Verificar se é atividade de TI / Engenharia sujeita ao Fator r
    if (natureza.includes('software') || natureza.includes('desenvolvimento') || natureza.includes('arquitetura') || natureza.includes('engenharia')) {
      return {
        anexo: 'Anexo III', // Padrão ou ajustado pelo Fator r
        modelo: 'NFSe',
        segregacao: 'tributacao_integral',
        motivoClassificacao: 'Serviços intelectuais/tecnológicos (sujeitos ao Fator r)',
      };
    }
    return {
      anexo: 'Anexo III',
      modelo: 'NFSe',
      segregacao: 'tributacao_integral',
      motivoClassificacao: 'Prestação de serviços em geral (Anexo III)',
    };
  }

  // 2. Indústria (Venda de produção própria / transformação)
  if (natureza.includes('produção') || natureza.includes('fabricação') || cfop.startsWith('5101') || cfop.startsWith('6101')) {
    return {
      anexo: 'Anexo II',
      modelo,
      segregacao: 'tributacao_integral',
      motivoClassificacao: 'Venda de produção própria do estabelecimento (Indústria)',
    };
  }

  // 3. Comércio (Revenda de mercadorias - Anexo I)
  // Verificar se há Substituição Tributária (CFOP 5.405 / 5.403 / ICMS ST)
  const temSt = cfop.startsWith('5405') || cfop.startsWith('5403') || natureza.includes('substituição') || natureza.includes('st');
  const temMonofasico =
    natureza.includes('monofásico') ||
    natureza.includes('eletrônicos') ||
    natureza.includes('autopeças') ||
    natureza.includes('cosmético') ||
    natureza.includes('bebida');

  if (temSt && temMonofasico) {
    return {
      anexo: 'Anexo I',
      modelo,
      segregacao: 'icms_st_e_monofasico',
      motivoClassificacao: 'Revenda com ICMS-ST (CFOP 5.405) e PIS/COFINS Monofásicos',
    };
  }

  if (temSt) {
    return {
      anexo: 'Anexo I',
      modelo,
      segregacao: 'substituicao_tributaria_icms',
      motivoClassificacao: 'Revenda de mercadoria com ICMS retido por Substituição Tributária',
    };
  }

  if (temMonofasico) {
    return {
      anexo: 'Anexo I',
      modelo,
      segregacao: 'pis_cofins_monofasico',
      motivoClassificacao: 'Revenda com PIS/COFINS sujeitos à tributação monofásica concentrada',
    };
  }

  // Comércio normal integral
  return {
    anexo: 'Anexo I',
    modelo,
    segregacao: 'tributacao_integral',
    motivoClassificacao: 'Revenda de mercadoria com tributação integral no Simples Nacional (CFOP 5.102)',
  };
}

/**
 * Apura o PGDAS-D completo da competência com base nas notas fiscais emitidas
 */
export function apurarSimplesNacionalPeriodo(params: {
  empresaId: string;
  competencia: string; // Ex: '09/2026'
  notasFiscais: NotaFiscal[];
  rbt12: number;
  folha12Meses: number;
  rpaExportacao?: number;
  observacoes?: string;
}): ApuracaoSimplesNacional {
  const { empresaId, competencia, notasFiscais, rbt12, folha12Meses, rpaExportacao = 0, observacoes } = params;

  // 1. Filtrar notas autorizadas da competência para a empresa
  const [compMes, compAno] = competencia.split('/').map(Number);
  
  const notasPeriodo = notasFiscais.filter((nf) => {
    if (nf.empresaId !== empresaId) return false;
    if (nf.status === 'cancelada' || nf.status === 'rejeitada') return false;

    // Checar data de emissão
    const dt = new Date(nf.dataEmissao);
    if (isNaN(dt.getTime())) return false;
    const mesNota = dt.getUTCMonth() + 1;
    const anoNota = dt.getUTCFullYear();

    return mesNota === compMes && anoNota === compAno;
  });

  // Estatísticas de documentos
  let totalNfeQtd = 0;
  let totalNfeVal = 0;
  let totalNfceQtd = 0;
  let totalNfceVal = 0;
  let totalNfseQtd = 0;
  let totalNfseVal = 0;

  // Agrupador por Anexo e por Segregação
  const agrupamentoAnexos: Record<
    TipoAnexoSimples,
    {
      descricao: string;
      integral: number;
      stIcms: number;
      monofasico: number;
      stEMonofasico: number;
      exportacao: number;
      isento: number;
      total: number;
    }
  > = {
    'Anexo I': {
      descricao: 'Comércio - Revenda de Mercadorias',
      integral: 0,
      stIcms: 0,
      monofasico: 0,
      stEMonofasico: 0,
      exportacao: 0,
      isento: 0,
      total: 0,
    },
    'Anexo II': {
      descricao: 'Indústria - Venda de Produção Própria',
      integral: 0,
      stIcms: 0,
      monofasico: 0,
      stEMonofasico: 0,
      exportacao: 0,
      isento: 0,
      total: 0,
    },
    'Anexo III': {
      descricao: 'Serviços - Instalação, Manutenção e Demais Serviços (Art. 18, § 5º-B)',
      integral: 0,
      stIcms: 0,
      monofasico: 0,
      stEMonofasico: 0,
      exportacao: 0,
      isento: 0,
      total: 0,
    },
    'Anexo IV': {
      descricao: 'Serviços - Construção Civil, Vigilância e Advocacia (Sem CPP no DAS)',
      integral: 0,
      stIcms: 0,
      monofasico: 0,
      stEMonofasico: 0,
      exportacao: 0,
      isento: 0,
      total: 0,
    },
    'Anexo V': {
      descricao: 'Serviços Intelectuais com Fator r < 28% (Art. 18, § 5º-I)',
      integral: 0,
      stIcms: 0,
      monofasico: 0,
      stEMonofasico: 0,
      exportacao: 0,
      isento: 0,
      total: 0,
    },
  };

  const notasIds: string[] = [];

  // Fator r: se folha12Meses / rbt12 >= 0.28 (28%)
  const fatorRCalculado = rbt12 > 0 ? folha12Meses / rbt12 : 0;
  const enquadramentoFatorR =
    fatorRCalculado >= 0.28 ? 'Anexo III' : 'Anexo V';

  for (const nota of notasPeriodo) {
    notasIds.push(nota.id);
    const val = Number(nota.valorTotal) || 0;

    // Classificar
    const classificacao = classificarDocumentoFiscalParaSimples(nota);

    // Contagem de documentos
    if (classificacao.modelo === '65') {
      totalNfceQtd += 1;
      totalNfceVal += val;
    } else if (classificacao.modelo === 'NFSe') {
      totalNfseQtd += 1;
      totalNfseVal += val;
    } else {
      totalNfeQtd += 1;
      totalNfeVal += val;
    }

    // Se for atividade de intelectuais sujeita ao fator r
    let anexoFinal = classificacao.anexo;
    if (classificacao.anexo === 'Anexo III' || classificacao.anexo === 'Anexo V') {
      const nat = (nota.naturezaOperacao || '').toLowerCase();
      if (nat.includes('software') || nat.includes('desenvolvimento') || nat.includes('engenharia') || nat.includes('arquitetura')) {
        anexoFinal = enquadramentoFatorR;
      }
    }

    const itemAgrup = agrupamentoAnexos[anexoFinal];
    itemAgrup.total += val;

    switch (classificacao.segregacao) {
      case 'substituicao_tributaria_icms':
        itemAgrup.stIcms += val;
        break;
      case 'pis_cofins_monofasico':
        itemAgrup.monofasico += val;
        break;
      case 'icms_st_e_monofasico':
        itemAgrup.stEMonofasico += val;
        break;
      case 'exportacao':
        itemAgrup.exportacao += val;
        break;
      case 'isento_imune':
        itemAgrup.isento += val;
        break;
      case 'tributacao_integral':
      default:
        itemAgrup.integral += val;
        break;
    }
  }

  // Buscar notas canceladas do período para o resumo
  const canceladas = notasFiscais.filter((nf) => {
    if (nf.empresaId !== empresaId) return false;
    if (nf.status !== 'cancelada') return false;
    const dt = new Date(nf.dataEmissao);
    return dt.getUTCMonth() + 1 === compMes && dt.getUTCFullYear() === compAno;
  });

  const resumoDocs: ResumoDocumentosPeriodo = {
    totalDocumentos: notasPeriodo.length,
    totalNfe: { quantidade: totalNfeQtd, valor: Number(totalNfeVal.toFixed(2)) },
    totalNfce: { quantidade: totalNfceQtd, valor: Number(totalNfceVal.toFixed(2)) },
    totalNfse: { quantidade: totalNfseQtd, valor: Number(totalNfseVal.toFixed(2)) },
    totalCanceladas: {
      quantidade: canceladas.length,
      valor: Number(canceladas.reduce((acc, c) => acc + (c.valorTotal || 0), 0).toFixed(2)),
    },
  };

  // 2. Processar cada Anexo ativo com receitas
  const itensAnexoApurados: ItemApuracaoAnexo[] = [];
  let totalGeralDas = 0;
  let totalIrpjGeral = 0;
  let totalCsllGeral = 0;
  let totalCofinsGeral = 0;
  let totalPisGeral = 0;
  let totalCppGeral = 0;
  let totalIcmsGeral = 0;
  let totalIpiGeral = 0;
  let totalIssGeral = 0;

  const anexosLista: TipoAnexoSimples[] = ['Anexo I', 'Anexo II', 'Anexo III', 'Anexo IV', 'Anexo V'];

  for (const anexoNome of anexosLista) {
    const dados = agrupamentoAnexos[anexoNome];
    if (dados.total <= 0) continue;

    const tabela = obterTabelaOficialPorAnexo(anexoNome);
    const calculoFaixa = calcularAliquotaEfetivaSimples(rbt12, tabela);
    const faixa = calculoFaixa.faixa;
    const aliqEfetivaBase = calculoFaixa.aliquotaEfetiva;

    // Percentuais de ICMS e PIS/COFINS na repartição
    const percIcms = faixa.reparticao.icms || 0;
    const percPis = faixa.reparticao.pis || 0;
    const percCofins = faixa.reparticao.cofins || 0;

    // Alíquotas com deduções legais de ICMS ST e PIS/COFINS Monofásicos:
    // Se a receita tem ICMS-ST, o ICMS não integra o DAS
    const aliqEfetivaSemIcms = aliqEfetivaBase * (1 - percIcms);
    // Se a receita é PIS/COFINS monofásico, deduz PIS e COFINS
    const aliqEfetivaSemPisCofins = aliqEfetivaBase * (1 - percPis - percCofins);
    // Se tiver ambos
    const aliqEfetivaSemIcmsPisCofins = aliqEfetivaBase * (1 - percIcms - percPis - percCofins);

    // Calcular parcelas devidas
    const valorIntegral = dados.integral * aliqEfetivaBase;
    const valorStIcms = dados.stIcms * aliqEfetivaSemIcms;
    const valorMonofasico = dados.monofasico * aliqEfetivaSemPisCofins;
    const valorStEMono = dados.stEMonofasico * aliqEfetivaSemIcmsPisCofins;
    const valorTotalAnexo = valorIntegral + valorStIcms + valorMonofasico + valorStEMono;

    // Repartição tributária dos valores
    const repIntegral = calcularReparticaoTributaria(valorIntegral, faixa, false, false);
    const repStIcms = calcularReparticaoTributaria(valorStIcms, faixa, true, false);
    const repMonofasico = calcularReparticaoTributaria(valorMonofasico, faixa, false, true);
    const repStMono = calcularReparticaoTributaria(valorStEMono, faixa, true, true);

    const reparticaoTotalAnexo: ReparticaoTributariaSimples = {
      irpj: Number((repIntegral.irpj + repStIcms.irpj + repMonofasico.irpj + repStMono.irpj).toFixed(2)),
      csll: Number((repIntegral.csll + repStIcms.csll + repMonofasico.csll + repStMono.csll).toFixed(2)),
      cofins: Number((repIntegral.cofins + repStIcms.cofins + repMonofasico.cofins + repStMono.cofins).toFixed(2)),
      pis: Number((repIntegral.pis + repStIcms.pis + repMonofasico.pis + repStMono.pis).toFixed(2)),
      cpp: Number((repIntegral.cpp + repStIcms.cpp + repMonofasico.cpp + repStMono.cpp).toFixed(2)),
      icms: Number((repIntegral.icms + repStIcms.icms + repMonofasico.icms + repStMono.icms).toFixed(2)),
      ipi: Number((repIntegral.ipi + repStIcms.ipi + repMonofasico.ipi + repStMono.ipi).toFixed(2)),
      iss: Number((repIntegral.iss + repStIcms.iss + repMonofasico.iss + repStMono.iss).toFixed(2)),
    };

    totalGeralDas += valorTotalAnexo;
    totalIrpjGeral += reparticaoTotalAnexo.irpj;
    totalCsllGeral += reparticaoTotalAnexo.csll;
    totalCofinsGeral += reparticaoTotalAnexo.cofins;
    totalPisGeral += reparticaoTotalAnexo.pis;
    totalCppGeral += reparticaoTotalAnexo.cpp;
    totalIcmsGeral += reparticaoTotalAnexo.icms;
    totalIpiGeral += reparticaoTotalAnexo.ipi;
    totalIssGeral += reparticaoTotalAnexo.iss;

    itensAnexoApurados.push({
      anexo: anexoNome,
      descricao: dados.descricao,
      faixaIndex: calculoFaixa.faixaIndex + 1,
      faixaDescricao: faixa.descricao,
      rbt12,
      aliquotaNominal: faixa.aliquotaNominal,
      parcelaDeduzir: faixa.parcelaDeduzir,
      aliquotaEfetivaBase: Number(aliqEfetivaBase.toFixed(6)),
      receitaBrutaPeriodo: Number(dados.total.toFixed(2)),
      receitaTributacaoIntegral: Number(dados.integral.toFixed(2)),
      receitaSubstituicaoTributariaIcms: Number((dados.stIcms + dados.stEMonofasico).toFixed(2)),
      receitaPisCofinsMonofasico: Number((dados.monofasico + dados.stEMonofasico).toFixed(2)),
      receitaExportacao: Number(dados.exportacao.toFixed(2)),
      receitaIsentaImune: Number(dados.isento.toFixed(2)),
      aliquotaEfetivaIntegral: Number(aliqEfetivaBase.toFixed(6)),
      aliquotaEfetivaSemIcms: Number(aliqEfetivaSemIcms.toFixed(6)),
      aliquotaEfetivaSemPisCofins: Number(aliqEfetivaSemPisCofins.toFixed(6)),
      aliquotaEfetivaSemIcmsPisCofins: Number(aliqEfetivaSemIcmsPisCofins.toFixed(6)),
      valorTributacaoIntegral: Number(valorIntegral.toFixed(2)),
      valorSubstituicaoTributariaIcms: Number(valorStIcms.toFixed(2)),
      valorPisCofinsMonofasico: Number(valorMonofasico.toFixed(2)),
      valorDevidoTotal: Number(valorTotalAnexo.toFixed(2)),
      reparticaoTributos: reparticaoTotalAnexo,
    });
  }

  // Receita total do período (RPA)
  const rpa = itensAnexoApurados.reduce((acc, item) => acc + item.receitaBrutaPeriodo, 0);

  // Data de vencimento: dia 20 do mês seguinte à competência
  let vencAno = compAno;
  let vencMes = compMes + 1;
  if (vencMes > 12) {
    vencMes = 1;
    vencAno += 1;
  }
  const strVencMes = String(vencMes).padStart(2, '0');
  const dataVencimento = `${vencAno}-${strVencMes}-20`;

  // Gerar dados bancários da Guia DAS
  const valorTotalArredondado = Number(totalGeralDas.toFixed(2));
  const { codigoBarras, linhaDigitavel, numeroGuia } = gerarCodigoBarrasDas({
    cnpj: '12345678000190',
    competencia,
    dataVencimento,
    valorTotal: valorTotalArredondado,
  });

  const pixQrCodePayload = gerarPixPayloadDas({
    valor: valorTotalArredondado,
    numeroGuia,
    competencia,
  });

  const apuracaoId = `pgdas_${empresaId}_${competencia.replace('/', '_')}`;

  return {
    id: apuracaoId,
    empresaId,
    competencia,
    dataApuracao: new Date().toISOString(),
    dataVencimentoDas: dataVencimento,
    status: 'apurado',
    rbt12,
    rpa: Number(rpa.toFixed(2)),
    rpaExportacao,
    folha12Meses,
    fatorRCalculado: Number(fatorRCalculado.toFixed(4)),
    fatorREnquadramento: enquadramentoFatorR,
    anexos: itensAnexoApurados,
    documentosResumo: resumoDocs,
    notasFiscaisIds: notasIds,
    valorTotalDas: valorTotalArredondado,
    totalIrpj: Number(totalIrpjGeral.toFixed(2)),
    totalCsll: Number(totalCsllGeral.toFixed(2)),
    totalCofins: Number(totalCofinsGeral.toFixed(2)),
    totalPis: Number(totalPisGeral.toFixed(2)),
    totalCpp: Number(totalCppGeral.toFixed(2)),
    totalIcms: Number(totalIcmsGeral.toFixed(2)),
    totalIpi: Number(totalIpiGeral.toFixed(2)),
    totalIss: Number(totalIssGeral.toFixed(2)),
    numeroGuiaDas: numeroGuia,
    codigoBarras,
    linhaDigitavel,
    pixQrCodePayload,
    observacoes: observacoes || 'Apuração automática realizada pelo sistema ContabGest com base nos DF-e (NF-e/NFC-e) autorizados.',
  };
}

/**
 * Gera código de barras e linha digitável oficial para Arrecadação de Tributos (Segmento 8 - FEBRABAN)
 * Campo 1: 858 + DV
 * Campo 2: Valor + DV
 * Campo 3: Órgão Arrecadador (RFB) + DV
 * Campo 4: Identificação do Simples + DV
 */
export function gerarCodigoBarrasDas(params: {
  cnpj: string;
  competencia: string;
  dataVencimento: string;
  valorTotal: number;
}): {
  codigoBarras: string;
  linhaDigitavel: string;
  numeroGuia: string;
} {
  const { valorTotal, competencia } = params;
  const valorCentavos = Math.round(valorTotal * 100).toString().padStart(11, '0');
  const compNumerica = competencia.replace(/\D/g, '');
  const seq = Math.floor(10000000 + Math.random() * 89999999).toString();
  const numeroGuia = `DAS-${compNumerica}-${seq.slice(0, 6)}`;

  // Formato da linha digitável FEBRABAN de Arrecadação Governamental: 4 blocos de 12 dígitos com DV
  // Ex: 85830000001 2 45890012345 8 67800019000 4 00000000000 1
  const campo1 = `8588${valorCentavos.slice(0, 7)}`;
  const dv1 = calcularModulo10(campo1);

  const campo2 = `${valorCentavos.slice(7, 11)}${compNumerica}${seq.slice(0, 3)}`;
  const dv2 = calcularModulo10(campo2);

  const campo3 = `${seq.slice(3, 8)}123456`;
  const dv3 = calcularModulo10(campo3);

  const campo4 = `00000000001`;
  const dv4 = calcularModulo10(campo4);

  const linhaDigitavel = `${campo1}-${dv1} ${campo2}-${dv2} ${campo3}-${dv3} ${campo4}-${dv4}`;
  const codigoBarras = `8588${valorCentavos}${compNumerica}${seq}12345600000000001`.slice(0, 44);

  return {
    codigoBarras,
    linhaDigitavel,
    numeroGuia,
  };
}

function calcularModulo10(numeroStr: string): number {
  let soma = 0;
  let peso = 2;
  for (let i = numeroStr.length - 1; i >= 0; i--) {
    let mul = Number(numeroStr[i]) * peso;
    if (mul > 9) mul = Math.floor(mul / 10) + (mul % 10);
    soma += mul;
    peso = peso === 2 ? 1 : 2;
  }
  const resto = soma % 10;
  return resto === 0 ? 0 : 10 - resto;
}

/**
 * Gera Payload EMVCo PIX Copia e Cola para pagamento do DAS
 */
export function gerarPixPayloadDas(params: {
  valor: number;
  numeroGuia: string;
  competencia: string;
}): string {
  const { valor, numeroGuia, competencia } = params;
  const valorFormatado = valor.toFixed(2);
  const txid = `DAS${competencia.replace('/', '')}${numeroGuia.replace(/\D/g, '')}`.slice(0, 25);
  
  // Payload simulado compatível com padrão EMVCo do Banco Central do Brasil para DAS
  return `00020126580014br.gov.bcb.pix0136arrecadacao-das@receita.fazenda.gov.br0218PGDAS-D ${competencia}520400005303986540${valorFormatado.length}${valorFormatado}5802BR5925RECEITA FEDERAL DO BRASIL6009BRASILIA62300526${txid}6304E9A2`;
}
