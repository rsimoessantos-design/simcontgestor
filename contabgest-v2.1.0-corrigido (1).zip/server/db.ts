import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { DEMO_PONTOS } from './demoPontos.js';
import { DEMO_FERIAS } from './demoFerias.js';
import { DEMO_RESCISOES } from './demoRescisoes.js';
import { DEMO_ESOCIAL_CONFIGURACOES, DEMO_ESOCIAL_EVENTOS } from './demoESocial.js';
import { DEMO_NOTAS_ENTRADA, DEMO_SINCRONIZACOES_SEFAZ } from './demoNotasEntrada.js';
import { DEMO_NOTAS_SIMPLES_ADICIONAIS, DEMO_APURACOES_SIMPLES } from './demoSimplesNacional.js';
import {
  DEMO_GUIAS_MEI,
  DEMO_DECLARACOES_MEI,
  DEMO_NOTAS_MEI_ADICIONAIS,
} from './demoMei.js';
import {
  calcularRescisaoCompleta,
  gerarDocumentoTRCTOficial,
} from '../src/utils/rescisaoCalculator.js';
import {
  validarDadosColaboradorESocial,
  validarParametrosFechamentoFolha,
  gerarXmlEventoESocial,
} from '../src/utils/esocialXmlGenerator.js';
import {
  User,
  Empresa,
  Cliente,
  Socio,
  Obrigacao,
  Documento,
  Certidao,
  Tarefa,
  ContaPagar,
  ContaReceber,
  CategoriaFinanceira,
  NotaFiscal,
  NotaFiscalEntrada,
  ApuracaoSimplesNacional,
  GuiaDasMei,
  DeclaracaoAnualMei,
  TipoManifestacaoDestinatario,
  StatusEscrituracaoEntrada,
  SincronizacaoSefazLog,
  CertificadoDigital,
  PendenciaEcac,
  AlvaraLicenca,
  FuncaoRH,
  Funcionario,
  HoleriteCalculado,
  ItemHolerite,
  DashboardMetrics,
  MarcacaoPonto,
  RegistroPontoDia,
  EspelhoPontoMensal,
  TipoBatidaPonto,
  OrigemBatida,
  StatusAuditoriaPonto,
  ComprovantePontoEmitido,
  PeriodoGozoFerias,
  PeriodoAquisitivoHistorico,
  AlertaFeriasItem,
  PainelAvisosFeriasResponse,
  DocumentoAvisoReciboFerias,
  StatusFeriasPeriodo,
  SeveridadeAlertaFerias,
  TipoMotivoRescisao,
  TipoAvisoPrevioRescisao,
  CalculoRescisaoResultado,
  DocumentoTRCT,
  RescisaoContratualRegistro,
  ESocialConfiguracao,
  EventoESocialRegistro,
  FechamentoFolhaESocialPainel,
  InconsistenciaValidacaoESocial,
  BackupSchedule,
  BackupHistoryItem,
  DestinoBackup,
} from '../src/types.js';

interface StoredUser extends User {
  passwordHash?: string;
}

export interface DatabaseSchema {
  version: string;
  isDemoDatabase: boolean;
  users: StoredUser[];
  empresas: Empresa[];
  clientes: Cliente[];
  socios: Socio[];
  obrigacoes: Obrigacao[];
  documentos: Documento[];
  certidoes: Certidao[];
  tarefas: Tarefa[];
  contasPagar: ContaPagar[];
  contasReceber: ContaReceber[];
  categoriasFinanceiras: CategoriaFinanceira[];
  notasFiscais: NotaFiscal[];
  notasFiscaisEntrada: NotaFiscalEntrada[];
  sincronizacoesSefaz: SincronizacaoSefazLog[];
  certificados: CertificadoDigital[];
  pendenciasEcac: PendenciaEcac[];
  alvaras: AlvaraLicenca[];
  funcoes: FuncaoRH[];
  funcionarios: Funcionario[];
  pontos: RegistroPontoDia[];
  ferias: PeriodoGozoFerias[];
  rescisoes: RescisaoContratualRegistro[];
  esocialConfiguracoes: ESocialConfiguracao[];
  esocialEventos: EventoESocialRegistro[];
  apuracoesSimples: ApuracaoSimplesNacional[];
  guiasDasMei: GuiaDasMei[];
  declaracoesAnuaisMei: DeclaracaoAnualMei[];
  backupSchedules?: BackupSchedule[];
  backupHistory?: BackupHistoryItem[];
}

const DEMO_USERS: User[] = [
  {
    id: 'user_1',
    nome: 'Carlos Eduardo Silveira',
    email: 'carlos.contador@contabgest.demo',
    cargo: 'Contador Responsável (CRC-SP 123456/O)',
    role: 'contador_admin',
    escritorioNome: 'Silveira & Associados Contabilidade [DEMO]',
  },
  {
    id: 'user_2',
    nome: 'Mariana Duarte',
    email: 'mariana.fiscal@contabgest.demo',
    cargo: 'Analista Fiscal Sênior',
    role: 'analista_fiscal',
    escritorioNome: 'Silveira & Associados Contabilidade [DEMO]',
  },
];

const DEMO_EMPRESAS: Empresa[] = [
  {
    id: 'emp_1',
    cnpj: '12.345.678/0001-90',
    razaoSocial: 'Inovatech Comércio de Eletrônicos Ltda [DEMO]',
    nomeFantasia: 'Inovatech Digital [DEMO]',
    regimeTributario: 'Simples Nacional',
    status: 'ativa',
    telefone: '(11) 3456-7890',
    email: 'contato@inovatech.demo',
    cidade: 'São Paulo',
    uf: 'SP',
    faturamentoMensal: 145000,
    qtdeFuncionarios: 12,
    responsavelContabil: 'Carlos Eduardo Silveira',
    isDemo: true,
  },
  {
    id: 'emp_2',
    cnpj: '98.765.432/0001-10',
    razaoSocial: 'Vanguarda Logística e Transportes S/A [DEMO]',
    nomeFantasia: 'Vanguarda Cargo [DEMO]',
    regimeTributario: 'Lucro Presumido',
    status: 'ativa',
    telefone: '(19) 3871-2244',
    email: 'financeiro@vanguardacargo.demo',
    cidade: 'Campinas',
    uf: 'SP',
    faturamentoMensal: 620000,
    qtdeFuncionarios: 45,
    responsavelContabil: 'Mariana Duarte',
    isDemo: true,
  },
  {
    id: 'emp_3',
    cnpj: '45.123.789/0001-55',
    razaoSocial: 'Prisma Consultoria e Arquitetura Ltda [DEMO]',
    nomeFantasia: 'Prisma Studio [DEMO]',
    regimeTributario: 'Simples Nacional',
    status: 'ativa',
    telefone: '(21) 2544-9988',
    email: 'adm@prismastudio.demo',
    cidade: 'Rio de Janeiro',
    uf: 'RJ',
    faturamentoMensal: 85000,
    qtdeFuncionarios: 6,
    responsavelContabil: 'Carlos Eduardo Silveira',
    isDemo: true,
  },
  {
    id: 'emp_4',
    cnpj: '33.888.999/0001-22',
    razaoSocial: 'Sul Metalmecânica Industrial Ltda [DEMO]',
    nomeFantasia: 'Sul Metal [DEMO]',
    regimeTributario: 'Lucro Real',
    status: 'ativa',
    telefone: '(41) 3322-1100',
    email: 'fiscal@sulmetal.demo',
    cidade: 'Curitiba',
    uf: 'PR',
    faturamentoMensal: 1850000,
    qtdeFuncionarios: 92,
    responsavelContabil: 'Mariana Duarte',
    isDemo: true,
  },
  {
    id: 'emp_5',
    cnpj: '71.222.333/0001-44',
    razaoSocial: '71.222.333 CARLOS EDUARDO DA SILVA MEI [DEMO]',
    nomeFantasia: 'Silva Suporte Tech MEI [DEMO]',
    regimeTributario: 'MEI',
    status: 'ativa',
    telefone: '(31) 3211-5544',
    email: 'silva.tech@demo.com',
    cidade: 'Belo Horizonte',
    uf: 'MG',
    faturamentoMensal: 5400,
    qtdeFuncionarios: 1,
    responsavelContabil: 'Carlos Eduardo Silveira',
    tipoAtividadeMei: 'servicos',
    categoriaMei: 'Técnico de Manutenção de Computadores e Suporte em TI',
    dataAberturaMei: '2023-03-10',
    isDemo: true,
  },
  {
    id: 'emp_6',
    cnpj: '48.999.111/0001-77',
    razaoSocial: '48.999.111 MARIANA ROCHA COMERCIO DE ROUPAS MEI [DEMO]',
    nomeFantasia: 'Boutique Bella Estilo MEI [DEMO]',
    regimeTributario: 'MEI',
    status: 'ativa',
    telefone: '(11) 98765-4321',
    email: 'contato@bellaestilo.demo',
    cidade: 'Campinas',
    uf: 'SP',
    faturamentoMensal: 6300,
    qtdeFuncionarios: 0,
    responsavelContabil: 'Carlos Eduardo Silveira',
    tipoAtividadeMei: 'comercio',
    categoriaMei: 'Comércio Varejista de Artigos do Vestuário e Acessórios',
    dataAberturaMei: '2024-01-15',
    isDemo: true,
  },
];

const DEMO_CLIENTES: Cliente[] = [
  {
    id: 'cli_1',
    empresaId: 'emp_1',
    nome: 'Distribuidora Alpha Tech Brasil Ltda [DEMO]',
    cpfCnpj: '03.222.111/0001-88',
    tipo: 'PJ',
    email: 'compras@alphadistribuidora.demo',
    telefone: '(11) 3222-9900',
    status: 'ativo',
    cidade: 'São Paulo',
    uf: 'SP',
    isDemo: true,
  },
  {
    id: 'cli_2',
    empresaId: 'emp_1',
    nome: 'Roberto Antunes de Oliveira [DEMO]',
    cpfCnpj: '234.567.890-12',
    tipo: 'PF',
    email: 'roberto.antunes@email.demo',
    telefone: '(11) 98765-4321',
    status: 'ativo',
    cidade: 'São Paulo',
    uf: 'SP',
    isDemo: true,
  },
  {
    id: 'cli_3',
    empresaId: 'emp_2',
    nome: 'Cargas Rápidas Paulista Ltda [DEMO]',
    cpfCnpj: '11.444.777/0001-33',
    tipo: 'PJ',
    email: 'operacoes@rapidaspaulista.demo',
    telefone: '(19) 3200-1122',
    status: 'ativo',
    cidade: 'Campinas',
    uf: 'SP',
    isDemo: true,
  },
  {
    id: 'cli_4',
    empresaId: 'emp_4',
    nome: 'Construtora Horizonte Brasil S/A [DEMO]',
    cpfCnpj: '44.999.000/0001-77',
    tipo: 'PJ',
    email: 'suprimentos@horizontebrasil.demo',
    telefone: '(41) 3500-8800',
    status: 'ativo',
    cidade: 'Curitiba',
    uf: 'PR',
    isDemo: true,
  },
];

const DEMO_SOCIOS: Socio[] = [
  {
    id: 'soc_1',
    empresaId: 'emp_1',
    nome: 'Renato Faria Albuquerque [DEMO]',
    cpf: '123.456.789-00',
    participacaoPercentual: 60,
    cargo: 'Sócio Administrador',
    email: 'renato@inovatech.demo',
    telefone: '(11) 99111-2233',
    proLabore: 8500,
    isDemo: true,
  },
  {
    id: 'soc_2',
    empresaId: 'emp_1',
    nome: 'Camila Siqueira Santos [DEMO]',
    cpf: '987.654.321-99',
    participacaoPercentual: 40,
    cargo: 'Sócio Cotista',
    email: 'camila@inovatech.demo',
    telefone: '(11) 98222-3344',
    proLabore: 4500,
    isDemo: true,
  },
  {
    id: 'soc_3',
    empresaId: 'emp_2',
    nome: 'Valdomiro Castanho Filho [DEMO]',
    cpf: '333.444.555-66',
    participacaoPercentual: 100,
    cargo: 'Sócio Administrador',
    email: 'valdomiro@vanguardacargo.demo',
    telefone: '(19) 99333-7788',
    proLabore: 18000,
    isDemo: true,
  },
  {
    id: 'soc_4',
    empresaId: 'emp_4',
    nome: 'Arthur Zimmermann [DEMO]',
    cpf: '555.666.777-88',
    participacaoPercentual: 70,
    cargo: 'Diretor',
    email: 'arthur@sulmetal.demo',
    telefone: '(41) 99888-1122',
    proLabore: 25000,
    isDemo: true,
  },
];

const DEMO_OBRIGACOES: Obrigacao[] = [
  {
    id: 'ob_1',
    empresaId: 'emp_1',
    titulo: 'PGDAS-D - Simples Nacional [DEMO]',
    tipo: 'Federal',
    competencia: '08/2026',
    dataVencimento: '2026-09-20',
    status: 'vencendo',
    valorTributo: 8450.32,
    responsavel: 'Carlos Eduardo Silveira',
    guiaEmitida: true,
    isDemo: true,
  },
  {
    id: 'ob_2',
    empresaId: 'emp_1',
    titulo: 'DCTFWeb Previdenciária e Trabalhista [DEMO]',
    tipo: 'Federal',
    competencia: '08/2026',
    dataVencimento: '2026-09-15',
    status: 'vencendo',
    valorTributo: 3890.15,
    responsavel: 'Mariana Duarte',
    guiaEmitida: false,
    isDemo: true,
  },
  {
    id: 'ob_3',
    empresaId: 'emp_2',
    titulo: 'EFD-Contribuições (PIS/COFINS) [DEMO]',
    tipo: 'Federal',
    competencia: '07/2026',
    dataVencimento: '2026-09-15',
    status: 'vencendo',
    valorTributo: 24650.0,
    responsavel: 'Mariana Duarte',
    guiaEmitida: true,
    isDemo: true,
  },
  {
    id: 'ob_4',
    empresaId: 'emp_2',
    titulo: 'GIA - Guia de Informação ICMS SP [DEMO]',
    tipo: 'Estadual',
    competencia: '08/2026',
    dataVencimento: '2026-09-25',
    status: 'pendente',
    valorTributo: 18720.8,
    responsavel: 'Carlos Eduardo Silveira',
    guiaEmitida: false,
    isDemo: true,
  },
  {
    id: 'ob_5',
    empresaId: 'emp_4',
    titulo: 'SPED Fiscal EFD ICMS/IPI [DEMO]',
    tipo: 'Estadual',
    competencia: '08/2026',
    dataVencimento: '2026-09-18',
    status: 'vencendo',
    valorTributo: 68400.0,
    responsavel: 'Mariana Duarte',
    guiaEmitida: true,
    isDemo: true,
  },
  {
    id: 'ob_6',
    empresaId: 'emp_4',
    titulo: 'IRPJ e CSLL Trimestral - Lucro Real [DEMO]',
    tipo: 'Federal',
    competencia: '02º Trim/2026',
    dataVencimento: '2026-07-31',
    status: 'concluida',
    valorTributo: 142000.0,
    responsavel: 'Carlos Eduardo Silveira',
    guiaEmitida: true,
    isDemo: true,
  },
  {
    id: 'ob_7',
    empresaId: 'emp_3',
    titulo: 'ISS Mensal Eletrônico - Nota Carioca [DEMO]',
    tipo: 'Municipal',
    competencia: '08/2026',
    dataVencimento: '2026-09-10',
    status: 'atrasada',
    valorTributo: 4250.0,
    responsavel: 'Carlos Eduardo Silveira',
    guiaEmitida: false,
    isDemo: true,
  },
  {
    id: 'ob_8',
    empresaId: 'emp_1',
    titulo: 'eSocial - Fechamento Folha Mensal [DEMO]',
    tipo: 'Trabalhista',
    competencia: '08/2026',
    dataVencimento: '2026-09-07',
    status: 'concluida',
    valorTributo: 1240.0,
    responsavel: 'Mariana Duarte',
    guiaEmitida: true,
    isDemo: true,
  },
];

const DEMO_DOCUMENTOS: Documento[] = [
  {
    id: 'doc_1',
    empresaId: 'emp_1',
    nome: 'Extrato_Bancario_Agosto_2026.ofx [DEMO]',
    categoria: 'Contábil',
    tamanho: '245 KB',
    dataEnvio: '2026-09-02',
    status: 'aprovado',
    enviadoPor: 'Renato Faria (Cliente)',
    extensao: 'OFX',
    isDemo: true,
  },
  {
    id: 'doc_2',
    empresaId: 'emp_1',
    nome: 'Notas_Fiscais_Entrada_XML_082026.zip [DEMO]',
    categoria: 'Fiscal',
    tamanho: '4.8 MB',
    dataEnvio: '2026-09-05',
    status: 'pendente',
    enviadoPor: 'Camila Siqueira (Cliente)',
    extensao: 'ZIP',
    isDemo: true,
  },
  {
    id: 'doc_3',
    empresaId: 'emp_2',
    nome: 'Folha_Ponto_Funcionarios_082026.pdf [DEMO]',
    categoria: 'DP/RH',
    tamanho: '1.2 MB',
    dataEnvio: '2026-09-06',
    status: 'pendente',
    enviadoPor: 'RH Vanguarda Cargo',
    extensao: 'PDF',
    isDemo: true,
  },
  {
    id: 'doc_4',
    empresaId: 'emp_4',
    nome: 'Balancete_Verificacao_Julho_2026.pdf [DEMO]',
    categoria: 'Contábil',
    tamanho: '850 KB',
    dataEnvio: '2026-08-28',
    status: 'aprovado',
    enviadoPor: 'Mariana Duarte (Contabilidade)',
    extensao: 'PDF',
    isDemo: true,
  },
  {
    id: 'doc_5',
    empresaId: 'emp_3',
    nome: 'Comprovantes_Despesas_Agosto_2026.pdf [DEMO]',
    categoria: 'Contábil',
    tamanho: '3.1 MB',
    dataEnvio: '2026-09-08',
    status: 'pendente',
    enviadoPor: 'Prisma Studio',
    extensao: 'PDF',
    isDemo: true,
  },
];

const DEMO_CERTIDOES: Certidao[] = [
  {
    id: 'cert_1',
    empresaId: 'emp_1',
    orgao: 'Receita Federal e PGFN',
    codigo: 'CND-RFB-2026-8849',
    dataEmissao: '2026-05-10',
    dataValidade: '2026-11-06',
    status: 'valida',
    isDemo: true,
  },
  {
    id: 'cert_2',
    empresaId: 'emp_1',
    orgao: 'FGTS (CRF)',
    codigo: 'CRF-CAIXA-9941-2026',
    dataEmissao: '2026-08-20',
    dataValidade: '2026-09-18',
    status: 'alerta',
    isDemo: true,
  },
  {
    id: 'cert_3',
    empresaId: 'emp_2',
    orgao: 'Trabalhista (CNDT)',
    codigo: 'CNDT-TST-4411-2026',
    dataEmissao: '2026-06-01',
    dataValidade: '2026-12-01',
    status: 'valida',
    isDemo: true,
  },
  {
    id: 'cert_4',
    empresaId: 'emp_3',
    orgao: 'Municipal (ISS)',
    codigo: 'CND-ISS-RIO-1200',
    dataEmissao: '2026-03-01',
    dataValidade: '2026-08-31',
    status: 'vencida',
    isDemo: true,
  },
];

const DEMO_TAREFAS: Tarefa[] = [
  {
    id: 'tar_1',
    empresaId: 'emp_1',
    titulo: 'Conciliação Bancária das contas Itaú e Bradesco [DEMO]',
    descricao: 'Importar extrato OFX de agosto e conciliar receitas operacionais com emissão de NF-e.',
    prioridade: 'alta',
    status: 'em_andamento',
    dataVencimento: '2026-09-14',
    responsavel: 'Carlos Eduardo Silveira',
    isDemo: true,
  },
  {
    id: 'tar_2',
    empresaId: 'emp_2',
    titulo: 'Apuração do PIS/COFINS não-cumulativo [DEMO]',
    descricao: 'Verificar créditos sobre aquisição de combustíveis e peças para transporte.',
    prioridade: 'urgente',
    status: 'a_fazer',
    dataVencimento: '2026-09-13',
    responsavel: 'Mariana Duarte',
    isDemo: true,
  },
  {
    id: 'tar_3',
    empresaId: 'emp_4',
    titulo: 'Revisão das retenções de IR e CSLL em notas de fornecedores [DEMO]',
    descricao: 'Conferir código de DARF 1708 e 5952 retidos no mês anterior.',
    prioridade: 'media',
    status: 'concluida',
    dataVencimento: '2026-09-08',
    responsavel: 'Mariana Duarte',
    isDemo: true,
  },
  {
    id: 'tar_4',
    empresaId: 'emp_5',
    titulo: 'Protocolo de registro na Junta Comercial e Alvará [DEMO]',
    descricao: 'Acompanhar deferimento da viabilidade na REDESIM para liberação da inscrição municipal.',
    prioridade: 'alta',
    status: 'em_andamento',
    dataVencimento: '2026-09-16',
    responsavel: 'Carlos Eduardo Silveira',
    isDemo: true,
  },
];

const DEMO_CATEGORIAS_FINANCEIRAS: CategoriaFinanceira[] = [
  { id: 'cat_1', nome: 'Honorários Contábeis', tipo: 'receita', cor: '#059669', isDemo: true },
  { id: 'cat_2', nome: 'Venda de Mercadorias', tipo: 'receita', cor: '#10b981', isDemo: true },
  { id: 'cat_3', nome: 'Prestação de Serviços', tipo: 'receita', cor: '#047857', isDemo: true },
  { id: 'cat_4', nome: 'Impostos e Tributos', tipo: 'despesa', cor: '#dc2626', isDemo: true },
  { id: 'cat_5', nome: 'Folha de Pagamento & Encargos', tipo: 'despesa', cor: '#ea580c', isDemo: true },
  { id: 'cat_6', nome: 'Fornecedores e Mercadorias', tipo: 'despesa', cor: '#d97706', isDemo: true },
  { id: 'cat_7', nome: 'Softwares & Infraestrutura', tipo: 'despesa', cor: '#6366f1', isDemo: true },
  { id: 'cat_8', nome: 'Aluguel & Condomínio', tipo: 'despesa', cor: '#8b5cf6', isDemo: true },
];

const DEMO_CONTAS_PAGAR: ContaPagar[] = [
  {
    id: 'cp_1',
    empresaId: 'emp_1',
    descricao: 'Fornecedor Tech Components Brasil - NF 8492 [DEMO]',
    categoriaId: 'cat_6',
    beneficiario: 'Tech Components Ltda',
    valor: 14250.0,
    dataVencimento: '2026-09-18',
    status: 'pendente',
    isDemo: true,
  },
  {
    id: 'cp_2',
    empresaId: 'emp_1',
    descricao: 'DARF - Simples Nacional Competência 08/2026 [DEMO]',
    categoriaId: 'cat_4',
    beneficiario: 'Receita Federal do Brasil',
    valor: 8450.32,
    dataVencimento: '2026-09-20',
    status: 'pendente',
    isDemo: true,
  },
  {
    id: 'cp_3',
    empresaId: 'emp_2',
    descricao: 'Folha Salarial Motoristas e Equipe Operacional [DEMO]',
    categoriaId: 'cat_5',
    beneficiario: 'Banco Itaú Folha',
    valor: 128400.0,
    dataVencimento: '2026-09-05',
    dataPagamento: '2026-09-05',
    status: 'pago',
    isDemo: true,
  },
  {
    id: 'cp_4',
    empresaId: 'emp_2',
    descricao: 'Distribuidora de Combustíveis PetroSul [DEMO]',
    categoriaId: 'cat_6',
    beneficiario: 'PetroSul S/A',
    valor: 45300.0,
    dataVencimento: '2026-09-12',
    status: 'pendente',
    isDemo: true,
  },
  {
    id: 'cp_5',
    empresaId: 'emp_3',
    descricao: 'Assinatura Licenças CAD e Adobe Cloud [DEMO]',
    categoriaId: 'cat_7',
    beneficiario: 'Autodesk do Brasil',
    valor: 3400.0,
    dataVencimento: '2026-09-10',
    status: 'vencido',
    isDemo: true,
  },
  {
    id: 'cp_6',
    empresaId: 'emp_4',
    descricao: 'Energia Elétrica Industrial - Alta Tensão [DEMO]',
    categoriaId: 'cat_8',
    beneficiario: 'Copel Distribuição S/A',
    valor: 38900.0,
    dataVencimento: '2026-09-22',
    status: 'pendente',
    isDemo: true,
  },
];

const DEMO_CONTAS_RECEBER: ContaReceber[] = [
  {
    id: 'cr_1',
    empresaId: 'emp_1',
    descricao: 'Fatura Venda Lote Eletrônicos - NF 4410 [DEMO]',
    categoriaId: 'cat_2',
    clienteId: 'cli_1',
    pagador: 'Distribuidora Alpha Tech Brasil Ltda',
    valor: 38500.0,
    dataVencimento: '2026-09-16',
    status: 'pendente',
    isDemo: true,
  },
  {
    id: 'cr_2',
    empresaId: 'emp_1',
    descricao: 'Venda Direta E-commerce B2B - NF 4412 [DEMO]',
    categoriaId: 'cat_2',
    clienteId: 'cli_2',
    pagador: 'Roberto Antunes de Oliveira',
    valor: 12600.0,
    dataVencimento: '2026-09-24',
    status: 'pendente',
    isDemo: true,
  },
  {
    id: 'cr_3',
    empresaId: 'emp_2',
    descricao: 'Frete Dedicado Campinas x Porto de Santos [DEMO]',
    categoriaId: 'cat_3',
    clienteId: 'cli_3',
    pagador: 'Cargas Rápidas Paulista Ltda',
    valor: 89400.0,
    dataVencimento: '2026-09-10',
    dataRecebimento: '2026-09-09',
    status: 'recebido',
    isDemo: true,
  },
  {
    id: 'cr_4',
    empresaId: 'emp_2',
    descricao: 'Contrato Logístico Mensal Armazenagem [DEMO]',
    categoriaId: 'cat_3',
    clienteId: 'cli_3',
    pagador: 'Cargas Rápidas Paulista Ltda',
    valor: 64000.0,
    dataVencimento: '2026-09-28',
    status: 'pendente',
    isDemo: true,
  },
  {
    id: 'cr_5',
    empresaId: 'emp_4',
    descricao: 'Fornecimento Estruturas Metálicas Mês [DEMO]',
    categoriaId: 'cat_2',
    clienteId: 'cli_4',
    pagador: 'Construtora Horizonte Brasil S/A',
    valor: 310000.0,
    dataVencimento: '2026-09-19',
    status: 'pendente',
    isDemo: true,
  },
  {
    id: 'cr_6',
    empresaId: 'emp_3',
    descricao: 'Projeto Arquitetônico Executivo - Etapa 02 [DEMO]',
    categoriaId: 'cat_3',
    pagador: 'Condomínio Solar das Palmeiras',
    valor: 22000.0,
    dataVencimento: '2026-09-05',
    status: 'vencido',
    isDemo: true,
  },
];

const DEMO_NOTAS_FISCAIS: NotaFiscal[] = [
  {
    id: 'nf_1',
    empresaId: 'emp_1',
    numero: 1450,
    serie: '1',
    tipo: 'NFe',
    naturezaOperacao: '5.102 - Venda de mercadoria adquirida de terceiros',
    destinatarioNome: 'Distribuidora Alpha Tech Brasil Ltda [DEMO]',
    destinatarioCpfCnpj: '08.123.456/0001-99',
    destinatarioEmail: 'compras@alphatech.demo',
    valorTotal: 34500.0,
    valorServicosOuProdutos: 34500.0,
    impostos: {
      icms: 4140.0,
      pis: 224.25,
      cofins: 1035.0,
    },
    itens: [
      {
        descricao: 'Microcomputador Corporativo i7 16GB SSD 512GB',
        quantidade: 10,
        valorUnitario: 3450.0,
        valorTotal: 34500.0,
      },
    ],
    dataEmissao: '2026-09-08T14:22:00Z',
    status: 'autorizada',
    chaveAcesso: '35260912345678000190550010000014501008472911',
    protocoloAutorizacao: '135260049281729',
    isDemo: true,
  },
  {
    id: 'nf_2',
    empresaId: 'emp_1',
    numero: 580,
    serie: 'E',
    tipo: 'NFSe',
    naturezaOperacao: '1.101 - Manutenção e suporte técnico de TI',
    destinatarioNome: 'Roberto Antunes de Oliveira [DEMO]',
    destinatarioCpfCnpj: '123.456.789-00',
    destinatarioEmail: 'roberto.antunes@email.demo',
    valorTotal: 4200.0,
    valorServicosOuProdutos: 4200.0,
    impostos: {
      iss: 210.0,
      pis: 27.3,
      cofins: 126.0,
    },
    itens: [
      {
        descricao: 'Serviço de configuração de servidores e segurança de rede',
        quantidade: 1,
        valorUnitario: 4200.0,
        valorTotal: 4200.0,
      },
    ],
    dataEmissao: '2026-09-10T10:15:00Z',
    status: 'autorizada',
    chaveAcesso: '35260912345678000190000010000005801008472912',
    protocoloAutorizacao: '135260049298711',
    isDemo: true,
  },
  {
    id: 'nf_3',
    empresaId: 'emp_2',
    numero: 8940,
    serie: '2',
    tipo: 'NFe',
    naturezaOperacao: '5.352 - Prestação de serviço de transporte interestadual',
    destinatarioNome: 'Cargas Rápidas Paulista Ltda [DEMO]',
    destinatarioCpfCnpj: '44.555.666/0001-22',
    destinatarioEmail: 'fiscal@cargasrapidas.demo',
    valorTotal: 89400.0,
    valorServicosOuProdutos: 89400.0,
    impostos: {
      icms: 10728.0,
      pis: 1475.1,
      cofins: 6794.4,
    },
    itens: [
      {
        descricao: 'Frete e logística refrigerada Campinas/SP -> Santos/SP Lote 902',
        quantidade: 1,
        valorUnitario: 89400.0,
        valorTotal: 89400.0,
      },
    ],
    dataEmissao: '2026-09-09T08:30:00Z',
    status: 'autorizada',
    chaveAcesso: '35260998765432000110550020000089401008472913',
    protocoloAutorizacao: '135260049301299',
    isDemo: true,
  },
  {
    id: 'nf_4',
    empresaId: 'emp_3',
    numero: 312,
    serie: 'A',
    tipo: 'NFSe',
    naturezaOperacao: 'Elaboração de projetos arquitetônicos e executivos',
    destinatarioNome: 'Condomínio Solar das Palmeiras [DEMO]',
    destinatarioCpfCnpj: '33.222.111/0001-88',
    destinatarioEmail: 'sindico@solarpalmeiras.demo',
    valorTotal: 22000.0,
    valorServicosOuProdutos: 22000.0,
    impostos: {
      iss: 1100.0,
      irpj: 330.0,
      csll: 220.0,
      pis: 143.0,
      cofins: 660.0,
    },
    itens: [
      {
        descricao: 'Projeto Executivo de Retrofit de Fachada e Hall',
        quantidade: 1,
        valorUnitario: 22000.0,
        valorTotal: 22000.0,
      },
    ],
    dataEmissao: '2026-09-04T16:00:00Z',
    status: 'autorizada',
    chaveAcesso: '35260945123789000155000010000003121008472914',
    protocoloAutorizacao: '135260049310844',
    isDemo: true,
  },
  {
    id: 'nf_5',
    empresaId: 'emp_1',
    numero: 1451,
    serie: '1',
    tipo: 'NFe',
    naturezaOperacao: '5.102 - Venda de mercadoria adquirida de terceiros',
    destinatarioNome: 'Tech Prime Informática Ltda [DEMO]',
    destinatarioCpfCnpj: '77.888.999/0001-11',
    valorTotal: 15800.0,
    valorServicosOuProdutos: 15800.0,
    impostos: {
      icms: 1896.0,
    },
    itens: [
      {
        descricao: 'Monitores Profissionais 4K 27 pol IPS',
        quantidade: 5,
        valorUnitario: 3160.0,
        valorTotal: 15800.0,
      },
    ],
    dataEmissao: '2026-09-11T11:45:00Z',
    status: 'cancelada',
    motivoCancelamento: 'Erro no cálculo do frete e desistência do comprador antes do despacho da mercadoria',
    chaveAcesso: '35260912345678000190550010000014511008472915',
    protocoloAutorizacao: '135260049325990',
    isDemo: true,
  },
];

const DEMO_CERTIFICADOS: CertificadoDigital[] = [
  {
    id: 'cert_1',
    empresaId: 'emp_1',
    titular: 'INOVATECH COMERCIO DE ELETRONICOS LTDA',
    tipo: 'A1',
    categoria: 'e-CNPJ',
    emissor: 'Certisign Autoridade Certificadora',
    cnpjCpf: '12.345.678/0001-90',
    dataEmissao: '2026-01-15',
    dataValidade: '2027-01-15',
    diasParaVencer: 125,
    status: 'valido',
    instaladoNoServidor: true,
    senhaSalva: true,
    arquivoNome: 'inovatech_ecnpj_a1_2026.pfx',
    serialNumber: '4A:78:9B:12:F3:5E:20:81',
    isDemo: true,
  },
  {
    id: 'cert_2',
    empresaId: 'emp_2',
    titular: 'VANGUARDA LOGISTICA E TRANSPORTES S/A',
    tipo: 'A1',
    categoria: 'e-CNPJ',
    emissor: 'Serasa Experian AC',
    cnpjCpf: '98.765.432/0001-10',
    dataEmissao: '2025-10-02',
    dataValidade: '2026-10-02',
    diasParaVencer: 20,
    status: 'alerta',
    instaladoNoServidor: true,
    senhaSalva: true,
    arquivoNome: 'vanguarda_cargo_a1.pfx',
    serialNumber: '1B:3C:99:A4:77:E1:12:D5',
    isDemo: true,
  },
  {
    id: 'cert_3',
    empresaId: 'emp_3',
    titular: 'PRISMA CONSULTORIA E ARQUITETURA LTDA',
    tipo: 'A1',
    categoria: 'NF-e',
    emissor: 'Soluti Autoridade Certificadora',
    cnpjCpf: '45.123.789/0001-55',
    dataEmissao: '2025-09-20',
    dataValidade: '2026-09-20',
    diasParaVencer: 8,
    status: 'expirando',
    instaladoNoServidor: true,
    senhaSalva: true,
    arquivoNome: 'prisma_nfe_soluti.pfx',
    serialNumber: '77:E2:44:A9:11:80:CC:54',
    isDemo: true,
  },
  {
    id: 'cert_4',
    empresaId: 'emp_4',
    titular: 'METALURGICA ALVORADA INDUSTRIAL LTDA',
    tipo: 'A3',
    categoria: 'e-CNPJ',
    emissor: 'Valid Certificadora Digital',
    cnpjCpf: '33.444.555/0001-66',
    dataEmissao: '2024-05-10',
    dataValidade: '2027-05-10',
    diasParaVencer: 605,
    status: 'valido',
    instaladoNoServidor: false,
    senhaSalva: false,
    serialNumber: '88:01:23:45:67:89:AB:CD',
    isDemo: true,
  },
  {
    id: 'cert_5',
    empresaId: 'emp_1',
    titular: 'CARLOS EDUARDO SILVEIRA (SOCIO)',
    tipo: 'A1',
    categoria: 'e-CPF',
    emissor: 'Certisign AC',
    cnpjCpf: '123.456.789-00',
    dataEmissao: '2025-08-10',
    dataValidade: '2026-08-10',
    diasParaVencer: -33,
    status: 'expirado',
    instaladoNoServidor: false,
    senhaSalva: false,
    arquivoNome: 'carlos_ecpf_antigo.pfx',
    serialNumber: '99:AA:BB:CC:DD:EE:FF:00',
    isDemo: true,
  },
];

const DEMO_PENDENCIAS_ECAC: PendenciaEcac[] = [
  {
    id: 'ecac_1',
    empresaId: 'emp_1',
    codigo: 'PEND-001/2026',
    titulo: 'Divergência GFIP x DCTFWeb - Competência 07/2026',
    descricao: 'Identificada divergência de valores apurados na guia da Previdência Social em relação à escrituração transmitida no eSocial/DCTFWeb.',
    orgao: 'Receita Federal',
    gravidade: 'alta',
    valorEnvolvido: 2340.5,
    dataDeteccao: '2026-08-25',
    status: 'pendente',
    acaoRecomendada: 'Transmitir DCTFWeb retificadora da competência 07/2026 ou compensar saldo via DCOMP Web.',
    isDemo: true,
  },
  {
    id: 'ecac_2',
    empresaId: 'emp_1',
    codigo: 'PEND-002/2026',
    titulo: 'Ausência de Transmissão EFD-Reinf Evento R-4010/R-4020',
    descricao: 'Falta de evento periódico de retenção de IRRF/CSLL sobre notas de serviços tomados no mês 07/2026.',
    orgao: 'Receita Federal',
    gravidade: 'media',
    valorEnvolvido: 580.0,
    dataDeteccao: '2026-08-28',
    status: 'resolvida',
    protocoloRegularizacao: 'REC-RFB-20260905-98124',
    resolvidoEm: '2026-09-05T14:30:00Z',
    acaoRecomendada: 'Transmitir lote complementar de eventos periódicos no e-CAC.',
    isDemo: true,
  },
  {
    id: 'ecac_3',
    empresaId: 'emp_2',
    codigo: 'PEND-003/2026',
    titulo: 'Débito Inscrito em Dívida Ativa da União - PGFN',
    descricao: 'Inscrição em Dívida Ativa relativa a saldo de PIS/COFINS de período anterior com termo de cobrança executiva.',
    orgao: 'PGFN',
    gravidade: 'critica',
    valorEnvolvido: 18450.0,
    dataDeteccao: '2026-08-15',
    status: 'pendente',
    acaoRecomendada: 'Aderir ao parcelamento no portal Regularize (PGFN) ou quitar via DARF com acréscimos legais para desbloquear CND.',
    isDemo: true,
  },
  {
    id: 'ecac_4',
    empresaId: 'emp_2',
    codigo: 'PEND-004/2026',
    titulo: 'Mensagem DTE: Intimação de Malha Fiscal PJ Cruzamento DIPJ/ECF',
    descricao: 'Aviso de inconsistência no Lalur/Lacs entre receita bruta declarada e movimentação bancária informada na e-Financeira.',
    orgao: 'DTE',
    gravidade: 'alta',
    valorEnvolvido: 12300.0,
    dataDeteccao: '2026-09-01',
    status: 'em_regularizacao',
    protocoloRegularizacao: 'PROTO-DTE-2026-091104',
    acaoRecomendada: 'Apresentar esclarecimentos ou retificar ECF no prazo de 30 dias pelo e-CAC.',
    isDemo: true,
  },
  {
    id: 'ecac_5',
    empresaId: 'emp_3',
    codigo: 'PEND-005/2026',
    titulo: 'Notificação do Simples Nacional: Pendência Cadastral no CNPJ',
    descricao: 'Necessidade de atualização do QSA (Quadro de Sócios e Administradores) após alteração contratual não averbada.',
    orgao: 'Simples Nacional',
    gravidade: 'media',
    valorEnvolvido: 0,
    dataDeteccao: '2026-09-02',
    status: 'resolvida',
    protocoloRegularizacao: 'REDESIM-SP-2026-090881',
    resolvidoEm: '2026-09-08T09:15:00Z',
    acaoRecomendada: 'Protocolar DBE (Documento Básico de Entrada) no Coletor Nacional da Redesim.',
    isDemo: true,
  },
  {
    id: 'ecac_6',
    empresaId: 'emp_4',
    codigo: 'PEND-006/2026',
    titulo: 'Falta de Recolhimento Saldo Devedor IPI Competência 06/2026',
    descricao: 'Apuração do livro fiscal indicou saldo a recolher sem DARF correspondente vinculado no sistema de cobrança da RFB.',
    orgao: 'Receita Federal',
    gravidade: 'critica',
    valorEnvolvido: 34200.0,
    dataDeteccao: '2026-08-10',
    status: 'pendente',
    acaoRecomendada: 'Emitir DARF complementar com código 5123 ou vincular pagamento efetuado no e-CAC.',
    isDemo: true,
  },
];

const DEMO_ALVARAS: AlvaraLicenca[] = [
  {
    id: 'alv_1',
    empresaId: 'emp_1',
    tipo: 'Alvará de Funcionamento',
    orgaoEmissor: 'Prefeitura Municipal de São Paulo - Subprefeitura Sé',
    numeroAlvara: 'ALV-SP-2024/098412',
    numeroClcbAvcb: 'AVCB-SP-2025-44912',
    numeroIptuPredio: '012.345.0089-1',
    areaImovel: 650.0,
    areaConstruida: 520.0,
    areaUtilizada: 380.0,
    numeroCadastroImobiliario: 'SQL-0123450089',
    numeroInscricaoMunicipal: '4.891.204-8',
    dataEmissao: '2024-03-10',
    dataValidade: '2027-03-10',
    diasParaVencer: 178,
    status: 'vigente',
    documentoAnexo: 'alvara_funcionamento_sp_inovatech.pdf',
    responsavelTecnico: 'Eng. Marcelo Albuquerque (CREA-SP 506129)',
    artRrtNumero: 'ART-2024-9912048',
    observacoes: 'Alvará definitivo expedido com base no zoneamento ZEU e CNAE de comércio atacadista.',
    isDemo: true,
  },
  {
    id: 'alv_2',
    empresaId: 'emp_1',
    tipo: 'Alvará do Corpo de Bombeiros (AVCB/CLCB)',
    orgaoEmissor: 'Corpo de Bombeiros Militar do Estado de SP (CBMSP)',
    numeroAlvara: 'AVCB-44912/2025',
    numeroClcbAvcb: 'AVCB-44912/2025',
    numeroIptuPredio: '012.345.0089-1',
    areaImovel: 650.0,
    areaConstruida: 520.0,
    areaUtilizada: 380.0,
    numeroCadastroImobiliario: 'SQL-0123450089',
    numeroInscricaoMunicipal: '4.891.204-8',
    dataEmissao: '2025-10-15',
    dataValidade: '2026-10-15',
    diasParaVencer: 33,
    status: 'vencendo',
    protocoloRenovacao: 'PROC-CBMSP-2026-8812',
    dataSolicitacaoRenovacao: '2026-09-02',
    documentoAnexo: 'avcb_bombeiros_cbmsp_2025.pdf',
    responsavelTecnico: 'Eng. Segurança do Trabalho Renata Rios (CREA-SP 491022)',
    artRrtNumero: 'ART-CB-2025-00129',
    observacoes: 'Vistoria agendada para 28/09. Equipamentos de combate a incêndio e iluminação de emergência inspecionados.',
    isDemo: true,
  },
  {
    id: 'alv_3',
    empresaId: 'emp_1',
    tipo: 'Alvará Sanitário',
    orgaoEmissor: 'Coordenação de Vigilância em Saúde (COVISA-SP)',
    numeroAlvara: 'VISA-SP-2024/7712',
    numeroIptuPredio: '012.345.0089-1',
    areaImovel: 650.0,
    areaConstruida: 520.0,
    areaUtilizada: 80.0,
    numeroCadastroImobiliario: 'SQL-0123450089',
    numeroInscricaoMunicipal: '4.891.204-8',
    dataEmissao: '2024-08-01',
    dataValidade: '2025-08-01',
    diasParaVencer: -408,
    status: 'em_renovacao',
    protocoloRenovacao: 'COVISA-PROC-2026/049182',
    dataSolicitacaoRenovacao: '2026-08-15',
    observacoes: 'Aguardando publicação em Diário Oficial do deferimento da renovação sanitária para depósito de componentes.',
    isDemo: true,
  },
  {
    id: 'alv_4',
    empresaId: 'emp_2',
    tipo: 'Licença Ambiental (LP/LI/LO)',
    orgaoEmissor: 'INEA - Instituto Estadual do Ambiente (RJ)',
    numeroAlvara: 'LO-INEA-004921/2023',
    numeroIptuPredio: '2.840.119-0',
    areaImovel: 12500.0,
    areaConstruida: 6800.0,
    areaUtilizada: 6800.0,
    numeroCadastroImobiliario: 'CAD-IMO-RJ-98210',
    numeroInscricaoMunicipal: '9.812.340-1',
    dataEmissao: '2023-09-20',
    dataValidade: '2026-09-20',
    diasParaVencer: 8,
    status: 'vencendo',
    protocoloRenovacao: 'INEA-E-07/50012/2026',
    dataSolicitacaoRenovacao: '2026-05-18',
    responsavelTecnico: 'Dra. Juliana Furtado (CRQ-III 03214)',
    artRrtNumero: 'CRQ-TR-2023-881',
    observacoes: 'Licença de Operação (LO) para pátio logístico e abastecimento de veículos pesados. Protocolo de renovação tempestivo.',
    isDemo: true,
  },
  {
    id: 'alv_5',
    empresaId: 'emp_2',
    tipo: 'Alvará do Corpo de Bombeiros (AVCB/CLCB)',
    orgaoEmissor: 'CBMERJ - Corpo de Bombeiros Militar do Estado do RJ',
    numeroAlvara: 'CBMERJ-LA-2024/9914',
    numeroClcbAvcb: 'CLCB-RJ-2024-9914',
    numeroIptuPredio: '2.840.119-0',
    areaImovel: 12500.0,
    areaConstruida: 6800.0,
    areaUtilizada: 6800.0,
    numeroCadastroImobiliario: 'CAD-IMO-RJ-98210',
    numeroInscricaoMunicipal: '9.812.340-1',
    dataEmissao: '2024-05-12',
    dataValidade: '2027-05-12',
    diasParaVencer: 607,
    status: 'vigente',
    responsavelTecnico: 'Cap. Ref. Bombeiro Alexandre Paes',
    observacoes: 'Certificado de Licenciamento do Corpo de Bombeiros com hidrantes e sistema de espuma.',
    isDemo: true,
  },
  {
    id: 'alv_6',
    empresaId: 'emp_4',
    tipo: 'Licença Ambiental (LP/LI/LO)',
    orgaoEmissor: 'IAT - Instituto Água e Terra (Paraná)',
    numeroAlvara: 'LO-IAT-PR-40192/2022',
    numeroIptuPredio: '55.109.283.001-4',
    areaImovel: 18400.0,
    areaConstruida: 9200.0,
    areaUtilizada: 8500.0,
    numeroCadastroImobiliario: 'CAD-CWB-55109',
    numeroInscricaoMunicipal: '01.049.281-7',
    dataEmissao: '2022-06-10',
    dataValidade: '2026-06-10',
    diasParaVencer: -94,
    status: 'vencido',
    responsavelTecnico: 'Eng. Ambiental Roberto Meireles (CREA-PR 41092)',
    artRrtNumero: 'ART-PR-2022-09412',
    observacoes: 'Alerta Crítico: Licença de Operação industrial expirada há mais de 90 dias. Necessário protocolar com urgência para evitar autuação.',
    isDemo: true,
  },
  {
    id: 'alv_7',
    empresaId: 'emp_4',
    tipo: 'Alvará Sanitário',
    orgaoEmissor: 'Secretaria Municipal da Saúde de Curitiba - Vigilância Sanitária',
    numeroAlvara: 'VISA-CWB-2025/1109',
    numeroIptuPredio: '55.109.283.001-4',
    areaImovel: 18400.0,
    areaConstruida: 9200.0,
    areaUtilizada: 1200.0,
    numeroCadastroImobiliario: 'CAD-CWB-55109',
    numeroInscricaoMunicipal: '01.049.281-7',
    dataEmissao: '2025-11-20',
    dataValidade: '2026-11-20',
    diasParaVencer: 69,
    status: 'vigente',
    observacoes: 'Válido para o refeitório industrial e ambulatório médico ocupacional.',
    isDemo: true,
  },
  {
    id: 'alv_8',
    empresaId: 'emp_5',
    tipo: 'Alvará Sanitário',
    orgaoEmissor: 'Vigilância Sanitária Municipal de Belo Horizonte (VISA-BH)',
    numeroAlvara: 'VISA-BH-2026/03912',
    numeroIptuPredio: '810.293.001-0',
    areaImovel: 180.0,
    areaConstruida: 150.0,
    areaUtilizada: 150.0,
    numeroCadastroImobiliario: 'BH-CAD-810293',
    numeroInscricaoMunicipal: '7.129.803-0',
    dataEmissao: '2026-02-10',
    dataValidade: '2027-02-10',
    diasParaVencer: 151,
    status: 'vigente',
    responsavelTecnico: 'Nutricionista Fabiana Guimarães (CRN-9 1042)',
    observacoes: 'Manipulação e fracionamento de alimentos saudáveis e suplementos naturais. Manual de BPF aprovado.',
    isDemo: true,
  },
  {
    id: 'alv_9',
    empresaId: 'emp_5',
    tipo: 'Alvará de Funcionamento',
    orgaoEmissor: 'Prefeitura Municipal de Belo Horizonte (PBH)',
    numeroAlvara: 'ALV-PBH-2026-004128',
    numeroClcbAvcb: 'CLCB-MG-2026-7781',
    numeroIptuPredio: '810.293.001-0',
    areaImovel: 180.0,
    areaConstruida: 150.0,
    areaUtilizada: 150.0,
    numeroCadastroImobiliario: 'BH-CAD-810293',
    numeroInscricaoMunicipal: '7.129.803-0',
    dataEmissao: '2026-03-01',
    dataValidade: '2028-03-01',
    diasParaVencer: 535,
    status: 'vigente',
    observacoes: 'Alvará de Localização e Funcionamento com dispensa de risco B conforme Decreto Municipal.',
    isDemo: true,
  },
];

const DEMO_FUNCOES: FuncaoRH[] = [
  {
    id: 'fnc_1',
    empresaId: 'emp_1',
    titulo: 'Desenvolvedor Full Stack Pleno',
    cbo: '2124-05',
    departamento: 'Tecnologia da Informação',
    salarioBase: 7800.0,
    cargaHorariaSemanal: 40,
    nivel: 'Pleno',
    descricao: 'Desenvolvimento e sustentação de sistemas web e APIs em TypeScript e Node.js.',
    requisitos: 'Superior em Computação ou correlatas. 3+ anos em React e APIs REST.',
    adicionalPericulosidade: false,
    adicionalInsalubridade: 'nenhum',
    isDemo: true,
  },
  {
    id: 'fnc_2',
    empresaId: 'emp_1',
    titulo: 'Engenheiro de DevOps & Cloud Sênior',
    cbo: '2124-20',
    departamento: 'Infraestrutura & Cloud',
    salarioBase: 13500.0,
    cargaHorariaSemanal: 40,
    nivel: 'Sênior',
    descricao: 'Gestão de infraestrutura em nuvem, esteiras de CI/CD, Kubernetes e segurança.',
    requisitos: 'Certificação GCP ou AWS, experiência em Docker, Terraform e observabilidade.',
    adicionalPericulosidade: false,
    adicionalInsalubridade: 'nenhum',
    isDemo: true,
  },
  {
    id: 'fnc_3',
    empresaId: 'emp_1',
    titulo: 'Assistente Comercial e Suporte Técnico',
    cbo: '4110-10',
    departamento: 'Comercial & Atendimento',
    salarioBase: 3100.0,
    cargaHorariaSemanal: 44,
    nivel: 'Júnior',
    descricao: 'Atendimento a clientes, suporte de 1º nível e demonstração de soluções.',
    requisitos: 'Ensino Médio completo ou Superior cursando. Boa comunicação interpessoal.',
    adicionalPericulosidade: false,
    adicionalInsalubridade: 'nenhum',
    isDemo: true,
  },
  {
    id: 'fnc_4',
    empresaId: 'emp_2',
    titulo: 'Motorista de Carreta Articulada',
    cbo: '7825-10',
    departamento: 'Operações & Transporte',
    salarioBase: 4200.0,
    cargaHorariaSemanal: 44,
    nivel: 'Pleno',
    descricao: 'Transporte interestadual de cargas gerais e produtos controlados.',
    requisitos: 'CNH Categoria E com EAR e curso MOPP atualizado.',
    adicionalPericulosidade: true,
    adicionalInsalubridade: 'nenhum',
    isDemo: true,
  },
  {
    id: 'fnc_5',
    empresaId: 'emp_2',
    titulo: 'Analista de Logística e Rastreamento',
    cbo: '4110-05',
    departamento: 'Logística & Gerenciamento de Risco',
    salarioBase: 4800.0,
    cargaHorariaSemanal: 44,
    nivel: 'Pleno',
    descricao: 'Monitoramento de frota, emissão de CTe/MDFe e conferência de entregas.',
    requisitos: 'Tecnólogo em Logística ou Administração. Domínio de sistemas TMS.',
    adicionalPericulosidade: false,
    adicionalInsalubridade: 'nenhum',
    isDemo: true,
  },
  {
    id: 'fnc_6',
    empresaId: 'emp_3',
    titulo: 'Arquiteto Coordenador de Projetos',
    cbo: '2141-05',
    departamento: 'Projetos Arquitetônicos',
    salarioBase: 9600.0,
    cargaHorariaSemanal: 40,
    nivel: 'Coordenação',
    descricao: 'Coordenação técnica de equipe, compatibilização de projetos BIM e emissão de ART/RRT.',
    requisitos: 'Graduação em Arquitetura com CAU ativo. Domínio de Revit e modelagem 3D.',
    adicionalPericulosidade: false,
    adicionalInsalubridade: 'nenhum',
    isDemo: true,
  },
  {
    id: 'fnc_7',
    empresaId: 'emp_4',
    titulo: 'Torneiro Mecânico CNC Sênior',
    cbo: '7214-05',
    departamento: 'Usinagem & Metalurgia',
    salarioBase: 5100.0,
    cargaHorariaSemanal: 44,
    nivel: 'Sênior',
    descricao: 'Programação e operação de tornos CNC e leitura de desenhos mecânicos de precisão.',
    requisitos: 'Formação SENAI em Mecânica de Usinagem. Experiência de 5+ anos.',
    adicionalPericulosidade: false,
    adicionalInsalubridade: 'grau_medio',
    isDemo: true,
  },
  {
    id: 'fnc_8',
    empresaId: 'emp_5',
    titulo: 'Nutricionista de Controle de Qualidade',
    cbo: '2237-10',
    departamento: 'Qualidade & Boas Práticas',
    salarioBase: 5400.0,
    cargaHorariaSemanal: 40,
    nivel: 'Pleno',
    descricao: 'Supervisão de Boas Práticas de Fabricação (BPF) e auditorias sanitárias.',
    requisitos: 'Bacharelado em Nutrição com registro ativo no CRN.',
    adicionalPericulosidade: false,
    adicionalInsalubridade: 'nenhum',
    isDemo: true,
  },
  {
    id: 'fnc_9',
    empresaId: 'todas',
    titulo: 'Assistente Administrativo Financeiro',
    cbo: '4110-10',
    departamento: 'Administrativo & Financeiro',
    salarioBase: 2650.0,
    cargaHorariaSemanal: 44,
    nivel: 'Júnior',
    descricao: 'Conciliação bancária, lançamento de notas fiscais e controle de arquivos.',
    requisitos: 'Ensino Médio completo ou Superior cursando Administração/Contabilidade.',
    adicionalPericulosidade: false,
    adicionalInsalubridade: 'nenhum',
    isDemo: true,
  },
  {
    id: 'fnc_10',
    empresaId: 'todas',
    titulo: 'Estagiário de Ensino Superior',
    cbo: '2124-05',
    departamento: 'Tecnologia / Operações',
    salarioBase: 1600.0,
    cargaHorariaSemanal: 30,
    nivel: 'Estagiário',
    descricao: 'Apoio em rotinas de suporte, organização de documentação e rotinas assistidas.',
    requisitos: 'Cursando Ensino Superior a partir do 3º semestre.',
    adicionalPericulosidade: false,
    adicionalInsalubridade: 'nenhum',
    isDemo: true,
  },
];

const DEMO_FUNCIONARIOS: Funcionario[] = [
  {
    id: 'func_1',
    empresaId: 'emp_1',
    matricula: 'ESOC-00104',
    nomeCompleto: 'Gabriel Ramos de Oliveira',
    cpf: '234.567.890-12',
    rg: '44.891.203-X',
    rgOrgaoEmissor: 'SSP/SP',
    dataNascimento: '1994-06-15',
    sexo: 'M',
    estadoCivil: 'Casado(a)',
    nomeMae: 'Tereza Cristina Ramos de Oliveira',
    nomePai: 'Antônio Marcos de Oliveira',
    pisPasep: '124.89102.34-5',
    ctpsNumero: '98412',
    ctpsSerie: '002',
    ctpsUf: 'SP',
    email: 'gabriel.oliveira@inovatech.demo',
    telefone: '(11) 98712-3401',
    whatsapp: '(11) 98712-3401',
    cep: '01310-200',
    logradouro: 'Avenida Paulista',
    numero: '1842',
    complemento: 'Apto 64',
    bairro: 'Bela Vista',
    cidade: 'São Paulo',
    uf: 'SP',
    funcaoId: 'fnc_1',
    cargoNome: 'Desenvolvedor Full Stack Pleno',
    cbo: '2124-05',
    departamento: 'Tecnologia da Informação',
    tipoContrato: 'CLT Indeterminado',
    regimeTrabalho: 'hibrido',
    dataAdmissao: '2023-04-10',
    terminoExperiencia: '2023-07-10',
    salarioBase: 7800.0,
    adicionaisTotal: 0,
    status: 'ativo',
    bancoNome: 'Banco Itaú Unibanco (341)',
    bancoAgencia: '0412',
    bancoConta: '39102-8',
    chavePix: '234.567.890-12',
    valeTransporte: false,
    valorVrVaMensal: 950.0,
    planoSaude: true,
    dependentes: [
      {
        id: 'dep_1',
        nome: 'Enzo Ramos de Oliveira',
        parentesco: 'Filho(a)',
        cpf: '541.298.102-99',
        dataNascimento: '2020-08-22',
        deducaoIrrf: true,
        salarioFamilia: false,
      },
    ],
    periodoAquisitivoInicio: '2024-04-10',
    periodoAquisitivoFim: '2025-04-09',
    limiteConcessivoFerias: '2026-03-09',
    diasFeriasSaldo: 30,
    dataUltimoAso: '2025-04-05',
    dataValidadeAso: '2026-04-05',
    observacoes: 'Colaborador com excelente desempenho técnico. Elegível para plano de carreira sênior.',
    isDemo: true,
  },
  {
    id: 'func_2',
    empresaId: 'emp_1',
    matricula: 'ESOC-00088',
    nomeCompleto: 'Beatriz Souza Martins',
    cpf: '345.678.901-23',
    rg: '38.102.944-1',
    rgOrgaoEmissor: 'SSP/SP',
    dataNascimento: '1989-11-20',
    sexo: 'F',
    estadoCivil: 'Casado(a)',
    nomeMae: 'Lúcia Helena Souza Martins',
    nomePai: 'Cláudio Martins',
    pisPasep: '135.90123.45-6',
    ctpsNumero: '10294',
    ctpsSerie: '001',
    ctpsUf: 'SP',
    email: 'beatriz.martins@inovatech.demo',
    telefone: '(11) 97621-9980',
    whatsapp: '(11) 97621-9980',
    cep: '04538-133',
    logradouro: 'Rua Pedroso Alvarenga',
    numero: '1200',
    complemento: 'Conjunto 81',
    bairro: 'Itaim Bibi',
    cidade: 'São Paulo',
    uf: 'SP',
    funcaoId: 'fnc_2',
    cargoNome: 'Engenheiro de DevOps & Cloud Sênior',
    cbo: '2124-20',
    departamento: 'Infraestrutura & Cloud',
    tipoContrato: 'CLT Indeterminado',
    regimeTrabalho: 'remoto',
    dataAdmissao: '2022-01-15',
    terminoExperiencia: '2022-04-15',
    salarioBase: 13500.0,
    adicionaisTotal: 0,
    status: 'ferias',
    bancoNome: 'Banco Bradesco (237)',
    bancoAgencia: '1820',
    bancoConta: '29810-1',
    chavePix: 'beatriz.martins@email.demo',
    valeTransporte: false,
    valorVrVaMensal: 1100.0,
    planoSaude: true,
    dependentes: [
      {
        id: 'dep_2',
        nome: 'Alice Souza Martins',
        parentesco: 'Filho(a)',
        cpf: '612.304.991-00',
        dataNascimento: '2018-03-14',
        deducaoIrrf: true,
        salarioFamilia: false,
      },
      {
        id: 'dep_3',
        nome: 'Davi Souza Martins',
        parentesco: 'Filho(a)',
        cpf: '719.821.401-22',
        dataNascimento: '2021-10-09',
        deducaoIrrf: true,
        salarioFamilia: false,
      },
    ],
    periodoAquisitivoInicio: '2024-01-15',
    periodoAquisitivoFim: '2025-01-14',
    limiteConcessivoFerias: '2025-12-14',
    diasFeriasSaldo: 10,
    dataUltimoAso: '2025-01-10',
    dataValidadeAso: '2026-01-10',
    observacoes: 'Em gozo de férias no período de 01/09/2026 a 20/09/2026. Retorno em 21/09.',
    isDemo: true,
  },
  {
    id: 'func_3',
    empresaId: 'emp_1',
    matricula: 'ESOC-00122',
    nomeCompleto: 'Lucas Mendes Prado',
    cpf: '456.789.012-34',
    rg: '52.981.002-8',
    rgOrgaoEmissor: 'SSP/SP',
    dataNascimento: '2003-02-18',
    sexo: 'M',
    estadoCivil: 'Solteiro(a)',
    nomeMae: 'Sandra Regina Mendes Prado',
    pisPasep: '146.01234.56-7',
    ctpsNumero: '88102',
    ctpsSerie: '003',
    ctpsUf: 'SP',
    email: 'lucas.prado@inovatech.demo',
    telefone: '(11) 99123-4567',
    whatsapp: '(11) 99123-4567',
    cep: '03088-000',
    logradouro: 'Rua Cantagalo',
    numero: '450',
    bairro: 'Tatuapé',
    cidade: 'São Paulo',
    uf: 'SP',
    funcaoId: 'fnc_10',
    cargoNome: 'Estagiário de Ensino Superior',
    cbo: '2124-05',
    departamento: 'Tecnologia / Operações',
    tipoContrato: 'Estágio',
    regimeTrabalho: 'presencial',
    dataAdmissao: '2024-02-01',
    terminoContrato: '2026-09-30',
    terminoExperiencia: '2026-09-30',
    salarioBase: 1600.0,
    adicionaisTotal: 0,
    status: 'ativo',
    bancoNome: 'Nubank (260)',
    bancoAgencia: '0001',
    bancoConta: '8912405-1',
    chavePix: 'lucas.prado@email.demo',
    valeTransporte: true,
    valorVrVaMensal: 600.0,
    planoSaude: false,
    dependentes: [],
    diasFeriasSaldo: 15,
    dataUltimoAso: '2024-02-01',
    dataValidadeAso: '2026-02-01',
    observacoes: 'Termo de Compromisso de Estágio com a Universidade Presbiteriana Mackenzie.',
    isDemo: true,
  },
  {
    id: 'func_4',
    empresaId: 'emp_2',
    matricula: 'ESOC-00210',
    nomeCompleto: 'Valdir Antonio dos Santos',
    cpf: '567.890.123-45',
    rg: '19.402.819-3',
    rgOrgaoEmissor: 'DETRAN/RJ',
    dataNascimento: '1976-08-04',
    sexo: 'M',
    estadoCivil: 'Casado(a)',
    nomeMae: 'Maria José dos Santos',
    nomePai: 'Sebastião dos Santos',
    pisPasep: '157.12345.67-8',
    ctpsNumero: '40192',
    ctpsSerie: '005',
    ctpsUf: 'RJ',
    email: 'valdir.santos@vanguarda.demo',
    telefone: '(21) 98841-2099',
    whatsapp: '(21) 98841-2099',
    cep: '21040-360',
    logradouro: 'Avenida Brasil',
    numero: '8900',
    bairro: 'Bonsucesso',
    cidade: 'Rio de Janeiro',
    uf: 'RJ',
    funcaoId: 'fnc_4',
    cargoNome: 'Motorista de Carreta Articulada',
    cbo: '7825-10',
    departamento: 'Operações & Transporte',
    tipoContrato: 'CLT Indeterminado',
    regimeTrabalho: 'presencial',
    dataAdmissao: '2021-08-15',
    terminoExperiencia: '2021-11-15',
    salarioBase: 4200.0,
    adicionaisTotal: 1260.0, // 30% periculosidade
    status: 'ativo',
    bancoNome: 'Banco do Brasil (001)',
    bancoAgencia: '2840',
    bancoConta: '10928-3',
    chavePix: '567.890.123-45',
    valeTransporte: false,
    valorVrVaMensal: 1200.0,
    planoSaude: true,
    dependentes: [
      {
        id: 'dep_4',
        nome: 'Marcos Vinicius dos Santos',
        parentesco: 'Filho(a)',
        cpf: '812.901.442-10',
        dataNascimento: '2012-05-18',
        deducaoIrrf: true,
        salarioFamilia: false,
      },
    ],
    periodoAquisitivoInicio: '2024-08-15',
    periodoAquisitivoFim: '2025-08-14',
    limiteConcessivoFerias: '2026-07-14',
    diasFeriasSaldo: 30,
    dataUltimoAso: '2025-09-20',
    dataValidadeAso: '2026-09-20',
    observacoes: 'Atenção: Exame toxicológico periódico e ASO com vencimento em menos de 10 dias.',
    isDemo: true,
  },
  {
    id: 'func_5',
    empresaId: 'emp_2',
    matricula: 'ESOC-00215',
    nomeCompleto: 'Juliana Ferraz Nogueira',
    cpf: '678.901.234-56',
    rg: '25.901.821-4',
    rgOrgaoEmissor: 'SSP/RJ',
    dataNascimento: '1992-04-12',
    sexo: 'F',
    estadoCivil: 'Solteiro(a)',
    nomeMae: 'Clarice Ferraz Nogueira',
    pisPasep: '168.23456.78-9',
    ctpsNumero: '51092',
    ctpsSerie: '002',
    ctpsUf: 'RJ',
    email: 'juliana.nogueira@vanguarda.demo',
    telefone: '(21) 99310-8412',
    whatsapp: '(21) 99310-8412',
    cep: '20040-002',
    logradouro: 'Rua Primeiro de Março',
    numero: '120',
    bairro: 'Centro',
    cidade: 'Rio de Janeiro',
    uf: 'RJ',
    funcaoId: 'fnc_5',
    cargoNome: 'Analista de Logística e Rastreamento',
    cbo: '4110-05',
    departamento: 'Logística & Gerenciamento de Risco',
    tipoContrato: 'CLT Indeterminado',
    regimeTrabalho: 'presencial',
    dataAdmissao: '2023-09-01',
    salarioBase: 4800.0,
    adicionaisTotal: 0,
    status: 'ativo',
    bancoNome: 'Banco Santander (033)',
    bancoAgencia: '4019',
    bancoConta: '13904-8',
    chavePix: 'juliana.nogueira@email.demo',
    valeTransporte: true,
    valorVrVaMensal: 850.0,
    planoSaude: true,
    dependentes: [],
    diasFeriasSaldo: 30,
    dataUltimoAso: '2025-08-25',
    dataValidadeAso: '2026-08-25',
    observacoes: 'Responsável pela emissão de manifestos e controle de frotas frigoríficas.',
    isDemo: true,
  },
  {
    id: 'func_6',
    empresaId: 'emp_3',
    matricula: 'ESOC-00301',
    nomeCompleto: 'Camila Takahashi',
    cpf: '789.012.345-67',
    rg: '33.910.284-0',
    rgOrgaoEmissor: 'SSP/SP',
    dataNascimento: '1987-09-30',
    sexo: 'F',
    estadoCivil: 'Casado(a)',
    nomeMae: 'Sayuri Takahashi',
    nomePai: 'Kenji Takahashi',
    pisPasep: '179.34567.89-0',
    ctpsNumero: '62019',
    ctpsSerie: '001',
    ctpsUf: 'SP',
    email: 'camila.takahashi@prisma.demo',
    telefone: '(11) 98104-9210',
    whatsapp: '(11) 98104-9210',
    cep: '01420-001',
    logradouro: 'Alameda Lorena',
    numero: '890',
    bairro: 'Jardins',
    cidade: 'São Paulo',
    uf: 'SP',
    funcaoId: 'fnc_6',
    cargoNome: 'Arquiteto Coordenador de Projetos',
    cbo: '2141-05',
    departamento: 'Projetos Arquitetônicos',
    tipoContrato: 'CLT Indeterminado',
    regimeTrabalho: 'hibrido',
    dataAdmissao: '2020-03-12',
    salarioBase: 9600.0,
    adicionaisTotal: 0,
    status: 'ativo',
    bancoNome: 'Banco Itaú Unibanco (341)',
    bancoAgencia: '0190',
    bancoConta: '92104-7',
    chavePix: '789.012.345-67',
    valeTransporte: false,
    valorVrVaMensal: 1050.0,
    planoSaude: true,
    dependentes: [
      {
        id: 'dep_5',
        nome: 'Lucas Takahashi Lima',
        parentesco: 'Filho(a)',
        cpf: '912.801.340-99',
        dataNascimento: '2019-12-05',
        deducaoIrrf: true,
        salarioFamilia: false,
      },
    ],
    periodoAquisitivoInicio: '2024-03-12',
    periodoAquisitivoFim: '2025-03-11',
    limiteConcessivoFerias: '2026-02-11',
    diasFeriasSaldo: 20,
    dataUltimoAso: '2025-03-01',
    dataValidadeAso: '2026-03-01',
    observacoes: 'Coordena projetos residenciais e corporativos de alto padrão com selo LEED.',
    isDemo: true,
  },
  {
    id: 'func_7',
    empresaId: 'emp_4',
    matricula: 'ESOC-00405',
    nomeCompleto: 'Roberto Silvano Castilho',
    cpf: '890.123.456-78',
    rg: '14.890.123-5',
    rgOrgaoEmissor: 'SESP/PR',
    dataNascimento: '1979-01-25',
    sexo: 'M',
    estadoCivil: 'Casado(a)',
    nomeMae: 'Aparecida Silvano Castilho',
    nomePai: 'José Castilho',
    pisPasep: '180.45678.90-1',
    ctpsNumero: '73910',
    ctpsSerie: '004',
    ctpsUf: 'PR',
    email: 'roberto.castilho@alvorada.demo',
    telefone: '(41) 99201-8409',
    whatsapp: '(41) 99201-8409',
    cep: '81010-000',
    logradouro: 'Rua Marechal Floriano Peixoto',
    numero: '4500',
    bairro: 'Hauer',
    cidade: 'Curitiba',
    uf: 'PR',
    funcaoId: 'fnc_7',
    cargoNome: 'Torneiro Mecânico CNC Sênior',
    cbo: '7214-05',
    departamento: 'Usinagem & Metalurgia',
    tipoContrato: 'CLT Indeterminado',
    regimeTrabalho: 'presencial',
    dataAdmissao: '2019-11-05',
    salarioBase: 5100.0,
    adicionaisTotal: 282.4, // Insalubridade 20% sobre R$ 1.412,00
    status: 'afastado',
    bancoNome: 'Caixa Econômica Federal (104)',
    bancoAgencia: '1029',
    bancoConta: '0012984-5',
    chavePix: '890.123.456-78',
    valeTransporte: true,
    valorVrVaMensal: 800.0,
    planoSaude: true,
    dependentes: [
      {
        id: 'dep_6',
        nome: 'Lorena Silvano Castilho',
        parentesco: 'Filho(a)',
        cpf: '401.921.849-00',
        dataNascimento: '2015-07-14',
        deducaoIrrf: true,
        salarioFamilia: false,
      },
    ],
    periodoAquisitivoInicio: '2023-11-05',
    periodoAquisitivoFim: '2024-11-04',
    limiteConcessivoFerias: '2025-10-04',
    diasFeriasSaldo: 30,
    dataUltimoAso: '2025-05-15',
    dataValidadeAso: '2026-05-15',
    observacoes: 'Afastamento temporário por licença médica pelo INSS (Auxílio por Incapacidade Temporária B31).',
    isDemo: true,
  },
  {
    id: 'func_8',
    empresaId: 'emp_5',
    matricula: 'ESOC-00502',
    nomeCompleto: 'Renata Figueiredo Lins',
    cpf: '901.234.567-89',
    rg: 'MG-15.890.412',
    rgOrgaoEmissor: 'PCMG',
    dataNascimento: '1991-07-08',
    sexo: 'F',
    estadoCivil: 'Solteiro(a)',
    nomeMae: 'Marta Figueiredo Lins',
    pisPasep: '191.56789.01-2',
    ctpsNumero: '84019',
    ctpsSerie: '001',
    ctpsUf: 'MG',
    email: 'renata.lins@sabordaterra.demo',
    telefone: '(31) 98412-9033',
    whatsapp: '(31) 98412-9033',
    cep: '30140-061',
    logradouro: 'Rua da Bahia',
    numero: '1500',
    bairro: 'Lourdes',
    cidade: 'Belo Horizonte',
    uf: 'MG',
    funcaoId: 'fnc_8',
    cargoNome: 'Nutricionista de Controle de Qualidade',
    cbo: '2237-10',
    departamento: 'Qualidade & Boas Práticas',
    tipoContrato: 'CLT Indeterminado',
    regimeTrabalho: 'presencial',
    dataAdmissao: '2024-01-10',
    salarioBase: 5400.0,
    adicionaisTotal: 0,
    status: 'ativo',
    bancoNome: 'Banco Inter (077)',
    bancoAgencia: '0001',
    bancoConta: '4910283-9',
    chavePix: 'renata.lins@email.demo',
    valeTransporte: false,
    valorVrVaMensal: 900.0,
    planoSaude: true,
    dependentes: [],
    diasFeriasSaldo: 30,
    dataUltimoAso: '2025-01-10',
    dataValidadeAso: '2026-01-10',
    observacoes: 'Responsável técnica junto à Vigilância Sanitária e auditora líder de APPCC.',
    isDemo: true,
  },
  {
    id: 'func_9',
    empresaId: 'emp_1',
    matricula: 'ESOC-00135',
    nomeCompleto: 'Mariana Vasconcelos Prado',
    cpf: '512.438.990-12',
    rg: '36.901.442-8',
    rgOrgaoEmissor: 'SSP/SP',
    dataNascimento: '1996-09-22',
    sexo: 'F',
    estadoCivil: 'Solteiro(a)',
    nomeMae: 'Silvia Vasconcelos Prado',
    pisPasep: '198.44102.83-9',
    ctpsNumero: '91204',
    ctpsSerie: '001',
    ctpsUf: 'SP',
    email: 'mariana.prado@inovatech.demo',
    telefone: '(11) 98311-4099',
    whatsapp: '(11) 98311-4099',
    cep: '01419-001',
    logradouro: 'Rua Oscar Freire',
    numero: '400',
    bairro: 'Cerqueira César',
    cidade: 'São Paulo',
    uf: 'SP',
    funcaoId: 'fnc_1',
    cargoNome: 'Designer de UI/UX & Produto',
    cbo: '2124-05',
    departamento: 'Design & Produto',
    tipoContrato: 'CLT Prazo Determinado',
    regimeTrabalho: 'hibrido',
    dataAdmissao: '2026-06-25',
    terminoExperiencia: '2026-09-23',
    terminoContrato: '2026-12-25',
    salarioBase: 6500.0,
    adicionaisTotal: 0,
    status: 'ativo',
    bancoNome: 'Banco Nubank (260)',
    bancoAgencia: '0001',
    bancoConta: '5920194-2',
    chavePix: 'mariana.prado@inovatech.demo',
    valeTransporte: false,
    valorVrVaMensal: 950.0,
    planoSaude: true,
    dependentes: [],
    diasFeriasSaldo: 30,
    dataUltimoAso: '2026-06-20',
    dataValidadeAso: '2027-06-20',
    observacoes: 'Contrato de experiência de 90 dias com término iminente em 23/09/2026. Necessário avaliar efetivação.',
    isDemo: true,
  },
  {
    id: 'func_10',
    empresaId: 'emp_1',
    matricula: 'ESOC-00140',
    nomeCompleto: 'Bruno Albuquerque Siqueira',
    cpf: '601.294.881-33',
    rg: '50.192.839-1',
    rgOrgaoEmissor: 'SSP/SP',
    dataNascimento: '2002-10-04',
    sexo: 'M',
    estadoCivil: 'Solteiro(a)',
    nomeMae: 'Carla Albuquerque Siqueira',
    pisPasep: '201.88419.02-1',
    ctpsNumero: '83910',
    ctpsSerie: '002',
    ctpsUf: 'SP',
    email: 'bruno.siqueira@inovatech.demo',
    telefone: '(11) 97412-8800',
    whatsapp: '(11) 97412-8800',
    cep: '04101-000',
    logradouro: 'Rua Vergueiro',
    numero: '2100',
    bairro: 'Vila Mariana',
    cidade: 'São Paulo',
    uf: 'SP',
    funcaoId: 'fnc_10',
    cargoNome: 'Estagiário de Front-End & Web',
    cbo: '2124-05',
    departamento: 'Tecnologia da Informação',
    tipoContrato: 'Estágio',
    regimeTrabalho: 'hibrido',
    dataAdmissao: '2025-10-15',
    terminoContrato: '2026-10-15',
    salarioBase: 1800.0,
    adicionaisTotal: 0,
    status: 'ativo',
    bancoNome: 'Banco Inter (077)',
    bancoAgencia: '0001',
    bancoConta: '1092834-5',
    chavePix: 'bruno.siqueira@email.demo',
    valeTransporte: true,
    valorVrVaMensal: 650.0,
    planoSaude: false,
    dependentes: [],
    diasFeriasSaldo: 15,
    dataUltimoAso: '2025-10-10',
    dataValidadeAso: '2026-10-10',
    observacoes: 'Término de vigência anual de estágio em 15/10/2026. Possibilidade de efetivação como Desenvolvedor Júnior.',
    isDemo: true,
  },
  {
    id: 'func_11',
    empresaId: 'emp_2',
    matricula: 'ESOC-00228',
    nomeCompleto: 'Larissa Fontes Medeiros',
    cpf: '719.824.102-55',
    rg: '28.192.401-9',
    rgOrgaoEmissor: 'SSP/RJ',
    dataNascimento: '1990-10-18',
    sexo: 'F',
    estadoCivil: 'Casado(a)',
    nomeMae: 'Helena Fontes Medeiros',
    pisPasep: '210.99401.82-3',
    ctpsNumero: '48192',
    ctpsSerie: '001',
    ctpsUf: 'RJ',
    email: 'larissa.medeiros@vanguarda.demo',
    telefone: '(21) 99120-7734',
    whatsapp: '(21) 99120-7734',
    cep: '22250-040',
    logradouro: 'Praia de Botafogo',
    numero: '300',
    bairro: 'Botafogo',
    cidade: 'Rio de Janeiro',
    uf: 'RJ',
    funcaoId: 'fnc_5',
    cargoNome: 'Coordenadora de Recursos Humanos',
    cbo: '4110-05',
    departamento: 'Recursos Humanos & DP',
    tipoContrato: 'CLT Indeterminado',
    regimeTrabalho: 'presencial',
    dataAdmissao: '2026-07-15',
    terminoExperiencia: '2026-10-13',
    salarioBase: 7200.0,
    adicionaisTotal: 0,
    status: 'ativo',
    bancoNome: 'Banco Bradesco (237)',
    bancoAgencia: '3012',
    bancoConta: '89102-4',
    chavePix: '719.824.102-55',
    valeTransporte: false,
    valorVrVaMensal: 1100.0,
    planoSaude: true,
    dependentes: [],
    diasFeriasSaldo: 30,
    dataUltimoAso: '2026-07-10',
    dataValidadeAso: '2027-07-10',
    observacoes: 'Contrato em período de experiência (90 dias) com término em 13/10/2026.',
    isDemo: true,
  },
];

/**
 * Storage persistence engine
 * Ready for continuous usage and prepared to swap with PostgreSQL/Cloud SQL/MongoDB repository driver
 */
class AccountingDatabaseRepository {
  private hashPassword(password: string, salt = crypto.randomBytes(16).toString('hex')): string {
    const derived = crypto.pbkdf2Sync(password, salt, 120_000, 64, 'sha512').toString('hex');
    return `pbkdf2$120000$${salt}$${derived}`;
  }

  verifyPassword(user: StoredUser, password: string): boolean {
    if (!user.passwordHash) {
      const configured = process.env.CONTABGEST_DEFAULT_PASSWORD;
      if (!configured && process.env.NODE_ENV === 'production') return false;
      return password.length > 0 && password === (configured || 'admin123456');
    }
    const [scheme, iterationsRaw, salt, expected] = user.passwordHash.split('$');
    if (scheme !== 'pbkdf2' || !iterationsRaw || !salt || !expected) return false;
    const iterations = Number(iterationsRaw);
    if (!Number.isInteger(iterations) || iterations < 100_000) return false;
    const actual = crypto.pbkdf2Sync(password, salt, iterations, 64, 'sha512').toString('hex');
    return crypto.timingSafeEqual(Buffer.from(actual, 'hex'), Buffer.from(expected, 'hex'));
  }

  ensurePasswordHash(user: StoredUser): StoredUser {
    if (!user.passwordHash) {
      user.passwordHash = this.hashPassword(process.env.CONTABGEST_DEFAULT_PASSWORD || 'admin123456');
      this.persist();
    }
    return user;
  }

  private data: DatabaseSchema;
  private filePath: string;

  constructor() {
    this.filePath = path.join(process.cwd(), 'data', 'contabgest_db.json');
    this.data = this.loadInitialData();
  }

  private loadInitialData(): DatabaseSchema {
    try {
      const dataDir = path.dirname(this.filePath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      if (fs.existsSync(this.filePath)) {
        const fileContent = fs.readFileSync(this.filePath, 'utf-8');
        const parsed = JSON.parse(fileContent);
        let modified = false;
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
          throw new Error('Banco de dados inválido: estrutura raiz não é um objeto.');
        }
        if (!Array.isArray(parsed.users)) parsed.users = DEMO_USERS;
        if (!Array.isArray(parsed.empresas)) parsed.empresas = [];
        if (!Array.isArray(parsed.clientes)) parsed.clientes = [];
        if (!Array.isArray(parsed.socios)) parsed.socios = [];
        if (!Array.isArray(parsed.obrigacoes)) parsed.obrigacoes = [];
        if (!Array.isArray(parsed.documentos)) parsed.documentos = [];
        if (!Array.isArray(parsed.certidoes)) parsed.certidoes = [];
        if (!Array.isArray(parsed.tarefas)) parsed.tarefas = [];
        if (!Array.isArray(parsed.contasPagar)) parsed.contasPagar = [];
        if (!Array.isArray(parsed.contasReceber)) parsed.contasReceber = [];
        if (!Array.isArray(parsed.categoriasFinanceiras)) parsed.categoriasFinanceiras = [];
        if (!Array.isArray(parsed.notasFiscais)) parsed.notasFiscais = [];

        if (!parsed.notasFiscais) {
          parsed.notasFiscais = DEMO_NOTAS_FISCAIS;
          modified = true;
        }
        if (!parsed.certificados) {
          parsed.certificados = DEMO_CERTIFICADOS;
          modified = true;
        }
        if (!parsed.pendenciasEcac) {
          parsed.pendenciasEcac = DEMO_PENDENCIAS_ECAC;
          modified = true;
        }
        if (!parsed.alvaras) {
          parsed.alvaras = DEMO_ALVARAS;
          modified = true;
        }
        if (!parsed.funcoes) {
          parsed.funcoes = DEMO_FUNCOES;
          modified = true;
        }
        if (!parsed.funcionarios) {
          parsed.funcionarios = DEMO_FUNCIONARIOS;
          modified = true;
        }
        if (!parsed.pontos || !Array.isArray(parsed.pontos) || parsed.pontos.length === 0) {
          parsed.pontos = DEMO_PONTOS;
          modified = true;
        }
        if (!parsed.ferias || !Array.isArray(parsed.ferias) || parsed.ferias.length === 0) {
          parsed.ferias = DEMO_FERIAS;
          modified = true;
        }
        if (!parsed.rescisoes || !Array.isArray(parsed.rescisoes) || parsed.rescisoes.length === 0) {
          parsed.rescisoes = DEMO_RESCISOES;
          modified = true;
        }
        if (!parsed.esocialConfiguracoes || !Array.isArray(parsed.esocialConfiguracoes) || parsed.esocialConfiguracoes.length === 0) {
          parsed.esocialConfiguracoes = DEMO_ESOCIAL_CONFIGURACOES;
          modified = true;
        }
        if (!parsed.esocialEventos || !Array.isArray(parsed.esocialEventos) || parsed.esocialEventos.length === 0) {
          parsed.esocialEventos = DEMO_ESOCIAL_EVENTOS;
          modified = true;
        }
        if (!parsed.notasFiscaisEntrada || !Array.isArray(parsed.notasFiscaisEntrada) || parsed.notasFiscaisEntrada.length === 0) {
          parsed.notasFiscaisEntrada = DEMO_NOTAS_ENTRADA;
          modified = true;
        }
        if (!parsed.sincronizacoesSefaz || !Array.isArray(parsed.sincronizacoesSefaz)) {
          parsed.sincronizacoesSefaz = DEMO_SINCRONIZACOES_SEFAZ;
          modified = true;
        }
        if (!parsed.apuracoesSimples || !Array.isArray(parsed.apuracoesSimples)) {
          parsed.apuracoesSimples = DEMO_APURACOES_SIMPLES;
          modified = true;
        }
        if (!parsed.guiasDasMei || !Array.isArray(parsed.guiasDasMei)) {
          parsed.guiasDasMei = DEMO_GUIAS_MEI;
          modified = true;
        }
        if (!parsed.declaracoesAnuaisMei || !Array.isArray(parsed.declaracoesAnuaisMei)) {
          parsed.declaracoesAnuaisMei = DEMO_DECLARACOES_MEI;
          modified = true;
        }
        // Garante a presença das empresas MEI
        if (parsed.empresas && Array.isArray(parsed.empresas)) {
          for (const empDemo of DEMO_EMPRESAS) {
            const idx = parsed.empresas.findIndex((e) => e.id === empDemo.id);
            if (idx === -1) {
              parsed.empresas.push(empDemo);
              modified = true;
            } else if (empDemo.regimeTributario === 'MEI') {
              // Atualiza campos de MEI
              parsed.empresas[idx].regimeTributario = 'MEI';
              parsed.empresas[idx].tipoAtividadeMei = empDemo.tipoAtividadeMei;
              parsed.empresas[idx].categoriaMei = empDemo.categoriaMei;
              parsed.empresas[idx].status = empDemo.status;
              parsed.empresas[idx].razaoSocial = empDemo.razaoSocial;
              parsed.empresas[idx].nomeFantasia = empDemo.nomeFantasia;
              modified = true;
            }
          }
        }
        if (!parsed.version) { parsed.version = '2.1.0'; modified = true; }
        if (typeof parsed.isDemoDatabase !== 'boolean') { parsed.isDemoDatabase = true; modified = true; }
        // Garante a presença dos cupons fiscais NFC-e, notas do Simples e notas fiscais do MEI
        if (parsed.notasFiscais && Array.isArray(parsed.notasFiscais)) {
          for (const notaExtra of [...DEMO_NOTAS_SIMPLES_ADICIONAIS, ...DEMO_NOTAS_MEI_ADICIONAIS]) {
            if (!parsed.notasFiscais.some((n) => n.id === notaExtra.id)) {
              parsed.notasFiscais.push(notaExtra);
              modified = true;
            }
          }
        }
        if (parsed) {
          if (parsed.version === '1.0.0' || parsed.version === '2.0.0') {
            parsed.version = '2.1.0';
            modified = true;
          }
        }
        if (modified) {
          this.persist(parsed);
        }
        return parsed;
      }
    } catch (err) {
      console.warn('Iniciando banco de dados com semente padrão em memória:', err);
    }

    const initial: DatabaseSchema = {
      version: '2.0.0',
      isDemoDatabase: false,
      users: DEMO_USERS,
      empresas: DEMO_EMPRESAS,
      clientes: DEMO_CLIENTES,
      socios: DEMO_SOCIOS,
      obrigacoes: DEMO_OBRIGACOES,
      documentos: DEMO_DOCUMENTOS,
      certidoes: DEMO_CERTIDOES,
      tarefas: DEMO_TAREFAS,
      contasPagar: DEMO_CONTAS_PAGAR,
      contasReceber: DEMO_CONTAS_RECEBER,
      categoriasFinanceiras: DEMO_CATEGORIAS_FINANCEIRAS,
      notasFiscais: [
        ...DEMO_NOTAS_FISCAIS,
        ...DEMO_NOTAS_SIMPLES_ADICIONAIS,
        ...DEMO_NOTAS_MEI_ADICIONAIS,
      ],
      notasFiscaisEntrada: DEMO_NOTAS_ENTRADA,
      sincronizacoesSefaz: DEMO_SINCRONIZACOES_SEFAZ,
      certificados: DEMO_CERTIFICADOS,
      pendenciasEcac: DEMO_PENDENCIAS_ECAC,
      alvaras: DEMO_ALVARAS,
      funcoes: DEMO_FUNCOES,
      funcionarios: DEMO_FUNCIONARIOS,
      pontos: DEMO_PONTOS,
      ferias: DEMO_FERIAS,
      rescisoes: DEMO_RESCISOES,
      esocialConfiguracoes: DEMO_ESOCIAL_CONFIGURACOES,
      esocialEventos: DEMO_ESOCIAL_EVENTOS,
      apuracoesSimples: DEMO_APURACOES_SIMPLES,
      guiasDasMei: DEMO_GUIAS_MEI,
      declaracoesAnuaisMei: DEMO_DECLARACOES_MEI,
    };

    this.persist(initial);
    return initial;
  }

  private persist(dataToPersist = this.data): void {
    try {
      const dataDir = path.dirname(this.filePath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      const tempPath = `${this.filePath}.tmp`;
      const payload = JSON.stringify(dataToPersist, null, 2);
      fs.writeFileSync(tempPath, payload, 'utf-8');
      fs.renameSync(tempPath, this.filePath);
    } catch (err) {
      try {
        const tempPath = `${this.filePath}.tmp`;
        if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
      } catch {}

      console.error('Falha ao persistir dados locais:', err);
    }
  }

  // --- Users ---
  getUsers(): User[] {
    return this.data.users.map(({ passwordHash, ...user }) => user);
  }

  findUserByEmail(email: string): StoredUser | undefined {
    return this.data.users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
  }

  // --- Empresas ---
  getEmpresas(): Empresa[] {
    return this.data.empresas;
  }

  getEmpresaById(id: string): Empresa | undefined {
    return this.data.empresas.find((e) => e.id === id);
  }

  createEmpresa(emp: Omit<Empresa, 'id' | 'isDemo'>): Empresa {
    const newEmpresa: Empresa = {
      ...emp,
      id: `emp_${Date.now()}`,
      isDemo: false,
    };
    this.data.empresas.push(newEmpresa);
    this.persist();
    return newEmpresa;
  }

  // --- Clientes ---
  getClientes(empresaId?: string): Cliente[] {
    if (!empresaId || empresaId === 'todas') {
      return this.data.clientes;
    }
    return this.data.clientes.filter((c) => c.empresaId === empresaId);
  }

  // --- Sócios ---
  getSocios(empresaId?: string): Socio[] {
    if (!empresaId || empresaId === 'todas') {
      return this.data.socios;
    }
    return this.data.socios.filter((s) => s.empresaId === empresaId);
  }

  // --- Obrigações ---
  getObrigacoes(empresaId?: string): Obrigacao[] {
    if (!empresaId || empresaId === 'todas') {
      return this.data.obrigacoes;
    }
    return this.data.obrigacoes.filter((o) => o.empresaId === empresaId);
  }

  updateObrigacaoStatus(id: string, status: Obrigacao['status']): Obrigacao | null {
    const item = this.data.obrigacoes.find((o) => o.id === id);
    if (!item) return null;
    item.status = status;
    this.persist();
    return item;
  }

  // --- Documentos ---
  getDocumentos(empresaId?: string): Documento[] {
    if (!empresaId || empresaId === 'todas') {
      return this.data.documentos;
    }
    return this.data.documentos.filter((d) => d.empresaId === empresaId);
  }

  addDocumento(doc: Omit<Documento, 'id'>): Documento {
    const newDoc: Documento = {
      ...doc,
      id: `doc_${Date.now()}`,
    };
    this.data.documentos.unshift(newDoc);
    this.persist();
    return newDoc;
  }

  // --- Certidões ---
  getCertidoes(empresaId?: string): Certidao[] {
    if (!empresaId || empresaId === 'todas') {
      return this.data.certidoes;
    }
    return this.data.certidoes.filter((c) => c.empresaId === empresaId);
  }

  // --- Tarefas ---
  getTarefas(empresaId?: string): Tarefa[] {
    if (!empresaId || empresaId === 'todas') {
      return this.data.tarefas;
    }
    return this.data.tarefas.filter((t) => t.empresaId === empresaId);
  }

  updateTarefaStatus(id: string, status: Tarefa['status']): Tarefa | null {
    const item = this.data.tarefas.find((t) => t.id === id);
    if (!item) return null;
    item.status = status;
    this.persist();
    return item;
  }

  // --- Contas a Pagar & Receber ---
  getContasPagar(empresaId?: string): ContaPagar[] {
    if (!empresaId || empresaId === 'todas') {
      return this.data.contasPagar;
    }
    return this.data.contasPagar.filter((cp) => cp.empresaId === empresaId);
  }

  getContasReceber(empresaId?: string): ContaReceber[] {
    if (!empresaId || empresaId === 'todas') {
      return this.data.contasReceber;
    }
    return this.data.contasReceber.filter((cr) => cr.empresaId === empresaId);
  }

  getCategoriasFinanceiras(): CategoriaFinanceira[] {
    return this.data.categoriasFinanceiras;
  }

  // --- Dashboard Aggregation ---
  getDashboardMetrics(empresaId?: string): DashboardMetrics {
    const isAll = !empresaId || empresaId === 'todas';

    const empresasFiltradas = isAll
      ? this.data.empresas
      : this.data.empresas.filter((e) => e.id === empresaId);

    const obrigacoesFiltradas = isAll
      ? this.data.obrigacoes
      : this.data.obrigacoes.filter((o) => o.empresaId === empresaId);

    const documentosFiltrados = isAll
      ? this.data.documentos
      : this.data.documentos.filter((d) => d.empresaId === empresaId);

    const contasPagarFiltradas = isAll
      ? this.data.contasPagar
      : this.data.contasPagar.filter((cp) => cp.empresaId === empresaId);

    const contasReceberFiltradas = isAll
      ? this.data.contasReceber
      : this.data.contasReceber.filter((cr) => cr.empresaId === empresaId);

    const totalEmpresas = empresasFiltradas.length;
    const empresasAtivas = empresasFiltradas.filter((e) => e.status === 'ativa').length;

    const obrigacoesPendentes = obrigacoesFiltradas.filter(
      (o) => o.status === 'pendente' || o.status === 'atrasada'
    ).length;

    const obrigacoesVencendo = obrigacoesFiltradas.filter((o) => o.status === 'vencendo').length;

    const documentosPendentes = documentosFiltrados.filter((d) => d.status === 'pendente').length;

    // Financial calculations:
    // Contas a pagar pendentes e vencidas:
    const aPagarAbertas = contasPagarFiltradas.filter((cp) => cp.status !== 'pago');
    const valorContasPagar = aPagarAbertas.reduce((acc, curr) => acc + curr.valor, 0);

    // Contas a receber pendentes e vencidas:
    const aReceberAbertas = contasReceberFiltradas.filter((cr) => cr.status !== 'recebido');
    const valorContasReceber = aReceberAbertas.reduce((acc, curr) => acc + curr.valor, 0);

    const concluidas = obrigacoesFiltradas.filter((o) => o.status === 'concluida').length;
    const taxaConformidade =
      obrigacoesFiltradas.length > 0
        ? Math.round((concluidas / obrigacoesFiltradas.length) * 100)
        : 100;

    // Monthly Cash Flow data (last 6 months DEMO comparison)
    const monthlyFlow = [
      { mes: 'Abr/26', receber: 185000, pagar: 142000, saldo: 43000 },
      { mes: 'Mai/26', receber: 210000, pagar: 165000, saldo: 45000 },
      { mes: 'Jun/26', receber: 240000, pagar: 178000, saldo: 62000 },
      { mes: 'Jul/26', receber: 265000, pagar: 195000, saldo: 70000 },
      { mes: 'Ago/26', receber: 290000, pagar: 210000, saldo: 80000 },
      {
        mes: 'Set/26',
        receber: isAll ? 445500 : valorContasReceber * 1.2,
        pagar: isAll ? 238300 : valorContasPagar * 1.1,
        saldo: isAll ? 207200 : valorContasReceber * 1.2 - valorContasPagar * 1.1,
      },
    ];

    // Status das obrigações
    const statusObrigacoes = {
      concluidas: obrigacoesFiltradas.filter((o) => o.status === 'concluida').length,
      pendentes: obrigacoesFiltradas.filter((o) => o.status === 'pendente').length,
      vencendo: obrigacoesFiltradas.filter((o) => o.status === 'vencendo').length,
      atrasadas: obrigacoesFiltradas.filter((o) => o.status === 'atrasada').length,
    };

    // Distribution by Tax Regime
    const regimeCountMap: Record<string, number> = {};
    for (const emp of empresasFiltradas) {
      regimeCountMap[emp.regimeTributario] = (regimeCountMap[emp.regimeTributario] || 0) + 1;
    }
    const regimesDistribuicao = Object.entries(regimeCountMap).map(([regime, quantidade]) => ({
      regime,
      quantidade,
    }));

    // Novas métricas (Notas Fiscais, Certificados, e-CAC)
    const notasFiltradas = isAll
      ? this.data.notasFiscais
      : this.data.notasFiscais.filter((nf) => nf.empresaId === empresaId);

    const certsFiltrados = isAll
      ? this.data.certificados
      : this.data.certificados.filter((c) => c.empresaId === empresaId);

    const pendenciasFiltradas = isAll
      ? this.data.pendenciasEcac
      : this.data.pendenciasEcac.filter((p) => p.empresaId === empresaId);

    const totalNotasEmitidas = notasFiltradas.length;
    const certificadosAlerta = certsFiltrados.filter(
      (c) => c.status === 'alerta' || c.status === 'expirando' || c.status === 'expirado'
    ).length;

    const pendenciasResolvidas = pendenciasFiltradas.filter((p) => p.status === 'resolvida').length;
    const pendenciasTotal = pendenciasFiltradas.length;
    const pendenciasEcacResolvidasPercentual =
      pendenciasTotal > 0 ? Math.round((pendenciasResolvidas / pendenciasTotal) * 100) : 100;

    return {
      totalEmpresas,
      empresasAtivas,
      obrigacoesPendentes,
      obrigacoesVencendo,
      documentosPendentes,
      totalContasPagar: aPagarAbertas.length,
      valorContasPagar,
      totalContasReceber: aReceberAbertas.length,
      valorContasReceber,
      taxaConformidade,
      monthlyFlow,
      statusObrigacoes,
      regimesDistribuicao,
      totalNotasEmitidas,
      certificadosAlerta,
      pendenciasEcacResolvidasPercentual,
      pendenciasEcacTotal: pendenciasTotal,
      pendenciasEcacPendentes: pendenciasFiltradas.filter((p) => p.status !== 'resolvida').length,
    };
  }

  // --- Notas Fiscais Eletrônicas ---
  getNotasFiscais(empresaId?: string): NotaFiscal[] {
    if (!empresaId || empresaId === 'todas') {
      return this.data.notasFiscais;
    }
    return this.data.notasFiscais.filter((nf) => nf.empresaId === empresaId);
  }

  createNotaFiscal(nota: Omit<NotaFiscal, 'id' | 'isDemo' | 'chaveAcesso'>): NotaFiscal {
    const randomChave = `352609${Math.random().toString().slice(2, 16)}${Math.random().toString().slice(2, 16)}${Math.random().toString().slice(2, 16)}`.slice(0, 44);
    const newNf: NotaFiscal = {
      ...nota,
      id: `nf_${Date.now()}`,
      chaveAcesso: randomChave,
      protocoloAutorizacao: `1352600${Math.floor(10000000 + Math.random() * 90000000)}`,
      dataEmissao: nota.dataEmissao || new Date().toISOString(),
      status: 'autorizada',
      isDemo: false,
    };
    this.data.notasFiscais.unshift(newNf);
    this.persist();
    return newNf;
  }

  cancelarNotaFiscal(id: string, motivo: string): NotaFiscal {
    const index = this.data.notasFiscais.findIndex((nf) => nf.id === id);
    if (index === -1) {
      throw new Error('Nota Fiscal não encontrada');
    }
    this.data.notasFiscais[index].status = 'cancelada';
    this.data.notasFiscais[index].motivoCancelamento = motivo;
    this.persist();
    return this.data.notasFiscais[index];
  }

  // --- Importação de XMLs de Notas Eletrônicas de Saída (Modelo 55 - Outro ERP) ---
  importarXmlSaida(empresaId: string, xmlString: string): NotaFiscal {
    const empresa = this.getEmpresaById(empresaId) || this.getEmpresas()[0];
    const agora = new Date().toISOString();

    // Extrai chave de acesso
    const chaveMatch = xmlString.match(/<chNFe>(\d{44})<\/chNFe>/) || xmlString.match(/Id="NFe(\d{44})"/);
    const chave = chaveMatch ? chaveMatch[1] : `352609${Math.random().toString().slice(2, 16)}${Math.random().toString().slice(2, 16)}${Math.random().toString().slice(2, 16)}`.slice(0, 44);

    // Se já existe com a mesma chave, atualiza ou retorna existente
    const indexExistente = this.data.notasFiscais.findIndex((n) => n.chaveAcesso === chave);

    // Modelo e Tipo
    const modMatch = xmlString.match(/<mod>(\d+)<\/mod>/);
    const modeloDoc = (modMatch ? modMatch[1] : '55') as '55' | '65' | 'NFSe' | 'CFe';

    const nNfMatch = xmlString.match(/<nNF>(\d+)<\/nNF>/);
    const numero = nNfMatch ? parseInt(nNfMatch[1], 10) : Math.floor(1000 + Math.random() * 90000);

    const serieMatch = xmlString.match(/<serie>(\d+)<\/serie>/);
    const serie = serieMatch ? serieMatch[1] : '1';

    // Data de emissão
    const dEmiMatch = xmlString.match(/<dhEmi>([^<]+)<\/dhEmi>/) || xmlString.match(/<dEmi>([^<]+)<\/dEmi>/);
    const dataEmissao = dEmiMatch ? dEmiMatch[1] : agora;

    // Destinatário
    const destNomeMatch = xmlString.match(/<dest>[\s\S]*?<xNome>([^<]+)<\/xNome>/);
    const destinatarioNome = destNomeMatch ? destNomeMatch[1].trim() : 'Cliente ERP Importado Ltda';

    const destCnpjMatch = xmlString.match(/<dest>[\s\S]*?<CNPJ>(\d{14})<\/CNPJ>/);
    const destCpfMatch = xmlString.match(/<dest>[\s\S]*?<CPF>(\d{11})<\/CPF>/);
    let destinatarioCpfCnpj = '00.000.000/0001-00';
    if (destCnpjMatch) {
      destinatarioCpfCnpj = destCnpjMatch[1].replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
    } else if (destCpfMatch) {
      destinatarioCpfCnpj = destCpfMatch[1].replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
    }

    const destEmailMatch = xmlString.match(/<dest>[\s\S]*?<email>([^<]+)<\/email>/);
    const destinatarioEmail = destEmailMatch ? destEmailMatch[1].trim() : undefined;

    // Natureza da Operação e Totais
    const natOpMatch = xmlString.match(/<natOp>([^<]+)<\/natOp>/);
    const naturezaOperacao = natOpMatch ? natOpMatch[1] : '5.102 - Venda de mercadoria adquirida ou recebida de terceiros';

    const vNfMatch = xmlString.match(/<vNF>([\d.]+)<\/vNF>/);
    const valorTotal = vNfMatch ? parseFloat(vNfMatch[1]) : 1250.0;

    const vProdMatch = xmlString.match(/<vProd>([\d.]+)<\/vProd>/);
    const valorProdutos = vProdMatch ? parseFloat(vProdMatch[1]) : valorTotal;

    const vIcmsMatch = xmlString.match(/<vICMS>([\d.]+)<\/vICMS>/);
    const icms = vIcmsMatch ? parseFloat(vIcmsMatch[1]) : parseFloat((valorTotal * 0.12).toFixed(2));

    const vPisMatch = xmlString.match(/<vPIS>([\d.]+)<\/vPIS>/);
    const pis = vPisMatch ? parseFloat(vPisMatch[1]) : parseFloat((valorTotal * 0.0065).toFixed(2));

    const vCofinsMatch = xmlString.match(/<vCOFINS>([\d.]+)<\/vCOFINS>/);
    const cofins = vCofinsMatch ? parseFloat(vCofinsMatch[1]) : parseFloat((valorTotal * 0.03).toFixed(2));

    // CFOP
    const cfopMatch = xmlString.match(/<CFOP>(\d{4})<\/CFOP>/);
    const cfopPrincipal = cfopMatch ? cfopMatch[1] : '5.102';

    // Itens
    const detMatches = xmlString.match(/<det[\s\S]*?<\/det>/g) || [];
    const itens = detMatches.map((det, idx) => {
      const xProdMatch = det.match(/<xProd>([^<]+)<\/xProd>/);
      const qComMatch = det.match(/<qCom>([\d.]+)<\/qCom>/);
      const vUnComMatch = det.match(/<vUnCom>([\d.]+)<\/vUnCom>/);
      const vProdItemMatch = det.match(/<vProd>([\d.]+)<\/vProd>/);
      const cfopItemMatch = det.match(/<CFOP>(\d{4})<\/CFOP>/);
      const ncmMatch = det.match(/<NCM>(\d+)<\/NCM>/);
      const csosnMatch = det.match(/<CSOSN>(\d+)<\/CSOSN>/);

      const q = qComMatch ? parseFloat(qComMatch[1]) : 1;
      const vUn = vUnComMatch ? parseFloat(vUnComMatch[1]) : valorTotal;
      const vTotal = vProdItemMatch ? parseFloat(vProdItemMatch[1]) : q * vUn;

      return {
        numeroItem: idx + 1,
        descricao: xProdMatch ? xProdMatch[1].trim() : `Produto/Mercadoria Modelo 55 - Item ${idx + 1}`,
        quantidade: q,
        valorUnitario: vUn,
        valorTotal: vTotal,
        cfop: cfopItemMatch ? cfopItemMatch[1] : cfopPrincipal,
        ncm: ncmMatch ? ncmMatch[1] : '84713012',
        csosn: csosnMatch ? csosnMatch[1] : '102',
      };
    });

    if (itens.length === 0) {
      itens.push({
        numeroItem: 1,
        descricao: 'Mercadorias importadas via XML de saída (ERP Externo)',
        quantidade: 1,
        valorUnitario: valorTotal,
        valorTotal,
        cfop: cfopPrincipal,
        ncm: '84713012',
        csosn: '102',
      });
    }

    const nProtMatch = xmlString.match(/<nProt>(\d+)<\/nProt>/);
    const protocoloAutorizacao = nProtMatch ? nProtMatch[1] : `1352600${Math.floor(10000000 + Math.random() * 90000000)}`;

    const novaNota: NotaFiscal = {
      id: indexExistente !== -1 ? this.data.notasFiscais[indexExistente].id : `nf_saida_erp_${Date.now()}_${Math.random().toString().slice(2, 6)}`,
      empresaId: empresa.id,
      numero,
      serie,
      tipo: 'NFe',
      modeloDoc: '55',
      cfopPrincipal,
      anexoSimples: cfopPrincipal.startsWith('5.1') || cfopPrincipal.startsWith('6.1') ? 'Anexo I' : 'Anexo III',
      naturezaOperacao,
      destinatarioNome,
      destinatarioCpfCnpj,
      destinatarioEmail,
      valorTotal,
      valorServicosOuProdutos: valorProdutos,
      impostos: {
        icms,
        pis,
        cofins,
      },
      itens,
      dataEmissao,
      status: 'autorizada',
      chaveAcesso: chave,
      protocoloAutorizacao,
      origem: 'importado_erp',
      isDemo: false,
    };

    if (indexExistente !== -1) {
      this.data.notasFiscais[indexExistente] = novaNota;
    } else {
      this.data.notasFiscais.unshift(novaNota);
    }

    this.persist();
    return novaNota;
  }

  importarLoteXmlSaida(empresaId: string, xmlStrings: string[]): { importadas: NotaFiscal[]; totalImportadas: number; valorTotal: number } {
    const importadas: NotaFiscal[] = [];
    let valorTotal = 0;

    for (const xml of xmlStrings) {
      if (xml && xml.trim().length > 10) {
        try {
          const nf = this.importarXmlSaida(empresaId, xml);
          importadas.push(nf);
          valorTotal += nf.valorTotal;
        } catch (e) {
          console.error('Erro ao processar item do lote XML de saída:', e);
        }
      }
    }

    return {
      importadas,
      totalImportadas: importadas.length,
      valorTotal,
    };
  }

  // --- Fechamento do Simples Nacional & Apuração PGDAS-D ---
  getApuracoesSimples(empresaId?: string, competencia?: string): ApuracaoSimplesNacional[] {
    if (!this.data.apuracoesSimples) {
      this.data.apuracoesSimples = DEMO_APURACOES_SIMPLES;
    }
    let lista = this.data.apuracoesSimples;
    if (empresaId && empresaId !== 'todas') {
      lista = lista.filter((ap) => ap.empresaId === empresaId);
    }
    if (competencia) {
      lista = lista.filter((ap) => ap.competencia === competencia);
    }
    return lista;
  }

  getApuracaoSimplesById(id: string): ApuracaoSimplesNacional | undefined {
    if (!this.data.apuracoesSimples) {
      this.data.apuracoesSimples = DEMO_APURACOES_SIMPLES;
    }
    return this.data.apuracoesSimples.find((ap) => ap.id === id);
  }

  salvarApuracaoSimples(apuracao: ApuracaoSimplesNacional): ApuracaoSimplesNacional {
    if (!this.data.apuracoesSimples) {
      this.data.apuracoesSimples = DEMO_APURACOES_SIMPLES;
    }
    const index = this.data.apuracoesSimples.findIndex((ap) => ap.id === apuracao.id);
    if (index >= 0) {
      this.data.apuracoesSimples[index] = apuracao;
    } else {
      this.data.apuracoesSimples.unshift(apuracao);
    }
    this.persist();
    return apuracao;
  }

  transmitirApuracaoSimples(
    id: string,
    usuarioNome = 'Carlos Eduardo Silveira'
  ): { apuracao: ApuracaoSimplesNacional; obrigacaoAtualizada?: Obrigacao } {
    if (!this.data.apuracoesSimples) {
      this.data.apuracoesSimples = DEMO_APURACOES_SIMPLES;
    }
    const index = this.data.apuracoesSimples.findIndex((ap) => ap.id === id);
    if (index === -1) {
      throw new Error('Apuração do Simples Nacional não encontrada');
    }

    const agora = new Date().toISOString();
    const protocolo = `REC-PGDASD-${agora.slice(0, 10).replace(/-/g, '')}-${Math.floor(10000 + Math.random() * 89999)}-SP`;
    const recibo = `PGDAS-D-DECL-${this.data.apuracoesSimples[index].competencia.replace('/', '')}-${Math.floor(10000000000000 + Math.random() * 89999999999999)}`;

    this.data.apuracoesSimples[index].status = 'transmitido_pgdas';
    this.data.apuracoesSimples[index].protocoloTransmissao = protocolo;
    this.data.apuracoesSimples[index].reciboDeclaracao = recibo;
    this.data.apuracoesSimples[index].transmitidoEm = agora;
    this.data.apuracoesSimples[index].usuarioTransmissao = usuarioNome;

    // Atualiza ou cria a obrigação fiscal correspondente no sistema
    const apuracaoAtualizada = this.data.apuracoesSimples[index];
    let obrigacaoEncontrada = this.data.obrigacoes.find(
      (ob) =>
        ob.empresaId === apuracaoAtualizada.empresaId &&
        ob.competencia === apuracaoAtualizada.competencia &&
        ob.titulo.toLowerCase().includes('pgdas')
    );

    if (obrigacaoEncontrada) {
      obrigacaoEncontrada.status = 'concluida';
      obrigacaoEncontrada.dataEntrega = agora.slice(0, 10);
      obrigacaoEncontrada.valorTributo = apuracaoAtualizada.valorTotalDas;
      obrigacaoEncontrada.guiaEmitida = true;
      obrigacaoEncontrada.reciboEntrega = protocolo;
    } else {
      const novaObrigacao: Obrigacao = {
        id: `obrig_pgdas_${apuracaoAtualizada.empresaId}_${apuracaoAtualizada.competencia.replace('/', '_')}`,
        empresaId: apuracaoAtualizada.empresaId,
        titulo: 'PGDAS-D - Simples Nacional',
        tipo: 'Federal',
        competencia: apuracaoAtualizada.competencia,
        dataVencimento: apuracaoAtualizada.dataVencimentoDas,
        status: 'concluida',
        dataEntrega: agora.slice(0, 10),
        valorTributo: apuracaoAtualizada.valorTotalDas,
        responsavel: usuarioNome,
        guiaEmitida: true,
        reciboEntrega: protocolo,
        isDemo: false,
      };
      this.data.obrigacoes.unshift(novaObrigacao);
      obrigacaoEncontrada = novaObrigacao;
    }

    this.persist();
    return { apuracao: apuracaoAtualizada, obrigacaoAtualizada: obrigacaoEncontrada };
  }

  excluirApuracaoSimples(id: string): void {
    if (!this.data.apuracoesSimples) return;
    this.data.apuracoesSimples = this.data.apuracoesSimples.filter((ap) => ap.id !== id);
    this.persist();
  }

  // --- Fechamento do MEI: PGMEI (Guias Mensais) e Declaração Anual (DASN-SIMEI) ---
  getGuiasMei(empresaId?: string, ano?: number): GuiaDasMei[] {
    if (!this.data.guiasDasMei) {
      this.data.guiasDasMei = DEMO_GUIAS_MEI;
    }
    return this.data.guiasDasMei.filter((g) => {
      if (empresaId && empresaId !== 'todas' && g.empresaId !== empresaId) return false;
      if (ano && g.ano !== ano) return false;
      return true;
    });
  }

  salvarGuiaMei(guia: GuiaDasMei): GuiaDasMei {
    if (!this.data.guiasDasMei) {
      this.data.guiasDasMei = DEMO_GUIAS_MEI;
    }
    const idx = this.data.guiasDasMei.findIndex((g) => g.id === guia.id);
    if (idx >= 0) {
      this.data.guiasDasMei[idx] = guia;
    } else {
      this.data.guiasDasMei.push(guia);
    }
    this.persist();
    return guia;
  }

  marcarGuiaMeiPaga(guiaId: string, dataPagamento = new Date().toISOString()): GuiaDasMei {
    if (!this.data.guiasDasMei) {
      this.data.guiasDasMei = DEMO_GUIAS_MEI;
    }
    const idx = this.data.guiasDasMei.findIndex((g) => g.id === guiaId);
    if (idx === -1) {
      throw new Error('Guia DAS-MEI não encontrada');
    }
    this.data.guiasDasMei[idx].status = 'pago';
    this.data.guiasDasMei[idx].dataPagamento = dataPagamento;
    this.persist();
    return this.data.guiasDasMei[idx];
  }

  desmarcarGuiaMeiPaga(guiaId: string): GuiaDasMei {
    if (!this.data.guiasDasMei) {
      this.data.guiasDasMei = DEMO_GUIAS_MEI;
    }
    const idx = this.data.guiasDasMei.findIndex((g) => g.id === guiaId);
    if (idx === -1) {
      throw new Error('Guia DAS-MEI não encontrada');
    }
    this.data.guiasDasMei[idx].status = 'pendente';
    this.data.guiasDasMei[idx].dataPagamento = undefined;
    this.persist();
    return this.data.guiasDasMei[idx];
  }

  getDeclaracoesMei(empresaId?: string): DeclaracaoAnualMei[] {
    if (!this.data.declaracoesAnuaisMei) {
      this.data.declaracoesAnuaisMei = DEMO_DECLARACOES_MEI;
    }
    let lista = this.data.declaracoesAnuaisMei;
    if (empresaId && empresaId !== 'todas') {
      lista = lista.filter((d) => d.empresaId === empresaId);
    }
    return lista;
  }

  getDeclaracaoMeiById(id: string): DeclaracaoAnualMei | undefined {
    if (!this.data.declaracoesAnuaisMei) {
      this.data.declaracoesAnuaisMei = DEMO_DECLARACOES_MEI;
    }
    return this.data.declaracoesAnuaisMei.find((d) => d.id === id);
  }

  salvarDeclaracaoMei(declaracao: DeclaracaoAnualMei): DeclaracaoAnualMei {
    if (!this.data.declaracoesAnuaisMei) {
      this.data.declaracoesAnuaisMei = DEMO_DECLARACOES_MEI;
    }
    const idx = this.data.declaracoesAnuaisMei.findIndex((d) => d.id === declaracao.id);
    if (idx >= 0) {
      this.data.declaracoesAnuaisMei[idx] = declaracao;
    } else {
      this.data.declaracoesAnuaisMei.unshift(declaracao);
    }
    this.persist();
    return declaracao;
  }

  transmitirDeclaracaoMei(
    id: string,
    usuarioNome = 'Carlos Eduardo Silveira'
  ): { declaracao: DeclaracaoAnualMei; obrigacaoAtualizada?: Obrigacao } {
    if (!this.data.declaracoesAnuaisMei) {
      this.data.declaracoesAnuaisMei = DEMO_DECLARACOES_MEI;
    }
    const idx = this.data.declaracoesAnuaisMei.findIndex((d) => d.id === id);
    if (idx === -1) {
      throw new Error('Declaração Anual do MEI (DASN-SIMEI) não encontrada');
    }

    const agora = new Date().toISOString();
    const decl = this.data.declaracoesAnuaisMei[idx];
    const protocolo = `DASN-${decl.anoCalendario}-${agora.slice(0, 10).replace(/-/g, '')}-${Math.floor(100000 + Math.random() * 899999)}`;
    const recibo = `REC-SIMEI-${decl.anoCalendario}-${Math.floor(10000000 + Math.random() * 89999999)}`;

    decl.status = 'transmitida';
    decl.dataTransmissao = agora;
    decl.protocoloTransmissao = protocolo;
    decl.reciboEntrega = recibo;
    decl.usuarioTransmissao = usuarioNome;
    decl.hashAutenticidade = `SHA256-${decl.anoCalendario}.${protocolo}.${recibo}.OK`;

    // Atualiza ou cria a obrigação fiscal correspondente
    let obrigacaoEncontrada = this.data.obrigacoes.find(
      (ob) =>
        ob.empresaId === decl.empresaId &&
        ob.titulo.toLowerCase().includes('dasn') &&
        ob.competencia.includes(String(decl.anoCalendario))
    );

    if (obrigacaoEncontrada) {
      obrigacaoEncontrada.status = 'concluida';
      obrigacaoEncontrada.dataEntrega = agora.slice(0, 10);
      obrigacaoEncontrada.responsavel = usuarioNome;
      obrigacaoEncontrada.reciboEntrega = protocolo;
    } else {
      const novaObrigacao: Obrigacao = {
        id: `obrig_dasn_${decl.empresaId}_${decl.anoCalendario}`,
        empresaId: decl.empresaId,
        titulo: `DASN-SIMEI - Declaração Anual MEI (${decl.anoCalendario})`,
        tipo: 'Federal',
        competencia: String(decl.anoCalendario),
        dataVencimento: `${decl.anoCalendario + 1}-05-31`,
        status: 'concluida',
        dataEntrega: agora.slice(0, 10),
        responsavel: usuarioNome,
        guiaEmitida: true,
        reciboEntrega: protocolo,
        isDemo: false,
      };
      this.data.obrigacoes.unshift(novaObrigacao);
      obrigacaoEncontrada = novaObrigacao;
    }

    this.persist();
    return { declaracao: decl, obrigacaoAtualizada: obrigacaoEncontrada };
  }

  excluirDeclaracaoMei(id: string): boolean {
    if (!this.data.declaracoesAnuaisMei) return false;
    this.data.declaracoesAnuaisMei = this.data.declaracoesAnuaisMei.filter((d) => d.id !== id);
    this.persist();
    return true;
  }

  // --- SEFAZ DF-e: Notas Fiscais de Entrada Emitidas Contra o CNPJ ---
  getNotasFiscaisEntrada(empresaId?: string): NotaFiscalEntrada[] {
    if (!this.data.notasFiscaisEntrada) {
      this.data.notasFiscaisEntrada = DEMO_NOTAS_ENTRADA;
    }
    if (!empresaId || empresaId === 'todas') {
      return this.data.notasFiscaisEntrada;
    }
    return this.data.notasFiscaisEntrada.filter((nf) => nf.empresaId === empresaId);
  }

  getNotaEntradaById(id: string): NotaFiscalEntrada | undefined {
    return (this.data.notasFiscaisEntrada || []).find((nf) => nf.id === id);
  }

  manifestarNotaEntrada(
    id: string,
    manifestacao: TipoManifestacaoDestinatario,
    justificativa?: string
  ): NotaFiscalEntrada {
    const notas = this.data.notasFiscaisEntrada || [];
    const index = notas.findIndex((n) => n.id === id);
    if (index === -1) {
      throw new Error('Nota Fiscal de Entrada não encontrada');
    }

    const agora = new Date().toISOString();
    const protocoloManifestacao = `1352600${Math.floor(10000000 + Math.random() * 90000000)}`;

    notas[index] = {
      ...notas[index],
      manifestacao,
      dataManifestacao: agora,
      protocoloManifestacao,
      // Se manifestou ciência ou confirmação, a SEFAZ libera o download do XML completo
      xmlCompletoDisponivel: manifestacao === 'ciencia' || manifestacao === 'confirmada' ? true : notas[index].xmlCompletoDisponivel,
      observacoes: justificativa || notas[index].observacoes,
    };

    this.persist();
    return notas[index];
  }

  capturarNotaPorChave(
    empresaId: string,
    chaveRaw: string,
    efetuarCiencia: boolean = true
  ): NotaFiscalEntrada {
    const chave = (chaveRaw || '').replace(/\D/g, '');
    if (chave.length !== 44) {
      throw new Error('A chave de acesso deve conter exatamente 44 dígitos numéricos.');
    }

    if (!this.data.notasFiscaisEntrada) {
      this.data.notasFiscaisEntrada = [];
    }

    // Se já foi capturada, retorna a existente
    const jaExiste = this.data.notasFiscaisEntrada.find((n) => n.chaveAcesso === chave);
    if (jaExiste) {
      if (efetuarCiencia && jaExiste.manifestacao === 'sem_manifestacao') {
        jaExiste.manifestacao = 'ciencia';
        jaExiste.dataManifestacao = new Date().toISOString();
        jaExiste.xmlCompletoDisponivel = true;
        this.persist();
      }
      return jaExiste;
    }

    const empresa = this.getEmpresaById(empresaId) || this.getEmpresas()[0];
    const agora = new Date().toISOString();

    // Extrai partes estruturadas da chave da SEFAZ
    const ufCodigo = chave.substring(0, 2);
    const ano = `20${chave.substring(2, 4)}`;
    const mes = chave.substring(4, 6);
    const cnpjEmitente = chave.substring(6, 20);
    const serie = chave.substring(22, 25).replace(/^0+/, '') || '1';
    const numeroStr = chave.substring(25, 34).replace(/^0+/, '') || `${Math.floor(1000 + Math.random() * 90000)}`;
    const numero = parseInt(numeroStr, 10);

    const ufNomes: Record<string, string> = {
      '35': 'SP',
      '33': 'RJ',
      '31': 'MG',
      '41': 'PR',
      '43': 'RS',
      '52': 'GO',
      '53': 'DF',
      '29': 'BA',
      '23': 'CE',
      '26': 'PE',
    };
    const ufEmitente = ufNomes[ufCodigo] || 'SP';

    const cnpjFormatado = cnpjEmitente.replace(
      /(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/,
      '$1.$2.$3/$4-$5'
    );

    // Gera dados simulados realistas para a nota capturada
    const valorProdutos = Math.floor(1200 + Math.random() * 24000);
    const valorTotal = valorProdutos;
    const icms = parseFloat((valorTotal * 0.12).toFixed(2));
    const pis = parseFloat((valorTotal * 0.0065).toFixed(2));
    const cofins = parseFloat((valorTotal * 0.03).toFixed(2));

    const novaNotaEntrada: NotaFiscalEntrada = {
      id: `nfe_ent_${Date.now()}`,
      empresaId: empresa.id,
      numero,
      serie,
      modelo: '55',
      chaveAcesso: chave,
      dataEmissao: `${ano}-${mes}-05T10:00:00Z`,
      dataCapturaSefaz: agora,
      nsuSefaz: `000000000${Math.floor(148200 + Math.random() * 5000)}`,
      fornecedorNome: `Fornecedor Nacional Eletro-Industrial Ltda (CNPJ ${cnpjFormatado})`,
      fornecedorCnpj: cnpjFormatado,
      fornecedorIe: `${Math.floor(100000000 + Math.random() * 900000000)}`,
      fornecedorUf: ufEmitente,
      fornecedorMunicipio: ufEmitente === 'SP' ? 'São Paulo' : 'Curitiba',
      destinatarioNome: empresa.razaoSocial,
      destinatarioCnpj: empresa.cnpj,
      naturezaOperacao: '5.102 - Venda de mercadoria adquirida ou recebida de terceiros',
      cfopPrincipal: '5.102',
      valorProdutos,
      valorTotal,
      impostos: {
        icms,
        baseCalculoIcms: valorTotal,
        pis,
        cofins,
      },
      itens: [
        {
          codigo: 'ITEM-CAPT-01',
          descricao: 'Mercadoria ou Produto Industrializado para Comercialização/Estoque',
          ncm: '84713012',
          cst: '000',
          cfop: '5102',
          unidade: 'UN',
          quantidade: 5,
          valorUnitario: parseFloat((valorProdutos / 5).toFixed(2)),
          valorTotal: valorProdutos,
        },
      ],
      statusSefaz: 'autorizada',
      manifestacao: efetuarCiencia ? 'ciencia' : 'sem_manifestacao',
      dataManifestacao: efetuarCiencia ? agora : undefined,
      protocoloManifestacao: efetuarCiencia ? `1352600${Math.floor(10000000 + Math.random() * 90000000)}` : undefined,
      statusEscrituracao: 'pendente',
      xmlCompletoDisponivel: efetuarCiencia,
      observacoes: `Documento fiscal capturado individualmente via Chave de Acesso no Portal SEFAZ Nacional.`,
      isDemo: false,
    };

    this.data.notasFiscaisEntrada.unshift(novaNotaEntrada);

    // Registra log da consulta
    if (!this.data.sincronizacoesSefaz) this.data.sincronizacoesSefaz = [];
    this.data.sincronizacoesSefaz.unshift({
      id: `sinc_${Date.now()}`,
      empresaId: empresa.id,
      dataHora: agora,
      tipo: 'manual_chave',
      nsuConsultado: novaNotaEntrada.nsuSefaz,
      notasEncontradas: 1,
      status: 'sucesso',
      mensagem: `Chave ${chave.slice(0, 4)}...${chave.slice(-4)} consultada com sucesso no Web Service SEFAZ AN. XML e DANFE disponibilizados.`,
      tempoMs: 890,
    });

    this.persist();
    return novaNotaEntrada;
  }

  sincronizarEntradasSefaz(empresaId: string): {
    novasNotas: NotaFiscalEntrada[];
    totalConsultadas: number;
    log: SincronizacaoSefazLog;
  } {
    const empresa = this.getEmpresaById(empresaId) || this.getEmpresas()[0];
    const agora = new Date().toISOString();
    const notasExistentes = this.getNotasFiscaisEntrada(empresa.id);

    // Cria 1 ou 2 novas notas simuladas capturadas do Webservice Distribuição DF-e caso a lista seja pequena
    const novas: NotaFiscalEntrada[] = [];
    const novoNsu = `000000000${Math.floor(149000 + Math.random() * 1000)}`;

    const chaveGerada = `352609${Math.random().toString().slice(2, 16)}${Math.random().toString().slice(2, 16)}${Math.random().toString().slice(2, 16)}`.slice(0, 44);
    const numeroNfe = Math.floor(10000 + Math.random() * 89000);
    const valorTotal = Math.floor(3200 + Math.random() * 18000);

    const nova: NotaFiscalEntrada = {
      id: `nfe_ent_sinc_${Date.now()}`,
      empresaId: empresa.id,
      numero: numeroNfe,
      serie: '1',
      modelo: '55',
      chaveAcesso: chaveGerada,
      dataEmissao: agora,
      dataCapturaSefaz: agora,
      nsuSefaz: novoNsu,
      fornecedorNome: 'Atacado e Suprimentos Corporativos Brasil S/A',
      fornecedorCnpj: '08.921.849/0001-33',
      fornecedorIe: '118.928.371.109',
      fornecedorUf: 'SP',
      fornecedorMunicipio: 'São Paulo',
      destinatarioNome: empresa.razaoSocial,
      destinatarioCnpj: empresa.cnpj,
      naturezaOperacao: '5.102 - Venda de mercadorias no Estado',
      cfopPrincipal: '5.102',
      valorProdutos: valorTotal,
      valorTotal,
      impostos: {
        icms: parseFloat((valorTotal * 0.12).toFixed(2)),
        baseCalculoIcms: valorTotal,
        pis: parseFloat((valorTotal * 0.0065).toFixed(2)),
        cofins: parseFloat((valorTotal * 0.03).toFixed(2)),
      },
      itens: [
        {
          codigo: 'SUP-COMP-01',
          descricao: 'Lote de Suprimentos Tecnológicos e Acessórios para Revenda',
          ncm: '85044010',
          quantidade: 10,
          valorUnitario: parseFloat((valorTotal / 10).toFixed(2)),
          valorTotal,
        },
      ],
      statusSefaz: 'autorizada',
      manifestacao: 'sem_manifestacao',
      statusEscrituracao: 'pendente',
      xmlCompletoDisponivel: false,
      observacoes: 'Documento capturado automaticamente pelo Robô de Distribuição DF-e da SEFAZ.',
      isDemo: false,
    };

    if (!this.data.notasFiscaisEntrada) {
      this.data.notasFiscaisEntrada = [];
    }

    this.data.notasFiscaisEntrada.unshift(nova);
    novas.push(nova);

    const log: SincronizacaoSefazLog = {
      id: `sinc_${Date.now()}`,
      empresaId: empresa.id,
      dataHora: agora,
      tipo: 'sincronizacao_dfe',
      nsuConsultado: novoNsu,
      notasEncontradas: 1,
      status: 'sucesso',
      mensagem: `Consulta DF-e realizada com sucesso para o CNPJ ${empresa.cnpj}. Cód 138: 1 novo documento localizado e registrado.`,
      tempoMs: 1250,
    };

    if (!this.data.sincronizacoesSefaz) {
      this.data.sincronizacoesSefaz = [];
    }
    this.data.sincronizacoesSefaz.unshift(log);

    this.persist();

    return {
      novasNotas: novas,
      totalConsultadas: notasExistentes.length + 1,
      log,
    };
  }

  importarXmlEntrada(empresaId: string, xmlString: string): NotaFiscalEntrada {
    const empresa = this.getEmpresaById(empresaId) || this.getEmpresas()[0];
    const agora = new Date().toISOString();

    // Extrai campos via Regex do XML
    const chaveMatch = xmlString.match(/<chNFe>(\d{44})<\/chNFe>/) || xmlString.match(/Id="NFe(\d{44})"/);
    const chave = chaveMatch ? chaveMatch[1] : `352609${Math.random().toString().slice(2, 16)}${Math.random().toString().slice(2, 16)}${Math.random().toString().slice(2, 16)}`.slice(0, 44);

    const nNfMatch = xmlString.match(/<nNF>(\d+)<\/nNF>/);
    const numero = nNfMatch ? parseInt(nNfMatch[1], 10) : Math.floor(1000 + Math.random() * 90000);

    const serieMatch = xmlString.match(/<serie>(\d+)<\/serie>/);
    const serie = serieMatch ? serieMatch[1] : '1';

    const emitNomeMatch = xmlString.match(/<emit>[\s\S]*?<xNome>([^<]+)<\/xNome>/);
    const fornecedorNome = emitNomeMatch ? emitNomeMatch[1].trim() : 'Fornecedor XML Importado Ltda';

    const emitCnpjMatch = xmlString.match(/<emit>[\s\S]*?<CNPJ>(\d{14})<\/CNPJ>/);
    const fornecedorCnpj = emitCnpjMatch
      ? emitCnpjMatch[1].replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5')
      : '00.000.000/0001-00';

    const emitUfMatch = xmlString.match(/<emit>[\s\S]*?<UF>([A-Z]{2})<\/UF>/);
    const fornecedorUf = emitUfMatch ? emitUfMatch[1] : 'SP';

    const emitMunMatch = xmlString.match(/<emit>[\s\S]*?<xMun>([^<]+)<\/xMun>/);
    const fornecedorMunicipio = emitMunMatch ? emitMunMatch[1] : 'São Paulo';

    const natOpMatch = xmlString.match(/<natOp>([^<]+)<\/natOp>/);
    const naturezaOperacao = natOpMatch ? natOpMatch[1] : '5.102 - Compra para revenda';

    const vNfMatch = xmlString.match(/<vNF>([\d.]+)<\/vNF>/);
    const valorTotal = vNfMatch ? parseFloat(vNfMatch[1]) : 5400.0;

    const vIcmsMatch = xmlString.match(/<vICMS>([\d.]+)<\/vICMS>/);
    const icms = vIcmsMatch ? parseFloat(vIcmsMatch[1]) : parseFloat((valorTotal * 0.12).toFixed(2));

    const vPisMatch = xmlString.match(/<vPIS>([\d.]+)<\/vPIS>/);
    const pis = vPisMatch ? parseFloat(vPisMatch[1]) : parseFloat((valorTotal * 0.0065).toFixed(2));

    const vCofinsMatch = xmlString.match(/<vCOFINS>([\d.]+)<\/vCOFINS>/);
    const cofins = vCofinsMatch ? parseFloat(vCofinsMatch[1]) : parseFloat((valorTotal * 0.03).toFixed(2));

    const novaNota: NotaFiscalEntrada = {
      id: `nfe_ent_xml_${Date.now()}`,
      empresaId: empresa.id,
      numero,
      serie,
      modelo: '55',
      chaveAcesso: chave,
      dataEmissao: agora,
      dataCapturaSefaz: agora,
      nsuSefaz: `000000000${Math.floor(148200 + Math.random() * 5000)}`,
      fornecedorNome,
      fornecedorCnpj,
      fornecedorUf,
      fornecedorMunicipio,
      destinatarioNome: empresa.razaoSocial,
      destinatarioCnpj: empresa.cnpj,
      naturezaOperacao,
      cfopPrincipal: '5.102',
      valorProdutos: valorTotal,
      valorTotal,
      impostos: {
        icms,
        baseCalculoIcms: valorTotal,
        pis,
        cofins,
      },
      itens: [
        {
          codigo: 'XML-IMPORT-01',
          descricao: 'Item importado diretamente do arquivo XML da NF-e',
          ncm: '84713012',
          quantidade: 1,
          valorUnitario: valorTotal,
          valorTotal,
        },
      ],
      statusSefaz: 'autorizada',
      manifestacao: 'confirmada',
      dataManifestacao: agora,
      protocoloManifestacao: `1352600${Math.floor(10000000 + Math.random() * 90000000)}`,
      statusEscrituracao: 'escriturada',
      xmlCompletoDisponivel: true,
      xmlContent: xmlString,
      observacoes: 'Arquivo XML importado com sucesso via upload manual / drag & drop.',
      isDemo: false,
    };

    if (!this.data.notasFiscaisEntrada) {
      this.data.notasFiscaisEntrada = [];
    }
    this.data.notasFiscaisEntrada.unshift(novaNota);
    this.persist();
    return novaNota;
  }

  updateStatusEscrituracaoEntrada(
    id: string,
    statusEscrituracao: StatusEscrituracaoEntrada
  ): NotaFiscalEntrada {
    const notas = this.data.notasFiscaisEntrada || [];
    const index = notas.findIndex((n) => n.id === id);
    if (index === -1) {
      throw new Error('Nota Fiscal de Entrada não encontrada');
    }
    notas[index].statusEscrituracao = statusEscrituracao;
    this.persist();
    return notas[index];
  }

  getSincronizacoesSefaz(empresaId?: string): SincronizacaoSefazLog[] {
    if (!this.data.sincronizacoesSefaz) {
      this.data.sincronizacoesSefaz = DEMO_SINCRONIZACOES_SEFAZ;
    }
    if (!empresaId || empresaId === 'todas') {
      return this.data.sincronizacoesSefaz;
    }
    return this.data.sincronizacoesSefaz.filter((s) => s.empresaId === empresaId);
  }

  // --- Certificados Digitais ---
  getCertificados(empresaId?: string): CertificadoDigital[] {
    if (!empresaId || empresaId === 'todas') {
      return this.data.certificados;
    }
    return this.data.certificados.filter((c) => c.empresaId === empresaId);
  }

  createCertificado(cert: Omit<CertificadoDigital, 'id' | 'isDemo'>): CertificadoDigital {
    const newCert: CertificadoDigital = {
      ...cert,
      id: `cert_${Date.now()}`,
      isDemo: false,
    };
    this.data.certificados.unshift(newCert);
    this.persist();
    return newCert;
  }

  instalarCertificado(id: string, senhaSalva: boolean = true): CertificadoDigital {
    const index = this.data.certificados.findIndex((c) => c.id === id);
    if (index === -1) {
      throw new Error('Certificado não encontrado');
    }
    this.data.certificados[index].instaladoNoServidor = true;
    this.data.certificados[index].senhaSalva = senhaSalva;
    this.persist();
    return this.data.certificados[index];
  }

  // --- Pendências e-CAC & Receita Federal ---
  getPendenciasEcac(empresaId?: string): PendenciaEcac[] {
    if (!empresaId || empresaId === 'todas') {
      return this.data.pendenciasEcac;
    }
    return this.data.pendenciasEcac.filter((p) => p.empresaId === empresaId);
  }

  resolverPendenciaEcac(id: string, protocoloRegularizacao: string): PendenciaEcac {
    const index = this.data.pendenciasEcac.findIndex((p) => p.id === id);
    if (index === -1) {
      throw new Error('Pendência e-CAC não encontrada');
    }
    this.data.pendenciasEcac[index].status = 'resolvida';
    this.data.pendenciasEcac[index].protocoloRegularizacao = protocoloRegularizacao;
    this.data.pendenciasEcac[index].resolvidoEm = new Date().toISOString();
    this.persist();
    return this.data.pendenciasEcac[index];
  }

  sincronizarReceitaFederal(empresaId?: string): { sincronizadoEm: string; totalConsultadas: number; novasPendencias: number } {
    return {
      sincronizadoEm: new Date().toISOString(),
      totalConsultadas: this.getPendenciasEcac(empresaId).length,
      novasPendencias: 0,
    };
  }

  // --- Alvarás e Licenças ---
  getAlvaras(empresaId?: string): AlvaraLicenca[] {
    if (!empresaId || empresaId === 'todas') {
      return this.data.alvaras;
    }
    return this.data.alvaras.filter((a) => a.empresaId === empresaId);
  }

  createAlvara(alvara: Omit<AlvaraLicenca, 'id' | 'isDemo'>): AlvaraLicenca {
    const dataValidade = new Date(alvara.dataValidade);
    const hoje = new Date();
    const diffTime = dataValidade.getTime() - hoje.getTime();
    const diasParaVencer = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    let status = alvara.status;
    if (!status) {
      if (diasParaVencer < 0) status = 'vencido';
      else if (diasParaVencer <= 60) status = 'vencendo';
      else status = 'vigente';
    }

    const newAlvara: AlvaraLicenca = {
      ...alvara,
      diasParaVencer,
      status,
      id: `alv_${Date.now()}`,
      isDemo: false,
    };
    this.data.alvaras.unshift(newAlvara);
    this.persist();
    return newAlvara;
  }

  updateAlvara(id: string, updates: Partial<AlvaraLicenca>): AlvaraLicenca {
    const index = this.data.alvaras.findIndex((a) => a.id === id);
    if (index === -1) {
      throw new Error('Alvará/Licença não encontrado');
    }

    if (updates.dataValidade) {
      const dataValidade = new Date(updates.dataValidade);
      const hoje = new Date();
      const diffTime = dataValidade.getTime() - hoje.getTime();
      updates.diasParaVencer = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }

    this.data.alvaras[index] = {
      ...this.data.alvaras[index],
      ...updates,
      id,
    };
    this.persist();
    return this.data.alvaras[index];
  }

  deleteAlvara(id: string): boolean {
    const initialLen = this.data.alvaras.length;
    this.data.alvaras = this.data.alvaras.filter((a) => a.id !== id);
    if (this.data.alvaras.length < initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  registrarRenovacaoAlvara(id: string, protocolo: string, dataSolicitacao?: string): AlvaraLicenca {
    const index = this.data.alvaras.findIndex((a) => a.id === id);
    if (index === -1) {
      throw new Error('Alvará/Licença não encontrado');
    }
    this.data.alvaras[index].status = 'em_renovacao';
    this.data.alvaras[index].protocoloRenovacao = protocolo;
    this.data.alvaras[index].dataSolicitacaoRenovacao = dataSolicitacao || new Date().toISOString().split('T')[0];
    this.persist();
    return this.data.alvaras[index];
  }

  // =========================================================================
  // --- RECURSOS HUMANOS E DEPARTAMENTO PESSOAL (RH & DP) ---
  // =========================================================================

  getFuncoes(empresaId?: string): FuncaoRH[] {
    const allFuncoes = this.data.funcoes || [];
    if (!empresaId || empresaId === 'todas') {
      return allFuncoes;
    }
    // Retorna funções vinculadas à empresa ou compartilhadas ('todas')
    return allFuncoes.filter((f) => f.empresaId === empresaId || f.empresaId === 'todas');
  }

  createFuncao(funcao: Omit<FuncaoRH, 'id' | 'isDemo'>): FuncaoRH {
    const newFuncao: FuncaoRH = {
      ...funcao,
      id: `fnc_${Date.now()}`,
      isDemo: false,
    };
    if (!this.data.funcoes) this.data.funcoes = [];
    this.data.funcoes.unshift(newFuncao);
    this.persist();
    return newFuncao;
  }

  updateFuncao(id: string, updates: Partial<FuncaoRH>): FuncaoRH {
    if (!this.data.funcoes) this.data.funcoes = [];
    const index = this.data.funcoes.findIndex((f) => f.id === id);
    if (index === -1) {
      throw new Error('Função / Cargo não encontrado');
    }
    this.data.funcoes[index] = {
      ...this.data.funcoes[index],
      ...updates,
      id,
    };
    this.persist();
    return this.data.funcoes[index];
  }

  deleteFuncao(id: string): boolean {
    if (!this.data.funcoes) return false;
    const initialLen = this.data.funcoes.length;
    this.data.funcoes = this.data.funcoes.filter((f) => f.id !== id);
    if (this.data.funcoes.length < initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  getFuncionarios(empresaId?: string): Funcionario[] {
    const list = this.data.funcionarios || [];
    if (!empresaId || empresaId === 'todas') {
      return list;
    }
    return list.filter((func) => func.empresaId === empresaId);
  }

  getFuncionarioById(id: string): Funcionario | undefined {
    return (this.data.funcionarios || []).find((func) => func.id === id);
  }

  createFuncionario(func: Omit<Funcionario, 'id' | 'isDemo'>): Funcionario {
    const newFunc: Funcionario = {
      ...func,
      id: `func_${Date.now()}`,
      isDemo: false,
    };
    if (!this.data.funcionarios) this.data.funcionarios = [];
    this.data.funcionarios.unshift(newFunc);

    // Atualiza contagem na Empresa
    const empIndex = this.data.empresas.findIndex((e) => e.id === func.empresaId);
    if (empIndex !== -1) {
      this.data.empresas[empIndex].qtdeFuncionarios = (this.data.empresas[empIndex].qtdeFuncionarios || 0) + 1;
    }

    this.persist();
    return newFunc;
  }

  updateFuncionario(id: string, updates: Partial<Funcionario>): Funcionario {
    if (!this.data.funcionarios) this.data.funcionarios = [];
    const index = this.data.funcionarios.findIndex((f) => f.id === id);
    if (index === -1) {
      throw new Error('Funcionário não encontrado');
    }
    this.data.funcionarios[index] = {
      ...this.data.funcionarios[index],
      ...updates,
      id,
    };
    this.persist();
    return this.data.funcionarios[index];
  }

  deleteFuncionario(id: string): boolean {
    if (!this.data.funcionarios) return false;
    const func = this.data.funcionarios.find((f) => f.id === id);
    const initialLen = this.data.funcionarios.length;
    this.data.funcionarios = this.data.funcionarios.filter((f) => f.id !== id);
    if (this.data.funcionarios.length < initialLen) {
      if (func) {
        const empIndex = this.data.empresas.findIndex((e) => e.id === func.empresaId);
        if (empIndex !== -1 && this.data.empresas[empIndex].qtdeFuncionarios > 0) {
          this.data.empresas[empIndex].qtdeFuncionarios -= 1;
        }
      }
      this.persist();
      return true;
    }
    return false;
  }

  registrarFerias(id: string, dias: number, dataInicio: string, dataFim: string): Funcionario {
    const func = this.getFuncionarioById(id);
    if (!func) throw new Error('Funcionário não encontrado');

    const saldoAtual = func.diasFeriasSaldo || 30;
    const novoSaldo = Math.max(0, saldoAtual - dias);

    return this.updateFuncionario(id, {
      status: 'ferias',
      diasFeriasSaldo: novoSaldo,
      observacoes: `Férias registradas de ${dataInicio} a ${dataFim} (${dias} dias). Saldo restante: ${novoSaldo} dias.`,
    });
  }

  registrarAfastamento(id: string, motivo: string): Funcionario {
    const func = this.getFuncionarioById(id);
    if (!func) throw new Error('Funcionário não encontrado');

    return this.updateFuncionario(id, {
      status: 'afastado',
      observacoes: `Afastamento registrado em ${new Date().toLocaleDateString('pt-BR')}. Motivo: ${motivo}`,
    });
  }

  calcularHolerite(func: Funcionario, competencia = '09/2026'): HoleriteCalculado {
    const salarioBase = Number(func.salarioBase) || 0;
    const adicionaisTotal = Number(func.adicionaisTotal) || 0;
    const totalProventos = Math.round((salarioBase + adicionaisTotal) * 100) / 100;

    const itens: ItemHolerite[] = [
      {
        codigo: '001',
        descricao: 'Salário Base Contratual',
        referencia: '30D',
        tipo: 'provento',
        valor: salarioBase,
      },
    ];

    if (adicionaisTotal > 0) {
      itens.push({
        codigo: '015',
        descricao: 'Adicional de Função / Periculosidade / Insalubridade',
        referencia: 'Calculado',
        tipo: 'provento',
        valor: adicionaisTotal,
      });
    }

    // Cálculo progressivo do INSS (Tabela 2024/2026)
    let valorInss = 0;
    let faixaInss = '7.5%';
    if (totalProventos <= 1412.0) {
      valorInss = totalProventos * 0.075;
      faixaInss = '7.5%';
    } else if (totalProventos <= 2666.68) {
      valorInss = totalProventos * 0.09 - 21.18;
      faixaInss = '9.0%';
    } else if (totalProventos <= 4000.03) {
      valorInss = totalProventos * 0.12 - 101.18;
      faixaInss = '12.0%';
    } else if (totalProventos <= 7786.02) {
      valorInss = totalProventos * 0.14 - 181.18;
      faixaInss = '14.0%';
    } else {
      valorInss = 908.86;
      faixaInss = 'Teto INSS (R$ 908,86)';
    }
    valorInss = Math.max(0, Math.round(valorInss * 100) / 100);

    itens.push({
      codigo: '101',
      descricao: 'INSS - Previdência Social',
      referencia: faixaInss,
      tipo: 'desconto',
      valor: valorInss,
    });

    // Desconto Vale Transporte (se optante, máx 6% do salário base)
    let valorVt = 0;
    if (func.valeTransporte) {
      valorVt = Math.round(salarioBase * 0.06 * 100) / 100;
      itens.push({
        codigo: '105',
        descricao: 'Vale Transporte (Lei 7.418/85)',
        referencia: '6.0%',
        tipo: 'desconto',
        valor: valorVt,
      });
    }

    // Dependentes IRRF: R$ 189,59 por dependente
    const dependentesIrrf = (func.dependentes || []).filter((d) => d.deducaoIrrf).length;
    const deducaoDependentes = dependentesIrrf * 189.59;
    const baseIrrf = Math.max(0, totalProventos - valorInss - deducaoDependentes);

    // Tabela IRRF
    let valorIrrf = 0;
    let faixaIrrf = 'Isento';
    if (baseIrrf <= 2259.2) {
      valorIrrf = 0;
      faixaIrrf = 'Isento';
    } else if (baseIrrf <= 2826.65) {
      valorIrrf = baseIrrf * 0.075 - 169.44;
      faixaIrrf = '7.5%';
    } else if (baseIrrf <= 3751.05) {
      valorIrrf = baseIrrf * 0.15 - 381.44;
      faixaIrrf = '15.0%';
    } else if (baseIrrf <= 4664.68) {
      valorIrrf = baseIrrf * 0.225 - 662.77;
      faixaIrrf = '22.5%';
    } else {
      valorIrrf = baseIrrf * 0.275 - 896.0;
      faixaIrrf = '27.5%';
    }
    valorIrrf = Math.max(0, Math.round(valorIrrf * 100) / 100);

    if (valorIrrf > 0) {
      itens.push({
        codigo: '102',
        descricao: 'IRRF - Imposto de Renda Retido',
        referencia: faixaIrrf,
        tipo: 'desconto',
        valor: valorIrrf,
      });
    }

    const baseFgts = totalProventos;
    const valorFgts = Math.round(baseFgts * 0.08 * 100) / 100;

    const totalDescontos = Math.round((valorInss + valorVt + valorIrrf) * 100) / 100;
    const salarioLiquido = Math.round((totalProventos - totalDescontos) * 100) / 100;

    return {
      funcionarioId: func.id,
      competencia,
      salarioBase,
      totalProventos,
      totalDescontos,
      salarioLiquido,
      valorLiquido: salarioLiquido,
      baseInss: totalProventos,
      valorInss,
      baseIrrf: Math.round(baseIrrf * 100) / 100,
      valorIrrf,
      baseFgts,
      valorFgts,
      faixaInssAliquotaEfetiva: faixaInss,
      faixaIrrfAliquota: faixaIrrf,
      itens,
      bases: {
        salarioBase,
        baseInss: totalProventos,
        baseIrrf: Math.round(baseIrrf * 100) / 100,
        fgtsMes: valorFgts,
      },
    };
  }

  getFolhaSimulada(empresaId?: string, competencia = '09/2026') {
    const funcs = this.getFuncionarios(empresaId).filter((f) => f.status !== 'desligado');
    const holerites = funcs.map((f) => ({
      funcionario: f,
      holerite: this.calcularHolerite(f, competencia),
    }));

    const totalSalarioBase = holerites.reduce((acc, h) => acc + h.holerite.salarioBase, 0);
    const totalBruto = holerites.reduce((acc, h) => acc + h.holerite.totalProventos, 0);
    const totalDescontos = holerites.reduce((acc, h) => acc + h.holerite.totalDescontos, 0);
    const totalLiquido = holerites.reduce((acc, h) => acc + h.holerite.salarioLiquido, 0);
    const totalInssEmpregados = holerites.reduce((acc, h) => acc + h.holerite.valorInss, 0);
    const totalIrrf = holerites.reduce((acc, h) => acc + h.holerite.valorIrrf, 0);
    const totalFgts = holerites.reduce((acc, h) => acc + h.holerite.valorFgts, 0);

    // Encargo patronal estimado (20% CPP se regime não for Simples Nacional, ou conforme anexo)
    const inssPatronalEstimado = Math.round(totalBruto * 0.2 * 100) / 100;

    return {
      competencia,
      totalFuncionarios: funcs.length,
      totalSalarioBase: Math.round(totalSalarioBase * 100) / 100,
      totalBruto: Math.round(totalBruto * 100) / 100,
      totalDescontos: Math.round(totalDescontos * 100) / 100,
      totalLiquido: Math.round(totalLiquido * 100) / 100,
      totalInssEmpregados: Math.round(totalInssEmpregados * 100) / 100,
      totalIrrf: Math.round(totalIrrf * 100) / 100,
      totalFgts: Math.round(totalFgts * 100) / 100,
      inssPatronalEstimado,
      holerites,
    };
  }

  fecharFolhaContasPagar(empresaId: string, competencia: string, dados: { totalLiquido: number; totalInss: number; totalFgts: number }) {
    if (!this.data.contasPagar) this.data.contasPagar = [];
    const targetEmpresaId = empresaId && empresaId !== 'todas'
      ? empresaId
      : (this.data.empresas[0]?.id || 'emp_default');

    const created: ContaPagar[] = [];

    // 1. Salários Líquidos
    if (dados.totalLiquido > 0) {
      const item1: ContaPagar = {
        id: `cp_folha_sal_${Date.now()}`,
        empresaId: targetEmpresaId,
        descricao: `Folha de Pagamento - Salários Líquidos (${competencia})`,
        categoriaId: 'cat_folha',
        beneficiario: 'Colaboradores / Folha Líquida',
        valor: dados.totalLiquido,
        dataVencimento: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        status: 'pendente',
        isDemo: false,
      };
      this.data.contasPagar.unshift(item1);
      created.push(item1);
    }

    // 2. DARF / Guia Previdenciária
    if (dados.totalInss > 0) {
      const item2: ContaPagar = {
        id: `cp_folha_inss_${Date.now() + 1}`,
        empresaId: targetEmpresaId,
        descricao: `Guia Previdenciária DARF / INSS (${competencia})`,
        categoriaId: 'cat_impostos',
        beneficiario: 'Receita Federal do Brasil / Previdência',
        valor: dados.totalInss,
        dataVencimento: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        status: 'pendente',
        isDemo: false,
      };
      this.data.contasPagar.unshift(item2);
      created.push(item2);
    }

    // 3. Guia FGTS Digital
    if (dados.totalFgts > 0) {
      const item3: ContaPagar = {
        id: `cp_folha_fgts_${Date.now() + 2}`,
        empresaId: targetEmpresaId,
        descricao: `Guia FGTS Digital / DAE (${competencia})`,
        categoriaId: 'cat_impostos',
        beneficiario: 'Caixa Econômica Federal / FGTS Digital',
        valor: dados.totalFgts,
        dataVencimento: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        status: 'pendente',
        isDemo: false,
      };
      this.data.contasPagar.unshift(item3);
      created.push(item3);
    }

    this.persist();
    return created;
  }

  // =========================================================================
  // --- PONTO ELETRÔNICO, CONTROLE DE JORNADA & AUDITORIA RH (REP-P) ---
  // =========================================================================

  getPontos(filtros: {
    empresaId?: string;
    funcionarioId?: string;
    dataInicio?: string;
    dataFim?: string;
    competencia?: string; // MM/YYYY
    status?: string;
    inconsistenciasApenas?: boolean;
  } = {}): RegistroPontoDia[] {
    let lista = this.data.pontos || [];

    if (filtros.empresaId && filtros.empresaId !== 'todas') {
      lista = lista.filter((p) => p.empresaId === filtros.empresaId);
    }

    if (filtros.funcionarioId && filtros.funcionarioId !== 'todos') {
      lista = lista.filter((p) => p.funcionarioId === filtros.funcionarioId);
    }

    if (filtros.competencia) {
      const [mes, ano] = filtros.competencia.split('/');
      if (mes && ano) {
        const prefix = `${ano}-${mes}`;
        lista = lista.filter((p) => p.data.startsWith(prefix));
      }
    }

    if (filtros.dataInicio) {
      lista = lista.filter((p) => p.data >= filtros.dataInicio!);
    }

    if (filtros.dataFim) {
      lista = lista.filter((p) => p.data <= filtros.dataFim!);
    }

    if (filtros.status && filtros.status !== 'todos') {
      lista = lista.filter((p) => p.statusAuditoria === filtros.status);
    }

    if (filtros.inconsistenciasApenas) {
      lista = lista.filter((p) => (p.inconsistencias && p.inconsistencias.length > 0) || p.statusAuditoria === 'com_inconsistencia');
    }

    return lista.slice().sort((a, b) => b.data.localeCompare(a.data));
  }

  getPontosHoje(empresaId?: string): {
    dataHoje: string;
    totalFuncionarios: number;
    trabalhandoAgora: number;
    emIntervalo: number;
    expedienteConcluido: number;
    semRegistro: number;
    comInconsistencia: number;
    registros: RegistroPontoDia[];
    colaboradoresSemRegistro: Funcionario[];
  } {
    const dataHoje = new Date().toISOString().split('T')[0];
    const funcs = this.getFuncionarios(empresaId);
    const pontosHoje = (this.data.pontos || []).filter(
      (p) => p.data === dataHoje && (!empresaId || empresaId === 'todas' || p.empresaId === empresaId)
    );

    let trabalhandoAgora = 0;
    let emIntervalo = 0;
    let expedienteConcluido = 0;
    let comInconsistencia = 0;

    const funcsComRegistroIds = new Set<string>();

    for (const p of pontosHoje) {
      funcsComRegistroIds.add(p.funcionarioId);
      if (p.statusAuditoria === 'com_inconsistencia' || (p.inconsistencias && p.inconsistencias.length > 0)) {
        comInconsistencia++;
      }
      if (p.saida2) {
        expedienteConcluido++;
      } else if (p.saidaIntervalo && !p.retornoIntervalo) {
        emIntervalo++;
      } else if (p.entrada1) {
        trabalhandoAgora++;
      }
    }

    const colaboradoresSemRegistro = funcs.filter(
      (f) => f.status === 'ativo' && !funcsComRegistroIds.has(f.id)
    );
    const semRegistro = colaboradoresSemRegistro.length;

    return {
      dataHoje,
      totalFuncionarios: funcs.length,
      trabalhandoAgora,
      emIntervalo,
      expedienteConcluido,
      semRegistro,
      comInconsistencia,
      registros: pontosHoje,
      colaboradoresSemRegistro,
    };
  }

  registrarBatidaPonto(dados: {
    funcionarioId: string;
    tipo: TipoBatidaPonto;
    dataHora?: string;
    geolocalizacao?: {
      latitude: number;
      longitude: number;
      precisao?: number;
      endereco?: string;
    };
    ip?: string;
    fotoComprovante?: string;
    observacao?: string;
    origem?: OrigemBatida;
  }): {
    marcacao: MarcacaoPonto;
    pontoDia: RegistroPontoDia;
    comprovante: ComprovantePontoEmitido;
  } {
    const func = this.getFuncionarioById(dados.funcionarioId);
    if (!func) {
      throw new Error('Funcionário não encontrado');
    }

    const empresa = this.getEmpresaById(func.empresaId);
    if (!empresa) {
      throw new Error('Empresa do funcionário não encontrada');
    }

    const dataHoraIso = dados.dataHora || new Date().toISOString();
    const dataDate = new Date(dataHoraIso);
    const dataStr = dataHoraIso.split('T')[0];

    const horas = String(dataDate.getHours()).padStart(2, '0');
    const minutos = String(dataDate.getMinutes()).padStart(2, '0');
    const horaFormatada = `${horas}:${minutos}`;

    const diasSemana = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];
    const diaSemana = diasSemana[dataDate.getDay()];

    const allBatidas = (this.data.pontos || []).flatMap((p) => p.batidas || []);
    const maxNsr = allBatidas.reduce((max, b) => Math.max(max, b.nsr || 0), 10450);
    const nsr = maxNsr + 1;

    const rawData = `${nsr}|${empresa.cnpj}|${func.cpf}|${dataHoraIso}|${dados.tipo}|${dados.ip || '127.0.0.1'}`;
    const hashRegistro = crypto.createHash('sha256').update(rawData).digest('hex');

    const novaMarcacao: MarcacaoPonto = {
      id: `marc_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      funcionarioId: func.id,
      empresaId: empresa.id,
      dataHora: dataHoraIso,
      tipo: dados.tipo,
      nsr,
      hashRegistro,
      origem: dados.origem || 'rep_p',
      geolocalizacao: dados.geolocalizacao,
      ip: dados.ip || '189.120.45.12',
      fotoComprovante: dados.fotoComprovante,
      observacao: dados.observacao,
      isDemo: false,
    };

    if (!this.data.pontos) {
      this.data.pontos = [];
    }

    let pontoDiaIndex = this.data.pontos.findIndex(
      (p) => p.funcionarioId === func.id && p.data === dataStr
    );

    let pontoDia: RegistroPontoDia;

    if (pontoDiaIndex === -1) {
      pontoDia = {
        id: `ponto_${func.id}_${dataStr}`,
        funcionarioId: func.id,
        funcionarioNome: func.nomeCompleto,
        funcionarioMatricula: func.matricula,
        funcionarioCargo: func.cargoNome,
        departamento: func.departamento,
        empresaId: empresa.id,
        empresaNome: empresa.razaoSocial,
        data: dataStr,
        diaSemana,
        batidas: [novaMarcacao],
        horasPrevistasMinutos: 480,
        horasTrabalhadasMinutos: 0,
        horasIntervaloMinutos: 0,
        horasExtrasMinutos: 0,
        horasNegativasMinutos: 0,
        statusAuditoria: 'pendente',
        inconsistencias: [],
        isDemo: false,
      };
      this.data.pontos.unshift(pontoDia);
    } else {
      pontoDia = this.data.pontos[pontoDiaIndex];
      if (!pontoDia.batidas) pontoDia.batidas = [];
      pontoDia.batidas.push(novaMarcacao);
      pontoDia.batidas.sort((a, b) => a.dataHora.localeCompare(b.dataHora));
    }

    if (dados.tipo === 'entrada_1') {
      pontoDia.entrada1 = horaFormatada;
    } else if (dados.tipo === 'saida_intervalo') {
      pontoDia.saidaIntervalo = horaFormatada;
    } else if (dados.tipo === 'retorno_intervalo') {
      pontoDia.retornoIntervalo = horaFormatada;
    } else if (dados.tipo === 'saida_2') {
      pontoDia.saida2 = horaFormatada;
    }

    this.recalcularPontoDia(pontoDia);
    this.persist();

    const tipoDescricoes: Record<TipoBatidaPonto, string> = {
      entrada_1: '1ª Entrada (Início da Jornada)',
      saida_intervalo: '1ª Saída (Intervalo Intrajornada)',
      retorno_intervalo: '2ª Entrada (Retorno do Intervalo)',
      saida_2: '2ª Saída (Término da Jornada)',
      extra_inicio: 'Início de Horas Extras',
      extra_fim: 'Término de Horas Extras',
    };

    const comprovante: ComprovantePontoEmitido = {
      nsr,
      dataHora: dataHoraIso,
      tipo: dados.tipo,
      tipoDescricao: tipoDescricoes[dados.tipo] || dados.tipo,
      hashRegistro,
      empresa: {
        razaoSocial: empresa.razaoSocial,
        cnpj: empresa.cnpj,
        endereco: `${empresa.cidade} - ${empresa.uf}`,
      },
      funcionario: {
        nome: func.nomeCompleto,
        cpf: func.cpf,
        pisPasep: func.pisPasep,
        matricula: func.matricula,
        cargo: func.cargoNome,
      },
      dispositivo: 'REP-P ContabGest / Terminal Homologado Portaria 671 MTE',
      geolocalizacao: dados.geolocalizacao?.endereco || 'Coordenadas capturadas via GPS/Rede',
    };

    return {
      marcacao: novaMarcacao,
      pontoDia,
      comprovante,
    };
  }

  private recalcularPontoDia(pontoDia: RegistroPontoDia): void {
    const parseMinutos = (h?: string): number | null => {
      if (!h || !h.includes(':')) return null;
      const [hora, min] = h.split(':').map(Number);
      return hora * 60 + min;
    };

    const e1 = parseMinutos(pontoDia.entrada1);
    const s1 = parseMinutos(pontoDia.saidaIntervalo);
    const e2 = parseMinutos(pontoDia.retornoIntervalo);
    const s2 = parseMinutos(pontoDia.saida2);

    let minutosTrabalhados = 0;
    let minutosIntervalo = 0;

    if (e1 !== null && s1 !== null) {
      minutosTrabalhados += Math.max(0, s1 - e1);
    }
    if (e2 !== null && s2 !== null) {
      minutosTrabalhados += Math.max(0, s2 - e2);
    }
    if (s1 !== null && e2 !== null) {
      minutosIntervalo = Math.max(0, e2 - s1);
    } else if (e1 !== null && s2 !== null && s1 === null && e2 === null) {
      minutosTrabalhados = Math.max(0, s2 - e1);
    }

    pontoDia.horasTrabalhadasMinutos = minutosTrabalhados;
    pontoDia.horasIntervaloMinutos = minutosIntervalo;

    const previstas = pontoDia.horasPrevistasMinutos || 480;

    if (minutosTrabalhados > previstas) {
      pontoDia.horasExtrasMinutos = minutosTrabalhados - previstas;
      pontoDia.horasNegativasMinutos = 0;
    } else if (s2 !== null && minutosTrabalhados < previstas) {
      pontoDia.horasNegativasMinutos = previstas - minutosTrabalhados;
      pontoDia.horasExtrasMinutos = 0;
    } else {
      pontoDia.horasExtrasMinutos = 0;
      pontoDia.horasNegativasMinutos = 0;
    }

    const inconsistencias: string[] = [];
    const totalBatidas = pontoDia.batidas?.length || 0;
    if (totalBatidas > 0 && totalBatidas % 2 !== 0 && !pontoDia.saida2) {
      inconsistencias.push('Batida ímpar: registro pendente de marcação de retorno ou saída final');
    }

    if (minutosIntervalo > 0 && minutosIntervalo < 60) {
      inconsistencias.push(`Intervalo de refeição de ${minutosIntervalo} min inferior ao limite legal de 60 min (CLT Art. 71)`);
    }

    if (minutosTrabalhados > 600) {
      inconsistencias.push('Jornada total diária superior a 10 horas, excedendo o teto da CLT (Art. 59)');
    }

    pontoDia.inconsistencias = inconsistencias;

    if (inconsistencias.length > 0 && pontoDia.statusAuditoria !== 'ajustado' && pontoDia.statusAuditoria !== 'abonado') {
      pontoDia.statusAuditoria = 'com_inconsistencia';
    } else if (inconsistencias.length === 0 && pontoDia.statusAuditoria === 'com_inconsistencia') {
      pontoDia.statusAuditoria = 'pendente';
    }
  }

  ajustarPontoDia(
    pontoDiaId: string,
    ajustes: {
      entrada1?: string;
      saidaIntervalo?: string;
      retornoIntervalo?: string;
      saida2?: string;
      motivoAjuste: string;
      observacaoRH?: string;
      auditadoPor: string;
      statusAuditoria?: StatusAuditoriaPonto;
    }
  ): RegistroPontoDia {
    if (!this.data.pontos) this.data.pontos = [];
    const index = this.data.pontos.findIndex((p) => p.id === pontoDiaId);
    if (index === -1) {
      throw new Error('Registro de ponto não encontrado');
    }

    const ponto = this.data.pontos[index];

    if (ajustes.entrada1 !== undefined) ponto.entrada1 = ajustes.entrada1;
    if (ajustes.saidaIntervalo !== undefined) ponto.saidaIntervalo = ajustes.saidaIntervalo;
    if (ajustes.retornoIntervalo !== undefined) ponto.retornoIntervalo = ajustes.retornoIntervalo;
    if (ajustes.saida2 !== undefined) ponto.saida2 = ajustes.saida2;

    ponto.observacaoRH = ajustes.observacaoRH || ajustes.motivoAjuste;
    ponto.auditadoPor = ajustes.auditadoPor;
    ponto.dataAuditado = new Date().toISOString();
    ponto.statusAuditoria = ajustes.statusAuditoria || 'ajustado';

    const novaBatidaAjuste: MarcacaoPonto = {
      id: `marc_ajuste_${Date.now()}`,
      funcionarioId: ponto.funcionarioId,
      empresaId: ponto.empresaId,
      dataHora: `${ponto.data}T${ponto.saida2 || ponto.entrada1 || '12:00'}:00.000Z`,
      tipo: 'saida_2',
      nsr: 99999,
      hashRegistro: crypto.createHash('sha256').update(`AJUSTE_RH|${ponto.id}|${Date.now()}`).digest('hex'),
      origem: 'ajuste_rh',
      editadoManualmente: true,
      motivoAjuste: ajustes.motivoAjuste,
      ajustadoPor: ajustes.auditadoPor,
      dataHoraAjuste: new Date().toISOString(),
      isDemo: false,
    };

    if (!ponto.batidas) ponto.batidas = [];
    ponto.batidas.push(novaBatidaAjuste);

    this.recalcularPontoDia(ponto);
    ponto.statusAuditoria = ajustes.statusAuditoria || 'ajustado';

    this.persist();
    return ponto;
  }

  auditarPontoDia(
    pontoDiaId: string,
    dados: {
      status: StatusAuditoriaPonto;
      observacaoRH?: string;
      auditadoPor: string;
    }
  ): RegistroPontoDia {
    if (!this.data.pontos) this.data.pontos = [];
    const index = this.data.pontos.findIndex((p) => p.id === pontoDiaId);
    if (index === -1) {
      throw new Error('Registro de ponto não encontrado');
    }

    const ponto = this.data.pontos[index];
    ponto.statusAuditoria = dados.status;
    if (dados.observacaoRH) ponto.observacaoRH = dados.observacaoRH;
    ponto.auditadoPor = dados.auditadoPor;
    ponto.dataAuditado = new Date().toISOString();

    this.persist();
    return ponto;
  }

  homologarPontosLote(
    filtros: {
      empresaId?: string;
      competencia?: string;
      apenasSemInconsistencia?: boolean;
    },
    auditadoPor: string
  ): { totalHomologados: number } {
    let pontos = this.data.pontos || [];

    if (filtros.empresaId && filtros.empresaId !== 'todas') {
      pontos = pontos.filter((p) => p.empresaId === filtros.empresaId);
    }

    if (filtros.competencia) {
      const [mes, ano] = filtros.competencia.split('/');
      if (mes && ano) {
        pontos = pontos.filter((p) => p.data.startsWith(`${ano}-${mes}`));
      }
    }

    let homologados = 0;
    const agora = new Date().toISOString();

    for (const p of pontos) {
      const hasInconsistencia = p.inconsistencias && p.inconsistencias.length > 0;
      if (filtros.apenasSemInconsistencia && hasInconsistencia) {
        continue;
      }
      if (p.statusAuditoria !== 'aprovado') {
        p.statusAuditoria = 'aprovado';
        p.auditadoPor = auditadoPor;
        p.dataAuditado = agora;
        homologados++;
      }
    }

    if (homologados > 0) {
      this.persist();
    }

    return { totalHomologados: homologados };
  }

  getEspelhoPontoMensal(funcionarioId: string, competencia: string): EspelhoPontoMensal {
    const func = this.getFuncionarioById(funcionarioId);
    if (!func) {
      throw new Error('Funcionário não encontrado');
    }

    const empresa = this.getEmpresaById(func.empresaId) || {
      id: func.empresaId,
      razaoSocial: (func as any).empresaNome || 'InovaTech Soluções Digitais Ltda',
      cnpj: '12.345.678/0001-90',
      endereco: 'Av. Paulista, 1842 - Bela Vista',
      cidade: 'São Paulo',
      uf: 'SP',
    };

    const [mesStr, anoStr] = competencia.split('/');
    const mes = parseInt(mesStr, 10);
    const ano = parseInt(anoStr, 10);

    if (isNaN(mes) || isNaN(ano) || mes < 1 || mes > 12) {
      throw new Error('Formato de competência inválido. Use MM/AAAA.');
    }

    const totalDiasNoMes = new Date(ano, mes, 0).getDate();
    const dataAtualSimulada = '2026-09-14';

    // Férias ativas do colaborador no período
    const feriasColab = (this.data.ferias || []).filter(
      (f) => f.funcionarioId === funcionarioId && f.status !== 'cancelado'
    );

    // Registros reais de batidas no banco para o mês
    const prefixMes = `${ano}-${String(mes).padStart(2, '0')}`;
    const pontosGravados = (this.data.pontos || []).filter(
      (p) => p.funcionarioId === funcionarioId && p.data.startsWith(prefixMes)
    );
    const mapaPontosGravados = new Map<string, RegistroPontoDia>();
    for (const p of pontosGravados) {
      mapaPontosGravados.set(p.data, p);
    }

    // Tabela de feriados nacionais brasileiros
    const feriadosFixos: Record<string, string> = {
      '01-01': 'Confraternização Universal',
      '04-21': 'Tiradentes',
      '05-01': 'Dia do Trabalhador',
      '09-07': 'Independência do Brasil',
      '10-12': 'N. Sra. Aparecida (Padroeira do Brasil)',
      '11-02': 'Finados',
      '11-15': 'Proclamação da República',
      '11-20': 'Dia da Consciência Negra',
      '12-25': 'Natal',
    };

    const diasSemanaNomes = [
      'Domingo',
      'Segunda-feira',
      'Terça-feira',
      'Quarta-feira',
      'Quinta-feira',
      'Sexta-feira',
      'Sábado',
    ];

    const todosDias: RegistroPontoDia[] = [];

    let totalTrabalhadasMinutos = 0;
    let totalPrevistasMinutos = 0;
    let totalHorasExtras50Minutos = 0;
    let totalHorasExtras100Minutos = 0;
    let totalAtrasosMinutos = 0;
    let totalFaltasMinutos = 0;
    let totalFaltasDias = 0;
    let totalDiasTrabalhados = 0;
    let totalDiasUteis = 0;
    let totalDiasDsr = 0;
    let totalInconsistencias = 0;

    for (let d = 1; d <= totalDiasNoMes; d++) {
      const diaNumStr = String(d).padStart(2, '0');
      const dataIso = `${prefixMes}-${diaNumStr}`;
      const dataObj = new Date(ano, mes - 1, d);
      const diaSemanaIndex = dataObj.getDay();
      const diaSemanaNome = diasSemanaNomes[diaSemanaIndex];
      const mesDiaStr = `${String(mes).padStart(2, '0')}-${diaNumStr}`;
      const isFeriado = !!feriadosFixos[mesDiaStr];
      const nomeFeriado = feriadosFixos[mesDiaStr];

      const emFerias = feriasColab.some((f) => dataIso >= f.dataInicio && dataIso <= f.dataFim);

      const pontoExistente = mapaPontosGravados.get(dataIso);

      if (diaSemanaIndex === 0 || isFeriado) {
        totalDiasDsr++;
      } else if (diaSemanaIndex >= 1 && diaSemanaIndex <= 5 && !emFerias) {
        totalDiasUteis++;
      }

      if (pontoExistente) {
        // Usa as marcações reais registradas pelo REP-P
        const horasTrab = pontoExistente.horasTrabalhadasMinutos || 0;
        const horasPrev = pontoExistente.horasPrevistasMinutos ?? (diaSemanaIndex === 0 || diaSemanaIndex === 6 ? 0 : 480);
        let he50 = 0;
        let he100 = 0;
        let atrasoMin = 0;

        if (diaSemanaIndex === 0 || isFeriado) {
          // Trabalho em DSR ou feriado legal = Horas Extras a 100% (Súmula 146 TST)
          he100 = horasTrab;
          pontoExistente.tipoDia = isFeriado ? 'feriado' : 'dsr';
          pontoExistente.ocorrenciaDescricao = `Trabalho em ${isFeriado ? 'Feriado' : 'DSR'} (H.E. 100%)`;
        } else {
          pontoExistente.tipoDia = diaSemanaIndex === 6 ? 'sabado_compensado' : 'util';
          if (horasTrab > horasPrev) {
            he50 = horasTrab - horasPrev;
            pontoExistente.ocorrenciaDescricao = `Hora Extra 50%: +${Math.floor(he50 / 60)}h${String(he50 % 60).padStart(2, '0')}`;
          } else if (pontoExistente.saida2 && horasTrab < horasPrev) {
            atrasoMin = horasPrev - horasTrab;
            pontoExistente.ocorrenciaDescricao = `Atraso / Saída Antecipada: -${Math.floor(atrasoMin / 60)}h${String(atrasoMin % 60).padStart(2, '0')}`;
          }
        }

        pontoExistente.horasExtras50Minutos = he50;
        pontoExistente.horasExtras100Minutos = he100;
        pontoExistente.horasExtrasMinutos = he50 + he100;
        pontoExistente.horasNegativasMinutos = atrasoMin;

        totalTrabalhadasMinutos += horasTrab;
        totalPrevistasMinutos += horasPrev;
        totalHorasExtras50Minutos += he50;
        totalHorasExtras100Minutos += he100;
        totalAtrasosMinutos += atrasoMin;
        if (horasTrab > 0) totalDiasTrabalhados++;
        if (pontoExistente.inconsistencias && pontoExistente.inconsistencias.length > 0) {
          totalInconsistencias += pontoExistente.inconsistencias.length;
        }

        todosDias.push(pontoExistente);
      } else {
        // Dia sem batida registrada no REP-P
        let tipoDia: RegistroPontoDia['tipoDia'] = 'util';
        let horasPrevistas = 0;
        let ocorrencia = '';
        let isFalta = false;

        if (emFerias) {
          tipoDia = 'ferias';
          ocorrencia = 'Férias Regulamentares (CLT Art. 129)';
        } else if (isFeriado) {
          tipoDia = 'feriado';
          ocorrencia = `Feriado: ${nomeFeriado}`;
        } else if (diaSemanaIndex === 0) {
          tipoDia = 'dsr';
          ocorrencia = 'Repouso Semanal Remunerado (DSR)';
        } else if (diaSemanaIndex === 6) {
          tipoDia = 'sabado_compensado';
          ocorrencia = 'Sábado Compensado';
        } else {
          // Dia útil (Segunda a Sexta)
          horasPrevistas = 480; // 8h normais
          if (dataIso <= dataAtualSimulada) {
            // Dia útil passado sem registro = Falta Integral
            tipoDia = 'util';
            isFalta = true;
            ocorrencia = 'Falta Integral Não Justificada';
            totalFaltasDias++;
            totalFaltasMinutos += 480;
            totalPrevistasMinutos += 480;
          } else {
            // Dia futuro no mês
            tipoDia = 'futuro';
            ocorrencia = 'Expediente Futuro (A Cumprir)';
            totalPrevistasMinutos += 480;
          }
        }

        const registroVazio: RegistroPontoDia = {
          id: `ponto_esp_${funcionarioId}_${dataIso}`,
          funcionarioId,
          funcionarioNome: func.nomeCompleto,
          funcionarioMatricula: func.matricula,
          funcionarioCargo: func.cargoNome,
          departamento: func.departamento,
          empresaId: func.empresaId,
          empresaNome: empresa.razaoSocial,
          data: dataIso,
          diaSemana: diaSemanaNome,
          entrada1: undefined,
          saidaIntervalo: undefined,
          retornoIntervalo: undefined,
          saida2: undefined,
          horasPrevistasMinutos: horasPrevistas,
          horasTrabalhadasMinutos: 0,
          horasIntervaloMinutos: 0,
          horasExtrasMinutos: 0,
          horasExtras50Minutos: 0,
          horasExtras100Minutos: 0,
          horasNegativasMinutos: isFalta ? 480 : 0,
          tipoDia,
          isFaltaIntegral: isFalta,
          ocorrenciaDescricao: ocorrencia,
          statusAuditoria: isFalta ? 'com_inconsistencia' : 'aprovado',
          inconsistencias: isFalta ? ['Ausência de marcação em dia útil (Falta integral)'] : [],
          batidas: [],
        };

        todosDias.push(registroVazio);
      }
    }

    // Cálculo do Reflexo de DSR sobre Horas Extras (Lei 605/49 e Súmula 172 TST):
    // DSR = (Total Horas Extras no mês / Dias Úteis) * Dias de DSR e Feriados
    const totalHEMinutos = totalHorasExtras50Minutos + totalHorasExtras100Minutos;
    const totalDsrSobreHorasExtrasMinutos =
      totalDiasUteis > 0 ? Math.round((totalHEMinutos / totalDiasUteis) * totalDiasDsr) : 0;

    // Saldo consolidado de horas (Positivas vs Negativas)
    const saldoHorasMinutos = totalHEMinutos - (totalAtrasosMinutos + totalFaltasMinutos);

    // Valores Financeiros Calculados:
    // Salário hora divisor 220 (jornada 44h semanais CLT)
    const salarioBase = func.salarioBase || 3500;
    const valorHoraNormal = Math.round((salarioBase / 220) * 100) / 100;
    const valorHorasExtras50 = Math.round((totalHorasExtras50Minutos / 60) * (valorHoraNormal * 1.5) * 100) / 100;
    const valorHorasExtras100 = Math.round((totalHorasExtras100Minutos / 60) * (valorHoraNormal * 2.0) * 100) / 100;
    const valorDsrHorasExtras = Math.round((totalDsrSobreHorasExtrasMinutos / 60) * (valorHoraNormal * 1.5) * 100) / 100;
    const valorDescontoFaltas = Math.round((totalFaltasMinutos / 60) * valorHoraNormal * 100) / 100;
    const valorDescontoAtrasos = Math.round((totalAtrasosMinutos / 60) * valorHoraNormal * 100) / 100;

    const valorTotalProventosExtras = valorHorasExtras50 + valorHorasExtras100 + valorDsrHorasExtras;
    const valorTotalDescontosPonto = valorDescontoFaltas + valorDescontoAtrasos;
    const saldoFinanceiroLiquido = Math.round((valorTotalProventosExtras - valorTotalDescontosPonto) * 100) / 100;

    // Hash de integridade digital SHA-256 conforme Portaria MTP 671/2021 Art. 84
    const seedHash = `REP-P|${empresa.cnpj}|${func.cpf}|${competencia}|${totalTrabalhadasMinutos}|${totalHEMinutos}|${totalFaltasMinutos}`;
    const hashAutenticidade = crypto.createHash('sha256').update(seedHash).digest('hex');

    return {
      funcionarioId,
      competencia,
      empresaId: func.empresaId,
      empresa: {
        razaoSocial: empresa.razaoSocial,
        cnpj: empresa.cnpj,
        endereco: (empresa as any).endereco || `${(empresa as any).cidade || 'São Paulo'} - ${(empresa as any).uf || 'SP'}`,
        cidadeUf: `${(empresa as any).cidade || 'São Paulo'}/${(empresa as any).uf || 'SP'}`,
      },
      funcionario: {
        nome: func.nomeCompleto,
        cpf: func.cpf,
        pisPasep: func.pisPasep || 'Cadastrado no eSocial',
        matricula: func.matricula,
        cargo: func.cargoNome,
        departamento: func.departamento,
        salarioBase,
        dataAdmissao: func.dataAdmissao || '2023-01-01',
        jornadaDescricao: 'Segunda a Sexta das 08:00 às 17:00 (Intervalo: 12:00 às 13:00) • 44h semanais',
      },
      periodoDescricao: `01/${mesStr}/${anoStr} a ${totalDiasNoMes}/${mesStr}/${anoStr}`,
      totalDiasMes: totalDiasNoMes,
      totalDiasTrabalhados,
      totalDiasUteis,
      totalDiasDsr,
      totalFaltasDias,
      totalFaltasMinutos,
      totalHorasTrabalhadasMinutos: totalTrabalhadasMinutos,
      totalHorasPrevistasMinutos: totalPrevistasMinutos,
      saldoHorasMinutos,
      totalHorasExtrasMinutos: totalHEMinutos,
      totalHorasExtras50Minutos,
      totalHorasExtras100Minutos,
      totalDsrSobreHorasExtrasMinutos,
      totalAtrasosMinutos,
      totalInconsistencias,
      valorHoraNormal,
      valorHorasExtras50,
      valorHorasExtras100,
      valorDsrHorasExtras,
      valorDescontoFaltas,
      valorDescontoAtrasos,
      valorTotalProventosExtras,
      valorTotalDescontosPonto,
      saldoFinanceiroLiquido,
      hashAutenticidade,
      dataEmissao: new Date().toISOString().split('T')[0],
      dias: todosDias,
    };
  }

  // =========================================================================
  // --- CONTROLE DE FÉRIAS, PERÍODOS AQUISITIVOS & CONCESSIVOS (CLT) ---
  // =========================================================================

  getPeriodosFerias(filtros: {
    empresaId?: string;
    funcionarioId?: string;
    status?: string;
    ano?: number;
  } = {}): PeriodoGozoFerias[] {
    let lista = this.data.ferias || [];

    if (filtros.empresaId && filtros.empresaId !== 'todas') {
      lista = lista.filter((f) => f.empresaId === filtros.empresaId);
    }

    if (filtros.funcionarioId && filtros.funcionarioId !== 'todos') {
      lista = lista.filter((f) => f.funcionarioId === filtros.funcionarioId);
    }

    if (filtros.status && filtros.status !== 'todos') {
      lista = lista.filter((f) => f.status === filtros.status);
    }

    if (filtros.ano) {
      const anoStr = String(filtros.ano);
      lista = lista.filter((f) => f.dataInicio.startsWith(anoStr) || f.dataFim.startsWith(anoStr));
    }

    return lista.slice().sort((a, b) => b.dataInicio.localeCompare(a.dataInicio));
  }

  calcularValoresFerias(params: {
    salarioBase: number;
    diasGozo: number;
    abonoPecuniario: boolean;
    diasAbono: number;
    adiantamentoDecimoTerceiro: boolean;
    dependentesIrrf?: number;
  }) {
    const {
      salarioBase,
      diasGozo,
      abonoPecuniario,
      diasAbono,
      adiantamentoDecimoTerceiro,
      dependentesIrrf = 0,
    } = params;
    const valorDia = salarioBase / 30;

    const valorFeriasBruto = Math.round(valorDia * diasGozo * 100) / 100;
    const tercoConstitucional = Math.round((valorFeriasBruto / 3) * 100) / 100;

    const valorAbono = abonoPecuniario ? Math.round(valorDia * (diasAbono || 10) * 100) / 100 : 0;
    const tercoAbono = abonoPecuniario ? Math.round((valorAbono / 3) * 100) / 100 : 0;

    const adiantamento13 = adiantamentoDecimoTerceiro ? Math.round(salarioBase * 0.5 * 100) / 100 : 0;

    // INSS incide sobre férias gozadas + 1/3 (abono pecuniário e seu 1/3 são indenizatórios e isentos)
    const baseInss = valorFeriasBruto + tercoConstitucional;
    let inssFerias = 0;
    if (baseInss <= 1412.0) {
      inssFerias = baseInss * 0.075;
    } else if (baseInss <= 2666.68) {
      inssFerias = baseInss * 0.09 - 21.18;
    } else if (baseInss <= 4000.03) {
      inssFerias = baseInss * 0.12 - 101.18;
    } else if (baseInss <= 7786.02) {
      inssFerias = baseInss * 0.14 - 181.18;
    } else {
      inssFerias = 908.86;
    }
    inssFerias = Math.max(0, Math.round(inssFerias * 100) / 100);

    // IRRF sobre férias (tributação exclusiva na fonte)
    const deducaoDep = dependentesIrrf * 189.59;
    const baseIrrf = Math.max(0, baseInss - inssFerias - deducaoDep);
    let irrfFerias = 0;
    if (baseIrrf <= 2259.2) {
      irrfFerias = 0;
    } else if (baseIrrf <= 2826.65) {
      irrfFerias = baseIrrf * 0.075 - 169.44;
    } else if (baseIrrf <= 3751.05) {
      irrfFerias = baseIrrf * 0.15 - 381.44;
    } else if (baseIrrf <= 4664.68) {
      irrfFerias = baseIrrf * 0.225 - 662.77;
    } else {
      irrfFerias = baseIrrf * 0.275 - 896.0;
    }
    irrfFerias = Math.max(0, Math.round(irrfFerias * 100) / 100);

    const totalBruto =
      valorFeriasBruto + tercoConstitucional + valorAbono + tercoAbono + adiantamento13;
    const totalDescontos = inssFerias + irrfFerias;
    const totalLiquido = Math.round((totalBruto - totalDescontos) * 100) / 100;

    return {
      salarioBase,
      valorFeriasBruto,
      tercoConstitucional,
      valorAbono,
      tercoAbono,
      adiantamento13,
      inssFerias,
      irrfFerias,
      totalLiquido,
    };
  }

  registrarPeriodoGozo(dados: {
    funcionarioId: string;
    periodoAquisitivoInicio: string;
    periodoAquisitivoFim: string;
    limiteConcessivo: string;
    fracionamentoNumero: 1 | 2 | 3;
    dataInicio: string;
    dataFim: string;
    diasGozo: number;
    abonoPecuniario: boolean;
    diasAbono: number;
    adiantamentoDecimoTerceiro: boolean;
    dataAvisoFerias?: string;
    dataLimitePagamento?: string;
    observacoes?: string;
  }): { periodo: PeriodoGozoFerias; funcionario: Funcionario } {
    if (!this.data.ferias) this.data.ferias = [];
    const func = this.getFuncionarioById(dados.funcionarioId);
    if (!func) throw new Error('Colaborador não encontrado.');

    const saldoDisponivel = func.diasFeriasSaldo ?? 30;
    const diasConsumidos =
      Number(dados.diasGozo) + (dados.abonoPecuniario ? Number(dados.diasAbono || 10) : 0);

    if (diasConsumidos > saldoDisponivel) {
      throw new Error(
        `Saldo de férias insuficiente. Disponível: ${saldoDisponivel} dias, solicitado: ${diasConsumidos} dias.`
      );
    }

    // Calcula data do aviso se não enviada (mínimo 30 dias antes do gozo)
    const dtInicio = new Date(`${dados.dataInicio}T12:00:00.000Z`);
    let dataAviso = dados.dataAvisoFerias;
    if (!dataAviso) {
      const dtAviso = new Date(dtInicio);
      dtAviso.setDate(dtAviso.getDate() - 30);
      dataAviso = dtAviso.toISOString().split('T')[0];
    }

    // Calcula data limite de pagamento se não enviada (2 dias antes do início - Art. 145 CLT)
    let dataLimitePag = dados.dataLimitePagamento;
    if (!dataLimitePag) {
      const dtPag = new Date(dtInicio);
      dtPag.setDate(dtPag.getDate() - 2);
      dataLimitePag = dtPag.toISOString().split('T')[0];
    }

    const dependentesIrrf = (func.dependentes || []).filter((d) => d.deducaoIrrf).length;
    const valores = this.calcularValoresFerias({
      salarioBase: func.salarioBase || 0,
      diasGozo: Number(dados.diasGozo),
      abonoPecuniario: !!dados.abonoPecuniario,
      diasAbono: Number(dados.diasAbono || 0),
      adiantamentoDecimoTerceiro: !!dados.adiantamentoDecimoTerceiro,
      dependentesIrrf,
    });

    const empresa = this.data.empresas.find((e) => e.id === func.empresaId);

    // Determina status inicial com base nas datas e data atual simulada (2026-09-13)
    const hojeStr = '2026-09-13';
    let statusInicial: StatusFeriasPeriodo = 'planejado';
    if (hojeStr >= dados.dataInicio && hojeStr <= dados.dataFim) {
      statusInicial = 'em_gozo';
    } else if (hojeStr > dados.dataFim) {
      statusInicial = 'concluido';
    } else {
      statusInicial = 'aprovado';
    }

    const novoPeriodo: PeriodoGozoFerias = {
      id: `fer_${Date.now()}`,
      funcionarioId: func.id,
      funcionarioNome: func.nomeCompleto,
      funcionarioMatricula: func.matricula,
      funcionarioCargo: func.cargoNome,
      empresaId: func.empresaId,
      empresaNome: empresa?.razaoSocial || 'Empresa',
      periodoAquisitivoInicio: dados.periodoAquisitivoInicio,
      periodoAquisitivoFim: dados.periodoAquisitivoFim,
      limiteConcessivo: dados.limiteConcessivo,
      fracionamentoNumero: dados.fracionamentoNumero || 1,
      dataInicio: dados.dataInicio,
      dataFim: dados.dataFim,
      diasGozo: Number(dados.diasGozo),
      abonoPecuniario: !!dados.abonoPecuniario,
      diasAbono: dados.abonoPecuniario ? Number(dados.diasAbono || 10) : 0,
      adiantamentoDecimoTerceiro: !!dados.adiantamentoDecimoTerceiro,
      dataAvisoFerias: dataAviso,
      dataLimitePagamento: dataLimitePag,
      status: statusInicial,
      valoresFinanceiros: valores,
      observacoes: dados.observacoes,
      criadoEm: new Date().toISOString(),
      isDemo: false,
    };

    this.data.ferias.unshift(novoPeriodo);

    // Atualiza funcionário com novo saldo
    const novoSaldo = Math.max(0, saldoDisponivel - diasConsumidos);
    const updates: Partial<Funcionario> = {
      diasFeriasSaldo: novoSaldo,
      observacoes: `Férias registradas de ${dados.dataInicio} a ${dados.dataFim} (${dados.diasGozo} dias${
        dados.abonoPecuniario ? ' + 10d abono' : ''
      }). Saldo restante: ${novoSaldo} dias.`,
    };

    if (statusInicial === 'em_gozo') {
      updates.status = 'ferias';
    }

    const funcAtualizado = this.updateFuncionario(func.id, updates);
    this.persist();
    return { periodo: novoPeriodo, funcionario: funcAtualizado };
  }

  cancelarPeriodoGozo(id: string): { success: boolean; periodo: PeriodoGozoFerias } {
    if (!this.data.ferias) this.data.ferias = [];
    const index = this.data.ferias.findIndex((f) => f.id === id);
    if (index === -1) throw new Error('Registro de férias não encontrado.');

    const periodo = this.data.ferias[index];
    if (periodo.status === 'cancelado')
      throw new Error('Este período de férias já se encontra cancelado.');

    periodo.status = 'cancelado';

    // Devolve os dias para o saldo do funcionário
    const func = this.getFuncionarioById(periodo.funcionarioId);
    if (func) {
      const diasRestituidos =
        periodo.diasGozo + (periodo.abonoPecuniario ? periodo.diasAbono : 0);
      const saldoRestaurado = Math.min(30, (func.diasFeriasSaldo || 0) + diasRestituidos);
      const updates: Partial<Funcionario> = {
        diasFeriasSaldo: saldoRestaurado,
      };
      if (func.status === 'ferias') {
        updates.status = 'ativo';
      }
      this.updateFuncionario(func.id, updates);
    }

    this.persist();
    return { success: true, periodo };
  }

  calcularSaldosEPeriodosFuncionario(funcionarioId: string): {
    funcionario: Funcionario;
    periodos: PeriodoAquisitivoHistorico[];
    saldoTotalDisponivel: number;
    avisos: AlertaFeriasItem[];
  } {
    const func = this.getFuncionarioById(funcionarioId);
    if (!func) throw new Error('Colaborador não encontrado');

    const empresa = this.data.empresas.find((e) => e.id === func.empresaId);
    const periodosGozo = (this.data.ferias || []).filter(
      (f) => f.funcionarioId === funcionarioId && f.status !== 'cancelado'
    );

    const hoje = new Date('2026-09-13T12:00:00.000Z');
    const dataAdm = func.dataAdmissao
      ? new Date(`${func.dataAdmissao}T12:00:00.000Z`)
      : new Date('2023-01-01');

    const historicoPeriodos: PeriodoAquisitivoHistorico[] = [];
    const avisos: AlertaFeriasItem[] = [];

    // Itera ano a ano a partir da data de admissão
    let anoIndex = 0;
    let cursorInicio = new Date(dataAdm);

    while (cursorInicio < hoje && anoIndex < 6) {
      anoIndex++;
      const cursorFim = new Date(cursorInicio);
      cursorFim.setFullYear(cursorFim.getFullYear() + 1);
      cursorFim.setDate(cursorFim.getDate() - 1);

      const limiteConcessivo = new Date(cursorFim);
      limiteConcessivo.setFullYear(limiteConcessivo.getFullYear() + 1);

      const inicioStr = cursorInicio.toISOString().split('T')[0];
      const fimStr = cursorFim.toISOString().split('T')[0];
      const limiteStr = limiteConcessivo.toISOString().split('T')[0];

      // Períodos de gozo vinculados a este período aquisitivo
      const gozosDestePeriodo = periodosGozo.filter(
        (g) =>
          g.periodoAquisitivoInicio === inicioStr ||
          (g.dataInicio >= inicioStr && g.dataInicio <= limiteStr)
      );

      const diasGozados = gozosDestePeriodo.reduce((acc, g) => acc + g.diasGozo, 0);
      const diasAbonados = gozosDestePeriodo.reduce(
        (acc, g) => acc + (g.abonoPecuniario ? g.diasAbono : 0),
        0
      );
      const diasConsumidos = diasGozados + diasAbonados;

      const emAquisicao = cursorFim > hoje;
      let diasDireito = 30; // 30 dias integrais
      let diasProporcionais = 30;

      if (emAquisicao) {
        // Cálculo proporcional (2,5 dias por mês trabalhado)
        const mesesTrabalhados = Math.max(
          1,
          Math.min(
            12,
            Math.floor((hoje.getTime() - cursorInicio.getTime()) / (1000 * 60 * 60 * 24 * 30.4))
          )
        );
        diasProporcionais = Math.round(mesesTrabalhados * 2.5);
      }

      const saldoDias = Math.max(
        0,
        (emAquisicao ? diasProporcionais : diasDireito) - diasConsumidos
      );
      const diffDiasConcessivo = Math.ceil(
        (limiteConcessivo.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24)
      );

      let situacao: PeriodoAquisitivoHistorico['situacao'] = 'adquirido_regular';
      let severidade: SeveridadeAlertaFerias = 'regular';

      if (emAquisicao) {
        situacao = 'em_aquisicao';
        severidade = 'regular';
      } else if (saldoDias === 0) {
        situacao = 'quitado';
        severidade = 'regular';
      } else if (diffDiasConcessivo < 0) {
        situacao = 'vencido_dobro';
        severidade = 'vencido_dobro';
      } else if (diffDiasConcessivo <= 30) {
        situacao = 'urgente_30_dias';
        severidade = 'urgente_30';
      } else if (diffDiasConcessivo <= 60) {
        situacao = 'alerta_vencendo';
        severidade = 'atencao_60';
      }

      const itemHistorico: PeriodoAquisitivoHistorico = {
        id: `pa_${funcionarioId}_${anoIndex}`,
        funcionarioId,
        numeroPeriodo: anoIndex,
        dataInicio: inicioStr,
        dataFim: fimStr,
        limiteConcessivo: limiteStr,
        diasDireito,
        faltasInjustificadas: 0,
        diasGozados,
        diasAbonados,
        saldoDias,
        diasProporcionais: emAquisicao ? diasProporcionais : undefined,
        situacao,
        diasParaVencer: diffDiasConcessivo,
        periodosGozo: gozosDestePeriodo,
      };

      historicoPeriodos.push(itemHistorico);

      // Gera alerta se houver pendência e prazo curto
      if (saldoDias > 0 && !emAquisicao) {
        const salario = func.salarioBase || 0;
        const valorDia = salario / 30;
        const custoDobroEstimado = Math.round(saldoDias * valorDia * 1.3333 * 100) / 100;

        // Sugestão de data de início (próxima segunda-feira viável)
        const dtSugerida = new Date(hoje);
        dtSugerida.setDate(dtSugerida.getDate() + 32); // respeita antecedência
        while (dtSugerida.getDay() === 5 || dtSugerida.getDay() === 6 || dtSugerida.getDay() === 0) {
          dtSugerida.setDate(dtSugerida.getDate() + 1);
        }

        if (severidade === 'vencido_dobro') {
          avisos.push({
            id: `alt_dobro_${funcionarioId}_${anoIndex}`,
            funcionarioId,
            funcionarioNome: func.nomeCompleto,
            funcionarioCargo: func.cargoNome,
            departamento: func.departamento,
            empresaId: func.empresaId,
            empresaNome: empresa?.razaoSocial,
            periodoAquisitivoInicio: inicioStr,
            periodoAquisitivoFim: fimStr,
            limiteConcessivo: limiteStr,
            diasParaVencer: diffDiasConcessivo,
            saldoDiasRestantes: saldoDias,
            severidade: 'vencido_dobro',
            mensagem: `PERÍODO CONCESSIVO EXPIRADO! ${saldoDias} dias de férias não usufruídos dentro do prazo. Aplicação obrigatória de pagamento em dobro (Art. 137 CLT).`,
            riscoMultaDobro: true,
            estimativaCustoDobro: custoDobroEstimado,
            dataSugeridaInicio: dtSugerida.toISOString().split('T')[0],
          });
        } else if (severidade === 'urgente_30') {
          avisos.push({
            id: `alt_urgente_${funcionarioId}_${anoIndex}`,
            funcionarioId,
            funcionarioNome: func.nomeCompleto,
            funcionarioCargo: func.cargoNome,
            departamento: func.departamento,
            empresaId: func.empresaId,
            empresaNome: empresa?.razaoSocial,
            periodoAquisitivoInicio: inicioStr,
            periodoAquisitivoFim: fimStr,
            limiteConcessivo: limiteStr,
            diasParaVencer: diffDiasConcessivo,
            saldoDiasRestantes: saldoDias,
            severidade: 'urgente_30',
            mensagem: `URGENTE: Período concessivo vence em ${diffDiasConcessivo} dias! Conceda as férias imediatamente para evitar a penalidade de pagamento em dobro.`,
            riscoMultaDobro: true,
            estimativaCustoDobro: custoDobroEstimado,
            dataSugeridaInicio: dtSugerida.toISOString().split('T')[0],
          });
        } else if (severidade === 'atencao_60') {
          avisos.push({
            id: `alt_atencao_${funcionarioId}_${anoIndex}`,
            funcionarioId,
            funcionarioNome: func.nomeCompleto,
            funcionarioCargo: func.cargoNome,
            departamento: func.departamento,
            empresaId: func.empresaId,
            empresaNome: empresa?.razaoSocial,
            periodoAquisitivoInicio: inicioStr,
            periodoAquisitivoFim: fimStr,
            limiteConcessivo: limiteStr,
            diasParaVencer: diffDiasConcessivo,
            saldoDiasRestantes: saldoDias,
            severidade: 'atencao_60',
            mensagem: `ATENÇÃO: Período concessivo expira em ${diffDiasConcessivo} dias. Emita o aviso prévio de 30 dias (Art. 135 CLT) para garantir o gozo regular.`,
            riscoMultaDobro: false,
            estimativaCustoDobro: 0,
            dataSugeridaInicio: dtSugerida.toISOString().split('T')[0],
          });
        }
      }

      // Prepara próximo período
      cursorInicio = new Date(cursorFim);
      cursorInicio.setDate(cursorInicio.getDate() + 1);
    }

    const saldoTotal = historicoPeriodos.reduce((acc, p) => acc + p.saldoDias, 0);

    return {
      funcionario: func,
      periodos: historicoPeriodos,
      saldoTotalDisponivel: saldoTotal,
      avisos,
    };
  }

  getPainelAvisosFerias(empresaId?: string): PainelAvisosFeriasResponse {
    let funcs = this.data.funcionarios || [];
    if (empresaId && empresaId !== 'todas') {
      funcs = funcs.filter((f) => f.empresaId === empresaId);
    }
    funcs = funcs.filter((f) => f.status !== 'desligado');

    const totalFuncionarios = funcs.length;
    const emGozo = funcs.filter((f) => f.status === 'ferias').length;
    let alerta60Dias = 0;
    let urgente30Dias = 0;
    let vencidasDobro = 0;
    let saldoTotalDiasEmpresa = 0;
    const todosAlertas: AlertaFeriasItem[] = [];

    for (const f of funcs) {
      try {
        const calculo = this.calcularSaldosEPeriodosFuncionario(f.id);
        saldoTotalDiasEmpresa += calculo.saldoTotalDisponivel;

        for (const av of calculo.avisos) {
          todosAlertas.push(av);
          if (av.severidade === 'vencido_dobro') vencidasDobro++;
          else if (av.severidade === 'urgente_30') urgente30Dias++;
          else if (av.severidade === 'atencao_60') alerta60Dias++;
        }
      } catch (err) {
        // segue para próximo
      }
    }

    // Ordena alertas: vencidas primeiro, depois urgente, depois atenção
    const peso: Record<SeveridadeAlertaFerias, number> = {
      vencido_dobro: 1,
      urgente_30: 2,
      atencao_60: 3,
      em_gozo: 4,
      regular: 5,
    };
    todosAlertas.sort((a, b) => peso[a.severidade] - peso[b.severidade]);

    return {
      totalFuncionarios,
      emGozo,
      alerta60Dias,
      urgente30Dias,
      vencidasDobro,
      saldoTotalDiasEmpresa,
      alertas: todosAlertas,
    };
  }

  gerarDocumentoAvisoRecibo(periodoId: string): DocumentoAvisoReciboFerias {
    const periodo = (this.data.ferias || []).find((f) => f.id === periodoId);
    if (!periodo) throw new Error('Período de férias não encontrado.');

    const func = this.getFuncionarioById(periodo.funcionarioId);
    if (!func) throw new Error('Colaborador não encontrado.');

    const emp = this.data.empresas.find((e) => e.id === periodo.empresaId) || {
      razaoSocial: periodo.empresaNome || 'Empresa Empregadora Ltda',
      cnpj: '12.345.678/0001-90',
      cidade: 'São Paulo',
      uf: 'SP',
    };

    const valores =
      periodo.valoresFinanceiros ||
      this.calcularValoresFerias({
        salarioBase: func.salarioBase,
        diasGozo: periodo.diasGozo,
        abonoPecuniario: periodo.abonoPecuniario,
        diasAbono: periodo.diasAbono,
        adiantamentoDecimoTerceiro: periodo.adiantamentoDecimoTerceiro,
      });

    // Retorno das férias = dia seguinte ao dataFim
    const dtFim = new Date(`${periodo.dataFim}T12:00:00.000Z`);
    dtFim.setDate(dtFim.getDate() + 1);
    const dataRetorno = dtFim.toISOString().split('T')[0];

    return {
      id: `doc_recibo_${periodo.id}`,
      periodoGozoId: periodo.id,
      empresa: {
        razaoSocial: emp.razaoSocial,
        cnpj: emp.cnpj,
        endereco: `${emp.cidade} - ${emp.uf}`,
        cidadeUf: `${emp.cidade}/${emp.uf}`,
      },
      funcionario: {
        nome: func.nomeCompleto,
        cargo: func.cargoNome,
        matricula: func.matricula,
        cpf: func.cpf,
        ctps: `${func.ctpsNumero} Série ${func.ctpsSerie}/${func.ctpsUf}`,
        pis: func.pisPasep,
        departamento: func.departamento,
        dataAdmissao: func.dataAdmissao,
      },
      periodoAquisitivo: {
        inicio: periodo.periodoAquisitivoInicio,
        fim: periodo.periodoAquisitivoFim,
      },
      periodoGozo: {
        inicio: periodo.dataInicio,
        fim: periodo.dataFim,
        dias: periodo.diasGozo,
        dataRetorno,
        fracionamentoNumero: periodo.fracionamentoNumero,
      },
      abono: {
        solicitado: periodo.abonoPecuniario,
        dias: periodo.diasAbono,
      },
      adiantamento13: {
        solicitado: periodo.adiantamentoDecimoTerceiro,
        valor: valores.adiantamento13,
      },
      datasLegais: {
        dataComunicacaoAviso: periodo.dataAvisoFerias,
        dataLimitePagamento: periodo.dataLimitePagamento,
        dataEmissaoDocumento: new Date().toISOString().split('T')[0],
      },
      demonstrativo: {
        salarioBase: valores.salarioBase,
        valorFeriasGozadas: valores.valorFeriasBruto,
        tercoConstitucional: valores.tercoConstitucional,
        valorAbonoPecuniario: valores.valorAbono,
        tercoConstitucionalAbono: valores.tercoAbono,
        adiantamentoDecimoTerceiro: valores.adiantamento13,
        totalBruto:
          valores.valorFeriasBruto +
          valores.tercoConstitucional +
          valores.valorAbono +
          valores.tercoAbono +
          valores.adiantamento13,
        descontoInss: valores.inssFerias,
        descontoIrrf: valores.irrfFerias,
        outrosDescontos: 0,
        totalDescontos: valores.inssFerias + valores.irrfFerias,
        totalLiquidoReceber: valores.totalLiquido,
      },
    };
  }

  // =========================================================================
  // --- CÁLCULO DE RESCISÃO CONTRATUAL, VERBAS RESCISÓRIAS & TRCT (CLT) ---
  // =========================================================================

  getRescisoes(empresaId?: string, funcionarioId?: string): RescisaoContratualRegistro[] {
    let lista = this.data.rescisoes || [];
    if (empresaId && empresaId !== 'todas') {
      lista = lista.filter((r) => r.empresaId === empresaId);
    }
    if (funcionarioId && funcionarioId !== 'todos') {
      lista = lista.filter((r) => r.funcionarioId === funcionarioId);
    }
    return lista.slice().sort((a, b) => b.criadoEm.localeCompare(a.criadoEm));
  }

  getRescisaoById(id: string): RescisaoContratualRegistro | undefined {
    return (this.data.rescisoes || []).find((r) => r.id === id);
  }

  calcularRescisao(params: any): { calculo: CalculoRescisaoResultado; trct: DocumentoTRCT; funcionario: Funcionario; empresa: Empresa } {
    const funcionario = this.getFuncionarioById(params.funcionarioId);
    if (!funcionario) throw new Error('Funcionário não encontrado');

    const empresa = this.getEmpresaById(funcionario.empresaId) || ({
      id: funcionario.empresaId,
      razaoSocial: 'Empresa Empregadora Ltda',
      cnpj: '12.345.678/0001-90',
      cidade: 'São Paulo',
      uf: 'SP',
    } as Empresa);

    const calculo = calcularRescisaoCompleta({
      funcionario,
      empresa,
      motivoRescisao: params.motivoRescisao || 'sem_justa_causa',
      tipoAvisoPrevio: params.tipoAvisoPrevio || 'indenizado',
      dataDesligamento: params.dataDesligamento || new Date().toISOString().split('T')[0],
      dataAvisoPrevio: params.dataAvisoPrevio,
      saldoFgtsInformado: params.saldoFgtsInformado,
      diasSaldoSalarioManual: params.diasSaldoSalarioManual,
      horasExtrasValor: params.horasExtrasValor,
      outrosAdicionaisValor: params.outrosAdicionaisValor,
      faltasDsrValor: params.faltasDsrValor,
      outrosDescontosValor: params.outrosDescontosValor,
      diasFeriasVencidasManual: params.diasFeriasVencidasManual,
    });

    const trct = gerarDocumentoTRCTOficial(calculo, funcionario, empresa);

    return { calculo, trct, funcionario, empresa };
  }

  salvarRescisao(dados: Omit<RescisaoContratualRegistro, 'id' | 'criadoEm'> & { id?: string; atualizarStatusFuncionario?: boolean }): RescisaoContratualRegistro {
    if (!this.data.rescisoes) this.data.rescisoes = [];

    const id = dados.id || `resc_${Date.now()}`;
    const criadoEm = new Date().toISOString();

    const novoRegistro: RescisaoContratualRegistro = {
      ...dados,
      id,
      criadoEm,
      isDemo: false,
    };

    const existingIndex = this.data.rescisoes.findIndex((r) => r.id === id);
    if (existingIndex >= 0) {
      this.data.rescisoes[existingIndex] = novoRegistro;
    } else {
      this.data.rescisoes.unshift(novoRegistro);
    }

    if (dados.atualizarStatusFuncionario) {
      this.updateFuncionario(dados.funcionarioId, {
        status: 'desligado',
        observacoes: `Contrato rescindido em ${dados.dataAfastamento}. Motivo: ${dados.motivoRescisao}. TRCT oficial gerado (${novoRegistro.trct?.numeroTermo || id}).`,
      });
    }

    this.persist();
    return novoRegistro;
  }

  homologarRescisao(id: string): RescisaoContratualRegistro {
    if (!this.data.rescisoes) this.data.rescisoes = [];
    const index = this.data.rescisoes.findIndex((r) => r.id === id);
    if (index === -1) throw new Error('Rescisão não encontrada.');

    this.data.rescisoes[index].status = 'homologada';
    this.data.rescisoes[index].homologadoEm = new Date().toISOString();

    // Atualiza status do funcionário para desligado
    this.updateFuncionario(this.data.rescisoes[index].funcionarioId, {
      status: 'desligado',
      observacoes: `Rescisão homologada em ${new Date().toLocaleDateString('pt-BR')}.`,
    });

    this.persist();
    return this.data.rescisoes[index];
  }

  deleteRescisao(id: string): boolean {
    if (!this.data.rescisoes) return false;
    const initialLen = this.data.rescisoes.length;
    this.data.rescisoes = this.data.rescisoes.filter((r) => r.id !== id);
    if (this.data.rescisoes.length < initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  // =========================================================================
  // --- MÓDULO ESOCIAL & FECHAMENTO DE FOLHA (S-1200, S-1210, S-1299) ---
  // =========================================================================

  getESocialConfiguracao(empresaId: string): ESocialConfiguracao {
    if (!this.data.esocialConfiguracoes) {
      this.data.esocialConfiguracoes = JSON.parse(JSON.stringify(DEMO_ESOCIAL_CONFIGURACOES));
    }

    const config = this.data.esocialConfiguracoes.find((c) => c.empresaId === empresaId);
    if (config) {
      return config;
    }

    const empresa = this.data.empresas.find((e) => e.id === empresaId) || this.data.empresas[0];
    const isSimples = empresa?.regimeTributario?.toLowerCase().includes('simples');

    const newConfig: ESocialConfiguracao = {
      id: `cfg_esocial_${empresaId}`,
      empresaId,
      ambiente: 'producao',
      versaoManual: 'S-1.2',
      classificacaoTributaria: isSimples ? '01' : '99',
      tipoInscricao: 'CNPJ',
      numeroInscricao: empresa?.cnpj || '00.000.000/0001-00',
      razaoSocial: empresa?.razaoSocial || 'Empresa Empregadora',
      indicativoCooperativa: '0',
      indicativoConstrutora: '0',
      indicativoDesoneracaoFolha: '0',
      naturezaJuridica: '206-2 - Sociedade Empresária Limitada',
      cnaePrincipal: '4751-2/01 - Comércio varejista especializado',
      aliquotaRat: isSimples ? 1.0 : 2.0,
      fap: 1.0000,
      aliquotaRatAjustada: isSimples ? 1.0 : 2.0,
      codigoTerceirosOutrasEntidades: isSimples ? '0000' : '0079',
      aliquotaTerceiros: isSimples ? 0.0 : 5.8,
      certificadoDigitalId: 'cert_1',
      certificadoValidade: '2027-01-15',
      certificadoNome: 'Certificado Digital ICP-Brasil A1',
      transmissaoAutomatica: true,
      procuracaoEletronicaAtiva: true,
      contatoResponsavelNome: empresa?.responsavelContabil || 'Carlos Eduardo Silveira',
      contatoResponsavelCpf: '123.456.789-00',
      contatoResponsavelEmail: empresa?.email || 'fiscal@empresa.com.br',
      contatoResponsavelTelefone: empresa?.telefone || '(11) 3456-7890',
      atualizadoEm: new Date().toISOString(),
    };

    this.data.esocialConfiguracoes.push(newConfig);
    this.persist();
    return newConfig;
  }

  salvarESocialConfiguracao(empresaId: string, dados: Partial<ESocialConfiguracao>): ESocialConfiguracao {
    if (!this.data.esocialConfiguracoes) {
      this.data.esocialConfiguracoes = JSON.parse(JSON.stringify(DEMO_ESOCIAL_CONFIGURACOES));
    }

    const index = this.data.esocialConfiguracoes.findIndex((c) => c.empresaId === empresaId);
    const ratAjustado = Number(((dados.aliquotaRat ?? 1) * (dados.fap ?? 1)).toFixed(4));

    if (index >= 0) {
      this.data.esocialConfiguracoes[index] = {
        ...this.data.esocialConfiguracoes[index],
        ...dados,
        aliquotaRatAjustada: ratAjustado,
        atualizadoEm: new Date().toISOString(),
      };
      this.persist();
      return this.data.esocialConfiguracoes[index];
    }

    const current = this.getESocialConfiguracao(empresaId);
    const updated = {
      ...current,
      ...dados,
      aliquotaRatAjustada: ratAjustado,
      atualizadoEm: new Date().toISOString(),
    };
    this.data.esocialConfiguracoes.push(updated);
    this.persist();
    return updated;
  }

  getESocialEventos(empresaId?: string, competencia?: string): EventoESocialRegistro[] {
    if (!this.data.esocialEventos) {
      this.data.esocialEventos = JSON.parse(JSON.stringify(DEMO_ESOCIAL_EVENTOS));
    }

    let eventos = this.data.esocialEventos;
    if (empresaId && empresaId !== 'todas') {
      eventos = eventos.filter((ev) => ev.empresaId === empresaId);
    }
    if (competencia) {
      const compNorm = competencia.trim();
      eventos = eventos.filter((ev) => !ev.competencia || ev.competencia === compNorm);
    }

    return eventos;
  }

  validarEventosPeriodicosESocial(empresaId: string, competencia = '09/2026') {
    const config = this.getESocialConfiguracao(empresaId);
    const empresa = this.data.empresas.find((e) => e.id === empresaId) || this.data.empresas[0];
    const funcs = this.getFuncionarios(empresaId).filter((f) => f.status !== 'desligado');

    const eventosGerados: EventoESocialRegistro[] = [];
    const relatorioInconsistencias: Array<{
      colaborador: string;
      cpf: string;
      inconsistencias: InconsistenciaValidacaoESocial[];
    }> = [];

    funcs.forEach((func, idx) => {
      const erros = validarDadosColaboradorESocial(func, config);
      const holerite = this.calcularHolerite(func, competencia);

      if (erros.length > 0) {
        relatorioInconsistencias.push({
          colaborador: func.nomeCompleto,
          cpf: func.cpf,
          inconsistencias: erros,
        });
      }

      // Gera evento S-1200
      const xml1200 = gerarXmlEventoESocial('S-1200', {
        config,
        competencia,
        funcionario: func,
        holerite,
      });

      const s1200: EventoESocialRegistro = {
        id: `evt_s1200_${func.id}_${competencia.replace('/', '_')}`,
        empresaId,
        empresaNome: empresa?.razaoSocial || config.razaoSocial,
        tipoEvento: 'S-1200',
        descricaoEvento: `Remuneração de Trabalhador - ${func.nomeCompleto}`,
        competencia,
        trabalhadorId: func.id,
        trabalhadorNome: func.nomeCompleto,
        trabalhadorCpf: func.cpf,
        trabalhadorMatricula: func.matricula || `MAT-${idx + 1}`,
        status: erros.some((e) => e.tipo === 'erro') ? 'rejeitado_erro' : 'validado',
        xmlGerado: xml1200,
        inconsistencias: erros,
        dataGeracao: new Date().toISOString(),
        usuarioResponsavel: 'Validador eSocial ContabGest',
      };
      eventosGerados.push(s1200);

      // Gera evento S-1210
      const xml1210 = gerarXmlEventoESocial('S-1210', {
        config,
        competencia,
        funcionario: func,
        holerite,
      });

      const s1210: EventoESocialRegistro = {
        id: `evt_s1210_${func.id}_${competencia.replace('/', '_')}`,
        empresaId,
        empresaNome: empresa?.razaoSocial || config.razaoSocial,
        tipoEvento: 'S-1210',
        descricaoEvento: `Pagamentos de Rendimentos - ${func.nomeCompleto}`,
        competencia,
        trabalhadorId: func.id,
        trabalhadorNome: func.nomeCompleto,
        trabalhadorCpf: func.cpf,
        trabalhadorMatricula: func.matricula || `MAT-${idx + 1}`,
        status: erros.some((e) => e.tipo === 'erro') ? 'rejeitado_erro' : 'validado',
        xmlGerado: xml1210,
        inconsistencias: erros,
        dataGeracao: new Date().toISOString(),
        usuarioResponsavel: 'Validador eSocial ContabGest',
      };
      eventosGerados.push(s1210);
    });

    // Atualiza eventos no banco
    if (!this.data.esocialEventos) this.data.esocialEventos = [];
    eventosGerados.forEach((novoEvt) => {
      const existingIdx = this.data.esocialEventos.findIndex((e) => e.id === novoEvt.id);
      if (existingIdx >= 0) {
        this.data.esocialEventos[existingIdx] = novoEvt;
      } else {
        this.data.esocialEventos.unshift(novoEvt);
      }
    });
    this.persist();

    const totalErros = relatorioInconsistencias.reduce(
      (acc, r) => acc + r.inconsistencias.filter((i) => i.tipo === 'erro').length,
      0
    );
    const totalAvisos = relatorioInconsistencias.reduce(
      (acc, r) => acc + r.inconsistencias.filter((i) => i.tipo === 'aviso').length,
      0
    );

    return {
      competencia,
      totalColaboradoresApurados: funcs.length,
      totalEventosPeriodicos: eventosGerados.length,
      totalEventosValidados: eventosGerados.filter((e) => e.status === 'validado').length,
      totalEventosComErro: eventosGerados.filter((e) => e.status === 'rejeitado_erro').length,
      totalErros,
      totalAvisos,
      relatorioInconsistencias,
      eventos: eventosGerados,
    };
  }

  getPainelFechamentoFolhaESocial(empresaId: string, competencia = '09/2026'): FechamentoFolhaESocialPainel {
    const config = this.getESocialConfiguracao(empresaId);
    const empresa = this.data.empresas.find((e) => e.id === empresaId) || this.data.empresas[0];
    const folhaSimulada = this.getFolhaSimulada(empresaId, competencia);
    const funcs = this.getFuncionarios(empresaId).filter((f) => f.status !== 'desligado');

    // Valida ou recupera eventos periódicos existentes da competência
    const existingEvents = this.getESocialEventos(empresaId, competencia).filter(
      (e) => e.tipoEvento === 'S-1200' || e.tipoEvento === 'S-1210'
    );

    let eventosFinais = existingEvents;
    if (eventosFinais.length === 0 && funcs.length > 0) {
      // Auto valida se ainda não houver eventos
      const resValida = this.validarEventosPeriodicosESocial(empresaId, competencia);
      eventosFinais = resValida.eventos;
    }

    const s1299Existente = this.getESocialEventos(empresaId).find(
      (e) => e.tipoEvento === 'S-1299' && e.competencia === competencia
    );

    const isFechado = s1299Existente?.status === 'transmitido_sucesso';
    const inconsistenciasGerais = validarParametrosFechamentoFolha(config, competencia, eventosFinais);

    const totalInssSegurados = folhaSimulada.totalInssEmpregados;
    // Cálculo Patronal e RAT conforme parâmetros do eSocial
    const isSimplesSemDeson = config.classificacaoTributaria === '01' || config.classificacaoTributaria === '02';
    const inssPatronal = isSimplesSemDeson
      ? 0
      : Math.round(folhaSimulada.totalBruto * 0.2 * 100) / 100;
    const ratAjustado = isSimplesSemDeson
      ? 0
      : Math.round(folhaSimulada.totalBruto * (config.aliquotaRatAjustada / 100) * 100) / 100;
    const terceiros = isSimplesSemDeson
      ? 0
      : Math.round(folhaSimulada.totalBruto * (config.aliquotaTerceiros / 100) * 100) / 100;
    const inssDctfWebTotal = Math.round((totalInssSegurados + inssPatronal + ratAjustado + terceiros) * 100) / 100;

    const validados = eventosFinais.filter((e) => e.status === 'validado').length;
    const comErros = eventosFinais.filter((e) => e.status === 'rejeitado_erro').length;
    const transmitidos = eventosFinais.filter((e) => e.status === 'transmitido_sucesso').length;

    let statusFechamento: FechamentoFolhaESocialPainel['statusFechamento'] = 'aberto';
    if (isFechado) {
      statusFechamento = 'fechado_transmitido';
    } else if (comErros === 0 && inconsistenciasGerais.filter((i) => i.tipo === 'erro').length === 0) {
      statusFechamento = 'pronto_envio';
    } else if (comErros > 0) {
      statusFechamento = 'aberto';
    }

    return {
      empresaId,
      empresaNome: empresa?.razaoSocial || config.razaoSocial,
      cnpj: empresa?.cnpj || config.numeroInscricao,
      competencia,
      statusFechamento,
      versaoManual: config.versaoManual,
      ambiente: config.ambiente,
      totais: {
        totalColaboradores: funcs.length,
        remuneracaoBrutaTotal: folhaSimulada.totalBruto,
        totalBaseInss: folhaSimulada.totalBruto,
        totalInssSegurados,
        totalInssPatronal: inssPatronal,
        totalRatAjustado: ratAjustado,
        totalTerceirosOutrasEntidades: terceiros,
        totalInssDctfWeb: inssDctfWebTotal,
        totalBaseFgts: folhaSimulada.totalBruto,
        totalFgtsDigital: folhaSimulada.totalFgts,
        totalIrrfRetido: folhaSimulada.totalIrrf,
      },
      eventosPeriodicos: {
        totalEsperados: funcs.length * 2, // S-1200 e S-1210 para cada funcionário
        validadosComSucesso: validados,
        comErrosPendentes: comErros,
        transmitidos,
        itens: eventosFinais,
      },
      reciboFechamento: s1299Existente
        ? {
            numeroReciboS1299: s1299Existente.numeroReciboEnvio || '1.2.202609.999888777123',
            protocoloRecepcao: s1299Existente.protocoloEnvio || 'SP-20260930-1299-8812',
            hashXmlAssinado: 'SHA256-A1-4F91B2C84A6E7D01...',
            dataHoraEnvio: s1299Existente.dataTransmissao || s1299Existente.dataGeracao,
            retornoS5011DctfWeb: {
              numeroControleDctfWeb: `DCTFWEB-${competencia.replace('/', '')}-88219`,
              valorTotalGuiaDarfer: inssDctfWebTotal,
              codigoReceitaPrincipal: '1082-01',
              vencimentoDarfer: `20/${competencia.includes('/') ? (Number(competencia.split('/')[0]) + 1).toString().padStart(2, '0') : '10'}/${competencia.split('/')[1] || '2026'}`,
            },
          }
        : undefined,
      inconsistenciasGerais,
    };
  }

  transmitirFechamentoFolhaS1299(empresaId: string, competencia = '09/2026') {
    const config = this.getESocialConfiguracao(empresaId);
    const empresa = this.data.empresas.find((e) => e.id === empresaId) || this.data.empresas[0];
    const eventos = this.getESocialEventos(empresaId, competencia);
    const inconsistencias = validarParametrosFechamentoFolha(config, competencia, eventos);

    const errosBloqueantes = inconsistencias.filter((i) => i.tipo === 'erro');
    if (errosBloqueantes.length > 0) {
      throw new Error(
        `Não é possível transmitir o fechamento S-1299. Existem ${errosBloqueantes.length} erro(s) impeditivo(s): ${errosBloqueantes.map((e) => e.descricao).join('; ')}`
      );
    }

    const agoraIso = new Date().toISOString();
    const protocoloRecepcao = `SP-${agoraIso.slice(0, 10).replace(/-/g, '')}-1299-${Math.floor(10000 + Math.random() * 90000)}`;
    const numeroReciboS1299 = `1.2.${agoraIso.slice(0, 7).replace('-', '')}.${Math.floor(1000000000000000 + Math.random() * 9000000000000000)}`;

    const xmlS1299 = gerarXmlEventoESocial('S-1299', {
      config,
      competencia,
    });

    const eventoS1299: EventoESocialRegistro = {
      id: `evt_s1299_${empresaId}_${competencia.replace('/', '_')}`,
      empresaId,
      empresaNome: empresa?.razaoSocial || config.razaoSocial,
      tipoEvento: 'S-1299',
      descricaoEvento: `Fechamento dos Eventos Periódicos da Competência ${competencia}`,
      competencia,
      status: 'transmitido_sucesso',
      numeroReciboEnvio: numeroReciboS1299,
      protocoloEnvio: protocoloRecepcao,
      xmlGerado: xmlS1299,
      dataGeracao: agoraIso,
      dataTransmissao: agoraIso,
      usuarioResponsavel: config.contatoResponsavelNome || 'Carlos Eduardo Silveira',
    };

    if (!this.data.esocialEventos) this.data.esocialEventos = [];

    // Marca todos os eventos periódicos S-1200 e S-1210 da competência como transmitidos
    this.data.esocialEventos.forEach((ev) => {
      if (
        ev.empresaId === empresaId &&
        ev.competencia === competencia &&
        (ev.tipoEvento === 'S-1200' || ev.tipoEvento === 'S-1210')
      ) {
        ev.status = 'transmitido_sucesso';
        ev.dataTransmissao = agoraIso;
        if (!ev.numeroReciboEnvio) {
          ev.numeroReciboEnvio = `1.2.${agoraIso.slice(0, 7).replace('-', '')}.${Math.floor(1000000000000000 + Math.random() * 9000000000000000)}`;
        }
      }
    });

    // Insere ou atualiza o S-1299
    const existingIdx = this.data.esocialEventos.findIndex((e) => e.id === eventoS1299.id);
    if (existingIdx >= 0) {
      this.data.esocialEventos[existingIdx] = eventoS1299;
    } else {
      this.data.esocialEventos.unshift(eventoS1299);
    }

    // Cria também o evento de retorno totalizador DCTFWeb S-5011
    const folhaSimulada = this.getFolhaSimulada(empresaId, competencia);
    const isSimplesSemDeson = config.classificacaoTributaria === '01' || config.classificacaoTributaria === '02';
    const totalInssSegurados = folhaSimulada.totalInssEmpregados;
    const inssPatronal = isSimplesSemDeson ? 0 : Math.round(folhaSimulada.totalBruto * 0.2 * 100) / 100;
    const ratAjustado = isSimplesSemDeson ? 0 : Math.round(folhaSimulada.totalBruto * (config.aliquotaRatAjustada / 100) * 100) / 100;
    const terceiros = isSimplesSemDeson ? 0 : Math.round(folhaSimulada.totalBruto * (config.aliquotaTerceiros / 100) * 100) / 100;
    const totalDctfWeb = Math.round((totalInssSegurados + inssPatronal + ratAjustado + terceiros) * 100) / 100;

    const eventoS5011: EventoESocialRegistro = {
      id: `evt_s5011_${empresaId}_${competencia.replace('/', '_')}`,
      empresaId,
      empresaNome: empresa?.razaoSocial || config.razaoSocial,
      tipoEvento: 'S-5011',
      descricaoEvento: `Informações das Contribuições Sociais Consolidadas por Contribuinte (DCTFWeb)`,
      competencia,
      status: 'transmitido_sucesso',
      numeroReciboEnvio: `RET-5011-${numeroReciboS1299}`,
      protocoloEnvio: `DCTFWEB-${competencia.replace('/', '')}-${Math.floor(10000 + Math.random() * 90000)}`,
      dataGeracao: agoraIso,
      dataTransmissao: agoraIso,
      usuarioResponsavel: 'Ambiente Nacional eSocial / SERPRO',
    };

    const s5011Idx = this.data.esocialEventos.findIndex((e) => e.id === eventoS5011.id);
    if (s5011Idx >= 0) {
      this.data.esocialEventos[s5011Idx] = eventoS5011;
    } else {
      this.data.esocialEventos.unshift(eventoS5011);
    }

    this.persist();

    return {
      sucesso: true,
      mensagem: `Fechamento da folha ${competencia} transmitido com sucesso ao ambiente do eSocial!`,
      reciboS1299: numeroReciboS1299,
      protocoloEnvio: protocoloRecepcao,
      totalizadorDctfWeb: {
        valorTotalDarf: totalDctfWeb,
        guiaNumero: `DCTFWEB-${competencia.replace('/', '')}-88219`,
        dataVencimento: '20/10/2026',
      },
      evento: eventoS1299,
    };
  }

  reabrirFolhaESocialS1298(empresaId: string, competencia = '09/2026') {
    const config = this.getESocialConfiguracao(empresaId);
    const empresa = this.data.empresas.find((e) => e.id === empresaId) || this.data.empresas[0];
    const agoraIso = new Date().toISOString();

    const eventoS1298: EventoESocialRegistro = {
      id: `evt_s1298_${empresaId}_${competencia.replace('/', '_')}`,
      empresaId,
      empresaNome: empresa?.razaoSocial || config.razaoSocial,
      tipoEvento: 'S-1298',
      descricaoEvento: `Reabertura dos Eventos Periódicos da Competência ${competencia}`,
      competencia,
      status: 'transmitido_sucesso',
      numeroReciboEnvio: `1.2.${agoraIso.slice(0, 7).replace('-', '')}.${Math.floor(1000000000000000 + Math.random() * 9000000000000000)}`,
      protocoloEnvio: `SP-${agoraIso.slice(0, 10).replace(/-/g, '')}-1298-${Math.floor(10000 + Math.random() * 90000)}`,
      dataGeracao: agoraIso,
      dataTransmissao: agoraIso,
      usuarioResponsavel: config.contatoResponsavelNome || 'Carlos Eduardo Silveira',
    };

    if (!this.data.esocialEventos) this.data.esocialEventos = [];

    // Remove status de fechado do S-1299 anterior
    const s1299Idx = this.data.esocialEventos.findIndex(
      (e) => e.empresaId === empresaId && e.tipoEvento === 'S-1299' && e.competencia === competencia
    );
    if (s1299Idx >= 0) {
      this.data.esocialEventos.splice(s1299Idx, 1);
    }

    this.data.esocialEventos.unshift(eventoS1298);
    this.persist();

    return {
      sucesso: true,
      mensagem: `Competência ${competencia} reaberta no eSocial com sucesso (Evento S-1298).`,
      evento: eventoS1298,
    };
  }

  gerarXmlDownloadESocial(eventoId: string): { xml: string; nomeArquivo: string } {
    const eventos = this.data.esocialEventos || [];
    const evento = eventos.find((e) => e.id === eventoId);
    if (!evento) {
      throw new Error(`Evento eSocial "${eventoId}" não encontrado.`);
    }

    const config = this.getESocialConfiguracao(evento.empresaId);
    let xml = evento.xmlGerado;
    if (!xml) {
      xml = gerarXmlEventoESocial(evento.tipoEvento, {
        config,
        competencia: evento.competencia || '09/2026',
      });
    }

    const nomeArquivo = `eSocial_${evento.tipoEvento}_${evento.trabalhadorMatricula || 'Geral'}_${(evento.competencia || '2026-09').replace('/', '-')}.xml`;
    return { xml, nomeArquivo };
  }

  // =========================================================================
  // --- PAINEL DO ADMINISTRADOR: GESTÃO COMPLETA DO BANCO DE DADOS ---
  // =========================================================================

  getStats() {
    const counts: Record<string, number> = {
      empresas: this.data.empresas.length,
      clientes: this.data.clientes.length,
      socios: this.data.socios.length,
      obrigacoes: this.data.obrigacoes.length,
      documentos: this.data.documentos.length,
      certidoes: this.data.certidoes.length,
      tarefas: this.data.tarefas.length,
      contasPagar: this.data.contasPagar.length,
      contasReceber: this.data.contasReceber.length,
      categoriasFinanceiras: this.data.categoriasFinanceiras.length,
      users: this.data.users.length,
      notasFiscais: this.data.notasFiscais.length,
      certificados: this.data.certificados.length,
      pendenciasEcac: this.data.pendenciasEcac.length,
      alvaras: this.data.alvaras.length,
      funcoes: (this.data.funcoes || []).length,
      funcionarios: (this.data.funcionarios || []).length,
      pontos: (this.data.pontos || []).length,
      ferias: (this.data.ferias || []).length,
      rescisoes: (this.data.rescisoes || []).length,
      esocialConfiguracoes: (this.data.esocialConfiguracoes || []).length,
      esocialEventos: (this.data.esocialEventos || []).length,
    };

    const totalRecords = Object.values(counts).reduce((a, b) => a + b, 0);

    let lastSaved = new Date().toISOString();
    try {
      if (fs.existsSync(this.filePath)) {
        lastSaved = fs.statSync(this.filePath).mtime.toISOString();
      }
    } catch (e) {
      // fallback
    }

    return {
      storageType: 'ContabGest Embedded JSON Database Repository',
      filePath: this.filePath,
      version: this.data.version || '2.0.0',
      isDemoDatabase: this.data.isDemoDatabase ?? false,
      totalRecords,
      lastSaved,
      tableCounts: counts,
    };
  }

  getFullDatabase(): DatabaseSchema {
    return JSON.parse(JSON.stringify(this.data));
  }

  getTableRecords(table: string): any[] {
    const list = (this.data as any)[table];
    if (!Array.isArray(list)) {
      throw new Error(`Tabela "${table}" não encontrada no banco de dados.`);
    }
    return list;
  }

  createTableRecord(table: string, record: any): any {
    const list = (this.data as any)[table];
    if (!Array.isArray(list)) {
      throw new Error(`Tabela "${table}" não encontrada no banco de dados.`);
    }

    const newRecord = {
      ...record,
      id: record.id || `${table.substring(0, 3)}_${Date.now()}`,
    };

    list.unshift(newRecord);
    this.persist();
    return newRecord;
  }

  updateTableRecord(table: string, id: string, updates: any): any {
    const list = (this.data as any)[table];
    if (!Array.isArray(list)) {
      throw new Error(`Tabela "${table}" não encontrada no banco de dados.`);
    }

    const index = list.findIndex((item: any) => item.id === id);
    if (index === -1) {
      throw new Error(`Registro ID "${id}" não encontrado na tabela "${table}".`);
    }

    const updated = {
      ...list[index],
      ...updates,
      id, // ensure ID is preserved
    };

    list[index] = updated;
    this.persist();
    return updated;
  }

  deleteTableRecord(table: string, id: string): boolean {
    const list = (this.data as any)[table];
    if (!Array.isArray(list)) {
      throw new Error(`Tabela "${table}" não encontrada no banco de dados.`);
    }

    const initialLen = list.length;
    (this.data as any)[table] = list.filter((item: any) => item.id !== id);
    const deleted = (this.data as any)[table].length < initialLen;
    if (deleted) {
      this.persist();
    }
    return deleted;
  }

  restoreFullDatabase(newSchema: Partial<DatabaseSchema>): DatabaseSchema {
    if (!newSchema || typeof newSchema !== 'object') {
      throw new Error('Formato de backup inválido.');
    }

    // Merge or replace tables
    const restored: DatabaseSchema = {
      version: newSchema.version || '1.0.0',
      isDemoDatabase: Boolean(newSchema.isDemoDatabase),
      users: Array.isArray(newSchema.users) ? newSchema.users : this.data.users,
      empresas: Array.isArray(newSchema.empresas) ? newSchema.empresas : this.data.empresas,
      clientes: Array.isArray(newSchema.clientes) ? newSchema.clientes : this.data.clientes,
      socios: Array.isArray(newSchema.socios) ? newSchema.socios : this.data.socios,
      obrigacoes: Array.isArray(newSchema.obrigacoes) ? newSchema.obrigacoes : this.data.obrigacoes,
      documentos: Array.isArray(newSchema.documentos) ? newSchema.documentos : this.data.documentos,
      certidoes: Array.isArray(newSchema.certidoes) ? newSchema.certidoes : this.data.certidoes,
      tarefas: Array.isArray(newSchema.tarefas) ? newSchema.tarefas : this.data.tarefas,
      contasPagar: Array.isArray(newSchema.contasPagar) ? newSchema.contasPagar : this.data.contasPagar,
      contasReceber: Array.isArray(newSchema.contasReceber) ? newSchema.contasReceber : this.data.contasReceber,
      categoriasFinanceiras: Array.isArray(newSchema.categoriasFinanceiras)
        ? newSchema.categoriasFinanceiras
        : this.data.categoriasFinanceiras,
      notasFiscais: Array.isArray(newSchema.notasFiscais) ? newSchema.notasFiscais : this.data.notasFiscais,
      certificados: Array.isArray(newSchema.certificados) ? newSchema.certificados : this.data.certificados,
      pendenciasEcac: Array.isArray(newSchema.pendenciasEcac) ? newSchema.pendenciasEcac : this.data.pendenciasEcac,
      alvaras: Array.isArray(newSchema.alvaras) ? newSchema.alvaras : this.data.alvaras,
      funcoes: Array.isArray(newSchema.funcoes) ? newSchema.funcoes : this.data.funcoes,
      funcionarios: Array.isArray(newSchema.funcionarios) ? newSchema.funcionarios : this.data.funcionarios,
      pontos: Array.isArray(newSchema.pontos) ? newSchema.pontos : (this.data.pontos || []),
      ferias: Array.isArray(newSchema.ferias) ? newSchema.ferias : (this.data.ferias || []),
      rescisoes: Array.isArray(newSchema.rescisoes) ? newSchema.rescisoes : (this.data.rescisoes || []),
      esocialConfiguracoes: Array.isArray(newSchema.esocialConfiguracoes)
        ? newSchema.esocialConfiguracoes
        : (this.data.esocialConfiguracoes || []),
      esocialEventos: Array.isArray(newSchema.esocialEventos)
        ? newSchema.esocialEventos
        : (this.data.esocialEventos || []),
      notasFiscaisEntrada: Array.isArray(newSchema.notasFiscaisEntrada)
        ? newSchema.notasFiscaisEntrada
        : (this.data.notasFiscaisEntrada || []),
      sincronizacoesSefaz: Array.isArray(newSchema.sincronizacoesSefaz)
        ? newSchema.sincronizacoesSefaz
        : (this.data.sincronizacoesSefaz || []),
      apuracoesSimples: Array.isArray(newSchema.apuracoesSimples)
        ? newSchema.apuracoesSimples
        : (this.data.apuracoesSimples || []),
      guiasDasMei: Array.isArray(newSchema.guiasDasMei)
        ? newSchema.guiasDasMei
        : (this.data.guiasDasMei || []),
      declaracoesAnuaisMei: Array.isArray(newSchema.declaracoesAnuaisMei)
        ? newSchema.declaracoesAnuaisMei
        : (this.data.declaracoesAnuaisMei || []),
    };

    this.data = restored;
    this.persist();
    return this.data;
  }

  resetToDemoDatabase(): DatabaseSchema {
    const initial: DatabaseSchema = {
      version: '1.0.0',
      isDemoDatabase: true,
      users: JSON.parse(JSON.stringify(DEMO_USERS)),
      empresas: JSON.parse(JSON.stringify(DEMO_EMPRESAS)),
      clientes: JSON.parse(JSON.stringify(DEMO_CLIENTES)),
      socios: JSON.parse(JSON.stringify(DEMO_SOCIOS)),
      obrigacoes: JSON.parse(JSON.stringify(DEMO_OBRIGACOES)),
      documentos: JSON.parse(JSON.stringify(DEMO_DOCUMENTOS)),
      certidoes: JSON.parse(JSON.stringify(DEMO_CERTIDOES)),
      tarefas: JSON.parse(JSON.stringify(DEMO_TAREFAS)),
      contasPagar: JSON.parse(JSON.stringify(DEMO_CONTAS_PAGAR)),
      contasReceber: JSON.parse(JSON.stringify(DEMO_CONTAS_RECEBER)),
      categoriasFinanceiras: JSON.parse(JSON.stringify(DEMO_CATEGORIAS_FINANCEIRAS)),
      notasFiscais: JSON.parse(
        JSON.stringify([
          ...DEMO_NOTAS_FISCAIS,
          ...DEMO_NOTAS_SIMPLES_ADICIONAIS,
          ...DEMO_NOTAS_MEI_ADICIONAIS,
        ])
      ),
      certificados: JSON.parse(JSON.stringify(DEMO_CERTIFICADOS)),
      pendenciasEcac: JSON.parse(JSON.stringify(DEMO_PENDENCIAS_ECAC)),
      alvaras: JSON.parse(JSON.stringify(DEMO_ALVARAS)),
      funcoes: JSON.parse(JSON.stringify(DEMO_FUNCOES)),
      funcionarios: JSON.parse(JSON.stringify(DEMO_FUNCIONARIOS)),
      pontos: JSON.parse(JSON.stringify(DEMO_PONTOS)),
      ferias: JSON.parse(JSON.stringify(DEMO_FERIAS)),
      rescisoes: JSON.parse(JSON.stringify(DEMO_RESCISOES)),
      esocialConfiguracoes: JSON.parse(JSON.stringify(DEMO_ESOCIAL_CONFIGURACOES)),
      esocialEventos: JSON.parse(JSON.stringify(DEMO_ESOCIAL_EVENTOS)),
      notasFiscaisEntrada: JSON.parse(JSON.stringify(DEMO_NOTAS_ENTRADA)),
      sincronizacoesSefaz: JSON.parse(JSON.stringify(DEMO_SINCRONIZACOES_SEFAZ)),
      apuracoesSimples: JSON.parse(JSON.stringify(DEMO_APURACOES_SIMPLES)),
      guiasDasMei: JSON.parse(JSON.stringify(DEMO_GUIAS_MEI)),
      declaracoesAnuaisMei: JSON.parse(JSON.stringify(DEMO_DECLARACOES_MEI)),
    };

    this.data = initial;
    this.persist();
    return this.data;
  }

  setProductionMode(enabled: boolean = true, cleanLabels: boolean = true): {
    success: boolean;
    version: string;
    isDemoDatabase: boolean;
    cleanedCount: number;
  } {
    this.data.version = '2.0.0';
    this.data.isDemoDatabase = !enabled;

    let cleanedCount = 0;
    if (enabled && cleanLabels) {
      const cleanString = (str?: string) => {
        if (!str) return str;
        const cleaned = str.replace(/\s*\[DEMO\]/gi, '').replace(/\s*\(DEMO\)/gi, '').trim();
        if (cleaned !== str) cleanedCount++;
        return cleaned;
      };

      if (this.data.users) {
        this.data.users.forEach((u) => {
          u.escritorioNome = cleanString(u.escritorioNome) || 'Silveira & Associados Contabilidade';
          if (u.email.endsWith('.demo')) {
            u.email = u.email.replace('.demo', '.com.br');
            cleanedCount++;
          }
        });
      }

      if (this.data.empresas) {
        this.data.empresas.forEach((e) => {
          e.razaoSocial = cleanString(e.razaoSocial) || e.razaoSocial;
          e.nomeFantasia = cleanString(e.nomeFantasia) || e.nomeFantasia;
          e.isDemo = false;
        });
      }

      if (this.data.clientes) {
        this.data.clientes.forEach((c) => {
          c.nome = cleanString(c.nome) || c.nome;
          c.isDemo = false;
        });
      }

      if (this.data.socios) {
        this.data.socios.forEach((s) => {
          s.nome = cleanString(s.nome) || s.nome;
          s.isDemo = false;
        });
      }

      if (this.data.obrigacoes) {
        this.data.obrigacoes.forEach((o) => {
          o.titulo = cleanString(o.titulo) || o.titulo;
        });
      }
      if (this.data.documentos) {
        this.data.documentos.forEach((d) => {
          d.nome = cleanString(d.nome) || d.nome;
          d.isDemo = false;
        });
      }
      if (this.data.certidoes) {
        this.data.certidoes.forEach((c) => {
          c.codigo = cleanString(c.codigo) || c.codigo;
          c.isDemo = false;
        });
      }
      if (this.data.tarefas) {
        this.data.tarefas.forEach((t) => {
          t.titulo = cleanString(t.titulo) || t.titulo;
          t.isDemo = false;
        });
      }
      if (this.data.contasPagar) {
        this.data.contasPagar.forEach((cp) => {
          cp.descricao = cleanString(cp.descricao) || cp.descricao;
          cp.isDemo = false;
        });
      }
      if (this.data.contasReceber) {
        this.data.contasReceber.forEach((cr) => {
          cr.descricao = cleanString(cr.descricao) || cr.descricao;
          cr.isDemo = false;
        });
      }
      if (this.data.notasFiscais) {
        this.data.notasFiscais.forEach((nf) => {
          nf.isDemo = false;
        });
      }
      if (this.data.certificados) {
        this.data.certificados.forEach((cert) => {
          cert.titular = cleanString(cert.titular) || cert.titular;
          cert.isDemo = false;
        });
      }
      if (this.data.pendenciasEcac) {
        this.data.pendenciasEcac.forEach((p) => {
          p.isDemo = false;
        });
      }
      if (this.data.alvaras) {
        this.data.alvaras.forEach((a) => {
          a.isDemo = false;
        });
      }
      if (this.data.funcionarios) {
        this.data.funcionarios.forEach((f) => {
          f.isDemo = false;
        });
      }
      if (this.data.funcoes) {
        this.data.funcoes.forEach((fn) => {
          fn.isDemo = false;
        });
      }
    }

    this.persist();
    return {
      success: true,
      version: this.data.version,
      isDemoDatabase: this.data.isDemoDatabase,
      cleanedCount,
    };
  }

  // =========================================================================
  // --- MÓDULO DE AGENDAMENTO DE BACKUPS AUTOMÁTICOS & EXPORTAÇÃO JSON/CSV ---
  // =========================================================================

  getBackupSchedules(): BackupSchedule[] {
    if (!this.data.backupSchedules) {
      this.data.backupSchedules = [
        {
          id: 'sched_1',
          titulo: 'Backup Diário Contábil & Fiscal (Cloud Seguro Criptografado)',
          frequencia: 'diario',
          horarioExecucao: '02:00',
          formato: 'json',
          destinoArmazenamento: 'cloud_storage_seguro',
          incluirAnexos: true,
          criptografiaAtiva: true,
          retencaoDias: 90,
          ativo: true,
          ultimoBackupEm: '2026-09-17T02:00:15.000Z',
          proximaExecucaoEm: '2026-09-18T02:00:00.000Z',
          criadoEm: '2026-01-10T10:00:00.000Z',
        },
        {
          id: 'sched_2',
          titulo: 'Exportação Semanal de Livros e Tabelas (CSV Contábil)',
          frequencia: 'semanal',
          horarioExecucao: '03:30',
          diasSemana: [0], // Domingo
          formato: 'csv',
          destinoArmazenamento: 'local_criptografado',
          incluirAnexos: false,
          criptografiaAtiva: true,
          retencaoDias: 180,
          ativo: true,
          ultimoBackupEm: '2026-09-13T03:30:20.000Z',
          proximaExecucaoEm: '2026-09-20T03:30:00.000Z',
          criadoEm: '2026-02-01T14:00:00.000Z',
        },
      ];
    }
    return this.data.backupSchedules;
  }

  saveBackupSchedule(scheduleData: Partial<BackupSchedule>): BackupSchedule {
    const schedules = this.getBackupSchedules();
    const agora = new Date().toISOString();

    if (scheduleData.id) {
      const index = schedules.findIndex((s) => s.id === scheduleData.id);
      if (index !== -1) {
        schedules[index] = {
          ...schedules[index],
          ...scheduleData,
        };
        this.persist();
        return schedules[index];
      }
    }

    const novoSchedule: BackupSchedule = {
      id: `sched_${Date.now()}`,
      titulo: scheduleData.titulo || 'Agendamento de Backup Automático',
      frequencia: scheduleData.frequencia || 'diario',
      horarioExecucao: scheduleData.horarioExecucao || '02:00',
      diasSemana: scheduleData.diasSemana,
      diaDoMes: scheduleData.diaDoMes,
      formato: scheduleData.formato || 'json',
      destinoArmazenamento: scheduleData.destinoArmazenamento || 'cloud_storage_seguro',
      incluirAnexos: scheduleData.incluirAnexos ?? true,
      criptografiaAtiva: scheduleData.criptografiaAtiva ?? true,
      retencaoDias: scheduleData.retencaoDias || 90,
      ativo: scheduleData.ativo ?? true,
      criadoEm: agora,
      proximaExecucaoEm: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    };

    schedules.push(novoSchedule);
    this.persist();
    return novoSchedule;
  }

  deleteBackupSchedule(id: string): boolean {
    const schedules = this.getBackupSchedules();
    const index = schedules.findIndex((s) => s.id === id);
    if (index !== -1) {
      schedules.splice(index, 1);
      this.persist();
      return true;
    }
    return false;
  }

  getBackupHistory(): BackupHistoryItem[] {
    if (!this.data.backupHistory) {
      this.data.backupHistory = [
        {
          id: 'hist_1',
          scheduleId: 'sched_1',
          titulo: 'Backup Diário Automático - Dados Fiscais e Contábeis',
          tipoTrigger: 'automatico',
          formato: 'json',
          destinoArmazenamento: 'cloud_storage_seguro',
          status: 'sucesso',
          tamanhoFormatado: '14.8 MB',
          tamanhoBytes: 15518920,
          quantidadeRegistros: 2840,
          hashSha256: 'a7b8e9f0123456789abcdef0123456789abcdef0123456789abcdef012345678',
          dataInicio: '2026-09-17T02:00:00.000Z',
          dataConclusao: '2026-09-17T02:00:45.000Z',
          mensagemLog: 'Sincronização com bucket criptografado AES-256 concluída sem divergências.',
        },
        {
          id: 'hist_2',
          scheduleId: 'sched_2',
          titulo: 'Exportação Semanal Tabelas Contábeis (CSV)',
          tipoTrigger: 'automatico',
          formato: 'csv',
          destinoArmazenamento: 'local_criptografado',
          status: 'sucesso',
          tamanhoFormatado: '6.2 MB',
          tamanhoBytes: 6501171,
          quantidadeRegistros: 1950,
          hashSha256: '9f8e7d6c5b4a392817162534f4e3d2c1b0a99887766554433221100aabbccdde',
          dataInicio: '2026-09-13T03:30:00.000Z',
          dataConclusao: '2026-09-13T03:30:28.000Z',
          mensagemLog: '12 arquivos CSV gerados e compactados em storage local seguro.',
        },
      ];
    }
    return this.data.backupHistory;
  }

  // Exportador de dados tabulares em CSV
  exportarDadosCsv(tabela?: string): { nomeArquivo: string; conteudoCsv: string }[] {
    const formatCsvRow = (arr: any[]): string => {
      if (!arr || arr.length === 0) return '';
      const keys = Object.keys(arr[0]).filter((k) => typeof arr[0][k] !== 'object');
      const header = keys.join(';');
      const rows = arr.map((item) =>
        keys
          .map((k) => {
            const val = item[k];
            if (val === null || val === undefined) return '""';
            return `"${String(val).replace(/"/g, '""')}"`;
          })
          .join(';')
      );
      return [header, ...rows].join('\r\n');
    };

    const todasTabelas: Record<string, any[]> = {
      empresas: this.data.empresas,
      clientes: this.data.clientes,
      obrigacoes: this.data.obrigacoes,
      notas_fiscais_saida: this.data.notasFiscais,
      notas_fiscais_entrada: this.data.notasFiscaisEntrada || [],
      funcionarios: this.data.funcionarios,
      contas_pagar: this.data.contasPagar,
      contas_receber: this.data.contasReceber,
      alvaras_licencas: this.data.alvaras,
      certificados_digitais: this.data.certificados,
      apuracoes_simples: this.data.apuracoesSimples || [],
    };

    if (tabela && todasTabelas[tabela]) {
      return [
        {
          nomeArquivo: `contabgest_${tabela}_${new Date().toISOString().slice(0, 10)}.csv`,
          conteudoCsv: formatCsvRow(todasTabelas[tabela]),
        },
      ];
    }

    return Object.entries(todasTabelas).map(([nome, dados]) => ({
      nomeArquivo: `contabgest_${nome}_${new Date().toISOString().slice(0, 10)}.csv`,
      conteudoCsv: formatCsvRow(dados),
    }));
  }

  // Executa backup sob demanda ou pelo agendador
  executarBackup(params: {
    formato: 'json' | 'csv';
    destino?: DestinoBackup;
    scheduleId?: string;
    tipoTrigger?: 'automatico' | 'manual';
    titulo?: string;
  }): { item: BackupHistoryItem; dumpContent: string } {
    const agora = new Date().toISOString();
    const formato = params.formato || 'json';
    const destino = params.destino || 'cloud_storage_seguro';
    const trigger = params.tipoTrigger || 'manual';

    const dumpJson = JSON.stringify(this.data, null, 2);
    let dumpContent = dumpJson;
    let bytes = Buffer.byteLength(dumpJson, 'utf8');
    let qtdRegistros = 0;

    qtdRegistros += (this.data.empresas || []).length;
    qtdRegistros += (this.data.clientes || []).length;
    qtdRegistros += (this.data.notasFiscais || []).length;
    qtdRegistros += (this.data.obrigacoes || []).length;
    qtdRegistros += (this.data.funcionarios || []).length;
    qtdRegistros += (this.data.contasPagar || []).length;
    qtdRegistros += (this.data.contasReceber || []).length;

    if (formato === 'csv') {
      const csvFiles = this.exportarDadosCsv();
      dumpContent = csvFiles.map((f) => `=== TABELA: ${f.nomeArquivo} ===\r\n${f.conteudoCsv}`).join('\r\n\r\n');
      bytes = Buffer.byteLength(dumpContent, 'utf8');
    }

    const hash = crypto.createHash('sha256').update(dumpContent).digest('hex');
    const tamanhoFormatado = `${(bytes / (1024 * 1024)).toFixed(2)} MB`;

    const historyItem: BackupHistoryItem = {
      id: `hist_${Date.now()}`,
      scheduleId: params.scheduleId,
      titulo: params.titulo || `Backup Contábil Executado (${formato.toUpperCase()} - ${destino})`,
      tipoTrigger: trigger,
      formato,
      destinoArmazenamento: destino,
      status: 'sucesso',
      tamanhoFormatado,
      tamanhoBytes: bytes,
      quantidadeRegistros: qtdRegistros,
      hashSha256: hash,
      dataInicio: agora,
      dataConclusao: new Date(Date.now() + 1200).toISOString(),
      mensagemLog: `Backup de integridade ${formato.toUpperCase()} gerado com sucesso (${tamanhoFormatado}, ${qtdRegistros} registros contabilizados).`,
    };

    const history = this.getBackupHistory();
    history.unshift(historyItem);

    if (params.scheduleId) {
      const schedules = this.getBackupSchedules();
      const sched = schedules.find((s) => s.id === params.scheduleId);
      if (sched) {
        sched.ultimoBackupEm = agora;
      }
    }

    this.persist();
    return { item: historyItem, dumpContent };
  }
}

export const db = new AccountingDatabaseRepository();
