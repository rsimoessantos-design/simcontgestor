import http from 'http';
import { db } from '../server/db.js';

function request(path: string, options: http.RequestOptions = {}, postData?: any): Promise<{ status: number; body: any }> {
  return new Promise((resolve, reject) => {
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: 3000,
        path,
        method: options.method || 'GET',
        headers: {
          'Content-Type': 'application/json',
          ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
          ...(options.headers || {}),
        },
        timeout: 5000,
      },
      (res) => {
        let rawData = '';
        res.on('data', (chunk) => {
          rawData += chunk;
        });
        res.on('end', () => {
          try {
            const parsed = rawData ? JSON.parse(rawData) : null;
            resolve({ status: res.statusCode || 0, body: parsed });
          } catch (e) {
            resolve({ status: res.statusCode || 0, body: rawData });
          }
        });
      }
    );

    req.on('error', (err) => reject(err));
    req.on('timeout', () => {
      req.destroy();
      reject(new Error(`Timeout requesting ${path}`));
    });

    if (postData) {
      req.write(typeof postData === 'string' ? postData : JSON.stringify(postData));
    }
    req.end();
  });
}

let authToken = '';

async function runTests() {
  console.log('--- INICIANDO TESTES DO SISTEMA CONTABGEST ---');
  let failures = 0;
  let successes = 0;
  const failedTests: string[] = [];

  async function test(name: string, fn: () => Promise<void>) {
    try {
      await fn();
      console.log(`[PASS] ${name}`);
      successes++;
    } catch (err: any) {
      console.error(`[FAIL] ${name}: ${err.message}`);
      failedTests.push(name);
      failures++;
    }
  }

  // 1. Health check
  await test('GET /api/health', async () => {
    const res = await request('/api/health');
    if (res.status !== 200 || res.body.status !== 'ok') {
      throw new Error(`Status ${res.status}, body: ${JSON.stringify(res.body)}`);
    }
  });

  // 2. Auth Login
  await test('POST /api/auth/login', async () => {
    const res = await request('/api/auth/login', { method: 'POST' }, { email: 'admin@contabgest.com.br' });
    if (res.status !== 200 || !res.body.success || !res.body.user || !res.body.token) {
      throw new Error(`Login falhou: ${JSON.stringify(res.body)}`);
    }
    authToken = res.body.token;
  });

  // 3. Empresas
  let empresaId = '';
  await test('GET /api/empresas', async () => {
    const res = await request('/api/empresas');
    if (res.status !== 200 || !Array.isArray(res.body) || res.body.length === 0) {
      throw new Error(`Falha ao obter empresas: ${res.status}`);
    }
    empresaId = res.body[0].id;
  });

  // 4. Dashboard Metrics
  await test('GET /api/dashboard', async () => {
    const res = await request('/api/dashboard?empresaId=todas');
    if (res.status !== 200 || typeof res.body.totalEmpresas !== 'number') {
      throw new Error(`Métricas inválidas: ${JSON.stringify(res.body)}`);
    }
  });

  // 5. Clientes, Sócios, Obrigações, Tarefas
  await test('GET /api/clientes, /api/socios, /api/obrigacoes, /api/tarefas', async () => {
    const [c, s, o, t] = await Promise.all([
      request(`/api/clientes?empresaId=${empresaId}`),
      request(`/api/socios?empresaId=${empresaId}`),
      request(`/api/obrigacoes?empresaId=${empresaId}`),
      request(`/api/tarefas?empresaId=${empresaId}`),
    ]);
    if (c.status !== 200 || s.status !== 200 || o.status !== 200 || t.status !== 200) {
      throw new Error(`Status incorreto: c=${c.status}, s=${s.status}, o=${o.status}, t=${t.status}`);
    }
  });

  // 6. Financeiro Contas a Pagar e Receber
  await test('GET /api/financeiro/contas-pagar & receber', async () => {
    const [cp, cr] = await Promise.all([
      request(`/api/financeiro/contas-pagar?empresaId=${empresaId}`),
      request(`/api/financeiro/contas-receber?empresaId=${empresaId}`),
    ]);
    if (cp.status !== 200 || cr.status !== 200) {
      throw new Error(`Falha financeiro: cp=${cp.status}, cr=${cr.status}`);
    }
  });

  // 7. Notas Fiscais Emitidas
  await test('GET & POST /api/notas-fiscais', async () => {
    const getRes = await request(`/api/notas-fiscais?empresaId=${empresaId}`);
    if (getRes.status !== 200 || !Array.isArray(getRes.body)) {
      throw new Error(`Falha get notas fiscais: ${getRes.status}`);
    }
  });

  // 8. SEFAZ DF-e: Entradas contra CNPJ
  await test('GET /api/notas-fiscais-entrada', async () => {
    const res = await request(`/api/notas-fiscais-entrada?empresaId=${empresaId}`);
    if (res.status !== 200 || !Array.isArray(res.body)) {
      throw new Error(`Falha ao obter notas de entrada: ${res.status}`);
    }
  });

  // 9. SEFAZ DF-e: Captura por Chave (fsist style)
  let notaCapturadaId = '';
  await test('POST /api/notas-fiscais-entrada/capturar-chave', async () => {
    const chaveTeste = '35260911222333000199550010000889911987654321';
    const res = await request(
      '/api/notas-fiscais-entrada/capturar-chave',
      { method: 'POST' },
      { empresaId, chaveAcesso: chaveTeste, efetuarCiencia: true }
    );
    if (res.status !== 201 || !res.body.id || !res.body.chaveAcesso) {
      throw new Error(`Falha ao capturar nota por chave: ${res.status}, body: ${JSON.stringify(res.body)}`);
    }
    notaCapturadaId = res.body.id;
  });

  // 10. Manifestação do Destinatário
  await test('POST /api/notas-fiscais-entrada/:id/manifestar', async () => {
    if (!notaCapturadaId) throw new Error('Sem ID de nota capturada');
    const res = await request(
      `/api/notas-fiscais-entrada/${notaCapturadaId}/manifestar`,
      { method: 'POST' },
      { manifestacao: 'confirmada' }
    );
    if (res.status !== 200 || res.body.manifestacao !== 'confirmada') {
      throw new Error(`Falha ao manifestar: ${res.status}, body: ${JSON.stringify(res.body)}`);
    }
  });

  // 11. Sincronização em Lote SEFAZ DF-e
  await test('POST /api/notas-fiscais-entrada/sincronizar-sefaz', async () => {
    const res = await request(
      '/api/notas-fiscais-entrada/sincronizar-sefaz',
      { method: 'POST' },
      { empresaId }
    );
    if (res.status !== 200 || !Array.isArray(res.body.novasNotas)) {
      throw new Error(`Falha ao sincronizar SEFAZ: ${res.status}, body: ${JSON.stringify(res.body)}`);
    }
  });

  // 12. Certificados Digitais
  await test('GET /api/certificados', async () => {
    const res = await request(`/api/certificados?empresaId=${empresaId}`);
    if (res.status !== 200 || !Array.isArray(res.body)) {
      throw new Error(`Falha ao obter certificados: ${res.status}`);
    }
  });

  // 13. e-CAC Pendências
  await test('GET /api/ecac/pendencias', async () => {
    const res = await request(`/api/ecac/pendencias?empresaId=${empresaId}`);
    if (res.status !== 200 || !Array.isArray(res.body)) {
      throw new Error(`Falha ao obter pendências e-CAC: ${res.status}`);
    }
  });

  // 14. Alvarás e Licenças
  await test('GET /api/alvaras', async () => {
    const res = await request(`/api/alvaras?empresaId=${empresaId}`);
    if (res.status !== 200 || !Array.isArray(res.body)) {
      throw new Error(`Falha ao obter alvarás: ${res.status}`);
    }
  });

  // 15. RH: Funções e Funcionários
  let funcionarioId = '';
  await test('GET /api/funcoes e /api/funcionarios', async () => {
    const [f, funcs] = await Promise.all([
      request(`/api/funcoes?empresaId=${empresaId}`),
      request(`/api/funcionarios?empresaId=${empresaId}`),
    ]);
    if (f.status !== 200 || funcs.status !== 200) {
      throw new Error(`Falha ao obter funcoes ou funcionarios`);
    }
    if (funcs.body.length > 0) {
      funcionarioId = funcs.body[0].id;
    }
  });

  // 16. RH: Ponto Eletrônico
  await test('GET /api/pontos & /api/pontos/hoje', async () => {
    const [pts, hoje] = await Promise.all([
      request(`/api/pontos?empresaId=${empresaId}`),
      request(`/api/pontos/hoje?empresaId=${empresaId}`),
    ]);
    if (pts.status !== 200 || hoje.status !== 200) {
      throw new Error(`Falha ponto: pts=${pts.status}, hoje=${hoje.status}`);
    }
  });

  // 17. RH: Férias e Painel de Avisos
  await test('GET /api/ferias & /api/ferias/painel-avisos', async () => {
    const [ferias, painel] = await Promise.all([
      request(`/api/ferias?empresaId=${empresaId}`),
      request(`/api/ferias/painel-avisos?empresaId=${empresaId}`),
    ]);
    if (ferias.status !== 200 || painel.status !== 200) {
      throw new Error(`Falha ferias: ferias=${ferias.status}, painel=${painel.status}`);
    }
  });

  // 18. RH: Rescisão Contratual Cálculo
  await test('POST /api/rh/rescisoes/calcular', async () => {
    if (!funcionarioId) throw new Error('Sem colaborador para teste de rescisão');
    const res = await request(
      '/api/rh/rescisoes/calcular',
      { method: 'POST' },
      {
        funcionarioId,
        motivoDesligamento: 'sem_justa_causa',
        tipoAvisoPrevio: 'indenizado',
        dataAvisoPrevio: '2026-09-01',
        dataDesligamento: '2026-09-30',
        diasSaldoSalario: 30,
        motivoDetalhado: 'Reestruturação',
      }
    );
    if (res.status !== 200 || !res.body.calculo || typeof res.body.calculo.totalLiquidoRescisao !== 'number') {
      throw new Error(`Falha calculo rescisao: ${res.status}, body: ${JSON.stringify(res.body)}`);
    }
  });

  // 19. eSocial: Configuração & Validação Periódicos S-1200 / S-1210
  await test('POST /api/esocial/validar-periodicos', async () => {
    const res = await request(
      '/api/esocial/validar-periodicos',
      { method: 'POST' },
      { empresaId, competencia: '09/2026' }
    );
    if (res.status !== 200 || typeof res.body.totalErros !== 'number' || !Array.isArray(res.body.eventos)) {
      throw new Error(`Falha validacao periodicos eSocial: ${res.status}`);
    }
  });

  // 20. Database Admin Stats
  await test('GET /api/database/stats', async () => {
    const res = await request('/api/database/stats');
    if (res.status !== 200 || typeof res.body.totalRecords !== 'number') {
      throw new Error(`Falha stats database: ${res.status}, body: ${JSON.stringify(res.body)}`);
    }
  });

  console.log(`\n--- RESULTADO FINAL: ${successes} SUCESSOS, ${failures} FALHAS ---`);
  if (failedTests.length > 0) {
    console.log('Falhas detalhadas:', failedTests);
  }
  if (failures > 0) {
    process.exit(1);
  }
}

runTests().catch((err) => {
  console.error('Erro fatal durante execução dos testes:', err);
  process.exit(1);
});
