import {
  calcularInssProgressivo,
  calcularIrrf,
  calcularFolhaCompleta,
} from '../src/utils/payrollCalculator.js';

import {
  calcularRescisaoCompleta,
  gerarDocumentoTRCTOficial,
} from '../src/utils/rescisaoCalculator.js';

import {
  calcularComparativoTributario,
} from '../src/utils/tributarioCalculator.js';

import {
  validarDadosColaboradorESocial,
  validarParametrosFechamentoFolha,
  gerarXmlEventoESocial,
} from '../src/utils/esocialXmlGenerator.js';

import {
  gerarDanfeEntradaPdf,
  gerarXmlDanfeEntrada,
} from '../src/utils/danfePdfGenerator.js';

async function runCalculatorTests() {
  console.log('--- TESTANDO MOTORES DE CÁLCULO E GERADORES ---');
  let failures = 0;
  let successes = 0;

  function assert(condition: boolean, msg: string) {
    if (!condition) throw new Error(msg);
  }

  function test(name: string, fn: () => void) {
    try {
      fn();
      console.log(`[PASS] ${name}`);
      successes++;
    } catch (err: any) {
      console.error(`[FAIL] ${name}: ${err.message}`);
      failures++;
    }
  }

  // 1. Payroll calculations
  test('Payroll: INSS faixas progressivas 2026', () => {
    const inss1 = calcularInssProgressivo(1412.00); // 1 salário mínimo
    assert(inss1.aliquotaEfetiva > 0 && inss1.valorTotal > 0, 'INSS salário mínimo inválido');

    const inss2 = calcularInssProgressivo(5000.00);
    assert(inss2.valorTotal > inss1.valorTotal, 'INSS deve ser progressivo');

    const inssTeto = calcularInssProgressivo(12000.00);
    assert(inssTeto.valorTotal <= 910, 'INSS não pode ultrapassar o teto legal');
  });

  test('Payroll: IRRF com dedução simplificada vs deduções legais', () => {
    const irrf1 = calcularIrrf(2500, 200, 0, 0);
    assert(irrf1.valorImposto >= 0, 'IRRF não pode ser negativo');

    const irrfAlto = calcularIrrf(15000, 908, 2, 0);
    assert(irrfAlto.valorImposto > 1000, 'IRRF de salário alto incorreto');
  });

  test('Payroll: Folha Completa com FGTS e Encargos', () => {
    const folha = calcularFolhaCompleta({
      salarioBase: 5000,
      horasExtras50Horas: 10,
      valeTransporteOptante: true,
      valeTransporteCustoReal: 300,
      dependentesIrrf: 1,
    });
    assert(folha.valorFgts > 0, 'FGTS deve ser calculado');
    assert(folha.salarioLiquido > 0, 'Salário líquido deve ser positivo');
    assert(folha.totalProventos > 5000, 'Total de proventos com horas extras deve ser > 5000');
    assert(folha.encargosEmpresa.custoTotalColaborador > folha.totalProventos, 'Custo total empresa deve incluir encargos');
  });

  // 2. Rescisão Calculator
  test('Rescisao: Demissão sem justa causa com aviso indenizado', () => {
    const funcionarioFake: any = {
      id: 'func_test_1',
      empresaId: 'emp_1',
      nomeCompleto: 'Carlos Eduardo Teste',
      cpf: '123.456.789-00',
      dataAdmissao: '2023-01-10',
      salarioBase: 6000,
      adicionaisTotal: 0,
      dependentes: [{ deducaoIrrf: true }],
    };

    const resultado = calcularRescisaoCompleta({
      funcionario: funcionarioFake,
      motivoRescisao: 'sem_justa_causa',
      tipoAvisoPrevio: 'indenizado',
      dataDesligamento: '2026-09-30',
      dataAvisoPrevio: '2026-09-01',
      diasSaldoSalarioManual: 30,
      saldoFgtsInformado: 20000,
    });

    assert(resultado.proventos.totalBruto > 6000, 'Proventos rescisão sem justa causa insuficientes');
    assert(resultado.descontos.totalDescontos >= 0, 'Descontos inválidos');
    assert(resultado.totalLiquidoRescisao > 0, 'Líquido rescisão inválido');
    assert(resultado.fgts.aliquotaMultaFgts === 40, 'Alíquota multa FGTS deve ser 40%');
    assert(resultado.fgts.valorMultaRescisoriaFgts > 8000, `Multa rescisória FGTS 40% esperada > 8000, obtido ${resultado.fgts.valorMultaRescisoriaFgts}`);
    assert(resultado.diasAvisoLei12506 >= 39, 'Aviso prévio proporcional pela Lei 12.506 deve ser >= 39 dias');
  });

  test('Rescisao: Demissão com justa causa (sem aviso, sem 40%, sem 13º/férias prop)', () => {
    const funcionarioFake: any = {
      id: 'func_test_2',
      empresaId: 'emp_1',
      nomeCompleto: 'Ana Paula Justa Causa',
      cpf: '987.654.321-00',
      dataAdmissao: '2024-05-01',
      salarioBase: 4000,
      adicionaisTotal: 0,
      dependentes: [],
    };

    const resultado = calcularRescisaoCompleta({
      funcionario: funcionarioFake,
      motivoRescisao: 'justa_causa',
      tipoAvisoPrevio: 'dispensado',
      dataDesligamento: '2026-09-15',
      dataAvisoPrevio: '2026-09-15',
      diasSaldoSalarioManual: 15,
      saldoFgtsInformado: 5000,
    });

    assert(resultado.proventos.avisoPrevioIndenizado === 0, 'Não deve haver aviso prévio');
    assert(resultado.fgts.valorMultaRescisoriaFgts === 0, 'Não deve haver multa 40%');
    assert(resultado.proventos.decimoTerceiroProporcional === 0, 'Não deve haver 13º proporcional');
    assert(resultado.totalLiquidoRescisao > 0, 'Deve ter saldo de salário líquido');
  });

  // 3. Tributario Calculator
  test('Tributário: Comparativo Simples vs Lucro Presumido vs Lucro Real', () => {
    const resultado = calcularComparativoTributario({
      id: 'sim_teste',
      nomeEmpresa: 'Empresa Teste',
      atividade: 'comercio',
      anoAnalise: 2026,
      faturamentoAnual: 1800000,
      folhaAnual: 360000,
      proLaboreAnual: 60000,
      percentualVendasB2B: 60,
      comprasInsumosAnual: 900000,
      despesasOperacionaisAnual: 180000,
      margemLucroEstimada: 12,
      aliquotaIssMunicipal: 5,
      aliquotaIcmsInterno: 18,
      aliquotaRatFap: 2,
      aliquotaTerceiros: 5.8,
    });
    const cenarios = resultado.cenarios;

    assert(Array.isArray(cenarios) && cenarios.length === 4, 'Deve conter os 4 regimes tributários');
    const melhor = cenarios.find((c) => c.isMelhorOpcao);
    assert(!!melhor, 'Deve identificar o regime mais econômico');
    assert(cenarios.every((c) => c.tributos.totalTributosAnual > 0), 'Total de tributos deve ser positivo');
  });

  // 4. eSocial XML Generator
  test('eSocial: Validação e geração de XMLs S-1200 e S-1210', () => {
    const configFake: any = {
      empresaId: 'emp_1',
      ambiente: 'producao',
      versaoManual: 'S-1.2',
      classificacaoTributaria: '01',
      tipoInscricao: 'CNPJ',
      numeroInscricao: '12.345.678/0001-90',
      razaoSocial: 'Inovatech Ltda',
      aliquotaRatAjustada: 1.0,
      aliquotaTerceiros: 0.0,
      codigoTerceirosOutrasEntidades: '0000',
    };

    const funcFake: any = {
      id: 'func_1',
      nomeCompleto: 'João da Silva',
      cpf: '123.456.789-00',
      matricula: 'MAT-001',
      dataNascimento: '1990-01-01',
      pisPasep: '123.45678.90-1',
      cbo: '4110-10',
      tipoContrato: 'CLT Indeterminado',
      salarioBase: 3500,
      status: 'ativo',
    };

    const holeriteFake: any = {
      competencia: '09/2026',
      totalVencimentos: 3500,
      totalDescontos: 320,
      valorLiquido: 3180,
      baseInss: 3500,
      inss: 320,
      baseFgts: 3500,
      fgtsMes: 280,
      baseIrrf: 3180,
      irrf: 0,
      itens: [
        { codigo: '1000', descricao: 'Salário Base', tipo: 'provento', valor: 3500, referencia: '30d' },
        { codigo: '9001', descricao: 'INSS', tipo: 'desconto', valor: 320, referencia: '9.14%' },
      ],
    };

    const erros = validarDadosColaboradorESocial(funcFake, configFake);
    assert(Array.isArray(erros), 'Validação eSocial deve retornar array de inconsistências');

    const xml1200 = gerarXmlEventoESocial('S-1200', {
      config: configFake,
      competencia: '09/2026',
      funcionario: funcFake,
      holerite: holeriteFake,
    });
    assert(xml1200.includes('<evtRemun') && xml1200.includes('12345678900'), 'XML S-1200 deve conter tag evtRemun e CPF limpo');

    const xml1210 = gerarXmlEventoESocial('S-1210', {
      config: configFake,
      competencia: '09/2026',
      funcionario: funcFake,
      holerite: holeriteFake,
    });
    assert(xml1210.includes('<evtPgtos') && xml1210.includes('3180.00'), 'XML S-1210 deve conter tag evtPgtos e valor líquido formatado');
  });

  // 5. DANFE & XML NFe Simulado
  test('DANFE: Geração de XML e PDF', () => {
    const notaFake: any = {
      id: 'nfe_1',
      numero: 1045,
      serie: '1',
      modelo: '55',
      chaveAcesso: '35260912345678000190550010000010451987654321',
      dataEmissao: '2026-09-10T14:30:00Z',
      fornecedorNome: 'Distribuidora Global Ltda',
      fornecedorCnpj: '98.765.432/0001-11',
      fornecedorIe: '123456789',
      fornecedorUf: 'SP',
      fornecedorMunicipio: 'São Paulo',
      destinatarioNome: 'Inovatech Comércio Ltda',
      destinatarioCnpj: '12.345.678/0001-90',
      naturezaOperacao: 'Venda de mercadorias',
      cfopPrincipal: '5.102',
      valorProdutos: 1500,
      valorTotal: 1500,
      impostos: { icms: 180, pis: 9.75, cofins: 45 },
      itens: [
        {
          codigo: 'IT-01',
          descricao: 'Teclado Mecânico USB',
          ncm: '84716052',
          quantidade: 10,
          valorUnitario: 150,
          valorTotal: 1500,
        },
      ],
      statusSefaz: 'autorizada',
      manifestacao: 'confirmada',
      statusEscrituracao: 'pendente',
      xmlCompletoDisponivel: true,
      isDemo: true,
    };

    const xml = gerarXmlDanfeEntrada(notaFake);
    assert(xml.includes('<NFe') && xml.includes('35260912345678000190550010000010451987654321'), 'XML NF-e gerado deve ser válido');

    const pdfDoc = gerarDanfeEntradaPdf(notaFake, { autoDownload: false });
    assert(pdfDoc !== null && typeof pdfDoc.output === 'function', 'jsPDF doc deve ser instanciado');
  });

  console.log(`\n--- RESULTADO DOS MOTORES: ${successes} SUCESSOS, ${failures} FALHAS ---`);
  if (failures > 0) process.exit(1);
}

runCalculatorTests().catch((err) => {
  console.error('Erro nos testes de motores de cálculo:', err);
  process.exit(1);
});
